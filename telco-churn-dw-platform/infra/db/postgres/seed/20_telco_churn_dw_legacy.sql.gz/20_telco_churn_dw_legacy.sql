--
-- PostgreSQL database dump
--

\restrict FvZs1MufrmTwq7L7GmWXNgOCaO1EbuDmddi7L8F4SKZ2sLYhY90B3wZh0xbDVbN

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET search_path = legacy, pg_catalog;
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--




--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

CREATE SCHEMA IF NOT EXISTS legacy;
COMMENT ON SCHEMA legacy IS 'Original telco_churn_dw star schema, migrated as-is from the pre-platform build (build_churn_project_pg.py)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dim_churn; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE legacy.dim_churn (
    churn_key integer NOT NULL,
    churn_label character varying(3) NOT NULL,
    churn_flag smallint NOT NULL
);


--
-- Name: dim_churn_churn_key_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE legacy.dim_churn_churn_key_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dim_churn_churn_key_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE legacy.dim_churn_churn_key_seq OWNED BY legacy.dim_churn.churn_key;


--
-- Name: dim_contract; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE legacy.dim_contract (
    contract_key integer NOT NULL,
    contract_type character varying(20) NOT NULL,
    paperless_billing character varying(3) NOT NULL
);


--
-- Name: dim_contract_contract_key_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE legacy.dim_contract_contract_key_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dim_contract_contract_key_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE legacy.dim_contract_contract_key_seq OWNED BY legacy.dim_contract.contract_key;


--
-- Name: dim_customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE legacy.dim_customer (
    customer_key integer NOT NULL,
    customer_id character varying(20) NOT NULL,
    gender character varying(10) NOT NULL,
    senior_citizen smallint NOT NULL,
    partner character varying(3) NOT NULL,
    dependents character varying(3) NOT NULL
);


--
-- Name: dim_customer_customer_key_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE legacy.dim_customer_customer_key_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dim_customer_customer_key_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE legacy.dim_customer_customer_key_seq OWNED BY legacy.dim_customer.customer_key;


--
-- Name: dim_payment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE legacy.dim_payment (
    payment_key integer NOT NULL,
    payment_method character varying(30) NOT NULL
);


--
-- Name: dim_payment_payment_key_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE legacy.dim_payment_payment_key_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dim_payment_payment_key_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE legacy.dim_payment_payment_key_seq OWNED BY legacy.dim_payment.payment_key;


--
-- Name: dim_service; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE legacy.dim_service (
    service_key integer NOT NULL,
    phone_service character varying(3) NOT NULL,
    multiple_lines character varying(20) NOT NULL,
    internet_service character varying(20) NOT NULL,
    online_security character varying(25) NOT NULL,
    online_backup character varying(25) NOT NULL,
    device_protection character varying(25) NOT NULL,
    tech_support character varying(25) NOT NULL,
    streaming_tv character varying(25) NOT NULL,
    streaming_movies character varying(25) NOT NULL
);


--
-- Name: dim_service_service_key_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE legacy.dim_service_service_key_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dim_service_service_key_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE legacy.dim_service_service_key_seq OWNED BY legacy.dim_service.service_key;


--
-- Name: fact_customer_churn; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE legacy.fact_customer_churn (
    fact_key integer NOT NULL,
    customer_key integer NOT NULL,
    contract_key integer NOT NULL,
    service_key integer NOT NULL,
    payment_key integer NOT NULL,
    churn_key integer NOT NULL,
    tenure integer NOT NULL,
    monthly_charges numeric(10,2) NOT NULL,
    total_charges numeric(10,2)
);


--
-- Name: fact_customer_churn_fact_key_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE legacy.fact_customer_churn_fact_key_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fact_customer_churn_fact_key_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE legacy.fact_customer_churn_fact_key_seq OWNED BY legacy.fact_customer_churn.fact_key;


--
-- Name: dim_churn churn_key; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY legacy.dim_churn ALTER COLUMN churn_key SET DEFAULT nextval('legacy.dim_churn_churn_key_seq'::regclass);


--
-- Name: dim_contract contract_key; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY legacy.dim_contract ALTER COLUMN contract_key SET DEFAULT nextval('legacy.dim_contract_contract_key_seq'::regclass);


--
-- Name: dim_customer customer_key; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY legacy.dim_customer ALTER COLUMN customer_key SET DEFAULT nextval('legacy.dim_customer_customer_key_seq'::regclass);


--
-- Name: dim_payment payment_key; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY legacy.dim_payment ALTER COLUMN payment_key SET DEFAULT nextval('legacy.dim_payment_payment_key_seq'::regclass);


--
-- Name: dim_service service_key; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY legacy.dim_service ALTER COLUMN service_key SET DEFAULT nextval('legacy.dim_service_service_key_seq'::regclass);


--
-- Name: fact_customer_churn fact_key; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY legacy.fact_customer_churn ALTER COLUMN fact_key SET DEFAULT nextval('legacy.fact_customer_churn_fact_key_seq'::regclass);


--
-- Data for Name: dim_churn; Type: TABLE DATA; Schema: public; Owner: -
--

COPY legacy.dim_churn (churn_key, churn_label, churn_flag) FROM stdin;
1	No	0
2	Yes	1
\.


--
-- Data for Name: dim_contract; Type: TABLE DATA; Schema: public; Owner: -
--

COPY legacy.dim_contract (contract_key, contract_type, paperless_billing) FROM stdin;
1	Month-to-month	No
2	Month-to-month	Yes
3	One year	No
4	One year	Yes
5	Two year	No
6	Two year	Yes
\.


--
-- Data for Name: dim_customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY legacy.dim_customer (customer_key, customer_id, gender, senior_citizen, partner, dependents) FROM stdin;
1	7590-VHVEG	Female	0	Yes	No
2	5575-GNVDE	Male	0	No	No
3	3668-QPYBK	Male	0	No	No
4	7795-CFOCW	Male	0	No	No
5	9237-HQITU	Female	0	No	No
6	9305-CDSKC	Female	0	No	No
7	1452-KIOVK	Male	0	No	Yes
8	6713-OKOMC	Female	0	No	No
9	7892-POOKP	Female	0	Yes	No
10	6388-TABGU	Male	0	No	Yes
11	9763-GRSKD	Male	0	Yes	Yes
12	7469-LKBCI	Male	0	No	No
13	8091-TTVAX	Male	0	Yes	No
14	0280-XJGEX	Male	0	No	No
15	5129-JLPIS	Male	0	No	No
16	3655-SNQYZ	Female	0	Yes	Yes
17	8191-XWSZG	Female	0	No	No
18	9959-WOFKT	Male	0	No	Yes
19	4190-MFLUW	Female	0	Yes	Yes
20	4183-MYFRB	Female	0	No	No
21	8779-QRDMV	Male	1	No	No
22	1680-VDCWW	Male	0	Yes	No
23	1066-JKSGK	Male	0	No	No
24	3638-WEABW	Female	0	Yes	No
25	6322-HRPFA	Male	0	Yes	Yes
26	6865-JZNKO	Female	0	No	No
27	6467-CHFZW	Male	0	Yes	Yes
28	8665-UTDHZ	Male	0	Yes	Yes
29	5248-YGIJN	Male	0	Yes	No
30	8773-HHUOZ	Female	0	No	Yes
31	3841-NFECX	Female	1	Yes	No
32	4929-XIHVW	Male	1	Yes	No
33	6827-IEAUQ	Female	0	Yes	Yes
34	7310-EGVHZ	Male	0	No	No
35	3413-BMNZE	Male	1	No	No
36	6234-RAAPL	Female	0	Yes	Yes
37	6047-YHPVI	Male	0	No	No
38	6572-ADKRS	Female	0	No	No
39	5380-WJKOV	Male	0	No	No
40	8168-UQWWF	Female	0	No	No
41	8865-TNMNX	Male	0	Yes	Yes
42	9489-DEDVP	Female	0	Yes	Yes
43	9867-JCZSP	Female	0	Yes	Yes
44	4671-VJLCL	Female	0	No	No
45	4080-IIARD	Female	0	Yes	No
46	3714-NTNFO	Female	0	No	No
47	5948-UJZLF	Male	0	No	No
48	7760-OYPDY	Female	0	No	No
49	7639-LIAYI	Male	0	No	No
50	2954-PIBKO	Female	0	Yes	Yes
51	8012-SOUDQ	Female	1	No	No
52	9420-LOJKX	Female	0	No	No
53	6575-SUVOI	Female	1	Yes	No
54	7495-OOKFY	Female	1	Yes	No
55	4667-QONEA	Female	1	Yes	Yes
56	1658-BYGOY	Male	1	No	No
57	8769-KKTPH	Female	0	Yes	Yes
58	5067-XJQFU	Male	1	Yes	Yes
59	3957-SQXML	Female	0	Yes	Yes
60	5954-BDFSG	Female	0	No	No
61	0434-CSFON	Female	0	Yes	No
62	1215-FIGMP	Male	0	No	No
63	0526-SXDJP	Male	0	Yes	No
64	0557-ASKVU	Female	0	Yes	Yes
65	5698-BQJOH	Female	0	No	No
66	5122-CYFXA	Female	0	No	No
67	8627-ZYGSZ	Male	0	Yes	No
68	3410-YOQBQ	Female	0	No	No
69	3170-NMYVV	Female	0	Yes	Yes
70	7410-OIEDU	Male	0	No	No
71	2273-QCKXA	Male	0	No	No
72	0731-EBJQB	Female	0	Yes	Yes
73	1891-QRQSA	Male	1	Yes	Yes
74	8028-PNXHQ	Male	0	Yes	Yes
75	5630-AHZIL	Female	0	No	Yes
76	2673-CXQEU	Female	1	No	No
77	6416-JNVRK	Female	0	No	No
78	5590-ZSKRV	Female	0	Yes	Yes
79	0191-ZHSKZ	Male	1	No	No
80	3887-PBQAO	Female	0	Yes	Yes
81	5919-TMRGD	Female	0	No	Yes
82	8108-UXRQN	Female	0	Yes	Yes
83	9191-MYQKX	Female	0	Yes	No
84	9919-YLNNG	Female	0	No	No
85	0318-ZOPWS	Female	0	Yes	No
86	4445-ZJNMU	Male	0	No	No
87	4808-YNLEU	Female	0	Yes	No
88	1862-QRWPE	Female	0	Yes	Yes
89	2796-NNUFI	Female	0	Yes	Yes
90	3016-KSVCP	Male	0	Yes	No
91	4767-HZZHQ	Male	0	Yes	Yes
92	2424-WVHPL	Male	1	No	No
93	7233-PAHHL	Male	0	Yes	Yes
94	6067-NGCEU	Female	0	No	No
95	9848-JQJTX	Male	0	No	No
96	8637-XJIVR	Female	0	No	No
97	9803-FTJCG	Male	0	Yes	Yes
98	0278-YXOOG	Male	0	No	No
99	3212-KXOCR	Male	0	No	No
100	4598-XLKNJ	Female	1	Yes	No
101	6380-ARCEH	Male	0	No	No
102	3679-XASPY	Female	0	Yes	Yes
103	7123-WQUHX	Male	0	No	No
104	5386-THSLQ	Female	1	Yes	No
105	3192-NQECA	Male	0	Yes	No
106	6180-YBIQI	Male	0	No	No
107	6728-DKUCO	Female	0	Yes	Yes
108	9750-BOOHV	Female	0	No	No
109	8597-CWYHH	Male	0	No	No
110	2848-YXSMW	Male	0	Yes	Yes
111	0486-HECZI	Male	0	Yes	No
112	4549-ZDQYY	Female	0	No	No
113	5712-AHQNN	Female	0	No	No
114	4846-WHAFZ	Female	1	Yes	No
115	5256-SKJGO	Female	0	Yes	Yes
116	3071-VBYPO	Male	0	Yes	Yes
117	9560-BBZXK	Female	0	No	No
118	5299-RULOA	Female	0	Yes	Yes
119	8402-OOOHJ	Female	0	No	No
120	9445-ZUEQE	Male	0	Yes	Yes
121	1091-SOZGA	Female	0	Yes	Yes
122	2928-HLDBA	Female	0	No	No
123	0404-SWRVG	Male	0	No	No
124	6497-TILVL	Female	0	Yes	Yes
125	7219-TLZHO	Female	0	Yes	Yes
126	4622-YNKIJ	Male	0	No	No
127	4412-YLTKF	Female	1	No	No
128	6734-PSBAW	Male	0	Yes	No
129	3930-ZGWVE	Male	0	No	No
130	2639-UGMAZ	Male	1	No	No
131	2876-GZYZC	Female	0	No	No
132	6207-WIOLX	Female	0	Yes	Yes
133	8587-XYZSF	Male	0	No	No
134	3091-FYHKI	Male	0	No	No
135	2372-HWUHI	Male	0	No	No
136	7799-LGRDP	Female	0	No	No
137	7850-VWJUU	Female	0	No	No
138	3774-VBNXY	Female	0	Yes	Yes
139	6217-KDYWC	Male	0	No	Yes
140	0390-DCFDQ	Female	1	Yes	No
141	3146-MSEGF	Female	1	Yes	Yes
142	4080-OGPJL	Female	0	No	No
143	1095-WGNGG	Female	0	Yes	No
144	2636-SJDOU	Male	0	No	No
145	1131-QQZEB	Male	1	Yes	No
146	5716-EZXZN	Female	0	Yes	Yes
147	6837-BJYDQ	Male	0	No	No
148	2135-RXIHG	Male	0	No	No
149	6440-DKQGE	Male	0	No	Yes
150	3466-BYAVD	Male	0	Yes	Yes
151	3780-YVMFA	Female	0	Yes	Yes
152	3874-EQOEP	Male	0	No	No
153	1679-JRFBR	Female	0	Yes	Yes
154	9073-ZZIAY	Male	0	Yes	Yes
155	3077-RSNTJ	Female	0	Yes	Yes
156	6551-GNYDG	Female	0	Yes	Yes
157	9167-APMXZ	Female	0	No	No
158	2749-CTKAJ	Male	0	Yes	Yes
159	6371-NZYEG	Male	0	Yes	Yes
160	7554-NEWDD	Male	0	No	No
161	8992-VONJD	Female	0	No	Yes
162	0867-MKZVY	Female	0	Yes	No
163	4482-EWFMI	Female	0	No	No
164	4648-YPBTM	Male	0	No	No
165	2907-ILJBN	Female	0	Yes	Yes
166	6345-FZOQH	Male	0	Yes	No
167	3376-BMGFE	Female	0	No	No
168	5997-OPVFA	Male	0	Yes	No
169	3445-HXXGF	Male	1	Yes	No
170	1159-WFSGR	Female	0	Yes	Yes
171	7654-YWJUF	Male	0	Yes	No
172	1875-QIVME	Female	0	Yes	No
173	6727-IOTLZ	Male	0	Yes	No
174	0691-JVSYA	Female	0	Yes	No
175	5918-VUKWP	Female	0	No	No
176	1744-JHKYS	Female	0	Yes	No
177	2656-FMOKZ	Female	1	No	No
178	2070-FNEXE	Female	1	No	No
179	5947-SGKCL	Female	0	Yes	Yes
180	3712-PKXZA	Male	0	Yes	No
181	6317-YPKDH	Female	0	No	No
182	6582-OIVSP	Female	0	No	No
183	9367-WXLCH	Male	0	No	No
184	5524-KHNJP	Male	0	Yes	Yes
185	1918-ZBFQJ	Female	0	No	No
186	1024-GUALD	Female	0	Yes	No
187	4827-USJHP	Male	0	No	No
188	8167-GJLRN	Male	0	No	No
189	0956-SYCWG	Female	0	No	No
190	8017-UVSZU	Female	0	Yes	No
191	7100-FQPRV	Male	0	Yes	Yes
192	2472-OVKUP	Male	0	Yes	No
193	2984-RGEYA	Female	0	Yes	Yes
194	9680-NIAUV	Female	0	Yes	Yes
195	2146-EGVDT	Male	0	Yes	Yes
196	2604-IJPDU	Female	0	Yes	No
197	9178-JHUVJ	Male	0	Yes	Yes
198	6168-YBYNP	Male	0	No	No
199	7255-SSFBC	Male	0	Yes	Yes
200	3645-DEYGF	Male	0	No	Yes
201	9323-HGFWY	Female	0	Yes	No
202	8544-GOQSH	Female	0	No	No
203	3363-DTIVD	Male	0	Yes	Yes
204	7018-WBJNK	Male	0	No	Yes
205	9142-KZXOP	Male	0	No	No
206	7674-YTAFD	Female	0	No	No
207	6348-SNFUS	Male	0	Yes	Yes
208	1285-OKIPP	Male	0	No	No
209	7825-ECJRF	Female	0	No	No
210	1347-KTTTA	Male	0	Yes	No
211	7841-TZDMQ	Male	0	No	No
212	4195-NZGTA	Female	0	No	No
213	7157-SMCFK	Male	0	No	Yes
214	4709-LKHYG	Female	0	Yes	Yes
215	2504-DSHIH	Male	1	Yes	No
216	0699-NDKJM	Female	0	Yes	No
217	9286-BHDQG	Male	0	Yes	Yes
218	0230-WEQUW	Male	0	Yes	No
219	2040-LDIWQ	Male	0	Yes	Yes
220	6496-JDSSB	Female	0	No	No
221	9408-SSNVZ	Female	0	No	No
222	4443-EMBNA	Female	0	Yes	No
223	6469-MRVET	Male	0	Yes	Yes
224	0742-MOABM	Male	0	Yes	No
225	5961-VUSRV	Female	0	No	No
226	6778-JFCMK	Male	0	No	No
227	6341-JVQGF	Female	0	Yes	Yes
228	2232-DMLXU	Female	0	Yes	No
229	4811-JBUVU	Male	0	No	No
230	0945-TSONX	Female	0	Yes	Yes
231	2651-ZCBXV	Male	0	No	No
232	3316-UWXUY	Male	0	No	No
233	8937-RDTHP	Male	0	No	No
234	7083-MIOPC	Female	0	No	No
235	1984-GPTEH	Female	0	No	No
236	1251-KRREG	Male	0	No	No
237	0621-JFHOL	Female	0	No	No
238	9903-LYSAB	Male	0	Yes	No
239	0094-OIFMO	Female	1	No	No
240	9227-UAQFT	Male	0	No	No
241	7301-ABVAD	Female	0	No	No
242	6614-FHDBO	Male	0	No	No
243	7576-ASEJU	Female	0	Yes	Yes
244	9058-HRZSV	Female	1	Yes	No
245	4522-AKYLR	Female	1	No	No
246	0221-WMXNQ	Male	1	No	No
247	0303-UNCIP	Male	0	No	No
248	9947-OTFQU	Male	1	No	No
249	0322-YINQP	Male	0	No	No
250	0959-WHOKV	Male	0	No	No
251	4075-JFPGR	Female	0	Yes	No
252	4629-NRXKX	Female	0	Yes	Yes
253	9514-JDSKI	Male	1	Yes	No
254	3282-ZISZV	Male	0	No	Yes
255	3675-YDUPJ	Male	0	No	No
256	4111-BNXIF	Female	0	Yes	Yes
257	7017-VFHAY	Female	0	Yes	Yes
258	6655-LHBYW	Male	0	No	No
259	4959-JOSRX	Female	0	Yes	No
260	5046-NUHWD	Female	1	Yes	No
261	7273-TEFQD	Male	1	No	No
262	3606-TWKGI	Male	1	No	No
263	7529-ZDFXI	Male	1	Yes	No
264	7605-BDWDC	Female	0	No	No
265	1950-KSVVJ	Female	0	Yes	No
266	0123-CRBRT	Female	0	Yes	Yes
267	6292-TOSSS	Male	0	No	No
268	3197-ARFOY	Female	1	No	No
269	6323-AYBRX	Male	0	No	No
270	7014-ZZXAW	Female	0	Yes	No
271	4385-GZQXV	Female	1	No	No
272	7633-MVPUY	Male	0	Yes	No
273	6366-ZGQGL	Male	0	No	No
274	4716-HHKQH	Male	1	Yes	No
275	5940-AHUHD	Male	0	No	No
276	6432-TWQLB	Male	0	Yes	No
277	4484-GLZOU	Female	0	Yes	No
278	3179-GBRWV	Male	1	Yes	No
279	8645-KWHJO	Male	0	No	No
280	4130-MZLCC	Female	0	No	No
281	0314-TKOSI	Female	0	No	No
282	8229-MYEJZ	Female	0	No	No
283	2080-SRCDE	Female	0	No	Yes
284	9577-WJVCQ	Female	0	No	No
285	9512-UIBFX	Male	0	Yes	Yes
286	6202-DYYFX	Female	0	No	No
287	3808-HFKDE	Female	0	No	No
288	5583-SXDAG	Male	0	Yes	No
289	3488-PGMQJ	Male	1	No	No
290	3580-REOAC	Male	0	No	No
291	7534-BFESC	Male	1	No	No
292	3727-OWVYD	Male	0	No	No
293	2294-SALNE	Male	0	Yes	Yes
294	4847-TAJYI	Female	1	No	No
295	1563-IWQEX	Female	0	No	No
296	8203-XJZRC	Male	0	No	No
297	6556-DBKZF	Female	0	Yes	Yes
298	6851-WEFYX	Male	1	Yes	No
299	2985-JUUBZ	Male	0	Yes	Yes
300	6390-DSAZX	Female	0	No	Yes
301	0895-LMRSF	Male	0	No	No
302	8098-LLAZX	Female	1	No	No
303	8266-VBFQL	Male	0	No	No
304	8181-YHCMF	Female	0	Yes	Yes
305	2240-HSJQD	Male	0	No	Yes
306	1248-DYXUB	Male	0	Yes	Yes
307	0265-EDXBD	Male	1	Yes	No
308	4115-BNPJY	Male	0	Yes	Yes
309	3167-SNQPL	Male	1	Yes	Yes
310	4091-TVOCN	Male	0	No	Yes
311	1098-TDVUQ	Female	0	No	No
312	7277-OZCGZ	Female	0	No	No
313	1557-EMYVT	Female	0	No	No
314	2799-ARNLO	Female	1	Yes	No
315	7563-BIUPC	Male	0	No	No
316	5027-YOCXN	Male	0	Yes	Yes
317	3973-SKMLN	Male	0	No	No
318	2321-OMBXY	Female	0	Yes	Yes
319	2840-XANRC	Male	1	Yes	No
320	6745-JEFZB	Male	0	Yes	No
321	5020-ZSTTY	Female	1	No	No
322	9880-TDQAC	Female	0	Yes	Yes
323	8705-WZCYL	Male	0	No	No
324	7102-JJVTX	Female	0	Yes	Yes
325	8626-PTQGE	Male	0	No	No
326	4983-CLMLV	Female	0	Yes	No
327	5701-YVSVF	Female	1	Yes	No
328	5804-LEPIM	Female	1	No	No
329	5697-GOMBF	Female	1	Yes	Yes
330	2739-CACDQ	Female	1	No	No
331	9385-EHGDO	Female	0	Yes	Yes
332	9498-FIMXL	Female	0	No	No
333	2379-GYFLQ	Male	0	No	No
334	0122-OAHPZ	Female	0	No	No
335	2868-SNELZ	Female	0	No	No
336	4322-RCYMT	Male	0	Yes	Yes
337	6680-NENYN	Female	0	No	No
338	2088-IEBAU	Female	0	No	No
339	7982-VCELR	Female	0	No	No
340	1343-EHPYB	Male	0	Yes	No
341	6035-BXTTY	Female	1	No	No
342	6885-PKOAM	Female	0	Yes	No
343	7520-HQWJU	Female	0	Yes	Yes
344	9639-BUJXT	Male	0	No	No
345	5924-SNGKP	Female	0	No	Yes
346	0021-IKXGC	Female	1	No	No
347	2034-GDRCN	Female	0	No	No
348	8966-SNIZF	Female	0	Yes	No
349	6243-OZGFH	Female	0	No	No
350	4654-DLAMQ	Female	1	Yes	No
351	0513-RBGPE	Male	0	Yes	Yes
352	5160-UXJED	Male	0	No	Yes
353	4115-NZRKS	Female	1	No	No
354	0219-YTZUE	Male	0	Yes	Yes
355	0623-IIHUG	Female	1	No	No
356	4572-DVCGN	Female	0	No	No
357	3351-NGXYI	Female	1	No	No
358	8984-EYLLL	Male	0	Yes	No
359	9057-MSWCO	Male	1	Yes	No
360	9833-TGFHX	Male	0	Yes	Yes
361	9294-TDIPC	Male	0	No	Yes
362	5229-DTFYB	Female	0	No	No
363	0104-PPXDV	Male	0	Yes	No
364	5176-LMJXE	Female	0	No	No
365	3583-KRKMD	Male	0	No	No
366	1010-DIAUQ	Male	0	No	No
367	9069-LGEUL	Male	0	Yes	No
368	7302-ZHMHP	Female	0	No	No
369	9571-EDEBV	Male	0	Yes	No
370	3520-FJGCV	Male	0	Yes	Yes
371	6563-VRERX	Male	0	Yes	Yes
372	0259-GBZSH	Male	0	No	No
373	6122-EFVKN	Male	0	No	Yes
374	2805-EDJPQ	Female	0	Yes	Yes
375	6862-CQUMB	Male	0	No	No
376	7156-MXBJE	Female	0	No	No
377	6158-HDPXZ	Male	0	No	No
378	9601-BRXPO	Female	0	Yes	No
379	2863-IMQDR	Female	0	No	No
380	5686-CMAWK	Male	0	No	No
381	5651-CRHKQ	Female	0	Yes	No
382	6905-NIQIN	Male	0	No	No
383	8204-YJCLA	Male	1	Yes	Yes
384	5167-ZFFMM	Male	0	No	No
385	6583-SZVGP	Male	0	No	No
386	4895-TMWIR	Male	1	Yes	No
387	0533-BNWKF	Female	1	Yes	No
388	1708-PBBOA	Female	0	No	No
389	8782-LKFPK	Male	0	No	No
390	5522-JBWMO	Male	0	No	Yes
391	3597-MVHJT	Female	0	No	No
392	9774-NRNAU	Male	1	Yes	No
393	0224-RLWWD	Female	1	No	No
394	9967-ATRFS	Female	0	No	No
395	3951-NJCVI	Female	1	Yes	No
396	2977-CEBSX	Female	0	No	No
397	0177-PXBAT	Male	1	Yes	No
398	6599-CEBNN	Female	0	No	No
399	2519-ERQOJ	Male	1	No	No
400	5876-QMYLD	Female	0	Yes	Yes
401	2277-AXSDC	Female	0	No	No
402	9442-JTWDL	Female	0	No	No
403	0979-PHULV	Male	0	Yes	Yes
404	3067-SVMTC	Female	0	Yes	No
405	5495-GPSRW	Male	0	No	No
406	7606-BPHHN	Male	0	No	No
407	4742-DRORA	Male	0	Yes	Yes
408	0111-KLBQG	Male	1	Yes	Yes
409	4800-VHZKI	Female	0	No	No
410	7989-CHGTL	Male	0	No	No
411	0334-GDDSO	Male	1	No	No
412	4163-NCJAK	Female	0	Yes	No
413	5233-AOZUF	Female	0	Yes	No
414	5973-EJGDP	Male	0	No	No
415	1996-DBMUS	Female	1	Yes	No
416	7916-VCCPB	Female	0	Yes	Yes
417	4686-GEFRM	Male	0	Yes	No
418	5249-QYHEX	Female	0	Yes	Yes
419	0578-SKVMF	Female	0	Yes	Yes
420	5564-NEMQO	Female	1	No	No
421	2233-FAGXV	Female	0	Yes	Yes
422	5605-IYGFG	Female	0	No	No
423	7663-ZTEGJ	Male	0	No	Yes
424	3935-TBRZZ	Male	0	Yes	Yes
425	8111-BKVDS	Female	0	No	No
426	2055-SIFSS	Female	1	Yes	No
427	2806-MLNTI	Male	1	Yes	No
428	8734-DKSTZ	Female	0	Yes	Yes
429	4360-PNRQB	Male	0	No	No
430	6152-ONASV	Female	0	Yes	No
431	9063-ZGTUY	Female	0	Yes	Yes
432	7781-HVGMK	Female	0	Yes	Yes
433	2181-UAESM	Male	0	No	No
434	2957-LOLHO	Male	0	No	No
435	6048-NJXHX	Male	0	Yes	No
436	2320-SLKMB	Female	0	No	No
437	4980-URKXC	Male	0	Yes	No
438	4376-KFVRS	Male	0	Yes	Yes
439	5886-VLQVU	Male	0	Yes	No
440	3577-AMVUX	Male	0	No	No
441	0771-WLCLA	Female	0	Yes	Yes
442	5628-RKIFK	Female	1	No	No
443	0206-TBWLC	Female	0	Yes	No
444	2937-FTHUR	Female	0	No	Yes
445	1910-FMXJM	Female	0	Yes	No
446	7752-XUSCI	Female	0	No	No
447	4110-PFEUZ	Female	0	No	No
448	0732-OCQOC	Female	0	Yes	Yes
449	5168-MSWXT	Male	0	Yes	Yes
450	1090-ESELR	Male	0	Yes	Yes
451	8592-PLTMQ	Female	0	No	No
452	5760-WRAHC	Female	1	No	No
453	8847-GEOOQ	Male	0	Yes	No
454	0256-LTHVJ	Female	0	Yes	Yes
455	4785-FCIFB	Female	0	Yes	No
456	8313-NDOIA	Female	0	No	No
457	5149-CUZUJ	Male	0	Yes	Yes
458	0942-KOWSM	Female	0	Yes	Yes
459	4237-CLSMM	Male	0	Yes	No
460	1452-VOQCH	Male	0	No	No
461	4719-UMSIY	Male	0	No	Yes
462	6614-VBEGU	Female	0	Yes	No
463	0880-TKATG	Male	0	Yes	Yes
464	3811-VBYBZ	Male	0	No	No
465	1480-BKXGA	Male	1	Yes	No
466	2996-XAUVF	Male	0	No	No
467	9076-AXYIK	Male	1	Yes	No
468	5968-XQIVE	Male	0	Yes	Yes
469	8896-RAZCR	Female	0	No	Yes
470	4640-UHDOS	Female	0	Yes	Yes
471	4933-IKULF	Female	1	No	No
472	3583-EKAPL	Male	0	No	No
473	1304-BCCFO	Male	0	Yes	No
474	4104-PVRPS	Male	0	Yes	No
475	9399-APLBT	Female	0	Yes	Yes
476	2359-KMGLI	Male	0	No	No
477	3780-DDGSE	Male	1	Yes	Yes
478	4431-EDMIQ	Female	0	Yes	Yes
479	0306-JAELE	Male	0	No	No
480	6227-HWPWX	Female	0	No	Yes
481	0486-LGCCH	Male	0	Yes	Yes
482	0447-BEMNG	Female	0	Yes	No
483	4612-SSVHJ	Female	1	No	No
484	5168-MQQCA	Female	0	Yes	No
485	5949-XIKAE	Female	0	Yes	Yes
486	7971-HLVXI	Male	0	Yes	Yes
487	9094-AZPHK	Female	0	No	No
488	3649-JPUGY	Male	0	No	No
489	4472-LVYGI	Female	0	Yes	Yes
490	8372-JUXUI	Male	0	No	Yes
491	3552-CTCYF	Male	0	Yes	Yes
492	6778-YSNIH	Female	0	No	No
493	0388-EOPEX	Female	0	Yes	No
494	5756-OZRIO	Male	1	Yes	No
495	6579-JPICP	Male	0	No	No
496	8205-OTCHB	Male	0	No	No
497	4134-BSXLX	Male	0	Yes	No
498	0505-SPOOW	Female	0	Yes	No
499	6235-VDHOM	Female	1	No	No
500	7783-YKGDV	Female	0	No	No
501	4374-YMUSQ	Male	0	No	No
502	4513-CXYIX	Female	1	Yes	No
503	3957-HHLMR	Female	0	Yes	Yes
504	7803-XOCCZ	Female	0	Yes	Yes
505	5736-YEJAX	Male	0	No	Yes
506	5609-CEBID	Female	1	No	No
507	8981-FJGLA	Male	0	No	Yes
508	7218-HKQFK	Male	0	Yes	No
509	4636-QRJKY	Female	0	Yes	Yes
510	1135-LMECX	Female	0	No	No
511	4332-MUOEZ	Male	1	Yes	Yes
512	8535-SFUTN	Male	0	No	No
513	5956-VKDTT	Female	1	Yes	No
514	8677-HDZEE	Female	0	No	No
515	2475-MROZF	Male	0	No	No
516	9412-GHEEC	Male	0	No	No
517	3482-ABPKK	Female	0	No	No
518	6705-LXORM	Female	1	Yes	No
519	0257-ZESQC	Female	1	Yes	No
520	7531-GQHME	Male	0	No	No
521	5174-ITUMV	Male	0	Yes	Yes
522	4109-CYRBD	Male	1	Yes	No
523	0913-XWSCN	Male	0	Yes	Yes
524	6825-UYPFK	Female	0	No	No
525	8397-MVTAZ	Male	0	Yes	No
526	0750-EBAIU	Male	0	No	No
527	8606-CIQUL	Male	1	Yes	Yes
528	3571-DPYUH	Male	0	Yes	Yes
529	7601-GNDYK	Male	0	Yes	Yes
530	0356-OBMAC	Female	1	No	No
531	8067-NIOYM	Female	0	Yes	Yes
532	1403-GYAFU	Male	0	Yes	Yes
533	4234-XTNEA	Male	0	No	No
534	1297-VQDRP	Male	1	Yes	Yes
535	9282-IZGQK	Female	0	No	No
536	5348-CAGXB	Male	0	No	No
537	0621-HJWXJ	Female	0	Yes	No
538	5844-QVTAT	Female	0	Yes	Yes
539	8905-IAZPF	Female	0	Yes	No
540	5394-MEITZ	Female	0	Yes	Yes
541	6859-QNXIQ	Female	0	Yes	Yes
542	2782-LFZVW	Female	0	No	No
543	2866-IKBTM	Female	0	No	No
544	1342-JPNKI	Male	0	No	No
545	2817-NTQDO	Male	0	No	No
546	7129-AZJDE	Male	0	Yes	Yes
547	6986-IJDHX	Male	0	Yes	Yes
548	2560-PPCHE	Female	0	No	No
549	4676-MQUEA	Male	1	Yes	No
550	8138-EALND	Male	0	No	No
551	3580-HYCSP	Male	0	Yes	Yes
552	1352-HNSAW	Female	0	Yes	Yes
553	2075-PUEPR	Male	0	Yes	Yes
554	1982-FEBTD	Female	0	Yes	Yes
555	5301-GAUUY	Male	0	No	No
556	5791-KAJFD	Female	0	Yes	Yes
557	2654-VBVPB	Female	0	No	No
558	1154-HYWWO	Male	0	No	No
559	2501-XWWTZ	Male	0	No	No
560	3716-UVSPD	Male	0	No	No
561	6815-ABQFQ	Male	0	Yes	No
562	7343-EOBEU	Male	0	Yes	No
563	3701-SFMUH	Male	0	Yes	Yes
564	6103-LIANB	Male	0	Yes	Yes
565	7319-VENRZ	Male	0	No	No
566	5846-NEQVZ	Male	0	Yes	Yes
567	6967-QIQRV	Male	0	Yes	Yes
568	5781-RFZRP	Male	0	Yes	No
569	0939-YAPAF	Female	0	No	No
570	0308-IVGOK	Female	0	No	No
571	7293-LSCDV	Female	0	Yes	Yes
572	7025-WCBNE	Male	1	No	No
573	5756-JYOJT	Female	0	No	No
574	4710-FDUIZ	Male	0	Yes	No
575	6030-REHUX	Female	1	Yes	No
576	9548-LIGTA	Male	0	Yes	No
577	5150-LJNSR	Male	0	Yes	Yes
578	8270-RKSAP	Male	0	No	No
579	6522-YRBXD	Male	1	Yes	No
580	2640-LYMOV	Male	0	No	No
581	1218-VKFPE	Female	0	Yes	Yes
582	3627-FHKBK	Female	0	No	No
583	2865-TCHJW	Female	1	No	No
584	1423-BMPBQ	Female	0	Yes	Yes
585	2393-DIVAI	Female	0	No	No
586	5192-EBGOV	Female	1	No	No
587	4568-KNYWR	Male	0	No	No
588	8752-IMQOS	Male	0	Yes	Yes
589	0742-LAFQK	Male	0	Yes	No
590	0795-LAFGP	Male	0	Yes	Yes
591	0619-OLYUR	Male	0	Yes	No
592	5512-IDZEI	Male	0	Yes	Yes
593	0459-SPZHJ	Male	0	Yes	Yes
594	0215-BQKGS	Male	0	No	No
595	9244-ZVAPM	Male	0	No	No
596	0719-SYFRB	Female	0	No	No
597	8208-EUMTE	Male	0	No	No
598	5172-MIGPM	Male	0	No	No
599	1710-RCXUS	Male	0	Yes	No
600	0374-FIUCA	Male	0	Yes	No
601	5839-SUYVZ	Male	0	No	No
602	5173-ZXXXL	Male	0	No	No
603	1096-ADRUX	Female	0	Yes	Yes
604	2001-MCUUW	Male	0	No	No
605	2731-GJRDG	Female	0	No	No
606	4723-BEGSG	Male	0	Yes	No
607	6516-NKQBO	Male	0	Yes	Yes
608	8672-OAUPW	Male	0	No	Yes
609	8207-DMRVL	Male	0	Yes	Yes
610	3419-SNJJD	Female	1	Yes	No
611	6543-CPZMK	Male	0	Yes	Yes
612	4765-OXPPD	Female	0	Yes	Yes
613	2804-ETQDK	Male	0	No	Yes
614	6689-VRRTK	Female	1	No	No
615	7138-GIRSH	Male	0	No	No
616	9396-ZSFLL	Female	0	No	No
617	6464-KEXXH	Male	0	No	No
618	7134-MJPDY	Female	1	No	No
619	5240-CAOYT	Female	0	No	No
620	4059-IIEBK	Female	0	No	No
621	4881-JVQOD	Male	1	Yes	Yes
622	0516-UXRMT	Female	0	No	No
623	4851-BQDNX	Male	0	Yes	Yes
624	5148-HKFIR	Female	0	No	No
625	1009-IRMNA	Female	0	No	No
626	3003-CMDUU	Female	0	Yes	No
627	5016-IBERQ	Male	0	Yes	No
628	6797-UCJHZ	Female	1	Yes	No
629	2469-DTSGX	Female	1	No	No
630	4554-YGZIH	Male	1	Yes	No
631	5099-BAILX	Male	1	Yes	Yes
632	9931-KGHOA	Female	0	Yes	No
633	1775-KWJKQ	Male	0	Yes	Yes
634	7665-VIGUD	Male	0	No	No
635	9411-TPQQV	Female	0	No	No
636	7207-RMRDB	Female	0	Yes	Yes
637	7954-MLBUN	Male	0	No	No
638	2077-DDHJK	Female	0	Yes	No
639	4913-EHYUI	Male	1	Yes	Yes
640	0195-IESCP	Male	0	Yes	No
641	9574-BOSMD	Male	0	Yes	Yes
642	4580-TMHJU	Female	0	Yes	Yes
643	0970-ETWGE	Male	0	No	No
644	4908-XAXAY	Female	1	No	No
645	8404-VLQFB	Female	0	Yes	Yes
646	1626-ERCMM	Male	1	Yes	No
647	0887-HJGAR	Male	0	No	No
648	2391-IPLOP	Male	0	Yes	Yes
649	5644-PDMZC	Female	1	No	No
650	3509-GWQGF	Male	1	No	No
651	9576-ANLXO	Female	0	No	No
652	2024-BASKD	Female	0	No	No
653	5845-BZZIB	Male	0	Yes	Yes
654	1140-UKVZG	Female	0	No	No
655	4160-AMJTL	Female	1	No	No
656	5183-SNMJQ	Male	0	No	No
657	8100-PNJMH	Male	0	Yes	Yes
658	7838-LAZFO	Male	0	Yes	No
659	4464-JCOLN	Male	0	Yes	Yes
660	2085-JVGAD	Male	0	Yes	No
661	5650-VDUDS	Female	0	No	No
662	8095-WANWK	Female	0	No	No
663	3030-ZKIWL	Male	0	No	No
664	9565-FLVCG	Male	0	Yes	Yes
665	8755-OGKNA	Female	0	Yes	Yes
666	2800-VEQXM	Female	0	No	No
667	7538-GWHML	Female	0	No	No
668	5533-RJFTJ	Male	0	No	No
669	3859-CVCET	Female	0	No	No
670	0214-JHPFW	Female	0	Yes	No
671	5642-MHDQT	Female	0	Yes	Yes
672	3088-FVYWK	Male	0	Yes	Yes
673	3276-HDUEG	Female	0	No	No
674	9092-GDZKO	Male	0	No	No
675	0823-HSCDJ	Male	1	No	No
676	3729-OWRVL	Male	1	No	No
677	2324-AALNO	Female	0	No	No
678	0822-GAVAP	Female	0	No	No
679	5760-IFJOZ	Male	0	No	No
680	2826-UWHIS	Male	0	Yes	No
681	1448-PWKYE	Male	0	Yes	Yes
682	7501-IWUNG	Female	0	Yes	Yes
683	4957-TREIR	Male	0	No	No
684	7251-LJBQN	Female	1	No	No
685	8040-MNRTF	Female	0	No	No
686	1536-HBSWP	Female	0	No	No
687	5313-FPXWG	Male	0	No	No
688	0067-DKWBL	Male	1	No	No
689	0946-FKYTX	Male	0	No	No
690	5076-YVXCM	Male	0	No	No
691	8262-COGGB	Male	0	No	No
692	6663-JOCQO	Male	0	Yes	Yes
693	9620-QJREV	Male	0	No	Yes
694	2276-YDAVZ	Female	0	No	No
695	2682-KEVRP	Female	1	No	No
696	2480-JZOSN	Female	0	Yes	No
697	0078-XZMHT	Male	0	Yes	No
698	5896-NPFWW	Male	0	Yes	Yes
699	9978-HYCIN	Male	1	Yes	Yes
700	8338-QIUNR	Male	0	Yes	Yes
701	1525-LNLOJ	Male	0	Yes	Yes
702	9450-TRJUU	Male	0	No	No
703	1766-GKNMI	Male	0	No	No
704	6942-LBFDP	Female	0	No	No
705	1456-TWCGB	Male	0	No	No
706	7133-VBDCG	Female	0	No	No
707	7596-ZYWBB	Female	0	No	No
708	8329-UTMVM	Male	1	No	No
709	3014-WJKSM	Male	0	Yes	No
710	3347-YJZZE	Male	0	Yes	Yes
711	1029-QFBEN	Male	0	No	No
712	7929-DMBCV	Female	0	Yes	No
713	9661-JALZV	Female	0	No	No
714	5433-KYGHE	Female	0	No	Yes
715	4312-KFRXN	Male	0	Yes	No
716	5575-TPIZQ	Male	0	No	No
717	0114-IGABW	Female	0	Yes	No
718	9944-AEXBM	Male	0	No	No
719	1853-ARAAQ	Female	0	No	No
720	6952-OMNWB	Male	1	Yes	No
721	4697-LUPSU	Male	0	Yes	Yes
722	8434-VGEQQ	Male	0	Yes	Yes
723	4952-YSOGZ	Female	0	Yes	Yes
724	1589-AGTLK	Male	0	No	No
725	5244-IRFIH	Male	1	Yes	No
726	6549-YMFAW	Male	1	Yes	No
727	4950-HKQTE	Female	0	No	No
728	6786-OBWQR	Female	0	Yes	Yes
729	2684-EIWEO	Female	1	No	No
730	2753-JMMCV	Male	0	No	No
731	6439-GTPCA	Female	0	No	No
732	6621-YOBKI	Male	0	No	No
733	1216-JWVUX	Male	0	Yes	Yes
734	7564-GHCVB	Female	0	Yes	Yes
735	1173-NOEYG	Female	0	Yes	No
736	7595-EHCDL	Male	0	Yes	Yes
737	6647-ZEDXT	Female	0	No	No
738	2521-NPUZR	Male	0	Yes	No
739	1307-TVUFB	Male	1	No	No
740	7503-MIOGA	Female	1	Yes	No
741	4381-MHQDC	Female	0	No	No
742	6923-JHPMP	Female	0	No	No
743	5138-WVKYJ	Male	0	No	No
744	4018-PPNDW	Female	0	Yes	Yes
745	1635-FJFCC	Female	0	No	No
746	2499-AJYUA	Female	1	Yes	No
747	6919-ELBGL	Male	1	Yes	Yes
748	3966-HRMZA	Female	1	No	No
749	6425-JWTDV	Male	0	Yes	No
750	8405-IGQFX	Female	0	No	No
751	8224-IVVPA	Female	0	No	No
752	9477-LGWQI	Male	0	Yes	Yes
753	1410-RSCMR	Male	0	Yes	Yes
754	3115-CZMZD	Male	0	No	Yes
755	0139-IVFJG	Female	0	Yes	No
756	6683-VLCTZ	Male	1	No	No
757	5730-DBDSI	Male	0	No	No
758	0030-FNXPP	Female	0	No	No
759	2189-WWOEW	Female	0	No	Yes
760	5684-FJVYR	Female	0	Yes	Yes
761	4013-GUXND	Male	0	No	No
762	1894-IGFSG	Female	0	No	No
763	7379-POKDZ	Male	0	Yes	No
764	1266-NZYUI	Female	0	Yes	Yes
765	7969-FFOWG	Male	0	Yes	Yes
766	4718-DHSMV	Female	0	No	No
767	5175-WLYXL	Male	0	No	No
768	7817-OMJNA	Male	0	No	No
769	8728-SKJLR	Male	0	No	No
770	3137-NYQQI	Male	0	Yes	No
771	7706-DZNKK	Male	0	No	No
772	0236-HFWSV	Male	0	No	No
773	3900-AQPHZ	Female	0	No	No
774	5842-POCOP	Female	0	Yes	No
775	2037-XJFUP	Male	0	Yes	No
776	8823-RLPWL	Female	0	Yes	No
777	9505-SQFSW	Female	0	Yes	Yes
778	7314-OXENN	Male	0	No	No
779	3758-CKOQL	Female	0	Yes	No
780	0322-CHQRU	Male	0	No	No
781	5676-CFLYY	Male	0	Yes	Yes
782	7521-AFHAB	Female	0	Yes	Yes
783	0285-INHLN	Male	0	Yes	Yes
784	4678-DVQEO	Female	0	No	No
785	5125-CNDSP	Male	0	No	Yes
786	0691-IFBQW	Female	1	No	No
787	4992-LTJNE	Male	0	Yes	Yes
788	2202-OUTMO	Female	0	Yes	No
789	0810-BDHAW	Female	0	Yes	Yes
790	0229-LFJAF	Male	0	No	No
791	7131-ZQZNK	Female	0	Yes	Yes
792	3442-ZHHCC	Male	0	No	No
793	5726-CVNYA	Female	0	Yes	Yes
794	9871-ELEYA	Female	0	No	Yes
795	4257-GAESD	Female	0	No	No
796	5173-WXOQV	Male	0	Yes	No
797	2040-OBMLJ	Male	0	No	No
798	6286-ZHAOK	Female	0	Yes	Yes
799	3807-XHCJH	Female	0	Yes	Yes
800	3009-JWMPU	Male	0	No	No
801	5671-RQRLP	Female	1	Yes	No
802	1450-GALXR	Female	0	No	No
803	8859-AXJZP	Male	0	Yes	Yes
804	3174-AKMAS	Female	0	Yes	No
805	3138-BKYAV	Male	0	No	No
806	9926-PJHDQ	Female	0	Yes	Yes
807	7382-DFJTU	Male	0	No	No
808	2798-NYLMZ	Male	0	Yes	No
809	4289-DTDKW	Male	0	Yes	No
810	1820-TQVEV	Male	0	No	No
811	2239-JALAW	Male	0	No	No
812	4853-RULSV	Male	0	No	No
813	8098-TDCBU	Female	0	Yes	No
814	3551-GAEGL	Male	0	Yes	Yes
815	4785-NKHCX	Male	1	No	No
816	3196-NVXLZ	Female	0	No	No
817	6275-YDUVO	Female	0	No	No
818	0036-IHMOT	Female	0	Yes	Yes
819	0115-TFERT	Male	0	Yes	No
820	4178-EGMON	Male	0	Yes	No
821	4220-TINQT	Female	0	Yes	No
822	5318-YKDPV	Male	0	Yes	Yes
823	7975-TZMLR	Male	0	No	No
824	0295-QVKPB	Male	0	No	No
825	4335-BSMJS	Female	0	No	No
826	2311-QYMUQ	Female	0	Yes	Yes
827	3643-AHCFP	Male	1	Yes	No
828	9146-JRIOX	Female	0	Yes	Yes
829	3104-OWCGK	Male	0	Yes	Yes
830	5337-IIWKZ	Male	0	Yes	Yes
831	9101-BWFSS	Female	0	Yes	No
832	9650-VBUOG	Male	0	Yes	Yes
833	3487-EARAT	Female	0	Yes	Yes
834	2672-TGEFF	Female	0	Yes	Yes
835	9231-ZJYAM	Female	1	No	No
836	4250-WAROZ	Male	1	Yes	Yes
837	8184-WMOFI	Male	0	Yes	Yes
838	6982-SSHFK	Male	0	No	No
839	6092-QZVPP	Male	0	No	No
840	4625-LAMOB	Male	0	No	No
841	0727-BMPLR	Female	1	No	No
842	0392-BZIUW	Female	0	Yes	No
843	1038-ZAGBI	Female	0	Yes	Yes
844	6549-NNDYT	Female	0	No	No
845	3027-ZTDHO	Male	0	No	No
846	0422-OHQHQ	Female	0	Yes	Yes
847	6916-HIJSE	Female	0	No	No
848	2316-ESMLS	Female	0	Yes	Yes
849	9778-OGKQZ	Male	0	Yes	No
850	7408-OFWXJ	Female	0	Yes	Yes
851	6007-TCTST	Female	0	Yes	Yes
852	2252-NKNSI	Male	0	No	Yes
853	8713-IGZSO	Male	0	No	No
854	7905-TVXTA	Female	0	No	No
855	7695-PKLCZ	Female	0	No	No
856	2382-BCKQJ	Female	0	No	Yes
857	8374-UULRV	Male	0	No	No
858	2207-NHRJK	Male	0	No	No
859	3224-DFQNQ	Female	0	Yes	No
860	5275-PMFUT	Male	0	Yes	Yes
861	4795-UXVCJ	Male	0	No	No
862	9777-IQHWP	Male	0	Yes	Yes
863	0947-MUGVO	Male	1	Yes	No
864	9944-HKVVB	Female	0	No	No
865	4124-MMETB	Male	0	No	No
866	3671-SHRSP	Male	0	Yes	No
867	0979-MOZQI	Male	0	Yes	No
868	2732-ISEZX	Female	0	No	No
869	3313-QKNKB	Male	0	Yes	No
870	0323-XWWTN	Male	0	No	Yes
871	1937-OTUKY	Female	0	Yes	No
872	1573-LGXBA	Male	0	Yes	Yes
873	1764-VUUMT	Male	0	No	Yes
874	5073-WXOYN	Female	0	No	No
875	4713-ZBURT	Male	0	No	Yes
876	3050-GBUSH	Female	0	No	No
877	0207-MDKNV	Female	0	No	No
878	7876-AEHIG	Female	0	No	Yes
879	7945-HLKEA	Female	0	No	No
880	9342-VNIMQ	Male	0	No	No
881	9851-KIELU	Male	0	No	No
882	3523-BRGUW	Male	1	No	No
883	3908-BLSYF	Female	0	No	No
884	3199-NPKCN	Female	0	Yes	No
885	5170-PTRKA	Female	0	Yes	Yes
886	4661-NJEUX	Male	0	No	No
887	2123-AGEEN	Female	1	No	No
888	1258-YMZNM	Female	1	No	No
889	0048-LUMLS	Male	0	Yes	Yes
890	7549-MYGPK	Female	0	Yes	Yes
891	5898-IGSLP	Male	0	Yes	Yes
892	3804-RVTGV	Male	0	Yes	Yes
893	6259-WJQLC	Male	1	No	No
894	9227-LUNBG	Female	0	No	No
895	7997-EASSD	Female	0	Yes	No
896	0730-KOAVE	Male	0	No	No
897	8975-SKGRX	Male	0	Yes	No
898	0678-RLHVP	Female	0	No	No
899	4315-MURBD	Female	0	No	No
900	2267-FPIMA	Male	0	Yes	No
901	1051-GEJLJ	Female	0	No	No
902	9734-YWGEX	Female	0	No	No
903	2719-BDAQO	Male	0	No	No
904	5285-MVEHD	Female	0	Yes	No
905	0379-DJQHR	Male	0	Yes	Yes
906	0781-LKXBR	Male	1	No	No
907	5543-QDCRY	Male	0	No	No
908	0297-RBCSG	Male	0	No	No
909	4694-PHWFW	Female	0	No	Yes
910	0835-JKADZ	Female	0	No	No
911	1907-UBQFC	Male	1	No	No
912	7508-SMHXL	Female	1	No	No
913	3865-YIOTT	Male	0	Yes	Yes
914	5993-BQHEA	Male	0	No	No
915	6024-RUGGH	Male	0	Yes	Yes
916	6513-EECDB	Male	1	Yes	No
917	3956-CJUST	Female	1	No	No
918	4079-WWQQQ	Male	0	No	No
919	6103-BOCOU	Female	0	No	No
920	5149-TGWDZ	Female	0	No	No
921	7471-WNSUF	Male	0	Yes	No
922	8942-DBMHZ	Male	0	No	No
923	4301-VVZKA	Male	0	Yes	No
924	9199-PWQVC	Female	0	Yes	No
925	4824-GUCBY	Female	1	No	No
926	5393-HJZSM	Female	0	Yes	Yes
927	7074-IEVOJ	Female	1	No	No
928	9625-QSTYE	Female	0	No	No
929	0862-PRCBS	Female	0	Yes	Yes
930	8812-ZRHFP	Female	0	Yes	Yes
931	5146-CBVOE	Female	0	No	No
932	0454-OKRCT	Male	0	No	No
933	5787-KXGIY	Male	0	Yes	No
934	4750-ZRXIU	Female	1	No	No
935	4198-VFOEA	Female	0	No	No
936	6630-UJZMY	Female	1	Yes	No
937	5709-LVOEQ	Female	0	Yes	Yes
938	6400-BWQKW	Female	0	No	No
939	2692-AQCPF	Female	0	Yes	No
940	0347-UBKUZ	Female	0	No	No
941	0835-DUUIQ	Female	0	No	Yes
942	0811-GSDTP	Female	0	No	Yes
943	7567-ECMCM	Male	0	No	No
944	6115-ZTBFQ	Female	0	Yes	No
945	6353-BRMMA	Female	0	Yes	Yes
946	6680-WKXRZ	Female	0	No	No
947	6231-WFGFH	Male	0	Yes	Yes
948	9904-EHEVJ	Female	1	Yes	Yes
949	7028-DVOIQ	Male	1	No	No
950	6169-PPETC	Male	0	Yes	Yes
951	4208-UFFGW	Male	1	No	No
952	8584-KMVXD	Female	0	No	No
953	8467-WYNSR	Male	0	No	No
954	0851-DFJKB	Female	0	No	No
955	5382-SOYZL	Male	0	No	No
956	9448-REEVD	Male	0	Yes	No
957	3261-CQXOL	Female	0	Yes	Yes
958	8388-FYNPZ	Male	0	No	No
959	4002-BQWPQ	Male	0	No	No
960	5651-YLPRD	Female	0	Yes	Yes
961	2826-DXLQO	Male	1	Yes	No
962	4378-BZYFP	Male	0	No	No
963	9489-UTFKA	Male	1	Yes	No
964	4849-PYRLQ	Female	1	No	No
965	9117-SHLZX	Male	0	No	No
966	9889-TMAHG	Male	1	No	No
967	4541-RMRLG	Male	0	No	No
968	7764-BDPEE	Male	0	No	Yes
969	3429-IFLEM	Female	0	No	No
970	3158-MOERK	Female	0	No	No
971	7294-TMAOP	Female	0	No	No
972	5002-GCQFH	Male	0	Yes	No
973	0556-FJEGU	Male	0	No	No
974	8919-FYFQZ	Male	1	Yes	No
975	0604-THJFP	Female	0	Yes	Yes
976	2834-JRTUA	Male	0	No	No
977	5875-YPQFJ	Male	0	No	No
978	5879-SESNB	Female	0	No	No
979	6646-QVXLR	Male	1	Yes	No
980	6461-PPAXN	Female	0	Yes	Yes
981	3318-ISQFQ	Female	0	No	No
982	1106-HRLKZ	Male	0	Yes	Yes
983	2483-XSSMZ	Female	0	No	No
984	8603-IJWDN	Male	0	No	No
985	8165-ZJRNM	Female	0	Yes	Yes
986	9369-XFEHK	Female	1	Yes	No
987	2604-XVDAM	Female	0	No	No
988	3717-OFRTN	Male	0	No	No
989	9046-JBFWA	Male	0	No	Yes
990	3280-NMUVX	Male	0	Yes	Yes
991	1206-EHBDD	Female	0	Yes	No
992	8361-LBRDI	Female	0	No	No
993	4883-KCPZJ	Female	0	Yes	Yes
994	9108-EQPNQ	Female	0	Yes	Yes
995	7277-KAMWT	Male	0	No	No
996	3842-IYKUE	Female	0	No	No
997	6641-XRPSU	Female	0	No	No
998	1374-DMZUI	Female	1	No	No
999	2545-LXYVJ	Male	0	Yes	No
1000	3234-VKACU	Male	0	No	No
1001	8357-EQXFO	Female	0	No	No
1002	1989-PRJHP	Male	1	Yes	No
1003	8120-JDCAM	Male	0	Yes	Yes
1004	8917-FAEMR	Female	0	No	No
1005	7047-YXDMZ	Male	0	No	No
1006	2858-EIMXH	Female	1	Yes	No
1007	9524-EGPJC	Female	0	No	No
1008	6993-OHLXR	Female	0	No	No
1009	8818-XYFCQ	Male	0	Yes	Yes
1010	6419-ZTTLE	Male	1	Yes	No
1011	0929-HYQEW	Male	0	No	No
1012	6614-YOLAC	Female	0	Yes	Yes
1013	7426-RHZGU	Male	0	No	No
1014	4065-JJAVA	Female	0	No	No
1015	4695-VADHF	Male	0	Yes	Yes
1016	3863-IUBJR	Male	0	Yes	Yes
1017	7649-SIJJF	Male	0	Yes	No
1018	9361-YNQWJ	Female	0	No	No
1019	3748-FVMZZ	Male	0	No	No
1020	9391-TTOYH	Female	0	No	No
1021	1452-XRSJV	Female	0	Yes	Yes
1022	3422-WJOYD	Male	0	Yes	No
1023	8242-SOQUO	Female	1	No	No
1024	7460-ITWWP	Female	1	Yes	No
1025	7147-AYBAA	Male	0	No	No
1026	7868-TMWMZ	Female	1	Yes	No
1027	4822-RVYBB	Male	1	No	No
1028	6732-FZUGP	Female	0	No	No
1029	8436-BJUMM	Male	0	Yes	Yes
1030	4184-TJFAN	Female	1	Yes	Yes
1031	8329-GWVPJ	Female	0	Yes	Yes
1032	1352-VHKAJ	Male	0	Yes	Yes
1033	4145-UQXUQ	Female	1	No	No
1034	2632-TACXW	Female	0	Yes	No
1035	8146-QQKZH	Female	0	Yes	No
1036	1767-CJKBA	Male	0	No	No
1037	6445-TNRXS	Male	0	Yes	Yes
1038	4581-LNWUM	Female	0	No	No
1039	4869-EPIUS	Male	0	Yes	No
1040	9948-YPTDG	Male	0	Yes	No
1041	1236-WFCDV	Male	1	No	No
1042	1915-OAKWD	Female	0	No	Yes
1043	7296-PIXQY	Female	0	Yes	Yes
1044	4883-QICIH	Male	0	Yes	Yes
1045	3354-OADJP	Female	0	No	No
1046	3524-WQDSG	Female	0	Yes	Yes
1047	0810-DHDBD	Female	0	No	No
1048	4026-SKKHW	Male	0	No	No
1049	2829-HYVZP	Male	0	No	No
1050	8329-IBCTI	Female	0	No	No
1051	1271-SJBGZ	Male	1	No	No
1052	3845-JHAMY	Female	0	Yes	Yes
1053	7013-PSXHK	Female	0	No	No
1054	5669-SRAIP	Female	0	No	No
1055	5981-ITEMU	Male	0	Yes	No
1056	3486-NPGST	Female	0	No	No
1057	6941-PMGEP	Female	0	No	No
1058	1624-WOIWJ	Female	0	No	No
1059	2074-GKOWZ	Male	0	Yes	Yes
1060	0376-YMCJC	Male	0	No	No
1061	6100-FJZDG	Male	0	Yes	Yes
1062	4829-ZLJTK	Female	1	Yes	No
1063	1730-VFMWO	Female	0	Yes	No
1064	7143-BQIBA	Male	0	No	No
1065	3800-LYTRK	Female	0	No	No
1066	0634-SZPQA	Female	0	No	No
1067	9646-NMHXE	Male	0	Yes	No
1068	7030-NJVDP	Male	0	Yes	No
1069	5536-RTPWK	Male	0	Yes	No
1070	8883-GRDWQ	Male	1	No	No
1071	6166-ILMNY	Female	0	No	No
1072	3097-NNSPB	Female	0	No	No
1073	7771-ZONAT	Male	0	No	No
1074	0655-RBDUG	Male	0	No	No
1075	2111-DWYHN	Male	0	No	No
1076	4194-WHFCB	Female	0	Yes	Yes
1077	4121-AGSIN	Female	0	Yes	Yes
1078	4361-BKAXE	Female	0	No	No
1079	9845-PEEKO	Female	1	No	No
1080	0455-XFASS	Female	0	Yes	Yes
1081	0301-KOBTQ	Male	0	No	No
1082	1751-NCDLI	Male	1	Yes	No
1083	4367-NUYAO	Male	0	Yes	Yes
1084	9878-TNQGW	Male	0	No	No
1085	9170-ARBTB	Female	0	Yes	Yes
1086	4441-NIHPT	Female	1	No	No
1087	8999-BOHSE	Female	1	No	No
1088	7241-AJHFS	Male	0	No	No
1089	7029-RPUAV	Male	1	Yes	No
1090	4546-FOKWR	Female	0	No	No
1091	9036-CSKBW	Female	0	No	No
1092	5832-TRLPB	Male	0	No	No
1093	8590-YFFQO	Male	0	Yes	No
1094	8659-IOOPU	Female	0	Yes	Yes
1095	1338-CECEE	Male	0	Yes	Yes
1096	7439-DKZTW	Male	0	No	No
1097	4646-QZXTF	Female	0	Yes	No
1098	4607-CHPCA	Male	0	Yes	Yes
1099	9742-XOKTS	Male	0	Yes	Yes
1100	6921-OZMFH	Male	0	Yes	Yes
1101	9578-FOMUK	Male	0	No	Yes
1102	4712-UYOOI	Female	0	Yes	Yes
1103	8824-RWFXJ	Male	0	Yes	Yes
1104	7722-CVFXN	Male	0	Yes	Yes
1105	8717-VCTXJ	Male	0	No	No
1106	7363-QTBIW	Female	0	Yes	No
1107	4159-NAAIX	Female	0	No	No
1108	0971-QIFJK	Female	0	Yes	No
1109	9397-TZSHA	Female	0	No	No
1110	3391-JSQEW	Male	0	Yes	No
1111	0343-QLUZP	Male	0	No	No
1112	9763-PDTKK	Female	0	No	No
1113	2176-LVPNX	Female	1	No	No
1114	7627-JKIAZ	Female	0	Yes	No
1115	3312-UUMZW	Male	0	Yes	No
1116	1271-UODNO	Male	0	No	No
1117	8461-EFQYM	Female	0	No	No
1118	6900-RBKER	Male	0	No	No
1119	6891-JPYFF	Female	0	Yes	Yes
1120	1459-QNFQT	Male	0	Yes	Yes
1121	1047-NNCBF	Male	0	No	No
1122	3696-XRIEN	Female	0	No	No
1123	4081-DYXAV	Female	0	No	No
1124	0074-HDKDG	Male	0	Yes	Yes
1125	8791-GFXLZ	Male	0	No	No
1126	8111-SLLHI	Male	1	Yes	No
1127	0927-LCSMG	Male	0	No	No
1128	9330-DHBFL	Female	0	Yes	Yes
1129	0098-BOWSO	Male	0	No	No
1130	3452-ABWRL	Male	1	No	No
1131	5859-HZYLF	Male	0	Yes	Yes
1132	8257-RZAHR	Female	0	Yes	No
1133	5293-WXJAK	Female	1	Yes	No
1134	3156-QLHBO	Male	0	No	Yes
1135	2208-NQBCT	Female	0	Yes	Yes
1136	1779-PWPMG	Female	1	Yes	No
1137	6621-NRZAK	Female	0	Yes	Yes
1138	0831-JNISG	Male	0	Yes	Yes
1139	0774-IFUVM	Male	0	Yes	Yes
1140	3082-WQRVY	Male	1	Yes	No
1141	9553-DLCLU	Female	0	No	Yes
1142	1641-BYBTK	Male	0	No	Yes
1143	2460-NGXBJ	Male	1	Yes	Yes
1144	2446-ZKVAF	Male	0	Yes	No
1145	0841-NULXI	Male	0	No	No
1146	3522-CDKHF	Female	0	Yes	No
1147	1430-SFQSA	Male	0	No	No
1148	0411-EZJZE	Female	0	No	No
1149	7851-WZEKY	Female	0	No	No
1150	8844-TONUD	Male	0	Yes	Yes
1151	8807-ARQET	Female	0	No	No
1152	8992-CEUEN	Female	0	No	No
1153	4320-QMLLA	Male	0	No	No
1154	8777-PVYGU	Female	0	Yes	No
1155	8292-ITGYJ	Female	0	Yes	Yes
1156	6870-ZWMNX	Male	0	Yes	No
1157	0621-CXBKL	Female	0	No	No
1158	5268-DSMNQ	Female	1	Yes	No
1159	5334-JLAXU	Female	0	Yes	No
1160	4086-YQSNZ	Female	1	Yes	No
1161	6242-MBHPK	Female	1	Yes	No
1162	5868-CZJDR	Male	0	No	Yes
1163	9359-UGBTK	Female	0	No	No
1164	0135-NMXAP	Female	0	No	No
1165	4782-OSFXZ	Female	1	Yes	No
1166	6479-OAUSD	Male	0	No	No
1167	7129-ACFOG	Female	0	No	No
1168	4189-NAKJS	Male	0	No	No
1169	5562-BETPV	Male	0	Yes	Yes
1170	1282-IHQAC	Male	1	No	No
1171	9127-FHJBZ	Male	0	Yes	Yes
1172	6270-OMFIW	Male	0	Yes	No
1173	1641-RQDAY	Female	1	Yes	Yes
1174	0107-WESLM	Male	0	No	No
1175	6994-ORCWG	Female	0	No	No
1176	1346-UFHAX	Female	0	No	No
1177	3992-YWPKO	Female	0	No	No
1178	2933-XEUJM	Female	0	No	No
1179	0125-LZQXK	Male	0	No	No
1180	5461-QKNTN	Male	1	Yes	No
1181	4835-YSJMR	Male	0	No	No
1182	8399-YNDCH	Male	1	No	No
1183	3164-YAXFY	Male	0	No	No
1184	0887-WBJVH	Female	0	Yes	No
1185	4660-IRIBM	Male	0	Yes	Yes
1186	5673-FSSMF	Female	0	No	No
1187	7670-ZBPOQ	Female	0	Yes	No
1188	8089-UZWLX	Female	1	No	No
1189	0080-OROZO	Female	0	No	No
1190	3916-NRPAP	Male	0	No	No
1191	6807-SIWJI	Male	0	No	No
1192	8221-HVAYI	Male	0	Yes	Yes
1193	1579-KLYDT	Male	0	No	No
1194	5232-NXPAY	Female	0	No	No
1195	8967-SZQAS	Female	0	No	No
1196	4468-KAZHE	Female	1	Yes	No
1197	0455-ENTCR	Male	0	Yes	No
1198	8944-AILEF	Male	0	Yes	No
1199	5542-NKVRU	Female	0	No	No
1200	7126-RBHSD	Female	0	Yes	No
1201	5370-IIVVL	Male	0	No	No
1202	6789-HJBWG	Female	0	No	No
1203	3927-NLNRY	Male	0	Yes	No
1204	9087-EYCPR	Female	0	No	No
1205	6791-YBNAK	Male	0	Yes	Yes
1206	6358-LYNGM	Male	0	No	No
1207	6077-BDPXA	Female	0	No	No
1208	0013-MHZWF	Female	0	No	Yes
1209	5494-HECPR	Female	0	No	No
1210	8268-YDIXR	Male	0	Yes	No
1211	9824-BEMCV	Male	0	Yes	Yes
1212	1373-ORVIZ	Female	0	Yes	Yes
1213	4291-SHSBH	Male	0	No	No
1214	6980-IMXXE	Female	0	Yes	Yes
1215	9866-QEVEE	Male	0	No	No
1216	9897-KXHCM	Female	0	Yes	Yes
1217	0040-HALCW	Male	0	Yes	Yes
1218	0784-GTUUK	Male	0	Yes	No
1219	7979-CORPM	Male	0	No	No
1220	2294-DMMUS	Female	0	Yes	Yes
1221	0872-JCPIB	Male	0	No	No
1222	3055-MJDSB	Male	0	No	No
1223	9091-WTUUY	Male	0	Yes	Yes
1224	1618-CFHME	Female	0	No	No
1225	3165-HDOEW	Male	0	Yes	Yes
1226	6581-NQCBA	Female	0	Yes	No
1227	7115-IRDHS	Female	0	Yes	No
1228	8496-DMZUK	Male	0	No	No
1229	2040-VZIKE	Female	0	Yes	No
1230	9068-VPWQQ	Male	0	Yes	No
1231	0178-SZBHO	Male	0	Yes	Yes
1232	0384-RVBPI	Male	0	No	No
1233	1689-MRZQR	Male	0	Yes	Yes
1234	1299-AURJA	Female	0	Yes	Yes
1235	4525-VZCZG	Male	0	No	Yes
1236	1543-LLLFT	Male	1	Yes	No
1237	5835-BEQEU	Male	0	No	No
1238	2788-CJQAQ	Male	0	No	No
1239	5565-FILXA	Female	1	No	No
1240	0319-QZTCO	Female	0	Yes	Yes
1241	2120-SMPEX	Male	0	No	No
1242	0096-FCPUF	Male	0	No	No
1243	0668-OGMHD	Female	0	Yes	No
1244	5552-ZNFSJ	Male	0	No	No
1245	2223-KAGMX	Female	0	No	No
1246	6507-ZJSUR	Male	1	Yes	No
1247	9408-HRXRK	Female	0	Yes	Yes
1248	5593-SUAOO	Female	0	Yes	Yes
1249	7321-PKUYW	Female	0	No	No
1250	2833-SLKDQ	Male	0	No	No
1251	6766-HFKLA	Female	0	Yes	No
1252	7595-EUIVN	Female	0	No	No
1253	7617-EYGLW	Male	0	No	No
1254	2026-TGDHM	Female	0	No	No
1255	9220-ZNKJI	Female	1	Yes	No
1256	4030-VPZBD	Female	0	No	No
1257	2226-ICFDO	Female	0	Yes	Yes
1258	0723-VSOBE	Female	1	No	No
1259	5529-GIBVH	Female	0	No	No
1260	4187-CINZD	Female	1	No	No
1261	9992-UJOEL	Male	0	No	No
1262	4741-WWJQZ	Female	0	Yes	No
1263	6625-UTXEW	Female	0	Yes	No
1264	6818-WOBHJ	Female	1	Yes	No
1265	6244-BESBM	Male	0	Yes	Yes
1266	1004-NOZNR	Male	1	No	Yes
1267	1251-STYSZ	Female	1	No	No
1268	2612-PHGOX	Male	0	Yes	No
1269	2408-TZMJL	Male	0	Yes	No
1270	8480-PPONV	Male	0	Yes	Yes
1271	8780-IHCRN	Male	0	Yes	Yes
1272	4598-ZADCK	Female	0	No	No
1273	1257-SXUXQ	Male	0	Yes	Yes
1274	9681-KYGYB	Male	1	Yes	No
1275	7182-OVLBJ	Female	0	Yes	Yes
1276	5095-ETBRJ	Female	0	Yes	No
1277	7005-CYUIL	Female	1	Yes	No
1278	4821-WQOYN	Female	0	Yes	Yes
1279	4730-AWNAU	Male	0	Yes	Yes
1280	3452-FLHYD	Male	0	Yes	No
1281	2388-LAESQ	Female	1	Yes	No
1282	9531-NSBMR	Female	0	No	No
1283	6260-ONULR	Male	0	No	No
1284	4389-UEFCZ	Female	0	Yes	No
1285	8711-LOBKY	Male	0	Yes	Yes
1286	9134-CEQMF	Male	1	Yes	No
1287	8985-OOPOS	Female	0	No	No
1288	8800-ZKRFW	Female	0	Yes	Yes
1289	2616-FLVQC	Male	0	No	No
1290	9968-FFVVH	Male	0	No	No
1291	3108-PCCGG	Male	1	Yes	No
1292	7993-PYKOF	Male	0	Yes	No
1293	8390-FESFV	Female	0	No	No
1294	3022-BEXHZ	Male	0	Yes	Yes
1295	5027-XWQHA	Male	0	No	No
1296	6248-TKCQV	Female	0	Yes	Yes
1297	6729-GDNGC	Female	1	No	No
1298	6198-ZFIOJ	Female	0	No	No
1299	5989-OMNJE	Female	0	Yes	Yes
1300	4566-QVRRW	Female	0	Yes	No
1301	1291-CUOCY	Male	0	Yes	No
1302	9795-SHUHB	Female	0	Yes	Yes
1303	3230-IUALN	Female	0	Yes	Yes
1304	0042-RLHYP	Female	0	Yes	Yes
1305	8519-IMDHU	Male	1	Yes	No
1306	4945-RVMTE	Female	0	No	No
1307	0201-OAMXR	Female	0	No	No
1308	1866-NXPSP	Female	0	No	No
1309	3372-KWFBM	Male	1	No	No
1310	7831-QGOXH	Female	0	No	No
1311	6393-WRYZE	Female	0	Yes	No
1312	3941-XTSKM	Male	0	Yes	Yes
1313	1661-CZBAU	Male	0	No	No
1314	6599-RCLCJ	Male	0	Yes	No
1315	9831-BPFRI	Female	0	Yes	Yes
1316	5158-RIVOP	Female	0	Yes	Yes
1317	9788-YTFGE	Male	0	No	No
1318	9277-JOOMO	Female	0	No	No
1319	1907-YLNYW	Male	0	No	No
1320	1725-MIMXW	Male	0	No	Yes
1321	8947-YRTDV	Male	0	Yes	Yes
1322	3161-ONRWK	Male	0	Yes	Yes
1323	0114-RSRRW	Female	0	Yes	No
1324	4565-NLZBV	Female	0	Yes	No
1325	0031-PVLZI	Female	0	Yes	Yes
1326	7206-GZCDC	Female	1	No	No
1327	6682-VCIXC	Female	0	Yes	Yes
1328	4791-QRGMF	Male	0	Yes	No
1329	6475-VHUIZ	Female	0	Yes	No
1330	3910-MRQOY	Female	0	Yes	No
1331	0661-WCQNQ	Male	0	Yes	No
1332	7537-RBWEA	Female	0	No	No
1333	4656-CAURT	Male	0	No	No
1334	0121-SNYRK	Male	0	No	No
1335	1768-ZAIFU	Female	1	No	No
1336	4671-LXRDQ	Male	0	No	No
1337	3733-LSYCE	Female	0	Yes	No
1338	6265-FRMTQ	Male	0	No	No
1339	1934-SJVJK	Male	0	No	No
1340	3838-OZURD	Male	0	Yes	No
1341	1371-DWPAZ	Female	0	Yes	Yes
1342	9269-CQOOL	Male	0	No	Yes
1343	2017-CCBLH	Female	0	No	No
1344	7690-KPNCU	Male	0	Yes	Yes
1345	0536-BGFMZ	Female	0	Yes	No
1346	2293-IJWPS	Female	0	Yes	No
1347	2845-HSJCY	Female	0	Yes	Yes
1348	5469-NUJUR	Male	0	No	No
1349	1184-PJVDB	Male	0	Yes	No
1350	2625-TRCZQ	Female	0	Yes	No
1351	4102-HLENU	Female	0	Yes	No
1352	7266-GSSJX	Male	0	Yes	Yes
1353	7722-VJRQD	Male	0	Yes	Yes
1354	7073-QETQY	Male	0	Yes	Yes
1355	9415-DPEWS	Female	0	No	No
1356	5624-RYAMH	Female	0	No	No
1357	0196-JTUQI	Female	0	No	No
1358	7130-YXBRO	Male	0	Yes	No
1359	9272-LSVYH	Male	0	No	No
1360	7943-RQCHR	Female	0	No	No
1361	3793-MMFUH	Female	1	No	No
1362	3249-ZPQRG	Male	0	No	No
1363	2568-BRGYX	Male	0	No	No
1364	3084-DOWLE	Female	0	Yes	No
1365	1084-MNSMJ	Female	0	Yes	Yes
1366	7721-JXEAW	Male	0	Yes	No
1367	7249-WBIYX	Male	0	Yes	No
1368	4238-HFHSN	Male	1	Yes	No
1369	6250-CGGUN	Male	0	No	No
1370	5478-JJVZK	Female	0	No	No
1371	7596-IIWYC	Female	0	No	No
1372	6567-HOOPW	Female	1	No	No
1373	9793-WECQC	Male	0	No	No
1374	4291-HPAXL	Male	0	No	Yes
1375	8999-YPYBV	Male	0	Yes	Yes
1376	1839-FBNFR	Female	0	Yes	Yes
1377	3164-AALRN	Male	0	No	No
1378	3071-MVJCD	Male	0	Yes	Yes
1379	1697-BCSHV	Female	0	Yes	Yes
1380	0562-KBDVM	Female	0	No	No
1381	1131-SUEKT	Male	0	Yes	Yes
1382	3717-OEAUQ	Male	0	No	No
1383	4538-WNTMJ	Female	0	Yes	Yes
1384	3334-CTHOL	Female	0	No	No
1385	4704-ERYFC	Female	0	Yes	No
1386	9432-RUVSL	Female	0	No	No
1387	8060-HIWJJ	Male	0	No	No
1388	7684-XSZIY	Male	0	Yes	Yes
1389	9089-UOWJG	Female	0	Yes	Yes
1390	8621-MNIHH	Female	1	Yes	No
1391	8039-ACLPL	Female	0	Yes	Yes
1392	9885-AIBVB	Male	0	Yes	No
1393	1934-MKPXS	Male	0	Yes	Yes
1394	2592-YKDIF	Female	0	No	No
1395	2272-JKMSI	Female	0	Yes	Yes
1396	0471-LVHGK	Male	0	Yes	No
1397	9518-RWHZL	Female	0	No	No
1398	8714-CTZJW	Female	0	No	No
1399	3569-EDBPQ	Female	0	No	No
1400	3131-NWVFJ	Female	0	Yes	Yes
1401	7521-YXVZY	Male	0	No	Yes
1402	5419-CONWX	Female	1	No	No
1403	6240-EURKS	Female	0	No	Yes
1404	2373-NTKOD	Male	0	No	No
1405	1970-KKFWL	Female	0	No	No
1406	6960-HVYXR	Female	0	No	No
1407	9337-SRRNI	Male	0	No	Yes
1408	0895-UADGO	Male	0	No	Yes
1409	5678-VFNEQ	Female	0	Yes	No
1410	5977-CKHON	Female	0	Yes	Yes
1411	7024-OHCCK	Female	1	No	No
1412	2692-BUCFV	Male	1	No	No
1413	7861-UVUFT	Female	0	Yes	No
1414	1830-GGFNM	Male	0	Yes	Yes
1415	5302-BDJNT	Male	0	No	No
1416	5223-UZAVK	Male	0	No	No
1417	4859-ZSRDZ	Female	0	Yes	Yes
1418	5651-WYIPH	Female	1	No	No
1419	9350-VLHMB	Male	0	Yes	Yes
1420	3498-LZGQZ	Male	0	Yes	Yes
1421	8785-CJSHH	Female	0	Yes	No
1422	5357-TZHPP	Male	1	No	No
1423	3870-SPZSI	Female	0	Yes	Yes
1424	0680-DFNNY	Male	0	Yes	No
1425	7560-QRBXH	Female	0	No	Yes
1426	7077-XJMET	Male	0	Yes	No
1427	8752-GHJFU	Male	1	Yes	No
1428	6896-SRVYQ	Male	1	No	No
1429	7767-UXAGJ	Male	0	No	No
1430	4652-ODEVH	Male	0	Yes	Yes
1431	6510-UPNKS	Female	0	No	No
1432	6718-BDGHG	Female	0	Yes	No
1433	9046-DQMTP	Male	0	No	No
1434	6439-LAJXL	Male	0	Yes	No
1435	1571-SAVHK	Male	0	No	No
1436	9052-VKDUW	Female	1	Yes	No
1437	9546-CQJSU	Female	0	No	No
1438	1666-JZPZT	Male	0	No	No
1439	5777-KJIRB	Female	0	No	No
1440	0506-LVNGN	Female	1	No	No
1441	7677-SJJJK	Male	0	Yes	Yes
1442	2480-EJWYP	Female	1	Yes	No
1443	3253-HKOKL	Female	0	Yes	Yes
1444	7055-HNEOJ	Male	0	Yes	No
1445	5514-YQENT	Male	0	No	Yes
1446	3211-AAPKX	Male	0	No	No
1447	8445-DNBAE	Male	0	No	Yes
1448	2951-QOQTK	Male	0	No	Yes
1449	2958-NHPPS	Male	0	No	No
1450	6806-YDEUL	Female	1	No	No
1451	1735-XMJVH	Male	0	Yes	Yes
1452	6890-PFRQX	Male	0	No	No
1453	0222-CNVPT	Male	1	No	No
1454	5899-OUVKV	Male	0	No	No
1455	8681-ICONS	Male	0	Yes	Yes
1456	1621-YNCJH	Female	0	Yes	No
1457	3473-XIIIT	Female	0	Yes	No
1458	6362-QHAFM	Male	0	Yes	No
1459	7893-IXHRQ	Male	0	No	No
1460	3070-BDOQC	Female	0	No	No
1461	2952-QAYZF	Male	0	No	No
1462	6234-PFPXL	Male	0	Yes	No
1463	9824-QCJPK	Male	0	Yes	No
1464	4763-PGDPO	Female	0	No	No
1465	4283-IVYCI	Male	0	No	No
1466	1866-OBPNR	Male	0	Yes	Yes
1467	8205-MQUGY	Male	0	Yes	Yes
1468	8970-ANWXO	Female	0	No	No
1469	9480-BQJEI	Male	0	No	No
1470	5394-SVGJV	Male	0	No	No
1471	6979-TNDEU	Female	0	No	No
1472	9777-WJJPR	Male	0	Yes	No
1473	9283-LZQOH	Male	0	Yes	Yes
1474	7079-QRCBC	Female	0	No	No
1475	9495-SKLKD	Male	0	Yes	Yes
1476	6048-UWKAL	Female	1	Yes	No
1477	5067-DGXLL	Male	0	No	No
1478	5469-CTCWN	Male	0	Yes	Yes
1479	9851-QXEEQ	Male	0	No	No
1480	6281-FKEWS	Female	0	No	No
1481	8898-KASCD	Male	0	No	No
1482	9242-TKFSV	Male	0	Yes	Yes
1483	9290-SHCMB	Female	1	No	No
1484	0743-HNPFG	Female	0	Yes	Yes
1485	2277-BKJKN	Female	1	Yes	No
1486	9809-IMGCQ	Male	1	No	No
1487	5208-HFSBT	Female	0	No	No
1488	5035-PGZXH	Female	0	No	No
1489	8695-WDYEA	Male	0	No	No
1490	6543-JXSOO	Female	0	Yes	Yes
1491	8016-ZMGMO	Female	1	Yes	No
1492	8605-ITULD	Female	0	No	No
1493	3254-YRILK	Male	1	No	No
1494	6416-YJTTB	Male	0	No	No
1495	2667-WYLWJ	Female	0	Yes	Yes
1496	4472-VESGY	Female	0	Yes	Yes
1497	3195-TQDZX	Male	0	No	No
1498	3128-YOVTD	Female	0	Yes	Yes
1499	0529-ONKER	Male	1	No	No
1500	1728-CXQBE	Male	1	Yes	No
1501	7041-TXQJH	Female	0	No	No
1502	5014-GSOUQ	Male	0	No	No
1503	5724-BIDBU	Male	0	Yes	No
1504	0481-SUMCB	Female	1	No	No
1505	1769-GRUIK	Female	0	No	No
1506	5240-IJOQT	Male	1	No	No
1507	8819-WFGGJ	Male	0	Yes	No
1508	7427-AUFPY	Male	0	No	No
1509	2811-POVEX	Female	1	Yes	Yes
1510	1092-GANHU	Male	0	No	No
1511	7898-PDWQE	Male	0	Yes	No
1512	9972-EWRJS	Female	0	Yes	Yes
1513	9314-IJWSQ	Female	0	Yes	Yes
1514	0661-XEYAN	Female	1	No	No
1515	5799-JRCZO	Female	0	No	Yes
1516	1921-KYSAY	Female	0	No	No
1517	6198-RTPMF	Female	0	Yes	No
1518	2924-KHUVI	Male	0	Yes	No
1519	1925-GMVBW	Female	0	No	No
1520	7881-EVUAD	Female	0	No	No
1521	6184-DYUOB	Female	0	Yes	No
1522	9207-ZPANB	Male	0	No	No
1523	5766-XQXMQ	Female	0	No	No
1524	9327-QSDED	Male	0	No	No
1525	1656-DRSMG	Female	0	No	No
1526	3012-VFFMN	Female	0	Yes	Yes
1527	2984-AFWNC	Female	0	No	No
1528	0640-YJTPY	Male	0	Yes	Yes
1529	8096-LOIST	Female	0	No	No
1530	9764-REAFF	Female	0	Yes	No
1531	3703-VAVCL	Male	0	Yes	Yes
1532	7107-UBYKY	Female	0	Yes	Yes
1533	4881-GQJTW	Male	0	No	No
1534	8519-QJGJD	Female	0	No	No
1535	7876-DNYAP	Female	0	Yes	Yes
1536	7905-NJMXS	Male	1	Yes	No
1537	2882-WDTBA	Male	0	Yes	Yes
1538	2091-GPPIQ	Female	0	Yes	Yes
1539	6326-MTTXK	Male	0	No	No
1540	5071-FBJFS	Female	0	Yes	Yes
1541	2796-UUZZO	Male	0	Yes	Yes
1542	2429-AYKKO	Male	0	No	No
1543	9798-OPFEM	Female	0	No	No
1544	0330-IVZHA	Female	0	Yes	No
1545	3794-NFNCH	Male	0	Yes	No
1546	5193-QLVZB	Male	0	No	No
1547	7114-AEOZE	Female	0	No	No
1548	2886-KEFUM	Female	0	Yes	No
1549	5522-NYKPB	Male	0	Yes	Yes
1550	4237-RLAQD	Male	0	No	No
1551	9957-YODKZ	Male	1	Yes	No
1552	6518-KZXCB	Male	0	No	No
1553	2245-ADZFJ	Female	0	Yes	Yes
1554	7776-QGYJC	Female	0	Yes	Yes
1555	9313-QOLTZ	Male	0	No	No
1556	9651-GTSAQ	Female	0	Yes	No
1557	3186-BAXNB	Female	0	No	No
1558	4672-FOTSD	Male	0	No	No
1559	0637-YLETY	Female	0	No	No
1560	9818-XQCUV	Female	0	No	No
1561	7338-ERIVA	Male	0	No	Yes
1562	1157-BQCUW	Male	0	No	No
1563	8259-NFJTV	Female	0	Yes	Yes
1564	3223-DWFIO	Male	1	No	No
1565	2660-EMUBI	Male	1	No	No
1566	6968-GMKPR	Female	0	No	No
1567	4751-ERMAN	Male	0	Yes	Yes
1568	1436-ZMJAN	Female	0	Yes	No
1569	3292-PBZEJ	Male	1	No	No
1570	0799-DDIHE	Female	0	Yes	Yes
1571	3070-FNFZQ	Female	0	Yes	Yes
1572	2812-SFXMJ	Male	0	No	Yes
1573	7675-OZCZG	Female	1	No	No
1574	5014-WUQMG	Male	0	Yes	Yes
1575	5312-TSZVC	Female	0	No	Yes
1576	2003-CKLOR	Male	0	No	No
1577	0993-OSGPT	Female	1	Yes	No
1578	9254-RBFON	Female	0	Yes	Yes
1579	1205-WNWPJ	Female	0	No	No
1580	9391-EOYLI	Male	1	Yes	No
1581	7108-DGVUU	Female	1	Yes	No
1582	2782-JEEBU	Male	0	No	No
1583	5127-BZENZ	Female	0	Yes	Yes
1584	2720-FVBQP	Female	0	Yes	Yes
1585	9906-NHHVC	Female	1	No	No
1586	4522-XRWWI	Male	0	Yes	No
1587	3766-EJLFL	Female	0	Yes	Yes
1588	5939-SXWHM	Male	0	Yes	Yes
1589	8152-UOBNY	Female	1	No	No
1590	7351-KYHQH	Female	1	No	No
1591	7643-RCHXS	Female	0	Yes	Yes
1592	8246-SHFGA	Male	0	No	No
1593	8387-MOJJT	Female	0	Yes	Yes
1594	0620-XEFWH	Male	0	Yes	Yes
1595	6485-QXWWE	Female	0	No	Yes
1596	2761-OCIAX	Male	1	No	No
1597	7321-VGNKU	Female	0	Yes	No
1598	5327-CNLUQ	Male	0	Yes	No
1599	7552-KEYGT	Male	0	Yes	No
1600	5816-JMLGY	Female	0	Yes	Yes
1601	3068-OMWZA	Male	1	No	No
1602	2927-QRRQV	Male	0	Yes	No
1603	6032-KRXXO	Male	0	No	No
1604	7459-RRWQZ	Female	0	No	No
1605	6265-SXWBU	Male	0	Yes	Yes
1606	7941-RCJOW	Male	0	No	No
1607	6374-NTQLP	Male	1	Yes	Yes
1608	4154-AQUGT	Male	1	Yes	No
1609	2387-KDZQY	Male	0	No	No
1610	3584-WKTTW	Male	0	Yes	No
1611	3399-BMLVW	Male	0	Yes	Yes
1612	1971-DTCZB	Female	0	Yes	No
1613	3092-IGHWF	Male	0	Yes	Yes
1614	3374-PZLXD	Male	0	No	No
1615	3813-DHBBB	Male	0	Yes	No
1616	2812-REYAT	Female	0	Yes	No
1617	6518-PPLMZ	Male	0	Yes	Yes
1618	4939-KYYPY	Male	0	No	No
1619	8017-LXHFA	Female	1	No	No
1620	5930-GBIWP	Male	0	No	No
1621	6022-KOUQO	Female	0	Yes	Yes
1622	6352-TWCAU	Female	0	No	No
1623	2361-UPSND	Female	0	Yes	No
1624	6035-RIIOM	Female	0	No	No
1625	2929-QNSRW	Female	0	Yes	No
1626	1262-OPMFY	Female	0	Yes	No
1627	9504-DSHWM	Male	0	No	No
1628	5035-BVCXS	Male	0	No	No
1629	6267-DCFFZ	Female	1	Yes	No
1630	3533-UVMOM	Male	0	Yes	No
1631	2439-LYPMQ	Male	1	Yes	No
1632	4248-QPAVC	Female	1	Yes	No
1633	1899-VXWXM	Male	0	No	No
1634	1478-VPOAD	Female	0	No	No
1635	9995-HOTOH	Male	0	Yes	Yes
1636	2988-PLAHS	Female	0	No	No
1637	1371-OJCEK	Female	0	No	No
1638	4999-IEZLT	Male	0	No	No
1639	8883-ANODQ	Female	0	Yes	Yes
1640	4690-LLKUA	Male	1	No	No
1641	2351-RRBUE	Female	0	Yes	Yes
1642	5980-BDHPY	Male	0	Yes	No
1643	1498-DQNRX	Female	0	Yes	No
1644	9469-WEJBT	Male	0	Yes	No
1645	3331-HQDTW	Female	0	No	No
1646	9490-DFPMD	Female	1	No	No
1647	2581-VKIRT	Female	0	Yes	Yes
1648	5442-XSDCW	Male	0	Yes	Yes
1649	7426-WEIJX	Male	1	Yes	Yes
1650	2851-MMUTZ	Female	0	No	No
1651	3049-NDXFL	Female	0	No	No
1652	8580-AECUZ	Male	1	No	No
1653	3307-TLCUD	Male	0	Yes	No
1654	6625-FLENO	Male	0	Yes	No
1655	2967-MXRAV	Male	0	Yes	Yes
1656	7963-GQRMY	Female	0	Yes	Yes
1657	8189-HBVRW	Female	0	No	No
1658	4163-KIUHY	Male	0	No	No
1659	1228-FZFRV	Male	0	Yes	Yes
1660	3500-NSDOA	Male	0	Yes	Yes
1661	1171-TYKUR	Male	0	Yes	No
1662	3761-FLYZI	Female	1	Yes	No
1663	2058-DCJBE	Male	0	No	No
1664	5364-XYIRR	Male	0	Yes	No
1665	4829-AUOAX	Female	0	No	No
1666	1219-NNDDO	Female	0	No	No
1667	8388-DMKAE	Female	0	No	No
1668	4403-BWPAY	Male	0	No	No
1669	9659-QEQSY	Female	0	No	No
1670	5405-ZMYXQ	Female	0	No	No
1671	5047-LHVLY	Male	1	No	Yes
1672	1442-OKRJE	Male	0	Yes	Yes
1673	4737-AQCPU	Male	0	Yes	Yes
1674	9158-VCTQB	Female	0	Yes	No
1675	2808-CHTDM	Female	0	Yes	Yes
1676	6311-UEUME	Female	0	No	No
1677	0793-TWELN	Female	0	No	No
1678	3283-WCWXT	Male	0	Yes	Yes
1679	1060-ENTOF	Female	1	Yes	No
1680	0999-QXNSA	Male	1	No	Yes
1681	5451-MHQOF	Male	0	Yes	Yes
1682	4836-WNFNO	Female	0	Yes	No
1683	9225-BZLNZ	Male	0	Yes	No
1684	0354-VXMJC	Male	0	Yes	Yes
1685	4422-QVIJA	Female	0	No	Yes
1686	9365-SRSZE	Male	1	Yes	No
1687	6839-ITVZJ	Female	0	Yes	Yes
1688	8332-OSJDW	Male	0	Yes	Yes
1689	4735-BJKOU	Female	0	No	No
1690	0274-JKUJR	Male	0	Yes	Yes
1691	5740-YHGTW	Male	0	Yes	Yes
1692	8917-SZTTJ	Male	0	Yes	Yes
1693	1696-MZVAU	Male	0	Yes	Yes
1694	7359-WWYJV	Male	0	Yes	No
1695	0375-HVGXO	Female	0	No	No
1696	4906-ZHGPK	Male	0	Yes	Yes
1697	8593-WHYHV	Male	0	No	No
1698	3795-GWTRD	Female	0	Yes	Yes
1699	1298-PHBTI	Male	0	Yes	Yes
1700	6223-DHJGV	Female	0	No	No
1701	6961-MJKBO	Male	0	No	No
1702	6097-EQISJ	Female	0	Yes	Yes
1703	4423-YLHDV	Female	0	Yes	No
1704	8158-WPEZG	Male	0	No	No
1705	0107-YHINA	Male	0	No	Yes
1706	4918-FYJNT	Female	1	Yes	No
1707	0727-BNRLG	Male	0	No	No
1708	4854-CIDCF	Female	1	No	No
1709	8640-SDGKB	Male	0	No	No
1710	3280-MRDOF	Male	1	No	No
1711	6435-SRWBJ	Female	0	No	No
1712	9964-WBQDJ	Female	0	Yes	No
1713	6303-KFWSL	Female	0	No	No
1714	1702-CCFNJ	Male	0	Yes	No
1715	8932-CZHRQ	Male	0	No	No
1716	0386-CWRGM	Female	0	Yes	Yes
1717	5515-RUGKN	Male	0	No	No
1718	0404-AHASP	Male	0	Yes	No
1719	7279-NMVJC	Female	0	No	No
1720	2081-VEYEH	Male	0	No	No
1721	6407-UTSLV	Female	1	No	No
1722	4116-TZAQJ	Female	0	No	No
1723	9060-HJJRW	Female	0	No	No
1724	2587-YNLES	Female	0	Yes	Yes
1725	7398-SKNQZ	Female	0	Yes	No
1726	5935-FCCNB	Female	1	No	No
1727	1958-RNRKS	Male	0	Yes	No
1728	5136-RGMZO	Male	0	No	No
1729	8345-MVDYC	Female	0	No	No
1730	8226-BXGES	Male	0	Yes	No
1731	3877-JRJIP	Male	0	No	No
1732	8375-DKEBR	Female	1	No	No
1733	9705-IOVQQ	Male	1	Yes	Yes
1734	1015-OWJKI	Male	0	No	No
1735	7511-YMXVQ	Male	0	No	No
1736	2040-XBAVJ	Male	0	Yes	Yes
1737	7551-JOHTI	Female	0	No	No
1738	8887-IPQNC	Female	0	Yes	No
1739	8646-JCOMS	Female	0	Yes	No
1740	9804-ICWBG	Male	0	No	No
1741	1222-KJNZD	Male	0	Yes	Yes
1742	0106-GHRQR	Male	0	No	No
1743	5318-IXUZF	Female	0	No	No
1744	3768-VHXQO	Male	0	Yes	No
1745	8952-WCVCD	Female	0	Yes	No
1746	2418-TPEUN	Female	0	Yes	Yes
1747	3963-RYFNS	Female	0	No	No
1748	3198-VELRD	Female	0	Yes	Yes
1749	8540-ZQGEA	Female	0	Yes	No
1750	1320-REHCS	Male	1	No	No
1751	4137-JOPHL	Female	0	No	No
1752	9436-ZBZCT	Male	0	No	No
1753	7801-CEDNV	Male	0	Yes	No
1754	2057-BOYKM	Female	1	Yes	No
1755	3658-QQJYD	Male	0	No	No
1756	1803-BGNBD	Female	0	No	No
1757	0134-XWXCE	Female	1	No	No
1758	6950-TWMYB	Male	0	Yes	Yes
1759	5848-FHRFC	Female	0	No	No
1760	2243-FNMMI	Male	0	No	No
1761	2511-MORQY	Male	0	Yes	Yes
1762	5356-KZCKT	Male	0	No	No
1763	9470-XCCEM	Male	0	Yes	Yes
1764	6519-CFDBX	Female	0	No	No
1765	3902-MIVLE	Male	0	Yes	Yes
1766	0409-WTMPL	Female	0	Yes	No
1767	8763-KIAFH	Female	0	Yes	Yes
1768	3669-WHAFY	Female	0	Yes	No
1769	3055-VTCGS	Female	0	No	No
1770	3144-KMTWZ	Male	0	Yes	No
1771	7279-BUYWN	Female	1	No	No
1772	7156-MHUGY	Male	1	No	No
1773	7198-GLXTC	Male	0	No	No
1774	2007-QVGAW	Female	0	Yes	Yes
1775	5207-PLSTK	Male	0	Yes	Yes
1776	2307-FYNNL	Male	1	No	No
1777	5605-XNWEN	Male	1	Yes	No
1778	2155-AMQRX	Female	0	No	No
1779	6181-AXXYF	Male	0	Yes	Yes
1780	5091-HFAZW	Female	0	No	No
1781	0516-VRYBW	Female	0	No	Yes
1782	2519-LBNQL	Male	1	Yes	No
1783	8623-ULFNQ	Female	1	No	No
1784	8380-PEFPE	Male	0	No	Yes
1785	5687-DKDTV	Female	0	No	No
1786	1568-LJSZU	Male	0	Yes	Yes
1787	7530-HDYDS	Female	0	No	No
1788	7789-HKSBS	Female	1	Yes	No
1789	7416-CKTEP	Female	0	Yes	No
1790	2586-CWXVV	Male	0	Yes	No
1791	3096-IZETN	Female	0	No	No
1792	2348-KCJLT	Female	0	Yes	No
1793	8401-EMUWF	Male	0	Yes	Yes
1794	4193-IBKSW	Male	0	Yes	Yes
1795	5377-NDTOU	Female	0	Yes	Yes
1796	5922-ABDVO	Female	0	Yes	No
1797	2474-LCNUE	Female	0	Yes	No
1798	0839-QNXME	Female	0	No	No
1799	3506-OVLKD	Male	0	No	No
1800	9172-ANCRX	Female	0	No	No
1801	6650-VJONK	Male	0	No	No
1802	2178-PMGCJ	Male	0	No	No
1803	7492-TAFJD	Male	0	Yes	Yes
1804	2773-MADBQ	Female	0	No	No
1805	6016-LVTJQ	Female	0	Yes	Yes
1806	7860-KSUGX	Male	0	Yes	Yes
1807	8966-KZXXA	Male	0	Yes	Yes
1808	6910-HADCM	Female	0	No	No
1809	4816-LXZYW	Female	0	No	No
1810	9606-PBKBQ	Male	1	Yes	No
1811	5149-QYTTU	Female	0	Yes	Yes
1812	2070-XYMFH	Female	1	No	No
1813	2085-BOJKI	Male	0	Yes	No
1814	0817-HSUSE	Male	0	No	No
1815	5442-PPTJY	Male	0	Yes	Yes
1816	1927-QEWMY	Female	0	Yes	No
1817	1663-MHLHE	Male	0	No	No
1818	5663-QBGIS	Male	1	Yes	No
1819	4450-MDZFX	Male	0	Yes	Yes
1820	6701-DHKWQ	Female	0	Yes	Yes
1821	7554-AKDQF	Female	0	Yes	No
1822	3536-IQCTX	Male	1	Yes	No
1823	4911-BANWH	Female	0	No	Yes
1824	8496-EJAUI	Male	0	No	No
1825	0794-YVSGE	Male	0	Yes	Yes
1826	5423-BHIXO	Female	0	No	No
1827	6908-VVYHM	Male	0	Yes	No
1828	2959-EEXWB	Female	0	Yes	Yes
1829	1839-UMACK	Male	0	No	No
1830	3030-YDNRM	Male	0	No	No
1831	7321-KKSDU	Male	0	No	Yes
1832	3402-XRIUO	Female	1	Yes	No
1833	3132-TVFDZ	Male	1	Yes	No
1834	8286-AFUYI	Male	0	No	No
1835	8080-DDEMJ	Male	1	No	No
1836	8356-WUAOJ	Female	0	Yes	No
1837	6365-MTGZX	Male	0	No	No
1838	1349-WXNGG	Male	0	No	No
1839	8058-DMYRU	Male	1	No	No
1840	9350-ZXYJC	Female	0	No	No
1841	6990-YNRIO	Male	0	Yes	Yes
1842	8958-JPTRR	Female	0	Yes	No
1843	6959-GQEGV	Male	0	No	No
1844	3173-WSSUE	Female	0	Yes	Yes
1845	1265-HVPZB	Male	0	Yes	No
1846	4115-UMJFQ	Male	0	No	No
1847	7369-TRPFD	Male	0	No	No
1848	1098-KFQEC	Female	0	Yes	Yes
1849	7190-XHTWJ	Female	0	No	No
1850	0621-TWIEM	Male	0	No	No
1851	3537-RYBHH	Female	1	Yes	No
1852	2485-ITVKB	Female	0	Yes	No
1853	3669-OYSJI	Male	0	No	No
1854	1612-EOHDH	Female	0	No	No
1855	6702-OHFWR	Male	1	No	No
1856	5296-BFCYD	Male	0	Yes	Yes
1857	4510-PYUSH	Female	1	No	No
1858	9359-JANWS	Female	0	Yes	No
1859	7517-SAWMO	Female	0	Yes	No
1860	4143-HHPMK	Male	0	No	No
1861	3279-DYZQM	Male	0	Yes	Yes
1862	7054-LGEQW	Female	0	No	No
1863	0523-VNGTF	Female	1	No	No
1864	9575-IWCAZ	Male	0	Yes	No
1865	7105-MXJLL	Female	1	Yes	No
1866	7064-FRRSW	Male	1	No	No
1867	7940-UQQUG	Female	0	Yes	Yes
1868	0923-PNFUB	Female	0	No	No
1869	3961-SXAXY	Male	0	No	No
1870	7010-BRBUU	Male	0	Yes	Yes
1871	3566-HJGPK	Male	0	No	No
1872	3062-ICYZQ	Female	0	Yes	Yes
1873	9938-PRCVK	Female	0	Yes	Yes
1874	0973-KYVNF	Female	0	Yes	Yes
1875	5129-HHMZC	Female	0	Yes	No
1876	9637-CDTKZ	Male	0	Yes	No
1877	3946-JEWRQ	Male	0	Yes	No
1878	7873-CVMAW	Male	0	No	No
1879	0463-WZZKO	Male	0	No	No
1880	3494-JCHRQ	Male	0	No	No
1881	6474-FVJLC	Male	0	No	No
1882	4524-QCSSM	Male	0	No	No
1883	5832-EXGTT	Male	0	Yes	Yes
1884	8840-DQLGN	Female	1	Yes	No
1885	2039-JONDJ	Male	0	No	No
1886	7217-JYHOQ	Male	0	Yes	Yes
1887	6695-FRVEC	Male	0	Yes	Yes
1888	4547-LYTDD	Female	0	No	No
1889	9894-QMIMJ	Female	0	No	No
1890	8069-YQQAJ	Male	0	No	No
1891	6770-XUAGN	Female	0	Yes	Yes
1892	4193-ORFCL	Female	1	No	No
1893	1636-NTNCO	Male	1	No	No
1894	3466-WAESX	Male	0	No	Yes
1895	9281-PKKZE	Female	0	Yes	No
1896	3638-VBZTA	Male	0	No	Yes
1897	7459-IMVYU	Male	0	No	No
1898	7776-QWNFX	Male	1	Yes	No
1899	6689-TCZHQ	Female	1	No	No
1900	8563-OYMQY	Male	0	No	No
1901	0754-EEBDC	Male	0	Yes	Yes
1902	5777-ZPQNC	Female	0	No	No
1903	1951-IEYXM	Male	0	Yes	Yes
1904	3318-NMQXL	Male	0	No	No
1905	3143-ILDAL	Male	0	No	No
1906	1022-RKXDR	Female	0	No	No
1907	2361-FJWNO	Male	0	No	No
1908	2272-UOINI	Female	0	No	No
1909	8232-UTFOZ	Male	0	No	No
1910	3750-YHRYO	Male	0	Yes	Yes
1911	6637-KYRCV	Female	0	Yes	Yes
1912	5668-MEISB	Female	0	Yes	Yes
1913	0129-QMPDR	Male	0	Yes	Yes
1914	7188-CBBBA	Female	0	No	No
1915	5356-CSVSQ	Female	0	No	No
1916	3221-CJMSG	Male	0	No	No
1917	4720-VSTSI	Female	0	No	No
1918	3219-JQRSL	Female	1	Yes	No
1919	2801-NISEI	Male	0	No	No
1920	3946-MHCZW	Male	0	No	No
1921	4623-ZKHLY	Male	0	Yes	No
1922	6732-VAILE	Male	0	Yes	Yes
1923	8201-AAXCB	Male	0	Yes	Yes
1924	7696-CFTAT	Male	0	Yes	Yes
1925	1845-CSBRZ	Female	1	Yes	Yes
1926	2123-VSCOT	Female	0	Yes	Yes
1927	6651-AZVTJ	Male	0	Yes	Yes
1928	4566-GOLUK	Male	0	Yes	Yes
1929	2484-DGXPZ	Female	0	Yes	Yes
1930	2018-QKYGT	Male	0	Yes	Yes
1931	2792-VPPET	Male	0	No	No
1932	7409-JURKQ	Female	0	Yes	No
1933	3247-MHJKM	Male	0	No	No
1934	1964-SVLEA	Male	0	No	No
1935	4587-NUKOX	Female	0	No	No
1936	7297-DVYGA	Female	0	No	No
1937	2239-CGBUZ	Female	0	Yes	No
1938	0854-UYHZD	Female	0	Yes	Yes
1939	7243-LCGGZ	Female	0	No	No
1940	8267-KFGYD	Male	0	No	Yes
1941	4890-VMUAV	Male	0	No	No
1942	9261-WDCAF	Male	0	No	No
1943	3764-MNMOI	Male	0	No	No
1944	7442-YGZFK	Male	0	No	No
1945	0420-BWTPW	Male	0	No	Yes
1946	8229-BUJHX	Female	0	Yes	Yes
1947	7449-HVPIV	Male	0	Yes	Yes
1948	5504-WSIUR	Female	0	No	No
1949	8183-ONMXC	Female	0	No	No
1950	8466-PZBLH	Male	0	Yes	Yes
1951	9614-RMGHA	Male	0	Yes	No
1952	8735-IJJEG	Male	0	Yes	No
1953	0564-MUUQK	Female	0	Yes	Yes
1954	5054-IEXZT	Male	0	No	Yes
1955	5834-ASPWA	Male	0	No	No
1956	0701-RFGFI	Female	0	Yes	Yes
1957	0019-EFAEP	Female	0	No	No
1958	5619-PTMIK	Female	0	Yes	No
1959	3737-XBQDD	Male	0	No	No
1960	5882-CMAZQ	Female	0	Yes	Yes
1961	5846-QFDFI	Female	0	Yes	Yes
1962	4445-KWOKW	Female	0	No	No
1963	3511-APPBJ	Male	0	No	No
1964	7967-HYCDE	Male	0	No	No
1965	2430-RRYUW	Male	0	No	No
1966	3948-XHGNA	Male	0	No	No
1967	3723-BFBGR	Male	1	No	No
1968	0565-IYCGT	Male	0	No	No
1969	5447-WZAFP	Female	0	No	No
1970	5110-CHOPY	Female	0	No	No
1971	5445-UTODQ	Female	0	Yes	No
1972	4425-OWHWB	Female	0	No	No
1973	7892-QVYKW	Female	0	Yes	Yes
1974	9675-ICXCT	Male	0	Yes	Yes
1975	1024-VRZHF	Male	0	Yes	No
1976	4703-MQYKT	Male	0	No	No
1977	9497-QCMMS	Male	1	No	No
1978	5692-ICXLW	Male	1	No	No
1979	0602-DDUML	Female	0	No	No
1980	2208-MPXIO	Female	0	Yes	Yes
1981	1960-UYCNN	Male	0	No	No
1982	0348-SDKOL	Female	0	Yes	No
1983	3190-FZATL	Male	0	No	Yes
1984	7336-RLLRH	Male	0	Yes	No
1985	4373-MAVJG	Female	0	Yes	Yes
1986	8901-HJXTF	Female	0	Yes	Yes
1987	7710-JSYOA	Female	0	Yes	Yes
1988	5419-KLXBN	Female	0	Yes	Yes
1989	3424-NMNBO	Male	1	Yes	No
1990	9885-MFVSU	Female	0	Yes	Yes
1991	4514-GFCFI	Female	1	No	No
1992	0607-MVMGC	Male	0	Yes	Yes
1993	3365-SAIGS	Female	0	No	No
1994	9828-AOQLM	Female	0	Yes	Yes
1995	8022-BECSI	Male	0	No	No
1996	8000-REIQB	Female	1	No	No
1997	9993-LHIEB	Male	0	Yes	Yes
1998	0266-CLZKZ	Female	0	Yes	Yes
1999	7615-ESMYF	Female	0	Yes	No
2000	3858-VOBET	Male	0	No	No
2001	7020-OZKXZ	Female	1	No	No
2002	3977-QCRSL	Female	0	No	No
2003	0017-DINOC	Male	0	No	No
2004	1447-PJGGA	Female	0	No	No
2005	8565-CLBZW	Male	0	No	No
2006	9139-WQQDY	Female	0	Yes	Yes
2007	0224-HJAPT	Male	0	No	No
2008	8086-OVPWV	Male	0	No	No
2009	9430-FRQOC	Female	0	No	Yes
2010	7639-OPLNG	Male	0	Yes	Yes
2011	3074-GQWYX	Male	0	No	No
2012	1492-QGCLU	Male	0	Yes	Yes
2013	6845-RGTYS	Female	0	Yes	No
2014	7328-OWMOM	Female	0	No	Yes
2015	4418-LZMSV	Male	0	Yes	Yes
2016	5155-AZQPB	Female	0	Yes	Yes
2017	8861-HGGKB	Female	0	No	No
2018	1087-GRUYI	Male	0	Yes	No
2019	7065-YUNRY	Female	0	No	No
2020	7694-VLBWQ	Male	0	Yes	No
2021	2546-KZAAT	Male	0	Yes	No
2022	0181-RITDD	Male	0	Yes	Yes
2023	5989-PGKJB	Female	0	No	No
2024	4795-KTRTH	Female	1	Yes	No
2025	8272-ONJLV	Male	0	No	No
2026	1488-PBLJN	Female	0	Yes	Yes
2027	0308-GIQJT	Male	1	No	No
2028	3778-FOAQW	Female	0	Yes	No
2029	4452-ROHMO	Female	0	No	No
2030	6481-OGDOO	Male	0	Yes	No
2031	3090-LETTY	Male	0	No	Yes
2032	5349-AZPEW	Female	0	Yes	Yes
2033	3753-TSEMP	Female	0	Yes	No
2034	8305-VHZBZ	Male	0	No	No
2035	9720-JJJOR	Male	0	Yes	Yes
2036	8100-HZZLJ	Female	0	No	Yes
2037	8775-ERLNB	Male	1	Yes	No
2038	8309-IEYJD	Female	1	No	No
2039	9172-JITSM	Female	0	Yes	Yes
2040	6298-QDFNH	Male	0	No	No
2041	7398-HPYZQ	Male	0	Yes	No
2042	3546-GHEAE	Male	0	No	No
2043	7361-YPXFS	Female	1	No	No
2044	6557-BZXLQ	Male	1	No	No
2045	2550-QHZGP	Male	0	No	No
2046	7519-JTWQH	Female	0	No	No
2047	2538-OIMXF	Female	0	No	Yes
2048	8543-MSDMF	Male	0	No	No
2049	9961-JBNMK	Male	1	No	No
2050	1170-SASML	Female	0	Yes	No
2051	4872-JCVCA	Female	0	Yes	No
2052	5346-BZCHP	Female	0	Yes	Yes
2053	2038-LLMLM	Female	0	No	No
2054	6173-ITPWD	Male	0	Yes	No
2055	9734-UYXQI	Female	0	No	No
2056	1216-BGTSP	Male	0	No	No
2057	4138-NAXED	Male	0	No	No
2058	2189-UXTKY	Female	0	Yes	No
2059	0744-BIKKF	Male	0	No	No
2060	7483-IQWIB	Male	0	Yes	Yes
2061	5248-KWLAR	Male	0	Yes	Yes
2062	4958-GZWIY	Male	0	Yes	Yes
2063	7996-MHXLW	Female	0	No	No
2064	7833-PKIHD	Male	0	Yes	Yes
2065	7061-OVMIM	Female	0	Yes	Yes
2066	5153-RTHKF	Female	0	No	No
2067	1852-QSWCD	Male	0	Yes	Yes
2068	4832-VRBMR	Male	1	Yes	No
2069	9079-LWTFD	Male	0	No	No
2070	6356-ELRKD	Female	0	No	No
2071	8624-GIOUT	Female	0	No	No
2072	3392-EHMNK	Female	0	Yes	Yes
2073	5986-WWXDV	Male	0	No	Yes
2074	3061-BCKYI	Male	0	No	No
2075	6179-GJPSO	Female	1	No	No
2076	7901-TBKJX	Male	1	No	No
2077	7228-PAQPD	Female	0	No	No
2078	3177-LASXD	Female	0	No	No
2079	7746-QYVCO	Male	0	Yes	Yes
2080	5804-HYIEZ	Male	0	Yes	Yes
2081	9919-FZDED	Male	1	Yes	No
2082	5934-TSSAU	Female	0	Yes	Yes
2083	3486-KHMLI	Male	0	No	Yes
2084	4897-QSUYC	Female	0	No	No
2085	1084-UQCHV	Male	0	No	Yes
2086	8290-YWKHZ	Female	1	Yes	No
2087	2955-BJZHG	Male	0	Yes	Yes
2088	3806-DXQOM	Female	0	No	No
2089	6784-XYJAE	Female	0	No	No
2090	3933-DQPWX	Female	0	No	No
2091	6661-EIPZC	Female	0	Yes	Yes
2092	8957-THMOA	Female	0	No	Yes
2093	2251-PYLPB	Male	0	Yes	No
2094	5555-RNPGT	Male	0	No	Yes
2095	1057-FOGLZ	Female	0	No	No
2096	9300-RENDD	Male	0	No	No
2097	0761-AETCS	Female	0	No	No
2098	8087-LGYHQ	Male	0	No	No
2099	4137-BTIKL	Male	0	No	No
2100	2190-BCXEC	Female	0	Yes	No
2101	6227-FBDXH	Male	0	Yes	No
2102	2153-MREFK	Female	0	Yes	No
2103	2911-WDXMV	Male	0	No	Yes
2104	7206-PQBBZ	Male	1	Yes	No
2105	3106-ULWFW	Female	0	Yes	No
2106	0925-VYDLG	Female	0	No	No
2107	4547-FZJWE	Male	0	Yes	Yes
2108	7422-WNBTY	Male	0	Yes	No
2109	0842-IWYCP	Female	0	No	No
2110	3521-HTQTV	Male	0	No	No
2111	3744-ZBHON	Female	0	No	No
2112	3373-DIUUN	Male	0	Yes	Yes
2113	8383-SGHJU	Female	0	No	No
2114	7607-QKKTJ	Male	0	Yes	Yes
2115	7707-PYBBH	Male	0	No	No
2116	8984-HPEMB	Female	0	No	No
2117	4349-GFQHK	Male	0	No	No
2118	4139-DETXS	Female	0	Yes	Yes
2119	9779-DPNEJ	Female	0	Yes	Yes
2120	9805-FILKB	Male	0	Yes	Yes
2121	5793-YOLJN	Female	0	Yes	Yes
2122	0673-IGUQO	Male	0	No	No
2123	4123-FCVCB	Female	0	No	No
2124	8819-IMISP	Male	0	No	No
2125	7802-EFKNY	Male	0	Yes	No
2126	8311-UEUAB	Female	0	Yes	Yes
2127	5858-EAFCZ	Male	0	No	No
2128	8035-BUYVG	Male	0	Yes	No
2129	1163-ONYEY	Male	0	Yes	Yes
2130	9787-XVQIU	Male	0	No	No
2131	8945-MUQUF	Male	0	No	No
2132	5656-MJEFC	Male	0	Yes	Yes
2133	6082-OQFBA	Male	0	Yes	Yes
2134	8051-HJRLT	Female	1	No	No
2135	8974-OVACP	Female	0	No	No
2136	4010-YLMVT	Female	0	No	No
2137	1379-FRVEB	Male	0	No	Yes
2138	8612-GXIDD	Male	0	Yes	Yes
2139	6288-CHQJB	Female	0	Yes	Yes
2140	8160-HOWOX	Female	0	No	No
2141	3023-GFLBR	Female	0	Yes	Yes
2142	6648-INWPS	Male	0	Yes	Yes
2143	4223-BKEOR	Female	0	No	Yes
2144	4079-VTGLK	Male	1	Yes	No
2145	1763-WQFUK	Male	0	No	No
2146	1391-UBDAR	Male	0	No	No
2147	8894-JVDCV	Female	0	No	No
2148	2023-VQFDL	Male	0	No	No
2149	1345-GKDZZ	Male	0	No	Yes
2150	2014-MKGMH	Female	0	No	No
2151	5628-FCGYG	Male	0	No	No
2152	2560-WBWXF	Male	0	No	No
2153	0248-IPDFW	Female	0	No	No
2154	7978-DKUQH	Female	0	Yes	No
2155	4335-UPJSI	Female	0	No	Yes
2156	0524-IAVZO	Female	0	Yes	No
2157	2737-YNGYW	Female	0	No	No
2158	1784-EZDKJ	Male	0	Yes	No
2159	9297-FVVDH	Female	0	Yes	Yes
2160	8007-YYPWD	Female	0	No	No
2161	7101-HRBLJ	Female	0	Yes	Yes
2162	5159-YFPKQ	Female	0	No	No
2163	6635-CPNUN	Male	0	Yes	No
2164	4021-RQSNY	Male	1	Yes	No
2165	5453-YBTWV	Male	0	Yes	Yes
2166	5039-LZRQT	Female	0	No	No
2167	2931-VUVJN	Female	1	Yes	No
2168	9061-TIHDA	Male	1	Yes	No
2169	8699-ASUFO	Male	1	Yes	No
2170	6418-PIQSP	Female	0	Yes	No
2171	8220-OCUFY	Female	0	No	No
2172	3995-WFCSM	Female	0	No	No
2173	1895-QTKDO	Female	0	No	No
2174	2038-OEQZH	Male	0	No	No
2175	1178-PZGAB	Female	0	No	No
2176	7927-AUXBZ	Female	0	No	No
2177	2626-VEEWG	Male	0	Yes	Yes
2178	2878-RMWXY	Male	1	Yes	No
2179	1657-DYMBM	Male	0	Yes	No
2180	7311-MQJCH	Female	0	No	No
2181	7375-WMVMT	Male	1	Yes	No
2182	1136-XGEQU	Female	0	Yes	Yes
2183	2530-FMFXO	Male	0	Yes	Yes
2184	6844-DZKRF	Male	0	No	No
2185	4695-WJZUE	Female	1	No	No
2186	7619-ODSGN	Male	0	Yes	Yes
2187	5970-GHJAW	Male	0	Yes	Yes
2188	8879-XUAHX	Male	0	Yes	No
2189	3689-MOZGR	Female	0	No	No
2190	4195-PNGZS	Male	0	Yes	Yes
2191	5003-XZWWO	Male	0	Yes	No
2192	3988-RQIXO	Female	1	No	No
2193	7622-FWGEW	Male	1	Yes	No
2194	6922-NCEDI	Male	0	No	Yes
2195	2514-GINMM	Male	0	No	No
2196	9891-NQDBD	Female	0	Yes	No
2197	6131-IUNXN	Female	0	Yes	Yes
2198	8548-AWOFC	Male	0	Yes	No
2199	9798-DRYDS	Female	0	Yes	Yes
2200	8532-UEFWH	Male	0	Yes	Yes
2201	6296-DDOOR	Female	0	No	No
2202	7951-VRDVK	Female	0	No	No
2203	5931-FLJJF	Male	1	Yes	No
2204	4815-YOSUK	Male	0	Yes	Yes
2205	2659-VXMWZ	Male	0	Yes	Yes
2206	0380-NEAVX	Male	1	No	No
2207	3207-OYBWH	Male	1	Yes	No
2208	4285-GYRQC	Female	0	Yes	No
2209	7216-EWTRS	Female	1	Yes	No
2210	4365-MSDYN	Male	0	Yes	No
2211	7036-TYDEC	Female	0	No	No
2212	5802-ADBRC	Female	0	Yes	No
2213	8076-FEZKJ	Male	0	No	No
2214	5197-YPYBZ	Female	0	Yes	Yes
2215	8337-MSSXB	Female	0	No	No
2216	4312-GVYNH	Female	0	Yes	No
2217	8495-LJDFO	Female	1	No	No
2218	0839-JTCUD	Female	0	Yes	Yes
2219	5494-WOZRZ	Female	0	Yes	Yes
2220	1302-UHBDD	Male	1	No	No
2221	2234-EOFPT	Male	0	Yes	No
2222	8619-IJNDK	Female	0	Yes	Yes
2223	8378-LKJAF	Male	0	Yes	Yes
2224	8182-BJDSI	Female	0	No	No
2225	2528-HFYZX	Male	1	Yes	No
2226	1153-GNOLC	Male	0	No	No
2227	3298-QEICA	Female	0	Yes	Yes
2228	0788-DXBFY	Male	0	Yes	Yes
2229	3597-YASZG	Female	1	Yes	No
2230	3496-LFSZU	Male	0	Yes	No
2231	5242-UOWHD	Male	0	Yes	Yes
2232	2482-CZGBB	Male	0	No	No
2233	6479-SZPLM	Male	0	Yes	Yes
2234	8097-VBQTZ	Male	0	No	No
2235	4500-HKANN	Male	0	Yes	Yes
2236	9917-KWRBE	Female	0	Yes	Yes
2237	3420-ZDBMA	Male	1	No	No
2238	2212-LYASK	Male	0	Yes	Yes
2239	1393-IMKZG	Female	0	No	No
2240	8069-RHUXK	Female	0	Yes	Yes
2241	3398-GCPMU	Female	1	Yes	Yes
2242	2908-WGAXL	Female	0	Yes	Yes
2243	3378-AJRAO	Male	0	Yes	Yes
2244	1013-QCWAM	Female	1	Yes	No
2245	0866-QLSIR	Female	0	No	No
2246	6050-FFXES	Female	0	Yes	No
2247	7181-BQYBV	Female	0	Yes	Yes
2248	0362-RAOQO	Female	0	No	No
2249	9554-DFKIC	Male	0	Yes	Yes
2250	5527-ACHSO	Female	0	No	No
2251	0829-DDVLK	Female	0	No	No
2252	1399-UBQIU	Male	0	No	No
2253	1813-JLKWR	Female	0	Yes	Yes
2254	0336-PIKEI	Male	1	Yes	No
2255	7322-OCWHC	Male	1	Yes	No
2256	9537-VHDTA	Female	0	No	Yes
2257	4957-TIALW	Female	0	No	Yes
2258	2054-PJOCK	Female	0	No	No
2259	9150-HEPMB	Male	0	No	No
2260	9030-QGZNL	Female	0	No	No
2261	6204-IEUXJ	Female	0	No	No
2262	3126-WQMGH	Female	0	Yes	No
2263	4529-CKBCL	Female	0	No	No
2264	2506-CLAKW	Female	0	No	No
2265	7176-WRTNX	Male	0	No	No
2266	1583-IHQZE	Male	0	No	No
2267	5732-IKGQH	Male	1	Yes	No
2268	9239-GZHZE	Female	0	Yes	No
2269	7205-BAIAD	Female	0	No	No
2270	0151-ONTOV	Female	0	No	No
2271	4140-MUHUG	Female	1	No	No
2272	0093-EXYQL	Female	1	No	No
2273	8064-RAVOH	Male	0	No	Yes
2274	0219-QAERP	Male	0	Yes	No
2275	0320-JDNQG	Male	0	Yes	Yes
2276	7180-PISOG	Male	0	Yes	Yes
2277	9168-INPSZ	Female	1	Yes	No
2278	3571-RFHAR	Male	0	No	No
2279	0015-UOCOJ	Female	1	No	No
2280	5334-AFQJB	Male	1	No	No
2281	2754-SDJRD	Female	1	No	No
2282	9578-VRMNM	Female	0	No	No
2283	1587-FKLZB	Male	1	Yes	Yes
2284	6140-QNRQQ	Male	0	No	No
2285	8963-JLGJT	Male	0	No	Yes
2286	4307-KTUMW	Male	0	Yes	No
2287	1465-LNTLJ	Male	1	Yes	No
2288	5440-FLBQG	Male	1	Yes	No
2289	2135-DQWAQ	Female	0	No	No
2290	4056-QHXHZ	Female	0	Yes	Yes
2291	7470-MCQTK	Female	0	Yes	No
2292	7488-MXJIV	Female	0	No	No
2293	7401-JIXNM	Female	0	Yes	Yes
2294	9339-FIIJL	Male	0	Yes	No
2295	2027-FECZV	Male	0	No	No
2296	2672-DZUOY	Male	0	No	No
2297	4706-DGAHW	Male	1	No	No
2298	3870-MQAMG	Female	0	Yes	No
2299	6670-MFRPK	Male	0	Yes	Yes
2300	6177-PEVRA	Female	0	No	No
2301	4800-CZMPC	Female	0	Yes	Yes
2302	4813-HQMGZ	Female	0	Yes	No
2303	7579-KKLOE	Male	0	Yes	Yes
2304	7377-DMMRI	Male	0	No	No
2305	8402-EIVQS	Male	0	Yes	No
2306	4947-DSMXK	Male	0	Yes	Yes
2307	7245-NIIWQ	Female	0	No	No
2308	0002-ORFBO	Female	0	Yes	Yes
2309	3324-OIRTO	Male	0	Yes	Yes
2310	5414-OFQCB	Male	0	No	No
2311	4967-WPNCF	Male	0	No	No
2312	8552-OBVRU	Female	1	Yes	Yes
2313	8499-BRXTD	Male	0	No	No
2314	9154-QDGTH	Male	0	Yes	Yes
2315	8197-BFWVU	Female	0	Yes	Yes
2316	2577-GVSIL	Male	0	Yes	Yes
2317	9367-OIUXP	Male	0	No	No
2318	6770-UAYGJ	Female	0	Yes	Yes
2319	6463-HHXJR	Female	0	Yes	Yes
2320	7928-VJYAB	Male	0	Yes	Yes
2321	1187-WILMM	Male	0	Yes	Yes
2322	9776-OJUZI	Female	1	No	No
2323	1306-RPWXZ	Female	0	No	Yes
2324	8949-JTMAY	Female	0	No	No
2325	2774-LVQUS	Female	1	Yes	No
2326	3097-PYWXL	Female	0	Yes	Yes
2327	2266-SJNAT	Female	0	Yes	No
2328	0869-PAPRP	Female	1	Yes	No
2329	4238-JSSWH	Female	1	Yes	No
2330	2972-YDYUW	Female	0	No	No
2331	1104-FEJAM	Male	0	Yes	Yes
2332	2809-ILCYT	Female	0	Yes	No
2333	5499-ECUTN	Female	0	Yes	No
2334	4981-FLTMF	Female	0	Yes	Yes
2335	9121-PHQSR	Male	1	Yes	No
2336	3113-IWHLC	Male	0	No	No
2337	3211-ILJTT	Male	0	Yes	No
2338	4612-THJBS	Female	1	No	No
2339	4277-BWBML	Male	0	Yes	Yes
2340	4094-NSEDU	Female	1	No	No
2341	0234-TEVTT	Female	0	Yes	Yes
2342	4304-TSPVK	Female	0	Yes	No
2343	1552-AAGRX	Female	0	No	No
2344	2637-FKFSY	Female	0	Yes	No
2345	9796-MVYXX	Female	1	No	No
2346	7874-ECPQJ	Female	0	No	Yes
2347	0020-INWCK	Female	0	Yes	Yes
2348	7089-RKVSZ	Male	0	Yes	Yes
2349	2683-JXWQQ	Male	0	Yes	Yes
2350	9548-ZMVTX	Male	0	Yes	Yes
2351	8739-XNIKG	Female	0	No	No
2352	9755-JHNMN	Female	0	No	No
2353	3981-QSVQI	Male	0	No	No
2354	2789-HQBOU	Male	0	No	No
2355	9424-CMPOG	Male	0	Yes	Yes
2356	5067-WJEUN	Male	0	Yes	Yes
2357	3450-WXOAT	Male	0	No	No
2358	9251-WNSOD	Female	0	Yes	No
2359	6974-DAFLI	Female	0	Yes	No
2360	2616-UUTFK	Male	0	Yes	No
2361	7064-JHXCE	Male	0	Yes	Yes
2362	5103-MHMHY	Female	0	No	Yes
2363	7989-AWGEH	Male	0	Yes	Yes
2364	4373-VVHQL	Male	0	No	No
2365	4559-UWIHT	Male	0	Yes	No
2366	7268-IGMFD	Male	1	No	No
2367	1846-XWOQN	Female	1	No	No
2368	0235-KGSLC	Female	0	No	No
2369	6650-BWFRT	Female	0	Yes	No
2370	9570-KYEUA	Male	0	No	No
2371	6993-YGFJV	Male	0	Yes	No
2372	2712-SYWAY	Female	0	No	No
2373	0730-BGQGF	Male	0	Yes	Yes
2374	5498-IBWPI	Female	0	Yes	Yes
2375	9101-NTIXF	Male	0	No	No
2376	0013-SMEOE	Female	1	Yes	No
2377	9314-QDMDW	Male	0	No	No
2378	9308-ANMVE	Male	0	No	Yes
2379	2884-GBPFB	Female	0	Yes	No
2380	3757-NJYBX	Male	1	Yes	No
2381	3413-DHLPB	Male	0	Yes	Yes
2382	7649-PHJVR	Male	0	No	No
2383	6114-TCFID	Female	0	No	No
2384	3787-TRIAL	Male	0	Yes	Yes
2385	2573-GYRUU	Male	1	Yes	No
2386	5156-UMKOW	Female	0	No	Yes
2387	1247-QBVSH	Female	0	Yes	Yes
2388	6734-GMPVK	Male	0	No	No
2389	9822-OAOVB	Female	0	No	No
2390	6161-ERDGD	Male	0	Yes	Yes
2391	1226-JZNKR	Female	0	Yes	Yes
2392	7318-EIVKO	Male	0	No	No
2393	3771-PZOBW	Male	0	No	No
2394	5136-KCKGI	Female	0	Yes	Yes
2395	8231-BSWXX	Male	0	No	No
2396	6486-LHTMA	Female	1	Yes	No
2397	4083-BFNYK	Female	1	Yes	No
2398	3722-WPXTK	Male	0	No	No
2399	7389-KBFIT	Female	0	Yes	Yes
2400	7176-WIONM	Female	0	Yes	No
2401	5141-ZUVBH	Female	0	No	Yes
2402	1089-HDMKP	Male	1	No	Yes
2403	7623-HKYRK	Male	0	No	Yes
2404	0310-SUCIN	Female	0	Yes	No
2405	5197-PYEPU	Female	0	Yes	Yes
2406	2929-ERCFZ	Female	0	Yes	Yes
2407	7548-SEPYI	Female	0	No	No
2408	8835-VSDSE	Female	0	Yes	No
2409	6619-RPLQZ	Female	0	Yes	Yes
2410	3275-RHRNE	Male	0	Yes	Yes
2411	3503-TYDAY	Female	0	Yes	No
2412	6901-GOGZG	Male	0	No	Yes
2413	1623-NLDOT	Female	0	Yes	No
2414	7021-XSNYE	Male	0	Yes	Yes
2415	9621-OUPYD	Female	0	Yes	No
2416	9898-KZQDZ	Female	1	Yes	Yes
2417	8982-NHAVY	Male	0	No	No
2418	4307-KWMXE	Male	0	No	No
2419	0141-YEAYS	Female	1	No	No
2420	2450-ZKEED	Female	0	No	No
2421	3694-DELSO	Male	0	Yes	Yes
2422	3893-JRNFS	Male	0	No	No
2423	9603-OAIHC	Male	1	No	No
2424	1133-KXCGE	Female	0	No	No
2425	5236-PERKL	Female	0	No	No
2426	0142-GVYSN	Male	0	No	No
2427	1049-FYSYG	Female	0	Yes	No
2428	7854-FOKSF	Male	0	No	No
2429	2519-FAKOD	Male	0	No	Yes
2430	8406-LNMHF	Male	1	Yes	No
2431	1821-BUCWY	Male	0	No	No
2432	8263-JQAIK	Male	1	No	No
2433	0023-UYUPN	Female	1	Yes	No
2434	8314-DPQHL	Male	0	No	No
2435	1465-WCZVT	Female	0	Yes	Yes
2436	9481-SFCQY	Female	0	No	Yes
2437	6360-SVNWV	Female	1	No	No
2438	0567-GGCAC	Female	0	No	No
2439	7089-IVVAZ	Female	0	No	No
2440	8884-MRNSU	Male	0	Yes	Yes
2441	2171-UDMFD	Male	0	Yes	Yes
2442	9050-IKDZA	Female	1	No	No
2443	2205-YMZZJ	Male	1	No	No
2444	9802-CAQUT	Female	0	Yes	Yes
2445	1254-IZEYF	Female	1	No	No
2446	0187-WZNAB	Female	0	Yes	Yes
2447	9492-TOKRI	Female	0	No	No
2448	1475-VWVDO	Male	0	No	No
2449	9221-OTIVJ	Female	1	No	No
2450	1357-MVDOZ	Male	0	Yes	Yes
2451	7602-MVRMB	Female	0	Yes	Yes
2452	3325-FUYCG	Male	0	Yes	Yes
2453	5908-QMGOE	Male	1	No	No
2454	1197-BVMVG	Female	1	No	No
2455	5406-KGRMX	Female	0	No	No
2456	8481-YYXWG	Female	0	No	No
2457	5968-HYJRZ	Male	0	Yes	Yes
2458	5198-EFNBM	Male	1	Yes	No
2459	7516-GMHUV	Male	1	Yes	No
2460	7140-ADSMJ	Male	0	No	No
2461	2230-XTUWL	Female	0	Yes	Yes
2462	7706-YLMQA	Female	0	No	No
2463	2585-KTFRE	Male	0	No	Yes
2464	7994-UYIVZ	Male	0	Yes	No
2465	2609-IAICY	Female	0	No	No
2466	1740-CSDJP	Male	0	No	No
2467	7717-BICXI	Male	0	Yes	Yes
2468	6559-RAKOZ	Male	0	Yes	Yes
2469	2636-OHFMN	Male	0	Yes	No
2470	4716-MRVEN	Female	0	No	No
2471	2143-LJULT	Female	0	Yes	No
2472	1323-OOEPC	Female	0	Yes	No
2473	3200-MNQTF	Male	0	Yes	No
2474	6164-HXUGH	Female	0	Yes	Yes
2475	5630-IXDXV	Female	0	No	No
2476	0320-DWVTU	Female	0	No	No
2477	9135-MGVPY	Male	0	Yes	No
2478	1212-GLHMD	Male	0	No	No
2479	7878-JGDKK	Male	0	No	No
2480	1088-AUUZZ	Male	0	Yes	Yes
2481	0397-GZBBC	Male	1	Yes	No
2482	6614-YWYSC	Male	1	Yes	No
2483	9588-OZDMQ	Female	0	Yes	No
2484	7641-EUYET	Male	1	Yes	Yes
2485	6476-EPYZR	Male	0	Yes	Yes
2486	9921-ZVRHG	Female	0	No	No
2487	1174-FGIFN	Female	0	Yes	Yes
2488	6620-HVDUJ	Male	0	No	No
2489	4701-MLJPN	Male	0	No	No
2490	1032-MAELW	Female	0	Yes	Yes
2491	7641-TQFHN	Male	0	No	Yes
2492	1552-TKMXS	Female	0	Yes	No
2493	9206-GVPEQ	Male	0	Yes	No
2494	8622-ZLFKO	Female	0	Yes	No
2495	1596-BBVTG	Male	0	No	No
2496	6188-UXBBR	Female	0	Yes	No
2497	2333-KWEWW	Male	0	No	No
2498	5702-SKUOB	Female	0	Yes	No
2499	1134-YWTYF	Male	0	Yes	No
2500	6061-GWWAV	Male	0	No	Yes
2501	0679-TDGAK	Male	0	Yes	Yes
2502	6585-WCEWR	Male	0	Yes	Yes
2503	9067-YGSCA	Female	0	No	No
2504	9067-SQTNS	Male	0	Yes	Yes
2505	8433-WXGNA	Male	0	No	No
2506	1776-SPBWV	Female	0	Yes	Yes
2507	8735-SDUFN	Female	1	Yes	No
2508	9668-PUGNU	Male	0	Yes	No
2509	9405-GPBBG	Female	0	No	No
2510	1926-QUZNN	Female	0	Yes	No
2511	3707-GNWHM	Male	0	No	No
2512	7016-NVRIC	Male	1	Yes	No
2513	5829-NVSQN	Female	0	Yes	No
2514	9565-AXSMR	Male	0	Yes	Yes
2515	8922-LIEGH	Female	1	No	No
2516	8869-LIHMK	Female	0	No	No
2517	8245-UMPYT	Female	1	No	No
2518	5186-SAMNZ	Male	1	No	No
2519	0447-RXSGD	Male	0	No	No
2520	4927-WWOOZ	Male	0	Yes	No
2521	5788-YPOEG	Female	0	Yes	Yes
2522	5373-SFODM	Male	1	Yes	No
2523	0661-KBKPA	Male	0	Yes	Yes
2524	9081-WWXKP	Female	0	Yes	Yes
2525	0784-ZQJZX	Male	0	No	Yes
2526	3133-PZNSR	Male	0	Yes	Yes
2527	5766-ZJYBB	Male	0	No	No
2528	8931-GJJIQ	Female	0	No	No
2529	4277-PVRAN	Female	0	No	No
2530	0022-TCJCI	Male	1	No	No
2531	0722-SVSFK	Female	0	No	No
2532	3612-YVGSJ	Female	0	Yes	No
2533	9825-YCXWZ	Female	1	No	No
2534	5397-NSKQG	Male	0	Yes	Yes
2535	8565-HBFNN	Male	0	Yes	No
2536	2000-DHJUY	Female	1	Yes	No
2537	0203-HHYIJ	Male	0	No	No
2538	8670-ERCJH	Male	0	No	No
2539	7758-UJWYS	Male	0	Yes	Yes
2540	2050-ONYDQ	Female	0	Yes	Yes
2541	7055-JCGNI	Female	0	No	No
2542	0739-UUAJR	Female	0	Yes	Yes
2543	4826-DXMUP	Male	0	No	Yes
2544	0952-KMEEH	Male	0	No	No
2545	7285-KLOTR	Female	0	Yes	No
2546	0654-PQKDW	Female	0	Yes	Yes
2547	7175-NTIXE	Female	0	No	No
2548	7963-SHNDT	Female	0	No	No
2549	9796-BPKIW	Male	1	No	No
2550	0188-GWFLE	Male	0	No	No
2551	8129-GMVGI	Female	0	Yes	Yes
2552	2882-DDZPG	Female	0	No	No
2553	3547-LQRIK	Female	0	Yes	No
2554	9137-NOQKA	Male	1	No	No
2555	5843-TTHGI	Female	0	No	No
2556	1849-RJYIG	Female	0	No	No
2557	8868-GAGIO	Male	0	Yes	No
2558	4061-UKJWL	Male	0	No	No
2559	5380-XPJNZ	Female	0	No	No
2560	8263-QMNTJ	Male	0	Yes	No
2561	8178-EYZUO	Male	0	No	No
2562	3230-JCNZS	Female	0	Yes	Yes
2563	0277-ORXQS	Male	0	Yes	Yes
2564	5130-IEKQT	Male	1	No	No
2565	3230-WYKIR	Male	0	No	No
2566	7996-BPXHY	Female	0	Yes	Yes
2567	3227-WLKLI	Female	0	Yes	Yes
2568	0407-BDJKB	Male	0	Yes	No
2569	2266-FUBDZ	Male	0	Yes	Yes
2570	8237-ULIXL	Female	0	Yes	No
2571	9600-UDOPK	Male	0	Yes	No
2572	8216-AZUUZ	Female	0	Yes	Yes
2573	9153-BTBVV	Female	0	Yes	No
2574	4074-SJFFA	Female	0	No	No
2575	3269-ATYWD	Male	1	No	No
2576	5186-PEIZU	Female	0	No	No
2577	1074-AMIOH	Female	0	Yes	Yes
2578	4910-GMJOT	Female	0	No	No
2579	0354-WYROK	Female	1	Yes	Yes
2580	4361-FEBGN	Male	0	No	No
2581	7748-UMTRK	Female	1	No	Yes
2582	0380-ZCSBI	Male	0	No	No
2583	7145-FEJWU	Female	0	No	Yes
2584	6463-MVYRY	Female	1	No	No
2585	3969-JQABI	Female	0	Yes	No
2586	9624-EGDEQ	Female	0	No	No
2587	1051-EQPZR	Female	0	Yes	Yes
2588	5849-ASHZJ	Male	0	No	Yes
2589	5780-INQIK	Female	0	No	No
2590	7576-OYWBN	Male	1	No	No
2591	4526-ZJJTM	Female	1	Yes	No
2592	8384-FZBJK	Female	0	Yes	Yes
2593	3750-RNQKR	Female	0	No	No
2594	0962-CQPWQ	Female	0	Yes	Yes
2595	3096-YXENJ	Female	0	Yes	No
2596	1265-BCFEO	Female	0	Yes	No
2597	5837-LXSDN	Female	0	Yes	Yes
2598	5945-AZYHT	Male	0	Yes	No
2599	8325-QRPZR	Female	0	No	No
2600	6384-VMJHP	Female	0	No	No
2601	2262-SLNVK	Female	0	No	No
2602	7730-CLDSV	Female	0	Yes	Yes
2603	1135-HIORI	Female	0	Yes	Yes
2604	0164-APGRB	Female	0	No	No
2605	6481-ESCNL	Female	0	No	No
2606	1790-NESIO	Female	0	No	No
2607	1550-EENBN	Female	0	No	No
2608	5539-TMZLF	Male	1	No	No
2609	4323-SADQS	Male	0	Yes	Yes
2610	4446-BZKHU	Male	0	Yes	No
2611	5202-IVJNU	Female	0	No	Yes
2612	5976-JCJRH	Male	0	Yes	No
2613	8198-RKSZG	Female	0	Yes	Yes
2614	0137-OCGAB	Female	0	No	No
2615	3351-NQLDI	Female	0	Yes	Yes
2616	9297-EONCV	Female	0	No	No
2617	7593-JNWRU	Male	0	Yes	Yes
2618	4588-YBNIB	Female	0	No	No
2619	1069-QJOEE	Male	0	Yes	Yes
2620	3336-JORSO	Female	1	No	No
2621	7799-DSEWS	Male	0	No	No
2622	8766-PAFNE	Male	0	Yes	No
2623	5315-CKEQK	Male	1	Yes	Yes
2624	3130-ICDUP	Female	0	No	Yes
2625	0820-FNRNX	Male	0	Yes	Yes
2626	0880-FVFWF	Male	0	No	No
2627	4611-ANLQC	Female	0	Yes	No
2628	4213-HKBJO	Female	0	No	No
2629	2792-LSHWX	Female	0	No	No
2630	5028-GZLDO	Male	0	No	No
2631	0014-BMAQU	Male	0	Yes	No
2632	6861-XWTWQ	Male	1	Yes	No
2633	9018-PCIOK	Female	0	No	No
2634	4837-QUSFT	Female	0	Yes	No
2635	6877-TJMBR	Male	0	Yes	No
2636	9953-ZMKSM	Male	0	No	No
2637	0907-HQNTS	Female	1	Yes	No
2638	7665-NKLAV	Female	0	Yes	Yes
2639	6769-DCQLI	Male	0	No	No
2640	2433-KMEAS	Male	0	No	No
2641	4391-LNRXK	Male	0	No	No
2642	8250-ZNGGW	Female	1	No	No
2643	2195-ZRVAX	Female	0	Yes	No
2644	3550-SAHFP	Female	0	No	No
2645	2011-TRQYE	Male	0	No	No
2646	8562-GHPPI	Female	0	No	No
2647	5893-PYOLZ	Male	0	No	No
2648	4986-MXSFP	Female	0	No	No
2649	6131-FOYAS	Male	0	No	No
2650	3027-YNWZU	Female	0	Yes	No
2651	5609-IMCGG	Female	0	No	No
2652	4873-ILOLJ	Male	0	No	No
2653	4727-MCYZG	Male	0	No	No
2654	9481-WHGWY	Female	0	Yes	Yes
2655	2725-KXXWT	Male	0	Yes	No
2656	9565-DJPIB	Female	0	No	Yes
2657	4328-VUFWD	Female	0	No	No
2658	3301-LSLWQ	Female	0	No	No
2659	7473-ZBDSN	Female	0	Yes	Yes
2660	3166-PNEOF	Female	0	No	No
2661	5639-NTUPK	Male	0	No	Yes
2662	8780-YRMTT	Female	0	No	No
2663	8348-HFYIV	Male	0	No	No
2664	5140-FOMCQ	Female	0	Yes	No
2665	6242-SGYTS	Male	0	Yes	Yes
2666	8166-ORCHU	Male	1	Yes	No
2667	8414-OOEEL	Male	0	No	Yes
2668	8454-AATJP	Female	0	No	No
2669	6849-WLEYG	Male	0	No	Yes
2670	4659-NZRUF	Female	0	No	No
2671	4531-AUZNK	Female	0	Yes	Yes
2672	4191-XOVOM	Male	0	No	No
2673	2150-OEGBV	Male	0	No	No
2674	8429-XIBUM	Male	0	No	No
2675	1855-CFULU	Female	1	No	No
2676	4878-BUNFV	Male	0	Yes	Yes
2677	1872-EBWSC	Female	0	No	No
2678	2608-BHKFN	Female	0	No	No
2679	7026-YMSBE	Male	0	No	No
2680	7341-LXCAF	Male	0	Yes	No
2681	6997-UVGOX	Male	0	Yes	Yes
2682	9674-EHPPG	Male	0	Yes	No
2683	9462-MJUAW	Male	0	No	No
2684	8128-YVJRG	Female	0	No	No
2685	5440-VHLUL	Male	0	No	No
2686	5781-BKHOP	Female	0	Yes	No
2687	4283-FUTGF	Male	1	No	No
2688	5213-TWWJU	Male	0	No	No
2689	1569-TTNYJ	Male	0	Yes	No
2690	8628-MFKAX	Female	1	Yes	No
2691	2397-BRLOM	Male	1	Yes	Yes
2692	7629-WIXZF	Female	0	No	No
2693	5445-GLVOT	Female	0	No	No
2694	3976-HXHCE	Male	0	No	No
2695	2466-NEJOJ	Male	0	Yes	Yes
2696	0254-KCJGT	Male	0	Yes	No
2697	5472-CVMDX	Female	0	No	No
2698	6461-SZMCV	Female	0	Yes	No
2699	8150-QUDFX	Male	0	No	No
2700	9508-ILZDG	Female	1	No	No
2701	2346-DJQTB	Female	0	No	No
2702	1697-LYYYX	Female	0	Yes	Yes
2703	1942-OQFRW	Male	0	No	No
2704	4749-VFKVB	Female	0	No	No
2705	9640-ZSLDC	Female	0	Yes	Yes
2706	4231-LZUYM	Female	0	Yes	No
2707	7598-UAASY	Male	0	Yes	No
2708	7938-OUHIO	Male	0	No	No
2709	8510-AWCXC	Female	1	No	No
2710	6128-AQBMT	Male	1	Yes	No
2711	3594-BDSOA	Female	0	Yes	No
2712	0431-APWVY	Female	0	Yes	Yes
2713	5133-VRSAB	Male	0	No	No
2714	5996-DAOQL	Male	0	No	No
2715	6838-YAUVY	Female	0	No	No
2716	0484-JPBRU	Male	0	No	No
2717	7883-ROJOC	Female	0	Yes	No
2718	0244-LGNFY	Female	0	Yes	Yes
2719	7274-CGTOD	Male	0	No	No
2720	4295-YURET	Female	1	Yes	Yes
2721	3426-NIYYL	Male	0	No	No
2722	8225-BTJAU	Male	1	No	No
2723	4635-EJYPD	Male	0	Yes	Yes
2724	1866-ZSLJM	Male	0	No	No
2725	4636-TVXVG	Male	0	Yes	Yes
2726	4236-UJPWO	Female	0	No	No
2727	9392-XBGTD	Male	0	No	Yes
2728	3387-VATUS	Male	0	No	No
2729	6402-SSEJG	Female	0	No	No
2730	1143-NMNQJ	Female	0	No	No
2731	1169-SAOCL	Male	0	No	No
2732	1110-KYLGQ	Female	0	No	No
2733	9929-PLVPA	Female	0	No	Yes
2734	3518-PZXZQ	Female	0	Yes	No
2735	2371-JUNGC	Male	0	No	No
2736	7693-QPEFS	Male	1	No	No
2737	0924-BJCRC	Female	1	Yes	No
2738	5074-FBGHB	Male	0	No	No
2739	2351-BKRZW	Female	0	Yes	Yes
2740	4455-BFSPD	Female	0	Yes	No
2741	0415-MOSGF	Female	0	No	No
2742	1724-BQUHA	Male	1	No	No
2743	3948-KXDUF	Male	0	No	No
2744	2323-ARSVR	Male	0	Yes	No
2745	0815-MFZGM	Female	0	Yes	No
2746	4826-XTSOH	Male	1	Yes	No
2747	5480-XTFFL	Female	0	Yes	Yes
2748	8295-FHIVV	Male	0	No	No
2749	2495-INZWQ	Male	0	No	No
2750	9086-YJYXS	Male	0	Yes	Yes
2751	1179-INLAT	Male	0	No	No
2752	7909-FIOIY	Female	0	Yes	Yes
2753	4139-SUGLD	Male	0	Yes	Yes
2754	6857-VWJDT	Female	0	No	No
2755	6351-SCJKT	Male	0	No	No
2756	5468-BPMMO	Male	0	Yes	No
2757	5624-BQSSA	Female	0	No	No
2758	0197-PNKNK	Female	0	Yes	Yes
2759	2439-QKJUL	Male	0	No	No
2760	1194-SPVSP	Male	0	No	No
2761	9534-NSXEM	Male	0	No	No
2762	2408-WITXK	Female	1	No	No
2763	8929-KSWIH	Male	0	No	No
2764	2250-IVBWA	Male	0	Yes	Yes
2765	1810-MVMAI	Male	0	Yes	Yes
2766	9506-UXUSK	Male	0	No	No
2767	1229-RCALF	Female	0	Yes	No
2768	3572-UOLYZ	Female	0	No	Yes
2769	1429-UYJSV	Female	0	No	No
2770	5577-OTWWW	Female	0	No	No
2771	6100-QQHEB	Male	0	Yes	Yes
2772	6366-XIVKZ	Female	0	Yes	Yes
2773	3470-OBUET	Female	0	Yes	Yes
2774	2770-NSVDG	Male	0	Yes	No
2775	9375-MHRRS	Male	0	No	No
2776	2634-HCZGT	Male	1	Yes	No
2777	7503-QQRVF	Male	1	Yes	No
2778	4860-YZGZM	Male	0	No	No
2779	6599-GZWCM	Female	0	No	No
2780	2691-NZETQ	Male	0	No	No
2781	4404-HIBDJ	Female	0	No	No
2782	5533-NHFRF	Male	1	No	No
2783	7037-MTYVW	Male	0	Yes	Yes
2784	4760-THGOT	Female	0	Yes	No
2785	7295-JOMMD	Female	0	No	Yes
2786	4016-BJKTZ	Female	0	No	No
2787	6584-VQMYT	Male	0	No	Yes
2788	9838-BFCQT	Male	0	Yes	Yes
2789	2790-XUYMV	Male	0	No	Yes
2790	0581-MDMPW	Female	0	No	No
2791	5013-SBUIH	Female	0	No	No
2792	1023-BQXZE	Male	0	No	No
2793	9163-GHAYE	Female	0	No	No
2794	3904-UKFRE	Male	0	No	No
2795	5353-WILCI	Female	0	No	No
2796	0709-TVGUR	Female	1	No	No
2797	0058-EVZWM	Female	0	Yes	No
2798	6023-YEBUP	Male	0	No	No
2799	7209-JCUDS	Male	0	No	No
2800	7009-PCARS	Male	0	No	Yes
2801	0519-DRGTI	Female	0	Yes	Yes
2802	1017-FBQMM	Female	0	Yes	Yes
2803	3001-CBHLQ	Male	1	Yes	No
2804	1985-MBRYP	Female	0	No	No
2805	6158-DWPZT	Male	0	Yes	No
2806	9372-TXXPS	Female	0	Yes	No
2807	3259-QMXUN	Male	0	Yes	No
2808	1015-JPFYW	Male	0	No	Yes
2809	6645-MXQJT	Male	0	Yes	Yes
2810	4360-QRAVE	Male	1	No	No
2811	8433-WPJTV	Female	1	Yes	Yes
2812	5804-JMYIO	Female	0	Yes	Yes
2813	3763-GCZHZ	Male	0	Yes	No
2814	6484-LATFU	Male	0	No	No
2815	7599-NTMDP	Female	0	Yes	Yes
2816	0772-GYEQQ	Male	0	No	No
2817	0536-ACXIP	Female	0	Yes	No
2818	0936-NQLJU	Female	0	Yes	No
2819	4831-EOBFE	Male	0	Yes	Yes
2820	1575-KRZZE	Female	0	No	No
2821	3251-YMVWZ	Male	0	No	No
2822	4102-OQUPX	Male	1	Yes	No
2823	9170-GYZJC	Female	0	Yes	Yes
2824	4884-LEVMQ	Male	0	Yes	No
2825	8857-CUPFQ	Male	0	Yes	No
2826	7610-TVOPG	Male	0	No	No
2827	3638-DIMPH	Female	0	Yes	No
2828	1845-ZLLIG	Male	0	No	No
2829	8559-WNQZS	Male	0	No	No
2830	3999-QGRJH	Male	1	No	No
2831	1699-UOTXU	Male	0	No	No
2832	2454-RPBRZ	Female	1	Yes	No
2833	0635-WKOLD	Male	0	Yes	No
2834	5993-JSUWV	Female	0	No	No
2835	4518-FZBSX	Male	0	Yes	Yes
2836	5387-ASZNZ	Female	1	No	No
2837	6988-CJEYV	Male	0	No	No
2838	2002-MZHWP	Female	0	No	No
2839	3097-FQTVJ	Female	0	No	No
2840	5465-BUBFA	Female	0	Yes	Yes
2841	7299-GNVPL	Female	0	Yes	Yes
2842	9743-DQKQW	Male	0	No	No
2843	1215-VFYVK	Female	0	No	No
2844	9371-BITHB	Female	0	Yes	Yes
2845	2265-CYWIV	Female	1	Yes	No
2846	9093-FPDLG	Female	0	No	No
2847	0541-FITGH	Female	0	Yes	No
2848	6985-HAYWX	Female	0	Yes	No
2849	7508-KBIMB	Male	0	Yes	Yes
2850	6838-HVLXG	Female	0	No	No
2851	2277-DJJDL	Male	1	Yes	No
2852	1897-OKVMW	Female	0	Yes	Yes
2853	5485-ITNPC	Male	0	Yes	No
2854	0233-FTHAV	Female	0	No	No
2855	4644-PIZRT	Male	0	Yes	Yes
2856	8922-NPKBJ	Male	0	Yes	Yes
2857	2740-TVLFN	Male	0	No	No
2858	7771-CFQRQ	Female	0	Yes	Yes
2859	9512-PHSMG	Female	0	Yes	No
2860	6963-EZQEE	Male	1	Yes	No
2861	2452-KDRRH	Male	1	No	No
2862	2004-OCQXK	Female	0	No	No
2863	5027-QPKTE	Male	0	Yes	No
2864	4146-SVFUD	Male	0	No	No
2865	1564-HJUVY	Male	0	No	No
2866	3617-XLSGQ	Female	0	Yes	Yes
2867	7517-LDMPS	Female	0	No	No
2868	7244-KXYZN	Female	0	No	No
2869	5226-NOZFC	Male	0	No	No
2870	2672-HUYVI	Female	0	No	No
2871	1400-WIVLL	Male	0	Yes	No
2872	7508-MYBOG	Male	0	Yes	No
2873	8148-NLEGT	Female	0	Yes	Yes
2874	0148-DCDOS	Male	0	No	No
2875	8347-GDTMP	Female	0	Yes	No
2876	9992-RRAMN	Male	0	Yes	No
2877	6746-WAUWT	Male	0	No	No
2878	0310-MVLET	Female	0	Yes	Yes
2879	0428-IKYCP	Male	0	Yes	No
2880	4550-VBOFE	Male	1	Yes	No
2881	2187-PKZAY	Male	0	No	No
2882	4003-OCTMP	Female	0	Yes	No
2883	6652-YFFJO	Female	0	No	No
2884	7225-IILWY	Male	0	Yes	Yes
2885	5248-RPYWW	Female	1	Yes	Yes
2886	7923-IYJWY	Male	1	No	No
2887	3170-GWYKC	Female	0	No	No
2888	5696-QURRL	Male	0	No	No
2889	7409-KIUTL	Female	1	No	Yes
2890	9830-ECLEN	Male	0	Yes	Yes
2891	1732-VHUBQ	Female	1	Yes	Yes
2892	0495-RVCBF	Female	0	No	No
2893	2668-TZSPS	Male	0	No	No
2894	7854-EDSSA	Male	0	No	No
2895	8869-TORSS	Female	0	No	No
2896	7446-SFAOA	Female	0	Yes	No
2897	9522-ZSINC	Male	0	No	No
2898	8234-GSZYK	Male	0	No	No
2899	6505-OZNPG	Female	0	No	No
2900	6164-HAQTX	Male	0	No	No
2901	0679-IDSTG	Female	1	Yes	Yes
2902	7765-LWVVH	Female	0	Yes	Yes
2903	1658-TJVOA	Female	1	No	No
2904	0953-LGOVU	Male	0	Yes	Yes
2905	2115-BFTIW	Male	0	No	No
2906	4692-NNQRU	Female	0	Yes	No
2907	7742-MYPGI	Female	0	Yes	Yes
2908	0611-DFXKO	Male	0	Yes	No
2909	7780-OTDSO	Male	0	Yes	No
2910	9619-GSATL	Female	0	No	No
2911	5622-UEJFI	Female	0	Yes	Yes
2912	9747-DDZOS	Female	0	No	No
2913	0674-DGMAQ	Male	1	Yes	No
2914	6203-HBZPA	Male	0	No	No
2915	0484-FFVBJ	Male	0	No	No
2916	0301-FIDRB	Female	0	Yes	Yes
2917	4139-JPIAM	Male	0	No	No
2918	2181-TIDSV	Male	0	Yes	Yes
2919	2761-XECQW	Male	1	Yes	No
2920	1936-CZAKF	Male	0	Yes	No
2921	9453-PATOS	Female	0	Yes	No
2922	0564-JJHGS	Male	0	No	No
2923	3348-CFRNX	Female	0	Yes	No
2924	4402-FTBXC	Male	0	No	No
2925	1428-GTBJJ	Male	0	No	No
2926	2931-XIQBR	Female	0	Yes	Yes
2927	0106-UGRDO	Female	0	Yes	No
2928	5542-TBBWB	Male	0	No	No
2929	1930-QPBVZ	Male	0	Yes	Yes
2930	2606-PKWJB	Male	0	No	Yes
2931	5322-ZSMZY	Male	0	Yes	Yes
2932	8059-UDZFY	Female	1	No	Yes
2933	7740-BTPUX	Male	1	Yes	No
2934	5220-AGAAX	Male	0	Yes	Yes
2935	0208-BPQEJ	Female	0	Yes	Yes
2936	9435-JMLSX	Male	0	Yes	No
2937	3352-ALMCK	Male	0	No	No
2938	5312-IRCFR	Female	0	Yes	Yes
2939	5294-IMHHT	Male	0	Yes	No
2940	8802-UNOJF	Male	1	No	No
2941	6313-GIDIT	Male	1	No	No
2942	6176-YJWAS	Male	0	Yes	No
2943	5310-NOOVA	Male	0	No	No
2944	4526-EXKKN	Male	0	No	No
2945	5311-IHLEI	Male	0	No	No
2946	3987-KQDDU	Male	0	No	No
2947	3404-JNXAX	Female	0	Yes	Yes
2948	5131-PONJI	Male	0	Yes	Yes
2949	2845-AFFTX	Male	1	Yes	No
2950	3489-VSFRD	Female	0	No	No
2951	3345-JHUEO	Male	0	No	No
2952	5815-HGGHV	Male	0	Yes	No
2953	5260-UMPWX	Female	0	Yes	Yes
2954	2249-YPRNG	Female	0	Yes	Yes
2955	7410-YTJIK	Female	0	No	No
2956	4626-GYCZP	Male	0	No	No
2957	5649-RXQTV	Male	0	No	No
2958	2674-MIAHT	Female	0	No	No
2959	2576-HXMPA	Female	0	No	No
2960	7587-AOVVU	Male	0	Yes	Yes
2961	5590-BYNII	Male	0	No	No
2962	6898-MDLZW	Male	0	No	No
2963	3237-AJGEH	Female	0	Yes	Yes
2964	4707-YNOQA	Female	0	Yes	Yes
2965	9357-UJRUN	Male	0	Yes	No
2966	1591-NFNLQ	Male	0	No	No
2967	8648-PFRMP	Female	1	No	No
2968	7663-CUXZB	Male	0	Yes	No
2969	0258-NOKBL	Male	0	No	No
2970	1163-VIPRI	Female	0	Yes	Yes
2971	2815-CPTUL	Male	1	No	No
2972	9348-ROUAI	Female	0	Yes	Yes
2973	9443-JUBUO	Male	0	Yes	Yes
2974	0596-BQCEQ	Female	0	Yes	Yes
2975	1481-ZUWZA	Male	0	No	No
2976	3043-TYBNO	Male	0	No	No
2977	4830-FAXFM	Male	0	No	Yes
2978	5906-BFOZT	Male	0	No	No
2979	2960-NKRSO	Male	0	No	No
2980	8996-ZROXE	Male	1	No	No
2981	5598-IKHQQ	Female	0	No	No
2982	0397-ZXWQF	Male	0	No	No
2983	5266-PFRQK	Male	0	Yes	Yes
2984	4674-HGNUA	Male	0	Yes	Yes
2985	6765-MBQNU	Female	0	Yes	No
2986	9786-IJYDL	Female	0	No	No
2987	1303-SRDOK	Female	0	Yes	Yes
2988	3769-MHZNV	Female	0	Yes	Yes
2989	6295-OSINB	Male	0	Yes	No
2990	3308-MHOOC	Male	0	No	Yes
2991	2309-OSFEU	Male	0	No	No
2992	2207-QPJED	Female	1	Yes	No
2993	4177-JPDFU	Male	0	No	No
2994	2239-CFOUJ	Male	0	Yes	Yes
2995	8046-DNVTL	Male	0	Yes	No
2996	2209-XADXF	Female	0	No	No
2997	6620-JDYNW	Female	0	No	No
2998	1891-FZYSA	Male	1	Yes	No
2999	4770-UEZOX	Male	0	No	No
3000	1038-RQOST	Male	0	Yes	Yes
3001	7613-LLQFO	Male	0	No	No
3002	4568-TTZRT	Male	0	No	No
3003	9513-DXHDA	Male	0	No	No
3004	2640-PMGFL	Male	0	No	Yes
3005	3801-HMYNL	Male	0	Yes	Yes
3006	0516-QREYC	Female	1	No	No
3007	9685-WKZGT	Male	1	No	No
3008	6022-UGGSO	Female	1	No	No
3009	8084-OIVBS	Female	0	No	No
3010	8896-BQTTI	Male	0	No	No
3011	3865-QBWSJ	Male	1	No	Yes
3012	3352-RICWQ	Female	0	Yes	Yes
3013	2160-GPFXD	Male	0	Yes	Yes
3014	2065-MMKGR	Female	0	No	No
3015	5857-TYBCJ	Male	1	Yes	No
3016	1498-NHTLT	Male	0	Yes	Yes
3017	4484-CGXFK	Female	0	No	No
3018	1402-PTHGN	Female	0	Yes	Yes
3019	4176-RELJR	Male	1	No	No
3020	6214-EDAKZ	Female	0	Yes	Yes
3021	5199-FPUSP	Male	0	No	Yes
3022	6377-KSLXC	Male	0	No	No
3023	1796-JANOW	Female	0	No	No
3024	0238-WHBIQ	Male	0	Yes	Yes
3025	8735-NBLWT	Male	0	No	Yes
3026	6651-RLGGM	Male	0	Yes	Yes
3027	6127-ISGTU	Female	0	Yes	No
3028	1614-JBEBI	Female	0	No	No
3029	8740-XLHDR	Male	0	No	No
3030	1208-DNHLN	Male	0	Yes	Yes
3031	1761-AEZZR	Male	0	No	No
3032	3923-CSIHK	Female	1	Yes	No
3033	5696-EXCYS	Male	0	No	No
3034	5795-KTGUD	Female	0	Yes	No
3035	7120-RFMVS	Male	0	No	No
3036	7924-GJZFI	Female	1	Yes	No
3037	4702-HDRKD	Male	0	No	No
3038	8512-WIWYV	Male	0	No	No
3039	5897-ZYEKH	Female	1	Yes	No
3040	5456-ITGIC	Male	1	Yes	No
3041	7317-GGVPB	Male	0	Yes	No
3042	1406-PUQVY	Male	0	No	Yes
3043	1322-AGOQM	Male	0	No	No
3044	3677-IYRBF	Female	1	No	No
3045	5692-FPTAH	Female	0	No	No
3046	9114-AAFQH	Female	0	Yes	No
3047	8715-KKTFG	Female	0	Yes	No
3048	1550-LOAHA	Female	0	Yes	No
3049	1728-BQDMA	Female	0	No	No
3050	0268-QKIWO	Female	0	No	No
3051	0876-WDUUZ	Female	0	No	No
3052	5117-ZSMHQ	Female	0	Yes	Yes
3053	5151-HQRDG	Male	0	Yes	No
3054	0960-HUWBM	Male	0	Yes	Yes
3055	6465-GSRCL	Female	0	No	Yes
3056	0617-FHSGK	Male	0	No	Yes
3057	0263-FJTQO	Male	0	Yes	Yes
3058	7319-ZNRTR	Male	0	Yes	Yes
3059	2858-MOFSQ	Female	0	No	Yes
3060	7503-EPSZW	Female	0	Yes	Yes
3061	7089-XXAYG	Male	0	Yes	No
3062	8118-LSUEL	Male	1	No	No
3063	8070-AAWZP	Male	1	Yes	No
3064	1666-JXLKU	Female	0	No	No
3065	7855-DIWPO	Female	0	No	No
3066	5133-POWUA	Male	0	No	No
3067	5652-MSDEY	Female	0	No	No
3068	7005-CCBKV	Male	0	No	No
3069	1810-BOHSY	Male	0	Yes	No
3070	1784-BXEFA	Female	0	No	No
3071	7351-MHQVU	Female	0	No	No
3072	9224-VTYID	Male	0	Yes	Yes
3073	9500-IWPXQ	Female	0	Yes	Yes
3074	5762-TJXGK	Female	0	No	No
3075	4504-YOULA	Female	0	Yes	Yes
3076	5569-IDSEY	Male	0	Yes	No
3077	4250-FDVOU	Female	0	No	No
3078	7284-ZZLOH	Male	0	Yes	No
3079	5277-ZLOOR	Female	1	No	No
3080	2141-RRYGO	Female	0	No	No
3081	1777-JYQPJ	Male	0	No	No
3082	6376-GAHQE	Male	0	No	No
3083	3401-URHDA	Male	0	No	No
3084	1599-EAHXY	Male	0	Yes	Yes
3085	8631-XVRZL	Male	0	No	No
3086	5052-PNLOS	Male	0	No	No
3087	3853-LYGAM	Male	0	No	No
3088	6979-ZNSFF	Female	0	No	No
3089	5751-USDBL	Male	0	Yes	Yes
3090	5680-LQOGP	Female	0	No	No
3091	2386-LAHRK	Male	0	No	No
3092	8189-DUKMV	Female	0	Yes	No
3093	6032-IGALN	Female	0	No	No
3094	9931-DCEZH	Male	0	No	Yes
3095	1898-JSNDC	Female	0	No	No
3096	0315-LVCRK	Male	0	No	No
3097	3911-RSNHI	Female	0	Yes	No
3098	2410-CIYFZ	Male	0	No	Yes
3099	4248-HCETZ	Male	1	Yes	No
3100	5505-OVWQW	Female	0	No	No
3101	7271-AJDTL	Female	0	Yes	No
3102	1867-TJHTS	Female	0	No	No
3103	0516-WJVXC	Female	0	No	No
3104	9174-FKWZE	Female	1	No	No
3105	6860-YRJZP	Male	1	No	No
3106	4429-WYGFR	Male	0	No	No
3107	2817-LVCPP	Female	0	No	No
3108	5038-ETMLM	Female	0	Yes	No
3109	5056-FIMPT	Female	0	No	Yes
3110	4521-WFJAI	Male	0	No	No
3111	6569-KTMDU	Female	0	No	No
3112	8809-RIHDD	Male	0	Yes	Yes
3113	8809-XKHMD	Male	0	Yes	No
3114	0396-YCHWO	Male	0	Yes	No
3115	0867-LDTTC	Male	0	No	No
3116	4822-NGOCH	Female	0	No	No
3117	9391-DXGGG	Female	1	No	No
3118	9844-FELAJ	Female	1	Yes	Yes
3119	2122-SZZZD	Male	0	No	No
3120	5307-DZCVC	Female	1	Yes	No
3121	3148-AOIQT	Female	0	Yes	No
3122	8679-JOEVF	Female	1	No	No
3123	8395-ETZKQ	Male	1	Yes	Yes
3124	6692-YQHXC	Male	0	No	No
3125	3889-VWBID	Male	0	Yes	Yes
3126	5222-JCXZT	Male	0	No	No
3127	9754-CLVZW	Female	0	Yes	Yes
3128	1432-FPAXX	Female	0	No	No
3129	2739-CCZMB	Male	0	No	Yes
3130	7080-TNUWP	Male	0	Yes	No
3131	0496-AHOOK	Male	0	Yes	No
3132	8336-TAVKX	Female	1	Yes	No
3133	2468-SJFLM	Male	0	No	No
3134	3181-VTHOE	Male	0	Yes	No
3135	7168-HDQHG	Female	0	Yes	Yes
3136	4803-AXVYP	Female	1	No	No
3137	3884-HCSWG	Female	0	No	No
3138	4567-AKPIA	Female	0	Yes	Yes
3139	5077-DXTCG	Female	0	No	No
3140	1142-WACZW	Male	0	No	No
3141	7901-HXJVA	Male	0	No	No
3142	5649-ANRML	Male	1	No	No
3143	4892-VLANZ	Male	0	No	No
3144	5924-IFQTT	Male	0	Yes	Yes
3145	7968-QUXNS	Male	0	No	No
3146	2919-HBCJO	Female	0	No	No
3147	4236-XPXAV	Female	0	Yes	Yes
3148	8903-WMRNW	Female	0	Yes	No
3149	2452-SNHFZ	Female	0	No	No
3150	3629-WEAAM	Female	0	No	No
3151	6029-CSMJE	Male	0	No	No
3152	7993-NQLJE	Male	0	Yes	Yes
3153	9909-DFRJA	Female	0	No	No
3154	9099-FTUHS	Female	0	No	No
3155	0581-BXBUB	Female	1	No	No
3156	4962-CHQPW	Male	0	No	Yes
3157	9467-ROOLM	Female	0	No	No
3158	3030-YZADT	Male	0	No	No
3159	7410-KTVFV	Male	0	Yes	No
3160	5150-ITWWB	Male	1	No	No
3161	2253-KPMNB	Female	0	Yes	Yes
3162	1345-ZUKID	Male	0	No	No
3163	6429-SHBCB	Male	0	No	No
3164	9281-OFDMF	Male	1	No	No
3165	2603-HVKCG	Male	0	No	No
3166	1834-WULEG	Male	0	Yes	Yes
3167	9097-ZUBYC	Male	0	Yes	No
3168	5148-ORICT	Female	0	Yes	No
3169	4893-GYUJU	Female	0	No	No
3170	4578-PHJYZ	Male	0	Yes	Yes
3171	7272-QDCKA	Male	0	No	No
3172	8908-SLFCJ	Female	0	No	No
3173	8393-DLHGA	Male	0	No	Yes
3174	9766-HGEDE	Female	0	Yes	No
3175	6968-MHOMU	Male	0	Yes	No
3176	7395-IGJOS	Male	1	Yes	No
3177	5044-XDPYX	Female	0	Yes	No
3178	1814-WFGVS	Male	0	Yes	Yes
3179	2834-SPCJV	Male	0	Yes	No
3180	3721-WKIIL	Female	0	No	No
3181	6734-CKRSM	Female	0	No	No
3182	1265-ZFOSD	Female	0	Yes	No
3183	6568-POCUI	Female	0	Yes	No
3184	7890-VYYWG	Male	1	Yes	No
3185	5197-LQXXH	Female	0	Yes	No
3186	9907-SWKKF	Female	1	No	No
3187	3457-PQBYH	Female	0	Yes	Yes
3188	7682-AZNDK	Male	0	Yes	Yes
3189	0587-DMGBH	Female	0	No	No
3190	5384-ZTTWP	Female	0	Yes	Yes
3191	3745-HRPHI	Male	0	Yes	Yes
3192	7636-OWBPG	Male	1	No	No
3193	1231-YNDEK	Male	0	No	No
3194	1407-DIGZV	Female	0	Yes	Yes
3195	6397-JNZZG	Female	1	Yes	No
3196	0570-BFQHT	Female	0	No	No
3197	4393-OBCRR	Female	0	No	No
3198	3523-QRQLL	Female	0	Yes	Yes
3199	8564-LDKFL	Male	0	Yes	No
3200	3696-DFHHB	Female	0	No	No
3201	0895-DQHEW	Male	0	Yes	No
3202	4717-GHADL	Female	0	No	No
3203	5501-TVMGM	Male	0	No	No
3204	5879-HMFFH	Female	0	Yes	No
3205	6772-WFQRD	Male	0	No	Yes
3206	3810-DVDQQ	Female	0	Yes	Yes
3207	6972-SNKKW	Female	0	No	No
3208	3694-GLTJM	Female	0	No	No
3209	8550-XSXUQ	Male	0	Yes	No
3210	8149-RSOUN	Female	0	No	No
3211	9055-MOJJJ	Female	0	Yes	Yes
3212	4359-INNWN	Female	0	No	No
3213	0585-EGDDA	Male	0	Yes	No
3214	4032-RMHCI	Female	0	Yes	Yes
3215	0549-CYCQN	Male	1	No	No
3216	3481-JHUZH	Male	0	Yes	No
3217	7250-EQKIY	Female	0	Yes	Yes
3218	3594-IVHJZ	Female	0	No	No
3219	6869-FGJJC	Male	0	No	No
3220	3896-ZVNET	Female	0	Yes	Yes
3221	8205-VSLRB	Male	0	Yes	No
3222	5960-MVTUK	Male	0	No	No
3223	6817-WTYHE	Male	0	No	No
3224	3082-VQXNH	Male	0	Yes	No
3225	4013-UBXWQ	Female	0	No	No
3226	4931-TRZWN	Female	0	No	No
3227	0750-EKNGL	Male	0	No	No
3228	7669-LCRSD	Male	0	Yes	Yes
3229	3567-PQTSO	Male	0	Yes	Yes
3230	5519-NPHVG	Female	0	No	No
3231	8043-PNYSD	Male	0	Yes	Yes
3232	9938-EKRGF	Female	0	No	No
3233	2703-AMTUL	Male	0	Yes	Yes
3234	0928-JMXNP	Male	1	Yes	No
3235	8173-RXAYP	Female	0	Yes	Yes
3236	4825-XJGDM	Female	0	No	No
3237	5402-HTOTQ	Male	0	No	No
3238	6734-JDTTV	Male	0	Yes	Yes
3239	7850-THJMU	Female	0	Yes	Yes
3240	3890-RTCMS	Male	0	No	No
3241	8849-GYOKR	Female	0	Yes	No
3242	3148-BLQJT	Male	0	No	No
3243	3717-FDJFU	Male	0	No	Yes
3244	3665-JATSN	Female	0	No	No
3245	7966-YOTQW	Male	0	No	No
3246	0461-CVKMU	Female	0	Yes	Yes
3247	8806-EAGWC	Male	0	No	No
3248	8853-TZDGH	Female	0	No	No
3249	7779-LGOVN	Male	1	Yes	No
3250	4324-BZCKL	Female	0	Yes	Yes
3251	6924-TDGMT	Male	0	Yes	No
3252	9710-ZUSHQ	Female	1	No	No
3253	1536-YHDOE	Male	0	Yes	Yes
3254	8123-QBNAZ	Female	0	Yes	Yes
3255	3629-ZNKXA	Male	1	No	No
3256	4827-LTQRJ	Female	1	Yes	Yes
3257	7711-YIJWC	Male	0	Yes	Yes
3258	5482-VXSXJ	Male	0	No	No
3259	7365-BVCJH	Male	0	No	No
3260	9620-ENEJV	Female	0	No	No
3261	4183-WCSEP	Male	0	No	No
3262	2378-YIZKA	Female	0	Yes	Yes
3263	5498-TXHLF	Female	0	Yes	Yes
3264	0689-DSXGL	Female	0	Yes	Yes
3265	6818-DJXAA	Female	0	No	Yes
3266	9722-UJOJR	Male	0	Yes	Yes
3267	0464-WJTKO	Female	0	Yes	Yes
3268	8902-ZEOVF	Male	0	Yes	Yes
3269	6778-EICRF	Male	0	Yes	Yes
3270	2662-NNTDK	Male	0	No	No
3271	4132-KALRO	Female	0	No	No
3272	3902-FOIGH	Male	1	Yes	No
3273	6772-KSATR	Male	0	No	No
3274	7112-OPOTK	Male	0	No	No
3275	2874-YXVVA	Female	0	No	No
3276	1245-HARPS	Female	0	Yes	No
3277	4210-QFJMF	Female	0	No	No
3278	4323-ELYYB	Male	0	Yes	Yes
3279	4293-ETKAP	Female	0	Yes	Yes
3280	6064-PUPMC	Male	0	Yes	Yes
3281	6504-VBLFL	Male	0	Yes	No
3282	6322-PJJDJ	Male	0	Yes	No
3283	0330-BGYZE	Male	0	Yes	No
3284	1085-LDWAM	Female	0	Yes	Yes
3285	7586-ZATGZ	Male	0	No	No
3286	7197-VOJMM	Male	0	Yes	No
3287	3318-OSATS	Male	1	No	No
3288	5828-AVIPD	Male	0	Yes	Yes
3289	1843-TLSGD	Female	0	Yes	Yes
3290	9626-VFRGG	Female	0	No	Yes
3291	7075-BNDVQ	Female	0	No	No
3292	9143-CANJF	Female	0	Yes	Yes
3293	7284-BUYEC	Female	0	No	No
3294	2041-JIJCI	Female	0	No	No
3295	1086-LXKFY	Female	0	Yes	Yes
3296	4900-MSOMT	Female	0	Yes	Yes
3297	2229-VWQJH	Female	0	No	No
3298	9194-GFVOI	Female	0	Yes	No
3299	1336-EZFZY	Female	0	No	No
3300	4282-MSACW	Male	0	No	No
3301	1403-LKLIK	Female	0	Yes	Yes
3302	2636-ALXXZ	Female	1	No	No
3303	7774-OJSXI	Male	0	No	No
3304	7786-WBJYI	Female	0	No	No
3305	0136-IFMYD	Male	1	Yes	No
3306	5144-TVGLP	Male	1	No	No
3307	9643-AVVWI	Female	0	Yes	Yes
3308	0253-ZTEOB	Female	0	Yes	Yes
3309	2706-QZIHY	Female	0	Yes	No
3310	6061-PQHMK	Female	0	No	No
3311	9885-CSMWE	Female	1	No	No
3312	6137-MFAJN	Female	0	No	No
3313	9122-UMROB	Male	0	No	No
3314	4232-JGKIY	Male	0	No	No
3315	2402-TAIRZ	Female	0	No	No
3316	9659-ZTWSM	Male	1	Yes	No
3317	9139-TWBAS	Female	0	Yes	No
3318	6685-GBWJZ	Male	0	Yes	No
3319	5016-ETTFF	Male	0	No	No
3320	3866-MDTUB	Female	0	No	No
3321	2195-VVRJF	Male	1	Yes	No
3322	3913-RDSJZ	Female	0	Yes	No
3323	8058-JMEQO	Female	1	No	No
3324	4203-QGNZA	Female	0	No	Yes
3325	5043-TRZWM	Female	0	No	No
3326	0697-ZMSWS	Male	0	No	No
3327	7657-DYEPJ	Male	1	No	No
3328	9494-BDNNC	Male	0	Yes	No
3329	1640-PLFMP	Female	0	No	No
3330	5366-OBVMR	Female	0	Yes	No
3331	8276-MQBYC	Male	1	No	No
3332	7644-OMVMY	Male	0	Yes	Yes
3333	7593-XFKDI	Male	0	No	No
3334	4573-JKNAE	Male	0	No	Yes
3335	0337-CNPZE	Female	0	No	No
3336	9817-APLHW	Male	0	No	No
3337	8380-MQINP	Female	0	Yes	Yes
3338	0840-DFEZH	Female	0	No	No
3339	1513-XNPPH	Female	0	No	No
3340	8690-ZVLCL	Female	0	Yes	Yes
3341	6015-VVHHE	Female	1	No	No
3342	1125-SNVCK	Female	1	No	No
3343	0384-LPITE	Male	0	No	No
3344	4616-EWBNJ	Female	0	No	No
3345	6347-DCUIK	Male	0	No	No
3346	1335-HQMKX	Female	0	Yes	No
3347	2545-EBUPK	Female	1	No	No
3348	6923-AQONU	Male	0	Yes	Yes
3349	2172-EJXVF	Female	1	No	No
3350	0897-FEGMU	Female	0	Yes	No
3351	7663-RGWBC	Male	0	No	No
3352	1120-BMWUB	Female	0	No	No
3353	9124-LHCJQ	Female	0	No	No
3354	4536-PLEQY	Male	0	Yes	No
3355	7029-IJEJK	Female	0	No	No
3356	8871-JLMHM	Female	0	Yes	No
3357	2235-ZGKPT	Female	0	Yes	Yes
3358	3891-PUQOD	Female	0	No	Yes
3359	5447-VYTKW	Male	0	No	No
3360	3623-FQBOX	Male	0	No	No
3361	0689-NKYLF	Male	0	No	No
3362	8659-HDIYE	Female	1	No	No
3363	3658-KIBGF	Female	0	No	No
3364	3474-BAFSJ	Male	0	Yes	No
3365	5519-YLDGW	Female	0	Yes	No
3366	3865-ZFZIB	Male	0	No	No
3367	1855-AGAWH	Male	0	Yes	No
3368	7109-CQYUZ	Male	0	No	No
3369	1370-GGAWX	Female	0	No	No
3370	4680-KUTAJ	Female	1	No	No
3371	5307-UVGNB	Female	0	Yes	Yes
3372	4946-EDSEW	Female	0	Yes	Yes
3373	2883-ILGWO	Male	1	No	No
3374	2516-VQRRV	Female	1	No	No
3375	7580-UGXNC	Female	1	No	No
3376	3642-BYHDO	Female	0	Yes	Yes
3377	9629-NHXFW	Female	0	Yes	Yes
3378	2696-RZVZW	Male	0	Yes	No
3379	5766-FTRTS	Male	0	Yes	No
3380	0396-HUJBP	Female	0	No	No
3381	5178-LMXOP	Male	1	Yes	No
3382	8879-ZKJOF	Female	0	No	No
3383	6285-FTQBF	Male	0	Yes	Yes
3384	8185-UPYBR	Male	0	Yes	No
3385	4585-HETAI	Female	0	Yes	Yes
3386	7526-BEZQB	Male	0	No	No
3387	1474-JUWSM	Female	0	Yes	No
3388	3530-CRZSB	Female	0	No	No
3389	8498-XXGWA	Female	0	Yes	No
3390	9617-INGJY	Male	0	No	No
3391	0621-TSSMU	Male	0	Yes	No
3392	7234-KMNRQ	Male	0	No	No
3393	7636-PEPNS	Female	0	Yes	Yes
3394	4683-WYDOU	Male	0	Yes	No
3395	9052-DHNKM	Male	0	No	No
3396	6794-HKIAJ	Male	0	No	No
3397	5578-NKCXI	Female	0	Yes	Yes
3398	1642-HMARX	Female	0	Yes	No
3399	3096-WPXBT	Female	0	Yes	Yes
3400	8434-PNQZX	Female	0	No	No
3401	5950-AAAGJ	Male	0	No	No
3402	4299-OPXEJ	Female	0	No	No
3403	4951-UKAAQ	Female	0	No	No
3404	9618-LFJRU	Female	0	No	No
3405	6693-DJWTY	Female	0	No	Yes
3406	0744-GKNGE	Female	0	Yes	Yes
3407	6447-EGDIV	Female	0	No	No
3408	1167-OYZJF	Female	1	Yes	No
3409	2108-YKQTY	Female	0	No	No
3410	4806-DXQCE	Female	1	Yes	No
3411	4918-QLLIW	Male	0	No	No
3412	7056-IMHCC	Male	1	Yes	No
3413	4854-SSLTN	Male	0	Yes	Yes
3414	5294-DMSFH	Female	0	Yes	Yes
3415	4837-PZTIC	Female	0	No	No
3416	1625-JAIIY	Female	0	Yes	Yes
3417	0603-OLQDC	Male	0	No	Yes
3418	3272-VUHPV	Female	0	Yes	Yes
3419	4176-FXYBO	Male	0	Yes	No
3420	1063-DHQJF	Male	0	Yes	Yes
3421	8663-UPDGF	Female	0	No	No
3422	6719-FGEDO	Female	0	Yes	No
3423	1837-YQUCE	Female	0	No	No
3424	2947-DOMLJ	Male	0	No	Yes
3425	4112-LUEIZ	Male	0	No	No
3426	0369-ZGOVK	Female	0	Yes	Yes
3427	4510-HIMLV	Male	0	No	No
3428	9919-KNPOO	Female	0	Yes	No
3429	8749-JMNKX	Male	1	Yes	No
3430	7872-BAAZR	Female	0	Yes	Yes
3431	9391-LMANN	Male	0	No	Yes
3432	2430-USGXP	Male	0	Yes	No
3433	8174-TBVCF	Female	0	Yes	No
3434	1698-XFZCI	Male	0	No	No
3435	1877-HKBQX	Female	0	No	No
3436	4450-DLLMH	Male	0	No	No
3437	0428-AXXLJ	Male	0	No	No
3438	2746-DIJLO	Female	0	No	No
3439	5955-ERIHD	Male	0	Yes	No
3440	0917-EZOLA	Male	1	Yes	No
3441	3508-VLHCZ	Female	0	Yes	Yes
3442	4086-ATNFV	Female	0	Yes	Yes
3443	0468-YRPXN	Male	0	No	No
3444	5996-NRVXR	Male	1	Yes	No
3445	3739-YBWAB	Male	0	Yes	No
3446	7047-FWEYA	Female	0	Yes	No
3447	2000-MPKCA	Female	0	No	No
3448	9762-YAQAA	Male	0	No	No
3449	5949-EBSQK	Male	0	Yes	Yes
3450	5473-KHBPS	Female	0	Yes	Yes
3451	0100-DUVFC	Male	1	Yes	No
3452	5397-TUPSH	Male	1	Yes	No
3453	8950-MTZNV	Male	0	No	No
3454	0326-VDYXE	Female	0	Yes	No
3455	6773-LQTVT	Female	1	Yes	Yes
3456	7274-RTAPZ	Male	0	No	No
3457	0436-TWFFZ	Female	0	No	No
3458	8566-YPRGL	Female	0	No	No
3459	0311-UNPFF	Female	0	No	No
3460	6609-MXJHJ	Female	0	Yes	Yes
3461	2669-OIDSD	Female	0	Yes	No
3462	8400-WZICQ	Female	0	Yes	Yes
3463	3834-XUIFC	Male	0	No	No
3464	9576-SYUHJ	Male	0	No	No
3465	0410-IPFTY	Female	0	Yes	No
3466	2831-EBWRN	Male	0	No	No
3467	9430-NKQLY	Male	0	Yes	Yes
3468	8414-MYSHR	Male	1	No	No
3469	0247-SLUJI	Male	0	Yes	Yes
3470	9402-ORRAH	Female	1	No	No
3471	6483-OATDN	Male	0	Yes	Yes
3472	1293-HHSHJ	Female	0	No	No
3473	4840-ORQXB	Female	1	No	No
3474	7599-FKVXZ	Male	0	Yes	No
3475	3982-DQLUS	Male	1	Yes	Yes
3476	8610-ZIKJJ	Female	0	Yes	Yes
3477	3756-VNWDH	Male	1	Yes	No
3478	7801-KICAO	Female	0	No	No
3479	7673-LPRNY	Female	0	No	No
3480	8229-TNIQA	Female	0	No	No
3481	6060-QBMGV	Male	0	Yes	No
3482	7339-POGZN	Female	0	No	No
3483	2828-SLQPF	Male	0	No	No
3484	4465-VDKIQ	Female	0	No	No
3485	2921-XWDJH	Female	1	Yes	No
3486	6221-AVQYL	Male	0	No	No
3487	2558-BUOZZ	Male	0	No	No
3488	9257-AZMTZ	Female	0	Yes	Yes
3489	0003-MKNFE	Male	0	No	No
3490	0975-UYDTX	Female	0	Yes	No
3491	7743-EXURX	Male	0	Yes	Yes
3492	4682-BLBUC	Male	0	Yes	No
3493	0975-VOOVL	Female	0	No	No
3494	5968-VXZLG	Male	0	No	No
3495	5569-KGJHX	Female	0	Yes	Yes
3496	4988-IQIGL	Male	1	No	No
3497	5201-FRKKS	Male	0	No	No
3498	9799-CAYJJ	Female	1	Yes	No
3499	7730-IUTDZ	Male	0	No	No
3500	0426-TIRNE	Female	0	No	No
3501	5443-SCMKX	Female	0	Yes	No
3502	8295-KMENE	Female	0	Yes	Yes
3503	6738-ISCBM	Male	0	No	No
3504	9821-BESNZ	Male	0	No	No
3505	3678-MNGZX	Male	0	Yes	Yes
3506	1335-NTIUC	Male	0	No	No
3507	2916-BQZLN	Male	0	No	No
3508	4558-CGYCZ	Male	0	No	No
3509	2368-GAKKQ	Female	0	No	No
3510	8710-YGLWG	Male	0	No	No
3511	3199-XGZCY	Female	0	No	No
3512	3785-KTYSH	Male	0	No	No
3513	6814-ZPWFQ	Male	1	No	No
3514	4063-EIKNQ	Male	0	Yes	Yes
3515	6993-YCOBK	Male	0	Yes	Yes
3516	5206-HPJKM	Male	0	No	No
3517	7587-RZNME	Male	0	No	No
3518	0748-RDGGM	Male	0	Yes	No
3519	8393-JMVMB	Male	0	No	No
3520	5019-GQVCR	Male	1	No	No
3521	6036-TTFYU	Female	0	Yes	No
3522	2550-AEVRU	Female	0	Yes	Yes
3523	0969-RGKCU	Male	0	Yes	Yes
3524	0378-CJKPV	Female	0	Yes	No
3525	4706-AXVKM	Female	1	No	No
3526	5889-JTMUL	Female	1	Yes	No
3527	9026-RNUJS	Male	1	No	No
3528	3746-EUBYR	Male	0	Yes	No
3529	2332-EFBJY	Male	0	No	No
3530	2880-FPNAE	Male	1	Yes	No
3531	1703-MGIAB	Female	0	No	No
3532	4311-QTTAI	Female	0	No	No
3533	9474-PHLYD	Female	0	No	No
3534	4318-RAJVY	Female	0	No	No
3535	2165-VOEGB	Female	0	No	Yes
3536	3612-YUNGG	Male	0	Yes	Yes
3537	2254-DLXRI	Female	0	No	No
3538	5062-CJJKH	Male	0	Yes	Yes
3539	9028-LIHRP	Male	0	Yes	Yes
3540	2219-MVUSO	Male	0	No	No
3541	1053-MXTTK	Female	0	Yes	Yes
3542	1530-ZTDOZ	Female	0	Yes	No
3543	1301-LOPVR	Male	0	Yes	Yes
3544	0853-TWRVK	Male	0	Yes	No
3545	8914-RBTSB	Male	0	Yes	No
3546	6212-ATMLK	Female	0	No	No
3547	8200-LGKSR	Male	0	Yes	No
3548	1568-BEKZM	Male	1	Yes	No
3549	0670-ANMUU	Male	0	No	No
3550	6897-RWMUB	Male	0	Yes	Yes
3551	0963-ZBDRN	Male	0	No	No
3552	7594-RQHXR	Female	0	No	Yes
3553	6999-CHVCF	Male	0	No	No
3554	6134-KWTBV	Male	0	No	No
3555	1077-HUUJM	Female	0	No	Yes
3556	6331-EWIEB	Male	0	No	No
3557	0895-LNKRC	Male	0	Yes	Yes
3558	2045-BMBTJ	Female	1	No	No
3559	8417-GSODA	Male	0	Yes	Yes
3560	5171-EPLKN	Male	0	No	No
3561	4452-QIIEB	Male	0	No	No
3562	5998-VVEJY	Male	0	No	No
3563	1624-NALOJ	Male	1	No	No
3564	6741-EGCBI	Male	1	No	No
3565	7820-ZYGNY	Male	0	No	No
3566	4317-VTEOA	Male	0	No	No
3567	9677-AVKED	Female	0	No	Yes
3568	1670-SVOWZ	Female	0	Yes	Yes
3569	2227-JRSJX	Female	0	No	No
3570	9847-HNVGP	Male	0	No	No
3571	6696-YDAYZ	Male	0	Yes	Yes
3572	8980-WQFWL	Female	0	No	No
3573	1730-ZMAME	Female	1	No	No
3574	6506-EYCNH	Female	0	Yes	Yes
3575	4634-JLRJT	Female	0	No	No
3576	9501-UKKNL	Male	0	No	No
3577	2560-QTSBS	Female	0	Yes	Yes
3578	7541-YLXCL	Male	0	No	No
3579	4795-WRNVT	Female	0	No	No
3580	6080-TCMYC	Male	0	Yes	Yes
3581	0260-ZDLGK	Female	0	No	Yes
3582	7860-UXCRM	Male	0	Yes	Yes
3583	6357-JJPQT	Female	0	No	No
3584	2292-XQWSV	Male	0	Yes	Yes
3585	9552-TGUZV	Male	0	Yes	No
3586	5913-INRQV	Male	1	Yes	No
3587	8722-NGNBH	Male	0	No	No
3588	6210-KBBPI	Male	1	No	No
3589	9643-YBLUR	Male	0	Yes	No
3590	8734-FNWVH	Male	0	Yes	Yes
3591	9447-YPTBX	Female	0	Yes	No
3592	0133-BMFZO	Female	0	No	No
3593	6128-CZOMY	Female	0	No	No
3594	9540-JYROE	Male	0	No	No
3595	9026-LHEVG	Female	0	No	No
3596	2260-USTRB	Female	1	No	No
3597	3656-TKRVZ	Female	0	No	No
3598	7011-CVEUC	Male	0	Yes	No
3599	6185-TASNN	Male	1	No	No
3600	7925-PNRGI	Female	0	Yes	Yes
3601	8623-TMRBY	Male	1	Yes	Yes
3602	1552-CZCLL	Female	0	Yes	Yes
3603	3038-PQIUY	Female	0	No	No
3604	1501-SGHBW	Male	0	No	No
3605	9313-CDOGY	Male	0	Yes	Yes
3606	8148-BPLZQ	Male	0	No	No
3607	2623-DRYAM	Female	0	Yes	No
3608	9987-LUTYD	Female	0	No	No
3609	3208-YPIOE	Male	0	No	No
3610	4488-KQFDT	Female	0	No	No
3611	2612-RANWT	Female	0	No	No
3612	5693-PIPCS	Male	0	No	No
3613	0491-KAPQG	Male	0	No	No
3614	1925-LFCZZ	Male	1	No	No
3615	8039-EQPIM	Male	0	Yes	No
3616	6900-PXRMS	Male	1	Yes	Yes
3617	8707-RMEZH	Female	1	Yes	No
3618	3346-BRMIS	Female	1	Yes	No
3619	3209-ZPKFI	Male	0	Yes	Yes
3620	6479-VDGRK	Female	0	Yes	Yes
3621	9373-WSLOY	Male	1	Yes	No
3622	2933-FILNV	Female	0	Yes	Yes
3623	3569-JFODW	Female	0	Yes	Yes
3624	9819-FBNSV	Male	1	Yes	No
3625	9544-PYPSJ	Female	1	Yes	Yes
3626	1591-XWLGB	Female	0	Yes	No
3627	0396-UKGAI	Male	0	No	Yes
3628	3243-ZHOHY	Female	0	No	No
3629	5186-EJEGL	Male	0	No	No
3630	7527-QNRUS	Male	0	Yes	Yes
3631	9986-BONCE	Female	0	No	No
3632	2722-JMONI	Female	1	Yes	No
3633	2203-GHNWN	Female	0	Yes	No
3634	3878-AVSOQ	Female	1	No	No
3635	3258-SYSWS	Male	1	No	No
3636	5296-PSYVW	Female	0	Yes	No
3637	6319-QSUSR	Female	0	No	Yes
3638	4083-EUGRJ	Male	0	No	No
3639	7579-OOPEC	Female	1	Yes	No
3640	0512-FLFDW	Female	1	Yes	No
3641	1771-OADNZ	Male	1	Yes	No
3642	0487-CRLZF	Female	0	No	No
3643	2107-FBPTK	Female	1	No	No
3644	9451-WLYRI	Female	0	Yes	No
3645	8219-VYBVI	Male	0	No	Yes
3646	1991-VOPLL	Female	0	No	No
3647	9738-QLWTP	Male	0	No	No
3648	1016-DJTSV	Male	1	No	No
3649	9419-IPPBE	Female	0	Yes	Yes
3650	0174-QRVVY	Male	0	Yes	Yes
3651	5699-BNCAS	Male	1	No	No
3652	2900-PHPLN	Female	1	Yes	No
3653	0612-RTZZA	Female	1	No	No
3654	8106-GWQOK	Male	0	Yes	No
3655	8751-EDEKA	Female	0	Yes	No
3656	6878-GGDWG	Female	0	Yes	No
3657	4039-PIMHX	Male	1	Yes	No
3658	8450-LUGUK	Female	0	Yes	Yes
3659	3604-WLABM	Female	0	No	No
3660	0795-GMVQO	Male	0	Yes	No
3661	2259-OUUSZ	Male	0	No	No
3662	1142-IHLOO	Female	0	No	No
3663	6410-LEFEN	Female	0	No	No
3664	4633-MKHYU	Female	0	No	No
3665	6257-RJOHI	Male	0	No	No
3666	1545-JFUML	Male	0	Yes	No
3667	3194-ORPIK	Female	0	Yes	Yes
3668	7826-VVKWT	Female	1	Yes	Yes
3669	1353-GHZOS	Male	0	Yes	No
3670	2587-EKXTS	Male	0	No	No
3671	5442-BXVND	Female	0	Yes	Yes
3672	8816-VXNZD	Female	0	No	No
3673	9378-FXTIZ	Female	0	Yes	No
3674	1723-HKXJQ	Male	0	No	No
3675	7825-GKXMW	Female	0	No	No
3676	9753-OYLBX	Female	0	No	No
3677	2364-UFROM	Male	0	No	No
3678	6656-JWRQX	Female	0	No	No
3679	6473-ULUHT	Male	0	Yes	Yes
3680	1240-KNSEZ	Male	0	No	No
3681	0836-SEYLU	Male	0	Yes	No
3682	4433-JCGCG	Male	1	Yes	No
3683	3716-BDVDB	Male	0	No	No
3684	7688-AWMDX	Male	0	Yes	No
3685	2842-BCQGE	Male	0	No	No
3686	7244-QWYHG	Male	0	Yes	No
3687	5899-MQZZL	Female	0	No	No
3688	6849-OYAMU	Male	0	Yes	Yes
3689	5312-UXESG	Female	0	No	No
3690	9488-HGMJH	Female	1	No	No
3691	6038-GCYEC	Female	0	No	No
3692	2150-WLKUW	Female	0	Yes	No
3693	7159-FVYPK	Female	0	Yes	Yes
3694	7032-LMBHI	Female	0	No	No
3695	1150-WFARN	Female	0	Yes	Yes
3696	6088-BXMRG	Female	0	Yes	Yes
3697	3144-AUDBS	Female	0	Yes	No
3698	4821-SJHJV	Female	0	Yes	Yes
3699	7346-MEDWM	Female	0	No	No
3700	1137-DGOWI	Female	0	Yes	No
3701	5616-PRTNT	Male	0	No	Yes
3702	3812-LRZIR	Female	0	Yes	Yes
3703	4818-QIUFN	Female	1	No	No
3704	9483-GCPWE	Male	0	No	Yes
3705	4227-OJHAL	Female	0	Yes	Yes
3706	9220-CXRSC	Female	0	Yes	Yes
3707	4993-JCRGJ	Male	0	No	No
3708	9537-JALFH	Male	0	Yes	Yes
3709	6698-OXETB	Male	0	No	No
3710	2103-ZRXFN	Male	0	No	No
3711	3724-BSCVH	Male	0	Yes	Yes
3712	4877-TSOFF	Female	0	Yes	Yes
3713	9209-NWPGU	Male	0	No	No
3714	6961-VCPMC	Male	1	Yes	No
3715	7306-YDSOI	Male	0	Yes	Yes
3716	5288-AHOUP	Male	1	No	No
3717	6688-UZPWD	Female	0	Yes	No
3718	0655-YDGFJ	Male	0	No	No
3719	8468-EHYJA	Female	0	Yes	No
3720	6823-SIDFQ	Male	0	No	No
3721	1097-FSPVW	Female	0	No	No
3722	2839-RFSQE	Female	0	No	No
3723	8328-SKJNO	Male	0	No	Yes
3724	7010-ZMVBF	Female	0	Yes	Yes
3725	5201-CBWYG	Male	0	Yes	Yes
3726	0968-GSIKN	Female	0	No	No
3727	1965-DDBWU	Male	0	No	No
3728	9057-SIHCH	Female	0	No	No
3729	6352-GIGGQ	Male	0	No	No
3730	3635-QQRQD	Male	0	No	No
3731	6771-XWBDM	Female	0	Yes	No
3732	2897-DOVND	Male	0	No	No
3733	3082-YVEKW	Female	0	Yes	Yes
3734	0191-EQUUH	Female	0	No	Yes
3735	7134-HBPBS	Female	1	No	No
3736	3489-HHPFY	Female	0	Yes	No
3737	2926-JEJJC	Female	0	No	No
3738	8601-QACRS	Female	0	No	No
3739	4950-BDEUX	Male	0	No	No
3740	5789-LDFXO	Male	0	No	No
3741	0508-OOLTO	Female	0	Yes	Yes
3742	2984-TBYKU	Male	0	Yes	Yes
3743	9822-WMWVG	Female	0	No	No
3744	2391-SOORI	Male	0	No	Yes
3745	9040-KZVWO	Male	0	No	No
3746	2645-QTLMB	Male	0	No	No
3747	4806-HIPDW	Female	0	Yes	No
3748	1548-ARAGG	Female	0	Yes	Yes
3749	6339-RZCBJ	Male	0	No	No
3750	4424-TKOPW	Male	1	No	No
3751	4415-WNGVR	Female	1	Yes	No
3752	2522-AHJXR	Male	0	Yes	No
3753	0412-UCCNP	Male	0	No	No
3754	1816-FLZDK	Male	0	No	No
3755	7096-UCLNH	Male	0	No	No
3756	8443-ZRDBZ	Male	0	No	No
3757	9136-ALYBR	Male	0	No	No
3758	4615-PIVVU	Female	0	No	No
3759	8885-QSQBX	Female	0	No	No
3760	7479-NITWS	Male	0	No	No
3761	8617-ENBDS	Male	0	No	No
3762	9385-NXKDA	Female	0	Yes	No
3763	0430-IHCDJ	Male	0	No	No
3764	2959-MJHIC	Male	0	Yes	No
3765	6674-KVJHG	Female	0	No	No
3766	1814-DKOLC	Female	0	No	No
3767	4201-JMNGR	Female	1	No	No
3768	9351-HXDMR	Male	0	Yes	No
3769	3537-HPKQT	Female	0	Yes	No
3770	2129-ALKBS	Female	0	Yes	Yes
3771	5821-MMEIL	Female	0	Yes	No
3772	5960-WPXQM	Male	0	No	No
3773	0684-AOSIH	Male	0	Yes	No
3774	8260-NGFNY	Female	0	No	No
3775	1309-XGFSN	Male	1	Yes	Yes
3776	1866-RZZQS	Male	1	No	No
3777	6968-URWQU	Male	0	Yes	No
3778	4742-TXUEX	Female	0	Yes	Yes
3779	9631-XEYKE	Male	0	No	No
3780	8631-NBHFZ	Male	1	Yes	Yes
3781	1335-MXCSE	Male	0	Yes	Yes
3782	8873-TMKGR	Male	0	No	No
3783	8800-JOOCF	Female	0	No	Yes
3784	1469-LBJQJ	Female	0	Yes	No
3785	4958-XCBDQ	Male	1	No	No
3786	8337-UPOAQ	Male	1	Yes	No
3787	0064-YIJGF	Male	0	Yes	Yes
3788	2386-OWURY	Female	0	No	No
3789	1725-IQNIY	Male	0	Yes	No
3790	0310-VQXAM	Male	0	No	No
3791	6598-RFFVI	Male	0	No	No
3792	3453-RTHJQ	Male	0	No	No
3793	6712-OAWRH	Female	1	No	No
3794	6278-FEPBZ	Female	0	No	No
3795	4280-DLSHD	Male	0	Yes	No
3796	1508-DFXCU	Male	0	No	No
3797	8614-VGMMV	Female	0	No	No
3798	7868-BGSZA	Male	0	Yes	No
3799	2800-QQUSO	Male	0	No	No
3800	2930-UOTMB	Female	0	No	No
3801	7973-DZRKH	Female	0	No	Yes
3802	5914-DVBWJ	Female	1	No	No
3803	7698-YFGEZ	Male	0	No	No
3804	2533-QVMSK	Male	0	Yes	No
3805	9773-PEQBZ	Male	0	No	No
3806	8644-XLFBW	Male	1	No	No
3807	0650-BWOZN	Female	1	No	No
3808	8625-AZYZY	Male	0	Yes	No
3809	7785-RDVIG	Female	0	Yes	Yes
3810	9602-WCXPI	Male	0	No	No
3811	2903-YYTBW	Male	0	Yes	Yes
3812	3620-MWJNE	Male	0	No	No
3813	8573-JGCZW	Male	0	No	No
3814	6837-HAEVO	Male	0	Yes	Yes
3815	6701-YVNQG	Male	0	Yes	No
3816	9306-CPCBC	Female	0	No	No
3817	4304-XUMGI	Male	1	Yes	Yes
3818	9504-YAZWB	Female	0	No	No
3819	8819-ZBYNA	Female	0	Yes	No
3820	6174-NRBTZ	Male	0	No	No
3821	9481-IEBZY	Male	1	Yes	No
3822	1833-VGRUM	Female	1	No	No
3823	6137-NICCO	Female	0	Yes	Yes
3824	9065-ZCPQX	Male	0	Yes	No
3825	6402-EJMWF	Male	0	No	No
3826	3620-EHIMZ	Female	0	Yes	Yes
3827	3213-VVOLG	Male	0	Yes	Yes
3828	6870-ECSHE	Female	0	No	No
3829	8747-UDCOI	Female	0	Yes	No
3830	8374-XGEJJ	Male	1	Yes	No
3831	2656-TABEH	Male	0	Yes	No
3832	6946-LMSQS	Male	1	Yes	No
3833	4626-OZDTJ	Female	0	Yes	No
3834	9169-BSVIN	Male	0	No	No
3835	2325-ZUSFD	Female	0	Yes	Yes
3836	8194-PEEBY	Female	0	Yes	Yes
3837	6872-HXFNF	Female	0	Yes	No
3838	3932-CMDTD	Female	0	No	No
3839	7714-YXSMB	Female	0	No	No
3840	8387-UGUSU	Female	0	Yes	Yes
3841	1080-BWSYE	Male	1	Yes	No
3842	4039-HEUNW	Male	1	Yes	No
3843	1194-HVAIF	Female	0	Yes	No
3844	0812-WUPTB	Male	1	Yes	No
3845	3594-UVONA	Female	0	No	No
3846	0004-TLHLJ	Male	0	No	No
3847	1767-TGTKO	Female	0	Yes	Yes
3848	8439-LTUGF	Male	0	No	No
3849	8805-JNRAZ	Female	0	No	No
3850	5089-IFSDP	Female	0	Yes	No
3851	6418-HNFED	Male	0	Yes	No
3852	0206-OYVOC	Female	0	Yes	Yes
3853	7291-CDTMJ	Male	0	No	No
3854	7128-GGCNO	Male	0	No	No
3855	0237-YFUTL	Female	0	Yes	No
3856	7691-KGKGP	Male	0	Yes	Yes
3857	6710-HSJRD	Male	0	Yes	No
3858	3675-EQOZA	Male	0	No	No
3859	0840-DCNZE	Male	0	No	No
3860	1732-FEKLD	Female	0	No	No
3861	9862-KJTYK	Male	0	No	Yes
3862	0479-HMSWA	Female	0	No	Yes
3863	5854-KSRBJ	Male	0	Yes	Yes
3864	0365-BZUWY	Male	0	Yes	No
3865	4817-VYYWS	Female	0	No	No
3866	5701-SVCWR	Female	0	No	Yes
3867	3129-AAQOU	Female	0	Yes	Yes
3868	4922-CVPDX	Female	0	Yes	No
3869	1396-QWFBJ	Female	0	Yes	Yes
3870	1357-BIJKI	Male	0	Yes	No
3871	1099-BTKWT	Female	0	Yes	No
3872	5299-SJCZT	Male	0	No	No
3873	2018-PZKMU	Male	0	Yes	Yes
3874	7340-KEFQE	Female	0	Yes	Yes
3875	4570-QHXHL	Female	0	No	No
3876	2403-BCASL	Male	1	Yes	Yes
3877	7392-YYPYJ	Male	0	No	No
3878	2898-LSJGD	Female	0	Yes	Yes
3879	2223-GDSHL	Male	0	Yes	Yes
3880	7359-PTSXY	Male	0	No	No
3881	9470-RTWDV	Male	0	Yes	Yes
3882	2176-OSJUV	Male	0	Yes	No
3883	9348-YVOMK	Male	0	No	No
3884	8104-OSKWT	Female	0	No	No
3885	4521-YEEHE	Female	0	Yes	No
3886	4090-KPJIP	Female	0	No	No
3887	3786-WOVKF	Female	1	Yes	No
3888	4503-BDXBD	Male	0	No	No
3889	6086-ESGRL	Female	0	No	No
3890	2592-HODOV	Male	0	No	No
3891	3886-CERTZ	Female	0	Yes	No
3892	7995-ZHHNZ	Male	0	Yes	No
3893	3824-RHKVR	Female	0	No	No
3894	5816-SCGFC	Female	1	No	No
3895	5989-AXPUC	Female	0	Yes	No
3896	4979-HPRFL	Male	0	Yes	Yes
3897	8590-OHDIW	Female	0	Yes	Yes
3898	8015-IHCGW	Female	0	Yes	Yes
3899	2332-TODQS	Female	0	No	No
3900	9278-VZKCD	Female	1	Yes	No
3901	8008-OTEZX	Female	0	Yes	Yes
3902	2773-OVBPK	Male	0	Yes	No
3903	5999-LCXAO	Female	0	No	No
3904	5206-XZZQI	Male	0	No	No
3905	4803-LBYPN	Male	0	Yes	Yes
3906	5759-RCVCB	Female	0	No	No
3907	6372-RFVNS	Female	0	Yes	No
3908	2139-FQHLM	Male	0	No	No
3909	8261-GWDBQ	Female	1	Yes	No
3910	1093-YSWCA	Male	0	No	No
3911	8938-UMKPI	Female	0	No	No
3912	0991-BRRFB	Male	0	No	No
3913	3882-IYOIJ	Female	0	Yes	Yes
3914	8749-TZYEC	Male	0	Yes	No
3915	1755-FZQEC	Male	0	No	No
3916	3115-JPJDD	Female	0	Yes	No
3917	5600-KTXFM	Male	0	Yes	Yes
3918	3871-IKPYH	Male	1	No	No
3919	6319-IEJWJ	Male	0	Yes	Yes
3920	9025-AOMKI	Female	0	No	No
3921	6339-TBELP	Male	0	No	No
3922	7964-YESJC	Female	0	Yes	No
3923	6173-GOLSU	Male	1	Yes	No
3924	5275-SQEIZ	Male	0	No	No
3925	7716-YTYHG	Female	0	Yes	Yes
3926	9938-ZREHM	Female	0	Yes	No
3927	7950-XWOVN	Male	0	No	No
3928	4390-KYULV	Male	0	Yes	No
3929	4647-MUZON	Female	0	Yes	No
3930	9702-AIUJO	Male	0	Yes	Yes
3931	8849-PRIQJ	Female	0	Yes	Yes
3932	8851-RAGOV	Female	0	Yes	No
3933	1304-NECVQ	Female	1	No	No
3934	5396-IZEPB	Male	0	No	No
3935	1729-VLAZJ	Female	0	No	Yes
3936	8285-ABVLB	Female	0	Yes	No
3937	0701-TJSEF	Male	0	No	No
3938	5712-VBOXD	Female	0	No	No
3939	6629-LADHQ	Female	0	No	No
3940	8945-GRKHX	Female	0	No	Yes
3941	1559-DTODC	Male	0	No	No
3942	4797-MIWUM	Male	0	Yes	Yes
3943	6959-UWKHF	Male	0	No	No
3944	8720-RQSBJ	Male	1	No	No
3945	4537-CIBHB	Female	0	Yes	Yes
3946	3815-SLMEF	Female	0	No	No
3947	5154-VEKBL	Female	0	No	No
3948	4324-AHJKS	Female	0	No	No
3949	4355-CVPVS	Female	0	Yes	Yes
3950	4495-LHSSK	Female	0	No	Yes
3951	5655-JSMZM	Male	1	No	No
3952	5915-ANOEI	Male	0	Yes	No
3953	9861-PDSZP	Female	0	No	No
3954	4505-EXZHB	Female	1	No	No
3955	7225-CBZPL	Male	1	Yes	No
3956	6704-UTUKK	Male	0	Yes	No
3957	4587-VVTOX	Female	0	Yes	No
3958	2019-HDCZY	Male	0	Yes	No
3959	4652-NNHNY	Male	0	Yes	No
3960	8788-DOXSU	Male	0	No	No
3961	7404-JLKQG	Female	0	No	No
3962	7421-ZLUPA	Female	0	No	No
3963	8972-HJWNV	Female	1	Yes	No
3964	3274-NSDWE	Female	0	No	No
3965	2632-IVXVF	Female	0	Yes	Yes
3966	3692-JHONH	Female	1	Yes	No
3967	8915-NNTRC	Male	0	Yes	Yes
3968	5914-GXMDA	Female	0	Yes	No
3969	7463-IFMQU	Female	0	Yes	No
3970	2920-RNCEZ	Male	0	Yes	Yes
3971	2541-YGPKE	Male	0	Yes	Yes
3972	8515-OCTJS	Female	0	No	No
3973	5382-TEMLV	Male	0	No	No
3974	3441-CGZJH	Female	0	Yes	Yes
3975	9592-ERDKV	Male	0	Yes	No
3976	2860-RANUS	Female	1	No	No
3977	5261-QSHQM	Female	0	No	No
3978	4778-IZARL	Male	0	Yes	No
3979	0432-CAJZV	Male	0	No	No
3980	7008-LZVOZ	Male	0	Yes	Yes
3981	8868-WOZGU	Male	0	No	No
3982	1200-TUZHR	Female	1	No	No
3983	9365-CSLBQ	Male	0	No	Yes
3984	1334-FJSVR	Male	0	No	No
3985	5884-FBCTL	Female	0	Yes	Yes
3986	7130-CTCUS	Male	1	Yes	No
3987	6242-FEGFD	Male	0	Yes	No
3988	7625-XCQRH	Female	0	No	No
3989	6194-HBGQN	Male	0	No	No
3990	7634-WSWDB	Female	0	No	Yes
3991	6986-IXNDM	Male	0	No	No
3992	1731-TVIUK	Female	0	No	No
3993	2987-BJXIK	Female	0	No	No
3994	9769-TSBZE	Female	0	No	Yes
3995	0406-BPDVR	Female	1	Yes	No
3996	0618-XWMSS	Male	0	No	Yes
3997	1395-WSWXR	Male	0	No	No
3998	6023-GSSXW	Female	0	Yes	No
3999	6752-APNJL	Male	0	Yes	Yes
4000	5276-KQWHG	Female	1	No	No
4001	0420-HLGXF	Female	1	No	No
4002	7446-KQISO	Male	0	Yes	Yes
4003	9823-EALYC	Male	0	Yes	Yes
4004	0582-AVCLN	Female	0	No	No
4005	5803-NQJZO	Male	0	Yes	No
4006	2565-JSLRY	Male	0	No	No
4007	2607-DHDAK	Male	0	Yes	Yes
4008	1073-XXCZD	Male	0	Yes	No
4009	0743-HRVFF	Female	0	Yes	Yes
4010	4006-HKYHO	Male	0	No	No
4011	3727-JEZTU	Female	0	No	No
4012	8143-ETQTI	Female	0	Yes	Yes
4013	6689-KXGBO	Female	0	No	No
4014	9667-TKTVZ	Female	0	No	No
4015	3657-COGMW	Female	1	No	No
4016	8570-KLJYJ	Female	0	No	No
4017	7754-IXRMC	Female	0	No	No
4018	9473-CBZOP	Female	0	No	No
4019	2969-WGHQO	Female	0	Yes	Yes
4020	6615-NGGZJ	Male	0	No	No
4021	4334-HOWRP	Male	1	Yes	No
4022	4255-DDUOU	Female	0	Yes	Yes
4023	5863-OOKCL	Female	0	No	No
4024	1686-STUHN	Male	0	No	No
4025	1329-VHWNP	Female	0	No	No
4026	2984-MIIZL	Male	0	No	No
4027	0266-GMEAO	Male	0	Yes	Yes
4028	5590-YRFJT	Female	0	Yes	No
4029	5574-NXZIU	Male	0	No	No
4030	0019-GFNTW	Female	0	No	No
4031	4256-ZWTZI	Female	0	No	Yes
4032	8309-PPCED	Female	0	Yes	No
4033	4098-NAUKP	Male	1	Yes	Yes
4034	5196-WPYOW	Male	0	Yes	Yes
4035	4608-LCIMN	Male	0	Yes	Yes
4036	1485-YDHMM	Male	0	Yes	Yes
4037	4054-CUMIA	Female	0	Yes	Yes
4038	0603-TPMIB	Female	0	Yes	Yes
4039	2525-GVKQU	Female	0	No	No
4040	8161-QYMTT	Male	0	No	No
4041	9581-GVBXT	Male	0	Yes	Yes
4042	5862-BRIXZ	Male	0	No	No
4043	5404-GGUKR	Male	0	No	No
4044	3308-JSGML	Male	1	Yes	No
4045	2126-GSEGL	Female	0	Yes	No
4046	3677-TNKIO	Female	0	No	No
4047	0440-QEXBZ	Female	0	No	No
4048	2434-EEVDB	Female	0	Yes	No
4049	6762-QVYJO	Female	0	Yes	Yes
4050	6199-IWKGC	Female	1	Yes	No
4051	2675-DHUTR	Male	1	Yes	No
4052	8152-VETUR	Female	0	Yes	No
4053	9667-EQRXU	Female	1	No	No
4054	7446-YPODE	Male	1	No	No
4055	9522-BNTHX	Female	1	No	No
4056	4676-WLUHT	Male	0	No	No
4057	3329-WDIOK	Female	0	No	No
4058	7980-MHFLQ	Female	0	Yes	Yes
4059	2873-ZLIWT	Female	0	Yes	Yes
4060	3415-TAILE	Female	0	Yes	Yes
4061	0757-WCUUZ	Male	0	Yes	Yes
4062	1629-DQQVB	Female	0	No	No
4063	1915-IOFGU	Female	0	No	No
4064	3045-XETSH	Female	0	No	No
4065	0374-AACSZ	Female	0	No	No
4066	7239-HZZCX	Male	0	No	No
4067	4872-VXRIL	Male	0	No	No
4068	9140-CZQZZ	Female	0	Yes	No
4069	3423-HHXAO	Female	0	Yes	Yes
4070	9938-TKDGL	Male	0	Yes	Yes
4071	0531-ZZJWQ	Male	1	Yes	No
4072	6537-QLGEX	Female	0	No	No
4073	2688-BHGOG	Male	1	No	No
4074	7683-CBDKJ	Male	0	Yes	Yes
4075	0946-CLJTI	Male	1	Yes	No
4076	3160-TYXLT	Male	0	No	No
4077	1325-USMEC	Male	0	Yes	No
4078	0916-QOFDP	Female	1	Yes	Yes
4079	0628-CNQRM	Male	0	Yes	Yes
4080	5606-AMZBO	Female	0	Yes	No
4081	6199-IPCAO	Female	0	Yes	Yes
4082	7665-TOALD	Female	0	No	No
4083	0112-QWPNC	Male	0	Yes	No
4084	0324-BRPCJ	Female	1	Yes	No
4085	2777-PHDEI	Female	0	No	No
4086	5640-CAXOA	Female	0	No	No
4087	2235-EZAIK	Female	0	Yes	No
4088	3847-BAERP	Female	0	No	No
4089	1196-AMORA	Male	0	No	No
4090	4282-YMKNA	Female	0	No	No
4091	1453-RZFON	Female	0	No	Yes
4092	8263-OKETD	Female	0	No	No
4093	0670-KDOMA	Female	0	No	No
4094	2476-YGEFM	Female	0	No	No
4095	8687-BAFGU	Male	0	No	No
4096	0641-EVBOJ	Male	0	No	No
4097	0829-XXPLX	Female	0	No	No
4098	9974-JFBHQ	Male	0	No	Yes
4099	5356-RHIPP	Male	0	No	No
4100	6624-JDRDS	Female	0	No	No
4101	0608-JDVEC	Male	0	Yes	No
4102	9780-FKVVF	Male	0	No	No
4103	1919-RTPQD	Male	0	Yes	Yes
4104	5214-NLTIT	Male	0	Yes	Yes
4105	3345-PBBFH	Male	0	Yes	No
4106	5055-BRMNE	Female	0	Yes	Yes
4107	9189-JWSHV	Female	1	Yes	No
4108	2190-PHBHR	Female	0	Yes	No
4109	2650-GYRYL	Male	0	Yes	Yes
4110	0746-JTRFU	Male	0	No	No
4111	5208-FVQKB	Male	0	Yes	No
4112	7184-LRUUR	Female	0	No	No
4113	6627-CFOSN	Female	0	No	No
4114	3982-JGSFD	Male	0	No	No
4115	1574-DYCWE	Female	0	Yes	Yes
4116	7247-XOZPB	Male	0	Yes	No
4117	2466-FCCPT	Female	0	Yes	Yes
4118	6211-WWLTF	Male	0	Yes	No
4119	4826-TZEVA	Female	0	No	No
4120	6016-NXBNJ	Male	0	No	No
4121	9138-EFSMO	Male	0	Yes	Yes
4122	0576-WNXXC	Male	1	Yes	No
4123	4632-XJMEX	Male	0	No	Yes
4124	8910-LEDAG	Male	1	Yes	No
4125	3452-GWUIN	Female	1	Yes	No
4126	2716-GFZOR	Male	0	Yes	No
4127	3724-UCSHY	Male	0	Yes	Yes
4128	8626-XHBIE	Male	0	No	Yes
4129	4628-CTTLA	Male	0	No	No
4130	3192-LNKRK	Male	0	Yes	Yes
4131	4439-YRNVD	Female	0	No	No
4132	2876-VBBBL	Female	0	No	No
4133	6834-NXDCA	Female	0	No	No
4134	2208-UGTGR	Male	0	No	No
4135	3005-TYFRD	Female	0	Yes	No
4136	8670-MEFCP	Female	0	Yes	Yes
4137	3079-BCHLN	Male	0	Yes	No
4138	7777-UNYHB	Female	0	Yes	Yes
4139	5597-GLBUC	Female	0	No	No
4140	7278-CKDNC	Male	1	No	No
4141	2748-MYRVK	Female	0	No	No
4142	8450-UYIBU	Female	1	No	No
4143	2969-VAPYH	Female	0	No	No
4144	4822-YCXMX	Male	0	No	No
4145	7181-OQCUT	Male	0	No	No
4146	8474-UMLNT	Female	0	No	No
4147	9821-POOTN	Male	0	Yes	No
4148	3836-FZSDJ	Male	1	Yes	No
4149	9142-XMYJH	Female	0	No	No
4150	6559-ILWKJ	Male	0	Yes	No
4151	0187-QSXOE	Male	1	Yes	No
4152	7733-UDMTP	Female	1	No	No
4153	2649-HWLYB	Male	0	Yes	No
4154	5214-CHIWJ	Male	0	No	No
4155	4229-CZMLL	Male	0	No	No
4156	6904-JLBGY	Female	1	No	No
4157	2465-BLLEU	Male	0	No	No
4158	1685-VAYJF	Male	0	No	No
4159	8874-EJNSR	Male	0	Yes	Yes
4160	6917-YACBP	Female	1	No	No
4161	5049-MUBWG	Male	0	No	No
4162	4223-WOZCM	Male	1	No	No
4163	0769-MURVM	Female	0	Yes	Yes
4164	9253-VIFJQ	Male	0	Yes	No
4165	7030-FZTFM	Male	0	Yes	Yes
4166	9741-YLNTD	Male	0	No	No
4167	5917-RYRMG	Male	1	No	No
4168	5120-ZBLAI	Female	0	Yes	No
4169	1194-BHJYC	Male	0	Yes	No
4170	3663-MITLP	Female	0	No	No
4171	0906-QVPMS	Male	0	Yes	No
4172	9025-ZRPVR	Male	0	No	No
4173	1905-OEILC	Female	0	No	No
4174	7858-GTZSP	Female	0	No	No
4175	3285-UCQVC	Female	0	No	No
4176	6248-BSHKG	Male	0	Yes	Yes
4177	4685-TFLLS	Male	0	Yes	Yes
4178	3470-BTGQO	Male	0	No	Yes
4179	1209-VFFOC	Male	0	Yes	Yes
4180	8224-DWCKX	Male	1	No	No
4181	5482-PLVPE	Female	1	No	No
4182	4553-DVPZG	Female	0	Yes	No
4183	4902-OHLSK	Female	1	No	No
4184	6917-IAYHD	Male	0	No	Yes
4185	0495-ZBNGW	Male	1	Yes	No
4186	8620-RJPZN	Female	0	No	No
4187	7572-KPVKK	Male	0	No	Yes
4188	2642-MAWLJ	Female	0	Yes	Yes
4189	2357-COQEK	Female	1	No	No
4190	7103-ZGVNT	Female	0	Yes	Yes
4191	3737-GCSPV	Female	0	Yes	No
4192	2027-WKXMW	Female	0	Yes	No
4193	7137-NAXML	Male	0	No	No
4194	2428-ZMCTB	Male	0	No	No
4195	2961-VNFKL	Female	0	Yes	No
4196	1768-HNVGJ	Female	1	No	No
4197	6963-KQYQB	Female	0	Yes	Yes
4198	5934-RMPOV	Female	0	No	Yes
4199	1207-BLKSA	Female	0	Yes	Yes
4200	4088-YLDSU	Male	0	Yes	No
4201	8316-BBQAY	Female	0	No	No
4202	1166-PQLGG	Female	0	Yes	Yes
4203	3146-JTQHR	Male	0	Yes	No
4204	4291-YZODP	Female	0	No	Yes
4205	4395-PZMSN	Male	1	No	No
4206	6427-FEFIG	Female	0	Yes	Yes
4207	0017-IUDMW	Female	0	Yes	Yes
4208	8706-HRADD	Male	0	No	No
4209	9955-QOPOY	Male	0	Yes	No
4210	4385-ZKVNW	Male	0	Yes	Yes
4211	5446-DKWYW	Female	1	Yes	Yes
4212	2034-CGRHZ	Male	1	No	No
4213	5797-APWZC	Female	0	No	No
4214	3683-QKIUE	Female	0	No	No
4215	4228-ZGYUW	Male	0	No	No
4216	9031-ZVQPT	Male	0	Yes	No
4217	2990-IAJSV	Male	0	No	No
4218	8107-KNCIM	Male	1	Yes	No
4219	9027-YFHQJ	Male	0	No	No
4220	5176-LDKUH	Female	0	No	No
4221	4644-OBGFZ	Male	0	Yes	Yes
4222	7926-IJOOU	Male	0	No	No
4223	6480-YAGIY	Male	0	No	No
4224	4029-HPFVY	Male	0	No	No
4225	7602-DBTOU	Female	0	Yes	No
4226	5345-BMKWB	Male	0	Yes	No
4227	3519-ZKXGG	Female	0	Yes	No
4228	5457-COLHT	Male	0	Yes	Yes
4229	6416-TVAIH	Male	0	Yes	Yes
4230	5451-YHYPW	Female	1	Yes	No
4231	5108-ADXWO	Male	0	No	No
4232	7998-WNZEM	Male	0	No	No
4233	3066-RRJIO	Female	0	No	No
4234	4664-NJCMS	Female	0	Yes	No
4235	0307-BCOPK	Female	0	No	No
4236	7629-WFGLW	Female	1	Yes	No
4237	2542-HYGIQ	Female	0	No	No
4238	6715-OFDBP	Male	0	No	No
4239	5016-LIPDW	Male	0	Yes	Yes
4240	6481-LXPWL	Male	0	Yes	Yes
4241	1567-DSCIC	Male	0	No	No
4242	2150-UWTFY	Female	0	Yes	Yes
4243	6124-ACRHJ	Female	0	No	No
4244	9362-MWODR	Female	0	No	Yes
4245	9975-GPKZU	Male	0	Yes	Yes
4246	9625-RZFUK	Male	0	Yes	Yes
4247	5153-LXKDT	Male	0	Yes	Yes
4248	5161-UBZXI	Male	0	Yes	Yes
4249	1020-JPQOW	Female	0	Yes	No
4250	7919-ZODZZ	Female	0	Yes	Yes
4251	0565-JUPYD	Male	0	No	No
4252	6867-ACCZI	Female	0	Yes	Yes
4253	5939-XAIXZ	Female	0	No	No
4254	9054-FOWNV	Male	0	Yes	Yes
4255	2683-BPJSO	Male	0	Yes	No
4256	2157-MXBJS	Male	0	Yes	No
4257	8207-VVMYB	Female	0	Yes	No
4258	9732-EQMWY	Female	0	Yes	No
4259	9360-AHGNL	Female	1	Yes	No
4260	1087-UDSIH	Female	0	No	No
4261	5269-NRGDP	Male	0	Yes	Yes
4262	6195-MELTI	Male	0	No	No
4263	5485-WUYWF	Male	1	No	No
4264	2121-JAFOM	Female	0	Yes	No
4265	8818-DOPVL	Female	1	No	No
4266	2632-UCGVD	Male	1	Yes	No
4267	5445-PZWGX	Male	0	No	No
4268	1227-UDMZR	Female	0	Yes	No
4269	5198-HQAEN	Male	0	Yes	Yes
4270	9170-CCKOU	Male	0	Yes	No
4271	2167-FQSTQ	Female	0	Yes	No
4272	2819-GWENI	Female	0	Yes	Yes
4273	1043-YCUTE	Male	0	Yes	No
4274	3814-MLAXC	Female	0	No	No
4275	3572-UUHRS	Male	0	No	No
4276	2692-PFYTJ	Female	0	No	No
4277	1226-UDFZR	Female	0	No	No
4278	5955-EPOAZ	Female	0	No	No
4279	6821-JPCDC	Female	0	Yes	No
4280	8815-LMFLX	Male	0	Yes	Yes
4281	9135-HSWOC	Male	0	Yes	Yes
4282	8582-KRHPJ	Male	0	No	No
4283	5811-IWXYM	Female	0	Yes	Yes
4284	7044-YAACC	Male	1	Yes	No
4285	8189-XRIKE	Female	1	No	No
4286	1506-YJTYT	Male	0	Yes	Yes
4287	4123-DVHPH	Male	0	Yes	No
4288	6425-YQLLO	Female	1	Yes	No
4289	5442-UTCVD	Male	0	No	Yes
4290	2228-BZDEE	Female	0	No	No
4291	7734-DBOAI	Female	0	Yes	Yes
4292	2789-CZANW	Female	0	Yes	Yes
4293	2091-RFFBA	Female	1	No	No
4294	2114-MGINA	Female	0	No	No
4295	7596-LDUXP	Female	0	No	No
4296	3740-RLMVT	Male	1	Yes	No
4297	4489-SNOJF	Female	0	Yes	Yes
4298	2192-OZITF	Female	0	No	No
4299	5651-CPDND	Male	0	No	No
4300	2186-QZEYA	Female	1	No	No
4301	1131-ALZWV	Female	0	No	No
4302	7729-XBTWX	Male	0	Yes	Yes
4303	9134-WYRVP	Male	0	No	No
4304	3284-SVCRO	Female	0	Yes	No
4305	9732-OUYRN	Female	0	Yes	No
4306	0559-CKHUS	Female	0	Yes	No
4307	2931-SVLTV	Male	0	Yes	Yes
4308	6899-PPEEA	Female	1	No	No
4309	7504-UWHNB	Male	0	No	No
4310	2582-FFFZR	Female	0	No	No
4311	8908-NMQTX	Male	0	No	No
4312	2187-LZGPL	Female	0	No	No
4313	1431-AIDJQ	Male	0	Yes	Yes
4314	6288-LBEAR	Female	0	No	No
4315	4597-NUCQV	Male	1	No	No
4316	9019-QVLZD	Female	0	No	No
4317	8413-YNHNV	Male	0	No	No
4318	5808-TOTXO	Female	0	No	Yes
4319	4369-NYSCF	Male	0	No	No
4320	6333-YDVLT	Male	0	No	No
4321	5324-KTGCG	Male	0	Yes	No
4322	5599-HVLTW	Female	1	No	No
4323	7394-LWLYN	Female	0	No	No
4324	3707-LRWZD	Female	0	No	No
4325	6873-UDNLD	Male	0	No	No
4326	2700-LUEVA	Male	0	No	No
4327	1455-ESIQH	Male	0	No	No
4328	0958-YHXGP	Female	0	No	No
4329	1101-SSWAG	Female	0	Yes	No
4330	2979-SXESE	Female	0	Yes	Yes
4331	4013-TLDHQ	Male	0	No	No
4332	5743-KHMNA	Male	0	No	No
4333	4194-FJARJ	Female	0	Yes	Yes
4334	5325-UWTWJ	Male	0	Yes	No
4335	3969-GYXEL	Female	0	No	No
4336	9208-OLGAQ	Female	1	No	No
4337	3244-CQPHU	Female	1	No	No
4338	2674-MLXMN	Female	1	No	No
4339	9708-HPXWZ	Male	1	No	No
4340	6992-TKNYO	Male	0	Yes	No
4341	4468-YDOVK	Male	0	No	Yes
4342	3754-DXMRT	Male	1	No	No
4343	5792-JALQC	Female	1	No	No
4344	7130-VTEWQ	Female	1	No	No
4345	2200-DSAAL	Female	0	No	No
4346	4302-ZYFEL	Male	0	Yes	Yes
4347	9351-LZYGF	Female	0	Yes	No
4348	4366-CTOUZ	Female	0	No	No
4349	6121-VZNQB	Female	0	No	No
4350	7903-CMPEY	Male	1	Yes	No
4351	1518-OMDIK	Male	0	Yes	No
4352	6671-NGWON	Female	0	No	No
4353	0595-ITUDF	Male	0	Yes	Yes
4354	6996-KNSML	Female	0	No	No
4355	1955-IBMMB	Male	0	No	No
4356	0096-BXERS	Female	0	Yes	No
4357	3806-YAZOV	Female	0	No	No
4358	7998-ZLXWN	Female	0	Yes	No
4359	6253-WRFHY	Male	0	Yes	Yes
4360	9133-AYJZG	Female	0	No	No
4361	2675-OTVVJ	Male	1	Yes	No
4362	8680-CGLTP	Male	0	No	No
4363	8430-TWCBX	Female	0	Yes	No
4364	5018-GWURO	Female	0	Yes	No
4365	6741-QRLUP	Female	0	No	No
4366	4737-HOBAX	Male	0	Yes	No
4367	0537-QYZZN	Male	1	Yes	Yes
4368	3340-QBBFM	Male	1	Yes	No
4369	1704-NRWYE	Female	1	No	No
4370	2592-SEIFQ	Male	0	No	No
4371	8200-KLNYW	Female	0	Yes	No
4372	3372-CDXFJ	Male	0	Yes	Yes
4373	4781-ZXYGU	Male	0	Yes	Yes
4374	7632-YUTXB	Female	0	Yes	Yes
4375	2718-YSKCS	Male	0	Yes	Yes
4376	9896-UYMIE	Male	0	No	No
4377	0853-NWIFK	Female	0	No	No
4378	8212-CRQXP	Female	0	Yes	No
4379	6980-CDGFC	Female	0	Yes	No
4380	7691-XVTZH	Female	0	Yes	No
4381	2520-SGTTA	Female	0	Yes	Yes
4382	7481-ATQQS	Female	1	No	No
4383	2277-VWCNI	Female	1	No	No
4384	1088-CNNKB	Male	0	Yes	No
4385	8642-GVWRF	Female	0	Yes	No
4386	1930-BZLHI	Male	0	No	No
4387	3400-ESFUW	Male	0	Yes	Yes
4388	5868-YTYKS	Male	0	No	Yes
4389	3525-DVKFN	Female	0	No	No
4390	1482-OXZSY	Male	0	No	No
4391	0377-JBKKT	Male	0	Yes	Yes
4392	5778-BVOFB	Female	0	No	No
4393	3373-YZZYM	Male	0	Yes	Yes
4394	2057-ZBLPD	Female	0	Yes	No
4395	0228-MAUWC	Male	0	No	No
4396	5502-RLUYV	Female	0	Yes	Yes
4397	0023-HGHWL	Male	1	No	No
4398	7663-YJHSN	Female	0	Yes	No
4399	4915-BFSXL	Male	0	Yes	Yes
4400	3086-RUCRN	Female	0	No	No
4401	5215-LNLDJ	Female	0	Yes	Yes
4402	7576-JMYWV	Female	1	Yes	Yes
4403	9039-RBEEE	Male	0	No	No
4404	0257-KXZGU	Female	0	Yes	Yes
4405	1307-ATKGB	Male	0	No	No
4406	8417-FMLZI	Male	0	Yes	Yes
4407	3714-XPXBW	Female	0	No	No
4408	1850-AKQEP	Male	0	No	Yes
4409	2824-DXNKN	Female	0	Yes	Yes
4410	5227-JSCFE	Male	1	Yes	No
4411	0848-ZGQIJ	Female	0	Yes	No
4412	3621-CHYVB	Female	0	Yes	No
4413	8042-RNLKO	Male	0	No	No
4414	1792-UXAFY	Female	1	No	No
4415	5372-FBKBN	Female	0	No	Yes
4416	0420-TXVSG	Male	0	Yes	No
4417	6217-TOWGS	Female	0	Yes	No
4418	0515-YPMCW	Male	0	No	Yes
4419	0378-XSZPU	Male	0	Yes	No
4420	1045-LTCYT	Female	0	Yes	Yes
4421	1544-JJMYL	Male	0	No	No
4422	4636-JGAAI	Male	0	Yes	No
4423	6874-SGLHU	Male	0	No	No
4424	5951-AOFIH	Male	0	No	No
4425	4729-XKASR	Male	0	No	Yes
4426	3059-NGMXB	Male	0	Yes	Yes
4427	8652-YHIYU	Female	0	No	Yes
4428	5278-PNYOX	Female	0	No	No
4429	5449-FIBXJ	Male	0	Yes	Yes
4430	3486-HOOGQ	Female	0	Yes	Yes
4431	5061-PBXFW	Female	0	Yes	Yes
4432	8630-FJLIB	Female	0	No	No
4433	3891-NLXJB	Male	0	No	No
4434	4749-OJKQU	Female	0	No	No
4435	0577-WHMEV	Female	0	Yes	No
4436	5453-AXEPF	Male	0	Yes	No
4437	3639-XJHKQ	Female	0	No	Yes
4438	3716-LRGXK	Male	0	Yes	No
4439	2263-SFSQZ	Male	0	Yes	Yes
4440	9950-MTGYX	Male	0	Yes	Yes
4441	3397-AVTKU	Male	0	No	No
4442	4825-FUREZ	Male	0	Yes	No
4443	9837-BMCLM	Male	0	No	No
4444	2672-OJQZP	Female	0	No	No
4445	0137-UDEUO	Female	0	No	No
4446	3134-DSHVC	Female	0	No	No
4447	6161-UUUTA	Male	1	No	No
4448	7821-DPRQE	Male	0	Yes	No
4449	6543-XRMYR	Female	1	No	No
4450	2001-EWBQU	Female	0	No	No
4451	4925-LMHOK	Male	0	No	No
4452	1608-GMEWB	Male	1	No	No
4453	6695-AMZUF	Female	0	Yes	No
4454	1455-UGQVH	Male	0	Yes	No
4455	8410-BGQXN	Male	0	No	No
4456	8280-MQRQN	Female	0	No	No
4457	1619-YWUBB	Female	0	Yes	No
4458	7611-YKYTC	Male	0	Yes	Yes
4459	2037-SGXHH	Male	0	Yes	Yes
4460	3178-FESZO	Female	0	No	No
4461	0365-GXEZS	Male	0	Yes	No
4462	0082-OQIQY	Male	0	No	No
4463	6087-MVHJH	Female	0	No	No
4464	4603-JANFB	Male	0	No	No
4465	3018-TFTSU	Male	0	No	No
4466	3606-SBKRY	Male	0	No	No
4467	4806-KEXQR	Male	0	No	No
4468	0667-NSRGI	Female	0	Yes	No
4469	7083-YNSKY	Female	0	No	No
4470	6893-ODYYE	Male	0	No	No
4471	8242-JSVBO	Male	0	No	No
4472	2479-BRAMR	Male	1	Yes	No
4473	9541-ZPSEA	Male	0	Yes	Yes
4474	2665-NPTGL	Female	1	Yes	No
4475	1139-WUOAH	Male	0	No	No
4476	4693-VWVBO	Female	0	No	No
4477	7434-SHXLS	Female	0	No	No
4478	6937-GCDGQ	Male	0	Yes	Yes
4479	0988-JRWWP	Female	0	No	No
4480	5075-JSDKI	Female	0	No	No
4481	7908-QCBCA	Female	0	Yes	No
4482	8644-XYTSV	Male	0	Yes	No
4483	6711-FLDFB	Female	0	No	No
4484	3873-WOSBC	Male	0	Yes	No
4485	7465-ZZRVX	Male	0	No	No
4486	7975-JMZNT	Male	0	Yes	No
4487	7251-XFOIL	Female	0	No	No
4488	4116-IQRFR	Male	0	Yes	Yes
4489	3714-JTVOV	Female	1	Yes	No
4490	8259-DZLIZ	Female	0	Yes	Yes
4491	0442-ZXKVS	Female	1	Yes	No
4492	7853-WNZSY	Male	0	No	No
4493	3120-FAZKD	Male	0	Yes	Yes
4494	8606-OEGQZ	Female	0	No	Yes
4495	0225-ZORZP	Male	0	No	No
4496	4702-IOQDC	Female	0	No	No
4497	9489-JMTTN	Female	0	Yes	Yes
4498	0575-CUQOV	Male	1	Yes	No
4499	0967-BMLBD	Female	0	Yes	Yes
4500	6178-KFNHS	Female	0	No	Yes
4501	2830-LEWOA	Male	0	Yes	Yes
4502	5006-MXVRN	Female	0	No	No
4503	1264-BYWMS	Male	0	No	No
4504	9658-WYUFB	Female	0	No	No
4505	8327-WKMIE	Male	0	No	No
4506	6917-FIJHC	Female	0	Yes	No
4507	5329-KRDTM	Male	1	Yes	No
4508	7797-EJMDP	Female	0	No	No
4509	3530-VWVGU	Female	0	Yes	Yes
4510	2013-SGDXK	Female	0	No	No
4511	6368-NWMCE	Female	0	No	No
4512	3633-CDBUW	Male	0	No	Yes
4513	0707-HOVVN	Female	1	No	No
4514	8580-QVLOC	Female	1	Yes	Yes
4515	3956-MGXOG	Female	0	No	No
4516	9274-UARKJ	Female	0	No	No
4517	4077-HWUYD	Male	0	Yes	Yes
4518	2012-NWRPA	Female	1	Yes	No
4519	8808-ELEHO	Male	1	No	No
4520	0103-CSITQ	Female	0	Yes	No
4521	3506-LCJDC	Male	0	Yes	Yes
4522	8671-KKKOS	Female	0	Yes	No
4523	7305-ZWMAJ	Male	0	Yes	No
4524	9518-XXBXE	Male	1	Yes	No
4525	3934-HXCFZ	Male	0	Yes	No
4526	6578-KRMAW	Male	0	No	No
4527	4860-IJUDE	Male	0	No	No
4528	7666-WKRON	Female	0	No	No
4529	9688-YGXVR	Female	0	No	No
4530	0423-UDIJQ	Male	1	No	No
4531	1945-XISKS	Female	0	Yes	No
4532	4910-AQFFX	Male	0	Yes	Yes
4533	2154-KVJFF	Female	0	No	No
4534	5360-LJCNJ	Female	0	Yes	No
4535	2607-FBDFF	Male	0	No	No
4536	9647-ERGBE	Female	0	Yes	Yes
4537	3428-XZMAZ	Male	0	No	No
4538	1100-DDVRV	Male	0	Yes	No
4539	0378-TOVMS	Female	0	No	No
4540	4355-HBJHH	Male	0	Yes	Yes
4541	6728-WYQBC	Male	0	No	No
4542	9058-CBREO	Female	1	No	No
4543	9029-FEGVJ	Female	1	Yes	No
4544	7216-KAOID	Male	0	Yes	Yes
4545	0318-QUUOB	Male	0	Yes	No
4546	6145-NNPNO	Female	0	No	No
4547	5520-FVEWJ	Female	0	Yes	Yes
4548	5339-TJFEK	Male	0	Yes	Yes
4549	5572-ZDXHY	Female	0	No	No
4550	2074-GUHPQ	Female	0	No	Yes
4551	4625-XMOYM	Female	0	Yes	Yes
4552	5827-MWCZK	Male	0	Yes	Yes
4553	1385-TQOZW	Female	0	No	No
4554	5914-XRFQB	Male	0	Yes	No
4555	4329-YPDDQ	Male	0	No	No
4556	4804-NCPET	Male	0	Yes	Yes
4557	3750-CKVKH	Male	0	No	No
4558	5944-UGLLK	Male	0	No	No
4559	8063-GBATB	Female	1	No	No
4560	7787-BNTZM	Male	0	No	No
4561	2252-ISRNH	Male	0	Yes	Yes
4562	9415-TPKRV	Female	0	Yes	Yes
4563	5322-TEUJK	Female	0	Yes	Yes
4564	4547-KQRTM	Female	0	No	No
4565	4877-EVATK	Male	0	No	No
4566	1866-DIOQZ	Female	0	Yes	No
4567	8375-KVTHK	Male	0	Yes	No
4568	2697-NQBPF	Male	0	No	No
4569	3709-OIJEA	Male	0	No	No
4570	7639-SUPCW	Female	0	No	No
4571	1386-ZIKUV	Male	0	No	No
4572	0599-XNYDO	Female	0	Yes	No
4573	6377-WHAOX	Female	0	Yes	No
4574	6855-VLGOS	Male	0	Yes	Yes
4575	8999-XXGNS	Female	1	Yes	No
4576	8746-OQQRW	Male	0	No	No
4577	3181-MIZBN	Male	0	Yes	Yes
4578	0471-ARVMX	Female	1	Yes	No
4579	7766-CLTIC	Female	0	No	No
4580	5650-YLIBA	Male	0	No	No
4581	0825-CPPQH	Female	0	Yes	No
4582	9084-OAYKL	Male	0	No	No
4583	6122-LJADA	Male	0	Yes	Yes
4584	2400-XIWIO	Female	0	Yes	No
4585	7524-VRLPL	Male	1	No	No
4586	1069-XAIEM	Female	1	No	No
4587	7569-NMZYQ	Female	0	Yes	Yes
4588	5201-USSQZ	Female	0	Yes	No
4589	2105-PHWON	Female	0	Yes	No
4590	1494-EJZDW	Female	0	Yes	Yes
4591	4884-TVUQF	Female	1	No	No
4592	8003-EWNDZ	Female	0	No	No
4593	1897-RCFUM	Female	0	Yes	Yes
4594	9256-JTBNZ	Female	0	No	No
4595	4658-HCOHW	Female	0	Yes	Yes
4596	2211-RMNHO	Female	0	Yes	Yes
4597	2432-TFSMK	Male	0	No	No
4598	3440-JPSCL	Female	0	No	No
4599	4929-ROART	Male	0	No	No
4600	1834-ABKHQ	Female	0	Yes	Yes
4601	1741-WTPON	Male	0	Yes	Yes
4602	3932-IJWDZ	Male	0	No	No
4603	1240-HCBOH	Female	0	No	No
4604	3594-KADLU	Male	0	Yes	No
4605	8065-BVEPF	Male	1	No	No
4606	3796-ENZGF	Male	0	Yes	No
4607	1734-ZMNTZ	Female	0	Yes	Yes
4608	2853-CWQFQ	Male	0	No	Yes
4609	0813-TAXXS	Male	0	No	No
4610	2519-TWKFS	Male	0	Yes	Yes
4611	2889-FPWRM	Male	0	Yes	No
4612	0626-QXNGV	Female	0	Yes	No
4613	6723-CEGQI	Female	0	No	Yes
4614	6987-XQSJT	Female	1	No	No
4615	4732-RRJZC	Male	0	Yes	Yes
4616	9499-XPZXM	Female	0	Yes	No
4617	4338-EYCER	Male	0	Yes	No
4618	3007-FDPEA	Female	0	No	No
4619	6350-XFYGW	Male	1	No	No
4620	4290-BSXUX	Male	0	Yes	No
4621	8513-OLYGY	Male	0	Yes	No
4622	0311-QYWSS	Female	0	No	No
4623	8705-DWKTI	Male	0	No	No
4624	8755-IWJHN	Male	1	Yes	No
4625	0325-XBFAC	Male	0	No	No
4626	4480-QQRHC	Female	1	No	No
4627	0929-PECLO	Female	1	No	No
4628	3680-CTHUH	Male	0	No	No
4629	1202-KKGFU	Female	0	Yes	No
4630	6112-KTHFQ	Female	0	No	No
4631	1852-XEMDW	Male	0	No	No
4632	2462-XIIJB	Male	0	No	No
4633	4760-XOHVN	Female	0	Yes	Yes
4634	1820-DJFPH	Female	0	Yes	Yes
4635	9426-SXNHE	Female	0	No	No
4636	9068-FHQHD	Female	0	Yes	Yes
4637	1269-FOYWN	Male	0	Yes	Yes
4638	9470-YFUYI	Male	1	Yes	No
4639	7817-BOQPW	Female	0	No	No
4640	7402-EYFXX	Male	1	No	No
4641	1853-UDXBW	Male	0	Yes	Yes
4642	9895-VFOXH	Female	0	No	No
4643	5458-CQJTA	Male	0	Yes	Yes
4644	1230-QAJDW	Male	0	No	No
4645	5701-ZIKJE	Male	0	No	No
4646	5219-YIPTK	Female	0	Yes	No
4647	5032-MIYKT	Female	0	No	No
4648	7396-VJUZB	Male	0	Yes	Yes
4649	9717-QEBGU	Male	0	No	No
4650	5172-RKOCB	Male	0	Yes	No
4651	6509-TSGWN	Female	0	Yes	Yes
4652	3540-RZJYU	Female	0	No	No
4653	3178-CIFOT	Female	0	No	No
4654	2091-MJTFX	Female	0	Yes	Yes
4655	4530-NDRKU	Female	0	Yes	Yes
4656	5985-TBABQ	Female	0	No	No
4657	9800-ONTFE	Female	0	Yes	Yes
4658	6743-HHQPF	Male	0	Yes	No
4659	8455-HIRAQ	Female	0	No	No
4660	6616-AALSR	Female	0	Yes	Yes
4661	0883-EIBTI	Female	0	No	No
4662	9415-ZNBSX	Female	0	Yes	Yes
4663	4018-KJYUY	Male	0	No	Yes
4664	0722-TROQR	Female	1	No	No
4665	7571-YXDAD	Female	0	No	No
4666	3884-UEBXB	Female	0	Yes	Yes
4667	8780-RSYYU	Female	0	No	No
4668	5537-UXXVS	Female	0	Yes	No
4669	1791-PQHBB	Female	0	No	Yes
4670	8701-DGLVH	Male	0	No	No
4671	8741-LQOBK	Female	0	Yes	Yes
4672	3393-FMZPV	Female	0	No	No
4673	8082-GHXOP	Male	0	No	Yes
4674	6402-ZFPPI	Female	1	No	No
4675	0980-FEXWF	Male	0	Yes	Yes
4676	7486-KSRVI	Male	0	No	No
4677	3011-WQKSZ	Male	0	No	Yes
4678	8443-WVPSS	Male	0	Yes	No
4679	3006-XIMLN	Female	0	No	Yes
4680	8218-FFJDS	Female	0	Yes	No
4681	1986-PHGZF	Male	1	No	No
4682	9965-YOKZB	Male	1	No	No
4683	0504-HHAPI	Female	1	No	No
4684	9360-OMDZZ	Male	0	No	No
4685	6305-YLBMM	Male	0	No	No
4686	0345-XMMUG	Female	0	Yes	No
4687	8024-XNAFQ	Female	1	No	No
4688	3647-GMGDH	Male	0	Yes	No
4689	2988-GBIVW	Female	1	Yes	No
4690	2832-SCUCO	Female	0	No	No
4691	7036-ZZKBD	Male	0	Yes	No
4692	3791-LGQCY	Female	1	Yes	No
4693	0265-PSUAE	Female	0	Yes	Yes
4694	0463-TXOAK	Male	0	No	Yes
4695	0594-UFTUL	Male	0	Yes	Yes
4696	9509-MPYOD	Female	0	No	No
4697	9128-CPXKI	Female	0	No	No
4698	0129-KPTWJ	Male	0	Yes	No
4699	8166-ZZTFS	Female	1	Yes	No
4700	5855-EIBDE	Female	0	Yes	No
4701	5365-LLFYV	Female	0	No	No
4702	5956-YHHRX	Male	1	No	No
4703	6008-NAIXK	Male	1	No	No
4704	2956-GGUCQ	Male	1	Yes	No
4705	1928-BXYIV	Male	0	No	No
4706	5760-FXFVO	Male	0	No	No
4707	6595-COKXZ	Female	0	No	No
4708	0961-ZWLVI	Male	0	No	Yes
4709	5181-OABFK	Female	0	Yes	Yes
4710	4007-NHVHI	Female	1	No	No
4711	7816-VGHTO	Female	0	Yes	Yes
4712	5871-DGTXZ	Male	0	No	No
4713	7550-WIQVA	Male	0	Yes	Yes
4714	7544-ZVIKX	Male	0	Yes	Yes
4715	0016-QLJIS	Female	0	Yes	Yes
4716	7508-DQAKK	Female	0	No	No
4717	5176-OLSKT	Female	0	Yes	No
4718	9356-AXGMP	Male	0	Yes	No
4719	3556-BVQGL	Female	0	Yes	No
4720	0362-ZBZWJ	Male	0	No	No
4721	8979-CAMGB	Male	1	No	No
4722	4211-MMAZN	Male	0	No	No
4723	7581-EBBOU	Female	0	No	No
4724	4274-OWWYO	Male	0	No	No
4725	5073-RZGBK	Female	0	Yes	Yes
4726	1541-ETJZO	Male	0	No	No
4727	2192-CKRLV	Female	0	Yes	No
4728	3154-HMWUU	Male	0	Yes	No
4729	6119-SPUDB	Male	0	No	No
4730	6522-OIQSX	Female	0	Yes	Yes
4731	7813-ZGGAW	Male	1	No	No
4732	8748-HFWBO	Male	0	Yes	Yes
4733	1052-QJIBV	Female	0	Yes	Yes
4734	1319-YLZJG	Male	0	Yes	No
4735	4106-HADHQ	Male	0	Yes	Yes
4736	0723-FDLAY	Male	0	No	No
4737	3050-RLLXC	Female	0	Yes	Yes
4738	9298-WGMRW	Female	0	Yes	No
4739	2369-UAPKZ	Male	0	No	No
4740	3088-LHEFH	Female	0	No	No
4741	2778-OCLGR	Male	1	Yes	No
4742	6583-KQJLK	Female	1	Yes	No
4743	8544-JNBOX	Male	0	No	No
4744	6681-ZSEXG	Male	0	Yes	No
4745	6139-ZZRBQ	Male	1	No	No
4746	6116-RFVHN	Female	0	Yes	No
4747	0637-KVDLV	Male	0	No	No
4748	8884-FEEWR	Male	0	No	No
4749	3125-RAHBV	Male	0	No	No
4750	6633-MPWBS	Male	0	No	No
4751	0373-AIVNJ	Male	0	No	No
4752	8785-EPNCG	Male	0	No	No
4753	1682-VCOIO	Male	0	No	No
4754	5729-KLZAR	Female	0	Yes	Yes
4755	2072-ZVJJX	Male	0	Yes	No
4756	8849-AYPTR	Male	0	Yes	No
4757	9518-IMLHK	Male	0	No	No
4758	1582-RAFML	Male	0	No	No
4759	3646-ITDGM	Female	0	No	No
4760	8740-CRYFY	Male	0	No	No
4761	3569-VLDHH	Male	0	Yes	Yes
4762	8224-KDLKN	Male	0	Yes	Yes
4763	7594-LZNWR	Male	1	No	No
4764	4001-TSBTV	Female	0	Yes	Yes
4765	2962-XPMCQ	Male	0	No	No
4766	8727-XDPUD	Male	0	No	No
4767	1043-UXOVO	Female	0	No	No
4768	1064-FBXNK	Male	0	Yes	Yes
4769	3996-ZNWYK	Male	1	Yes	Yes
4770	2878-DHMIN	Male	0	Yes	Yes
4771	7762-ONLJY	Female	0	Yes	Yes
4772	1678-FYZOW	Female	0	No	No
4773	5795-BKOYE	Female	0	Yes	Yes
4774	8627-EHGIP	Male	0	No	No
4775	7402-PWYJJ	Female	0	Yes	No
4776	5480-TBGPH	Female	0	Yes	No
4777	0018-NYROU	Female	0	Yes	No
4778	7501-VTYLJ	Female	0	No	Yes
4779	7608-RGIRO	Male	0	No	Yes
4780	0480-BIXDE	Female	0	Yes	No
4781	5895-QSXOD	Male	0	No	No
4782	9814-AOUDH	Male	0	No	No
4783	6175-IRFIT	Male	0	No	No
4784	8760-ZRHKE	Female	1	Yes	Yes
4785	1622-HSHSF	Female	0	No	No
4786	8854-CCVSQ	Male	0	No	No
4787	6749-UTDVX	Male	0	No	No
4788	5542-DHSXL	Female	0	Yes	No
4789	9102-OXKFY	Male	0	No	No
4790	0511-JTEOY	Female	0	No	No
4791	5216-WASFJ	Female	1	Yes	No
4792	7808-DVWEP	Male	0	Yes	No
4793	7067-KSAZT	Female	1	Yes	No
4794	2284-VFLKH	Male	0	Yes	No
4795	0366-NQSHS	Male	0	No	No
4796	6532-YLWSI	Female	0	Yes	No
4797	3807-BPOMJ	Female	0	Yes	No
4798	3892-NXAZG	Male	0	Yes	Yes
4799	4948-WBBKL	Female	1	No	No
4800	4182-BGSIQ	Female	0	Yes	Yes
4801	9300-AGZNL	Male	1	No	No
4802	0988-AADSA	Female	0	Yes	Yes
4803	9972-NKTFD	Female	0	No	No
4804	3717-LNXKW	Male	0	Yes	No
4805	5734-EJKXG	Female	0	No	No
4806	2207-RYYRL	Male	0	Yes	Yes
4807	6729-FZWSY	Male	0	No	No
4808	9695-IDRZR	Female	0	No	Yes
4809	8144-DGHXP	Female	0	No	No
4810	7814-LEEVE	Female	0	Yes	No
4811	1112-CUNAO	Female	1	No	No
4812	5175-AOBHI	Female	0	No	No
4813	5174-RNGBH	Female	0	No	No
4814	8631-WUXGY	Female	0	No	Yes
4815	7270-BDIOA	Female	0	No	No
4816	9565-JSNFM	Male	0	No	No
4817	5906-DVAPM	Female	0	Yes	Yes
4818	6654-QGBZZ	Female	0	No	No
4819	8348-JLBUG	Male	1	Yes	No
4820	0607-DAAHE	Male	0	No	Yes
4821	5641-DMBFJ	Female	0	Yes	No
4822	9200-NLNPD	Male	0	Yes	No
4823	2664-XJZNO	Male	0	Yes	Yes
4824	9732-KPKBW	Male	0	No	No
4825	3339-EAQNV	Male	1	Yes	No
4826	0921-OHLVP	Male	0	No	No
4827	3389-YGYAI	Female	1	No	No
4828	9560-ARGQJ	Female	0	No	Yes
4829	8350-NYMVI	Female	0	No	No
4830	1600-DILPE	Female	0	No	No
4831	0536-ESJEP	Male	0	Yes	No
4832	4654-GGUII	Female	0	No	No
4833	6478-HRRCZ	Male	0	Yes	No
4834	8510-BBWMU	Female	0	No	No
4835	6857-TKDJV	Male	0	Yes	Yes
4836	2360-RDGRO	Male	0	Yes	No
4837	0584-BJQGZ	Female	0	No	No
4838	5134-IKDAY	Female	0	Yes	Yes
4839	1360-XFJMR	Female	0	Yes	No
4840	3070-DVEYC	Male	1	No	No
4841	5730-RIITO	Female	1	No	No
4842	9058-MJLZC	Female	0	No	No
4843	5707-ORNDZ	Male	1	No	No
4844	0902-XKXPN	Male	0	Yes	Yes
4845	5177-RVZNU	Female	0	No	Yes
4846	0056-EPFBG	Male	0	Yes	Yes
4847	8993-IZEUX	Male	0	No	No
4848	8696-JKZNU	Female	1	No	No
4849	5380-AFSSK	Female	0	No	No
4850	8190-ZTQFB	Male	0	No	No
4851	0931-MHTEM	Female	0	No	No
4852	2055-PDADH	Female	1	No	No
4853	7515-LODFU	Male	1	No	No
4854	0440-UEDAI	Female	0	No	No
4855	1337-BOZWO	Male	0	Yes	Yes
4856	0868-VJRDR	Male	0	Yes	No
4857	8714-EUHJO	Female	0	Yes	Yes
4858	6344-SFJVH	Female	0	No	No
4859	3950-VPYJB	Male	0	Yes	Yes
4860	8041-TMEID	Male	1	Yes	No
4861	7321-ZNSLA	Male	0	Yes	Yes
4862	6941-KXRRV	Female	1	Yes	No
4863	3721-CNEYS	Female	0	No	No
4864	8727-JQFHV	Male	0	Yes	Yes
4865	9475-NNDGC	Male	0	Yes	No
4866	1355-KUSBG	Female	0	Yes	Yes
4867	3688-FTHLT	Female	0	No	No
4868	0899-LIIBW	Male	0	Yes	No
4869	2568-OIADY	Female	0	Yes	No
4870	1384-RCUXW	Male	0	No	No
4871	5825-XJOCM	Male	0	No	Yes
4872	6848-YLDFR	Male	0	Yes	Yes
4873	8125-QPFJD	Female	0	Yes	No
4874	2320-YKQBO	Female	0	No	No
4875	1193-RTSLK	Female	0	No	No
4876	2302-ANTDP	Female	1	Yes	No
4877	5923-GXUOC	Male	0	No	No
4878	4973-RLZVI	Female	0	No	No
4879	7869-ZYDST	Male	0	Yes	No
4880	4501-UYKBC	Female	1	No	No
4881	1215-EXRMO	Male	0	Yes	No
4882	2305-MRGLV	Male	0	Yes	No
4883	8404-VIOMB	Female	0	No	No
4884	5233-GEEAX	Male	1	No	No
4885	2359-KLTEK	Female	0	Yes	Yes
4886	5304-EFJLP	Male	1	Yes	No
4887	2673-ZALNP	Female	0	No	No
4888	9184-GALIL	Female	0	Yes	Yes
4889	4393-RYCRE	Male	0	No	No
4890	9746-MDMBK	Male	0	Yes	Yes
4891	3162-ZJZFU	Male	0	Yes	Yes
4892	8404-GFGCZ	Male	0	Yes	No
4893	8875-AKBYH	Male	1	No	No
4894	4432-ADRLB	Male	0	No	No
4895	0533-UCAAU	Male	1	Yes	No
4896	1394-SUIUH	Female	1	Yes	No
4897	3521-MNKLV	Male	0	No	No
4898	2533-TIBIX	Male	0	Yes	Yes
4899	8993-PHFWD	Female	0	No	No
4900	1565-RHDJD	Female	0	No	Yes
4901	7137-RYLPP	Male	1	Yes	No
4902	3765-JXVKY	Female	0	No	No
4903	5092-STPKP	Female	0	No	No
4904	7330-WZLNC	Female	0	No	No
4905	0114-PEGZZ	Female	0	No	No
4906	3359-DSRKA	Female	0	Yes	Yes
4907	8639-NHQEI	Female	0	Yes	Yes
4908	7161-DFHUF	Female	0	Yes	No
4909	3957-LXOLK	Female	1	No	No
4910	3720-DBRWL	Male	0	Yes	No
4911	6635-MYYYZ	Female	0	No	No
4912	8565-WUXZU	Male	1	Yes	No
4913	5281-BUZGT	Male	1	No	No
4914	4994-OBRSZ	Male	0	No	Yes
4915	0562-FGDCR	Female	0	Yes	Yes
4916	2436-QBZFP	Female	0	Yes	Yes
4917	3420-YJLQT	Female	0	No	No
4918	6040-CGACY	Female	0	No	No
4919	6582-PLFUU	Male	0	Yes	Yes
4920	8242-PDSGJ	Male	0	Yes	No
4921	0264-CNITK	Female	0	Yes	Yes
4922	0089-IIQKO	Female	0	Yes	Yes
4923	7839-NUIAA	Female	0	Yes	Yes
4924	6075-QMNRR	Female	0	No	No
4925	5378-IKEEG	Female	0	No	No
4926	5966-EMAZU	Male	0	Yes	No
4927	0440-EKDCF	Male	0	Yes	No
4928	4774-HHGGS	Male	0	Yes	No
4929	2718-GAXQD	Female	1	Yes	Yes
4930	2055-BFOCC	Male	1	Yes	No
4931	8180-AKMJV	Female	0	No	No
4932	4298-OYIFC	Male	0	Yes	No
4933	5566-SOEZD	Male	0	Yes	Yes
4934	9842-EFSYY	Female	0	No	Yes
4935	2272-WUSPA	Female	0	Yes	No
4936	4584-LBNMK	Male	1	Yes	No
4937	3898-GUYTS	Female	1	No	No
4938	0930-EHUZA	Female	0	No	No
4939	6413-XKKPU	Male	0	Yes	Yes
4940	9975-SKRNR	Male	0	No	No
4941	3703-KBKZP	Male	1	No	No
4942	1449-XQEMT	Male	0	No	No
4943	2626-URJFX	Male	0	Yes	Yes
4944	4973-MGTON	Female	0	Yes	No
4945	3682-YEUWS	Male	0	Yes	Yes
4946	1223-UNPKS	Male	0	Yes	Yes
4947	2612-RRIDN	Male	0	No	No
4948	4735-ASGMA	Male	0	No	No
4949	3446-QDSZF	Female	0	No	No
4950	3669-LVWZB	Male	0	No	No
4951	6892-EZDTG	Female	0	Yes	No
4952	5117-IFGPS	Male	1	Yes	No
4953	7379-FNIUJ	Male	0	No	No
4954	1627-AFWVJ	Female	0	No	No
4955	9725-SCPZG	Male	0	No	Yes
4956	5884-GCYMI	Male	0	No	No
4957	3217-FZDMN	Female	1	No	No
4958	4486-EFAEB	Male	0	No	No
4959	0060-FUALY	Female	0	Yes	No
4960	7853-GVUDZ	Female	0	Yes	Yes
4961	7480-QNVZJ	Male	1	No	No
4962	6954-OOYZZ	Male	0	Yes	No
4963	7088-FBAWU	Female	0	Yes	Yes
4964	8313-AFGBW	Male	0	Yes	No
4965	3943-KDREE	Female	0	No	No
4966	9239-ZBZZV	Female	0	No	No
4967	3097-IDVPU	Male	0	Yes	Yes
4968	4398-HSCJH	Female	0	No	No
4969	2197-OMWGI	Female	1	Yes	Yes
4970	2303-PJYHN	Female	0	Yes	No
4971	9795-VOWON	Male	0	No	No
4972	1237-WIYYZ	Female	0	No	No
4973	1987-AUELQ	Female	0	Yes	No
4974	7852-LECYP	Male	1	Yes	No
4975	4430-UZIPO	Male	0	No	No
4976	4822-LPTYJ	Male	0	Yes	No
4977	8165-CBKXO	Male	0	Yes	Yes
4978	6527-PZFPV	Male	0	Yes	Yes
4979	4855-SNKMY	Female	0	No	No
4980	9593-CVZKR	Female	0	Yes	Yes
4981	8595-SIZNC	Female	1	Yes	No
4982	8008-HAWED	Male	0	No	No
4983	7124-UGSUR	Female	1	Yes	No
4984	1862-SKORY	Female	1	Yes	No
4985	5236-XMZJY	Female	0	No	No
4986	4827-DPADN	Female	0	Yes	Yes
4987	2694-CIUMO	Female	0	No	No
4988	5846-ABOBJ	Male	0	Yes	No
4989	1439-LCGVL	Female	0	Yes	No
4990	0909-SDHNU	Female	0	No	Yes
4991	4647-XXZAM	Female	0	Yes	Yes
4992	1502-XFCVR	Female	0	No	No
4993	7740-KKCXF	Male	0	Yes	No
4994	5360-XGYAZ	Male	0	Yes	Yes
4995	9692-TUSXH	Female	0	No	No
4996	7912-SYRQT	Female	0	No	No
4997	3557-HTYWR	Female	0	No	No
4998	4816-JBHOV	Male	1	No	No
4999	8920-NAVAY	Male	1	No	No
5000	1699-TLDLZ	Female	0	Yes	Yes
5001	5600-PDUJF	Male	0	No	No
5002	8292-TYSPY	Male	0	No	No
5003	0567-XRHCU	Female	0	Yes	Yes
5004	1867-BDVFH	Male	0	Yes	Yes
5005	2067-QYTCF	Female	0	Yes	No
5006	2359-QWQUL	Female	0	Yes	No
5007	9103-TCIHJ	Female	0	No	No
5008	7407-SUJIZ	Male	0	No	No
5009	9150-KPBJQ	Female	0	No	No
5010	0052-DCKON	Male	0	Yes	No
5011	3654-ARMGP	Female	0	No	No
5012	9699-UBQFS	Female	1	Yes	No
5013	9367-TCUYN	Female	0	No	No
5014	1261-FWTTE	Male	1	No	No
5015	3528-HFRIQ	Male	1	Yes	No
5016	0708-SJDIS	Female	0	No	No
5017	4140-WJAWW	Female	0	No	No
5018	2073-QBVBI	Female	0	Yes	No
5019	6928-ONTRW	Female	0	Yes	Yes
5020	3320-VEOYC	Male	1	No	No
5021	5231-FIQPA	Female	0	No	No
5022	6617-WLBQC	Female	0	Yes	Yes
5023	2599-CIPQE	Male	0	Yes	Yes
5024	6653-CBBOM	Female	0	No	No
5025	8774-GSBUN	Male	0	Yes	No
5026	7326-RIGQZ	Male	0	Yes	Yes
5027	1401-FTHFQ	Male	0	Yes	Yes
5028	3247-ZVOUO	Male	1	Yes	No
5029	0254-FNMCI	Female	0	No	No
5030	1848-LBZHY	Female	0	Yes	No
5031	6101-IMRMM	Male	0	No	Yes
5032	8118-TJAFG	Male	0	Yes	Yes
5033	5429-LWCMV	Female	0	No	No
5034	7298-IZWLY	Female	0	No	No
5035	9758-MFWGD	Female	1	Yes	Yes
5036	3955-JBZZM	Male	0	No	No
5037	1268-ASBGA	Female	1	Yes	No
5038	8943-URTMR	Female	0	No	No
5039	4815-TUMEQ	Female	0	No	No
5040	4713-LZDRV	Female	1	No	No
5041	9909-IDLEK	Male	0	Yes	Yes
5042	4092-OFQZS	Male	0	Yes	No
5043	1561-BWHIN	Male	0	Yes	Yes
5044	4325-NFSKC	Male	1	No	No
5045	9927-DSWDF	Male	0	Yes	No
5046	9500-LTVBP	Female	0	No	No
5047	7252-NTGSS	Female	0	No	No
5048	8149-AIQCG	Male	0	No	No
5049	1360-JYXKQ	Female	1	Yes	No
5050	2955-PSXOE	Female	0	No	No
5051	7762-URZQH	Male	0	Yes	No
5052	0899-WZRSD	Male	0	No	No
5053	3255-GRXMG	Male	0	No	Yes
5054	4828-FAZPK	Female	0	Yes	Yes
5055	6094-ZIVKX	Female	0	No	No
5056	6925-BAYGL	Female	1	Yes	No
5057	3262-EIDHV	Female	0	Yes	Yes
5058	7354-OIJLX	Male	0	No	No
5059	1376-HHBDV	Female	0	No	No
5060	6907-NZZIJ	Female	0	No	No
5061	6133-OZILE	Female	0	No	No
5062	4135-FRWKJ	Female	1	Yes	Yes
5063	2911-UREFD	Female	0	Yes	No
5064	3744-ZRRDZ	Male	0	No	No
5065	5673-TIYIB	Male	0	No	No
5066	6551-ZCOTS	Male	1	No	No
5067	7191-ADRGF	Male	0	Yes	No
5068	5018-LXQQG	Female	0	Yes	Yes
5069	6892-BOGQE	Female	0	Yes	No
5070	1602-IJQQE	Female	0	No	No
5071	4628-WQCQQ	Male	0	No	Yes
5072	1746-TGTWV	Male	0	Yes	No
5073	5995-SNNEW	Male	1	Yes	No
5074	8050-WYBND	Female	0	No	Yes
5075	2821-WARNZ	Female	0	No	Yes
5076	4879-GZLFH	Female	0	Yes	Yes
5077	1644-IRKSF	Female	0	Yes	Yes
5078	8314-HTWVE	Female	0	Yes	Yes
5079	9402-ROUMJ	Female	0	Yes	Yes
5080	2507-QZPQS	Male	0	No	No
5081	7159-NOKYQ	Male	0	Yes	No
5082	5707-ZMDJP	Male	0	Yes	Yes
5083	8779-YIQQA	Male	0	Yes	Yes
5084	7136-IHZJA	Female	0	Yes	Yes
5085	8966-OIQHG	Female	0	Yes	Yes
5086	7074-STDCN	Male	0	No	No
5087	3705-PSNGL	Male	0	No	No
5088	8739-QOTTN	Female	0	Yes	No
5089	1399-OUPJN	Female	0	Yes	Yes
5090	0277-BKSQP	Male	0	Yes	Yes
5091	6502-HCJTI	Male	1	Yes	No
5092	2606-RMDHZ	Male	0	No	No
5093	5774-XZTQC	Female	0	Yes	Yes
5094	2676-SSLTO	Male	0	No	No
5095	6266-QHOJZ	Female	0	No	No
5096	7269-JISCY	Female	0	No	No
5097	0363-SVHYR	Male	0	Yes	Yes
5098	8547-NSBBO	Male	0	No	No
5099	8258-GSTJK	Male	1	No	No
5100	6861-OKBCE	Female	0	No	Yes
5101	9940-RHLFB	Female	0	No	No
5102	6591-QGOYB	Male	0	No	No
5103	9070-BCKQP	Female	0	Yes	No
5104	6421-SZVEM	Female	0	Yes	Yes
5105	1328-EUZHC	Female	0	Yes	No
5106	2995-UPRYS	Female	1	Yes	No
5107	8878-RYUKI	Female	0	No	No
5108	9633-DENPU	Female	0	Yes	No
5109	7811-JIVPF	Female	0	No	No
5110	7113-HIPFI	Male	0	Yes	Yes
5111	8541-QVFKM	Female	0	No	No
5112	6686-YPGHK	Male	1	No	No
5113	1383-EZRWL	Female	0	No	No
5114	9258-CNWAC	Female	0	Yes	Yes
5115	5371-VYLSX	Female	1	No	No
5116	6374-AFWOX	Male	0	Yes	No
5117	4759-TRPLW	Male	0	No	No
5118	5317-FLPJF	Female	0	No	No
5119	7621-VPNET	Female	0	Yes	No
5120	6034-YMTOB	Female	0	No	No
5121	8563-IIOXK	Male	0	Yes	Yes
5122	4903-CNOZC	Male	0	No	No
5123	4353-HYOJD	Female	0	Yes	Yes
5124	8020-BWHYL	Female	1	No	No
5125	7267-FRMJW	Female	0	Yes	Yes
5126	2982-VPSGI	Female	0	Yes	No
5127	4188-FRABG	Male	0	Yes	No
5128	8199-ZLLSA	Male	0	No	No
5129	4128-ETESU	Female	1	Yes	No
5130	0620-DLSLK	Female	0	No	No
5131	4625-EWPTF	Male	0	No	No
5132	5980-NOPLP	Female	0	Yes	No
5133	3850-OKINF	Male	0	Yes	Yes
5134	6892-XPFPU	Male	1	Yes	No
5135	8010-EZLOU	Male	1	No	No
5136	1156-ZFYDO	Female	0	No	No
5137	3295-YVUSR	Male	1	No	No
5138	8016-NCFVO	Male	1	No	No
5139	4119-ZYPZY	Male	1	No	No
5140	5549-ZGHFB	Male	0	Yes	Yes
5141	7577-SWIFR	Male	0	No	No
5142	0303-WMMRN	Male	0	No	No
5143	6408-OTUBZ	Female	0	No	No
5144	5204-HMGYF	Female	0	Yes	Yes
5145	1078-TDCRN	Female	1	Yes	No
5146	3727-OVPRY	Male	0	Yes	Yes
5147	3797-FKOGQ	Male	0	No	Yes
5148	7622-NXQZR	Male	0	No	No
5149	6196-HBOBZ	Male	0	Yes	No
5150	3970-XGJDU	Female	0	No	No
5151	7017-VFULY	Female	0	Yes	No
5152	5562-YJQGT	Female	0	No	No
5153	8807-OPMBM	Female	0	Yes	Yes
5154	5439-WIKXB	Male	1	Yes	No
5155	9874-QLCLH	Female	0	Yes	Yes
5156	8294-UIMBA	Female	0	No	No
5157	8109-YUOHE	Male	0	No	No
5158	5840-NVDCG	Female	0	Yes	Yes
5159	8092-NLTGF	Male	0	No	No
5160	5928-QLDHB	Male	0	No	No
5161	9840-EFJQB	Female	0	No	No
5162	0696-UKTOX	Male	0	No	Yes
5163	4801-KFYKL	Male	0	No	Yes
5164	3472-OAOOR	Male	0	Yes	Yes
5165	6135-OZQVA	Female	0	No	No
5166	8062-YBDOE	Male	1	No	No
5167	2252-JHJGE	Male	0	No	No
5168	4188-PCPIG	Female	0	Yes	No
5169	6000-APYLU	Male	0	No	No
5170	7105-BENQF	Male	0	No	Yes
5171	7721-DVEKZ	Female	0	No	No
5172	3566-VVORZ	Female	0	Yes	No
5173	9507-HSMMZ	Male	0	No	No
5174	2480-SQIOB	Male	0	Yes	Yes
5175	0947-IDHRQ	Female	0	No	No
5176	7813-TKCVO	Female	0	Yes	No
5177	0128-MKWSG	Female	0	No	Yes
5178	3672-YITQD	Male	1	Yes	No
5179	4350-ZTLPI	Female	0	Yes	No
5180	9048-JVYVF	Male	0	No	No
5181	0361-HJRDX	Female	0	No	No
5182	5727-MYATE	Male	0	Yes	Yes
5183	3823-KYNQY	Male	0	No	No
5184	8988-ECPJR	Female	1	Yes	Yes
5185	7570-WELNY	Female	0	Yes	No
5186	3021-VLNRJ	Female	0	No	Yes
5187	3776-EKTKM	Female	1	No	No
5188	2080-CAZNM	Female	1	No	No
5189	1028-FFNJK	Male	1	Yes	No
5190	6907-FLBER	Male	0	No	No
5191	3001-UNBTL	Male	1	Yes	Yes
5192	5982-PSMKW	Female	0	Yes	Yes
5193	3507-GASNP	Male	0	No	Yes
5194	7096-ZNBZI	Female	0	Yes	No
5195	1902-XBTFB	Male	0	No	Yes
5196	1676-MQAOA	Male	0	No	No
5197	0786-IVLAW	Female	1	No	No
5198	7566-DSRLQ	Female	0	Yes	No
5199	0643-OKLRP	Female	1	Yes	No
5200	7245-JMTTQ	Female	0	No	No
5201	6050-IJRHS	Female	0	Yes	Yes
5202	6202-JVYEU	Male	0	No	No
5203	8591-TKMZH	Male	0	Yes	Yes
5204	0734-OXWBT	Male	0	No	Yes
5205	4282-ACRXS	Male	1	Yes	No
5206	0365-TRTPY	Female	0	No	No
5207	7349-ALMUX	Male	0	No	No
5208	9381-NDKME	Female	1	Yes	No
5209	6502-KUGLL	Female	0	Yes	Yes
5210	1841-YSJGV	Male	0	Yes	No
5211	2794-XIMMO	Male	0	Yes	No
5212	8382-SHQEH	Female	0	Yes	No
5213	3511-BFTJW	Male	0	Yes	Yes
5214	7668-XCFYV	Female	1	Yes	No
5215	2983-ZANRP	Female	0	Yes	Yes
5216	7845-URHJN	Female	0	Yes	No
5217	3034-ZBEQN	Female	0	Yes	No
5218	5018-HEKFO	Female	0	No	No
5219	2923-ARZLG	Male	0	Yes	Yes
5220	3976-NLDEZ	Male	0	No	No
5221	2282-YGNOR	Female	0	No	No
5222	5336-UFNZP	Female	1	Yes	Yes
5223	6854-EXGSF	Female	0	No	No
5224	1241-EZFMJ	Male	0	Yes	No
5225	9233-PSYHO	Female	1	No	No
5226	5376-PCKNB	Male	0	Yes	Yes
5227	8044-BGWPI	Male	0	Yes	Yes
5228	4060-LDNLU	Male	0	No	No
5229	3589-PPVKW	Male	0	No	No
5230	8327-LZKAS	Female	1	Yes	No
5231	5887-IKKYO	Male	0	Yes	Yes
5232	1075-BGWOH	Male	1	Yes	No
5233	1755-RMCXH	Male	0	Yes	Yes
5234	0302-JOIVN	Female	0	Yes	No
5235	3858-XHYJO	Female	0	Yes	No
5236	4299-SIMNS	Male	0	No	No
5237	7025-IWFHT	Male	0	No	No
5238	6261-LHRTG	Female	0	No	No
5239	7841-FCRQD	Female	0	Yes	No
5240	2056-EVGZL	Male	0	Yes	Yes
5241	8777-MBMTS	Female	1	Yes	No
5242	7753-USQYQ	Male	0	No	No
5243	5366-IJEQJ	Male	0	No	No
5244	7661-CPURM	Male	0	No	No
5245	6233-HXJMX	Female	0	No	No
5246	5902-WBLSE	Female	0	Yes	Yes
5247	1981-INRFU	Female	0	No	No
5248	4971-PUYQO	Female	0	No	No
5249	3239-TPHPZ	Female	0	Yes	No
5250	5115-GZDEL	Male	0	No	Yes
5251	3338-CVVEH	Male	0	No	No
5252	8485-GJCDN	Female	1	No	No
5253	2615-YVMYX	Male	1	Yes	No
5254	2851-STERV	Male	1	No	No
5255	4393-GEADV	Male	0	Yes	Yes
5256	8486-AYEQH	Female	0	No	No
5257	1527-SXDPN	Male	0	Yes	Yes
5258	6029-WTIPC	Male	1	No	No
5259	8634-CILSZ	Male	0	No	No
5260	5419-JKZNQ	Male	1	Yes	No
5261	2495-KZNFB	Female	0	No	No
5262	1409-PHXTF	Male	1	Yes	No
5263	4560-WQAQW	Female	0	No	No
5264	9591-YVTEB	Male	1	No	No
5265	9309-BZGNT	Male	1	Yes	No
5266	4274-DRSQT	Female	0	No	No
5267	2027-DNKIV	Male	0	Yes	Yes
5268	8075-GXIUB	Male	1	Yes	No
5269	2885-HIJDH	Male	0	Yes	Yes
5270	5424-RLQLC	Male	0	No	No
5271	6682-QJDGB	Male	0	No	Yes
5272	6507-DTJZV	Male	0	No	Yes
5273	8780-IXSTS	Female	0	No	No
5274	7673-BQGKU	Female	0	Yes	Yes
5275	6723-WSNTY	Female	1	Yes	No
5276	9530-EHPOH	Male	0	No	No
5277	2725-IWWBA	Male	0	Yes	Yes
5278	0345-HKJVM	Female	0	No	No
5279	1061-PNTHC	Female	0	Yes	Yes
5280	0394-YONDK	Male	0	Yes	Yes
5281	6574-MCOEH	Female	0	Yes	Yes
5282	7399-QHBJS	Female	0	Yes	Yes
5283	3049-SOLAY	Female	0	Yes	No
5284	0997-YTLNY	Female	0	No	Yes
5285	3317-HRTNN	Female	1	No	No
5286	9479-HYNYL	Female	0	Yes	No
5287	3235-ETOOB	Male	0	Yes	No
5288	9708-KFDBY	Male	0	No	No
5289	8058-INTPH	Female	0	No	No
5290	3642-GKTCT	Female	0	No	No
5291	0774-RMNUW	Female	0	Yes	Yes
5292	1334-PDUKM	Female	0	Yes	No
5293	0756-MPZRL	Male	0	No	No
5294	2242-MFOTG	Male	0	No	No
5295	2927-CVULT	Female	0	Yes	Yes
5296	2144-BFDSO	Female	1	Yes	No
5297	8745-PVESG	Female	0	No	No
5298	7647-GYYKX	Female	0	Yes	Yes
5299	5647-FXOTP	Female	1	Yes	No
5300	5569-OUICF	Female	1	Yes	No
5301	8821-XNHVZ	Female	0	Yes	Yes
5302	2082-OJVTK	Male	0	Yes	Yes
5303	9700-ISPUP	Female	0	Yes	Yes
5304	9839-ETQOE	Male	0	No	Yes
5305	6078-VESFR	Male	1	Yes	No
5306	9027-TMATR	Female	0	Yes	No
5307	5940-NFXKV	Male	0	Yes	Yes
5308	1941-HOSAM	Male	0	Yes	Yes
5309	9110-HSGTV	Female	0	No	No
5310	0704-VCUMB	Female	0	Yes	No
5311	6171-ZTVYB	Male	0	Yes	No
5312	8053-WWDRO	Female	0	Yes	No
5313	9564-KCLHR	Male	0	No	No
5314	1935-IMVBB	Male	0	Yes	No
5315	2535-PBCGC	Female	0	Yes	No
5316	2082-CEFLT	Male	0	No	No
5317	1470-PSXNM	Male	0	Yes	Yes
5318	1213-NGCUN	Female	0	No	No
5319	2498-XLDZR	Female	0	Yes	Yes
5320	9866-OCCKE	Female	1	Yes	No
5321	5338-YHWYT	Male	0	No	Yes
5322	7718-UPSKJ	Female	0	Yes	No
5323	8731-WBBMB	Female	0	Yes	No
5324	1448-CYWKC	Female	0	Yes	Yes
5325	7901-IIDQV	Male	0	No	No
5326	2690-DVRVK	Male	0	Yes	Yes
5327	5688-KZTSN	Male	0	Yes	Yes
5328	1270-XKUCC	Female	0	Yes	Yes
5329	0334-ZFJSR	Female	0	Yes	No
5330	2894-QOJRX	Female	0	Yes	No
5331	5747-PMBSQ	Male	1	Yes	No
5332	5583-EJXRD	Male	0	Yes	Yes
5333	4565-EVZMJ	Female	0	No	No
5334	3143-JQEGI	Female	0	Yes	Yes
5335	6386-SZZKH	Female	0	Yes	Yes
5336	3327-YBAKM	Female	0	Yes	No
5337	9441-QHEVC	Male	0	No	No
5338	6705-LNMDD	Male	0	No	No
5339	2580-ASVVY	Female	0	Yes	No
5340	3370-GQEAL	Male	0	Yes	Yes
5341	5032-USPKF	Female	0	No	No
5342	2982-IHMFT	Female	1	No	No
5343	3521-SYVOR	Female	0	No	No
5344	4254-QPEDE	Female	0	Yes	No
5345	6283-GITPX	Male	0	No	Yes
5346	9526-JAWYF	Male	0	No	No
5347	0771-CHWSK	Male	0	No	No
5348	9788-HNGUT	Male	0	Yes	No
5349	9495-REDIY	Male	0	No	Yes
5350	5375-XLDOF	Male	0	Yes	Yes
5351	1172-VIYBP	Male	0	Yes	Yes
5352	5649-VUKMC	Female	0	No	No
5353	6559-PDZLR	Male	0	No	No
5354	8992-OBVDG	Male	0	No	No
5355	4273-MBHYA	Female	0	No	Yes
5356	4724-WXVWF	Male	0	No	No
5357	5701-GUXDC	Female	0	Yes	No
5358	1460-UZPRJ	Male	0	Yes	No
5359	6082-GLJIX	Male	0	No	No
5360	5143-EGQFK	Female	1	No	No
5361	4919-IKATY	Male	0	Yes	Yes
5362	2495-TTHBQ	Female	0	No	Yes
5363	0485-ZBSLN	Male	0	Yes	Yes
5364	3810-PJUHR	Male	0	Yes	Yes
5365	9050-QLROH	Male	0	No	No
5366	0847-HGRML	Male	0	No	Yes
5367	8232-CTLKO	Female	0	Yes	Yes
5368	9227-YBAXE	Female	0	Yes	Yes
5369	6168-WFVVF	Female	1	No	No
5370	9860-LISIZ	Female	0	No	No
5371	0112-QAWRZ	Male	0	Yes	Yes
5372	0877-SDMBN	Female	0	No	No
5373	2786-GCDPI	Female	1	No	No
5374	4043-MKDTV	Male	0	Yes	No
5375	8065-YKXKD	Female	0	No	No
5376	9637-EIHEQ	Female	0	No	No
5377	9229-RQABD	Male	0	No	No
5378	8313-KTIHG	Male	0	No	No
5379	5320-BRKGK	Female	0	Yes	Yes
5380	6284-KMNUF	Female	0	Yes	No
5381	9689-PTNPG	Male	0	No	No
5382	9465-RWMXL	Male	0	Yes	No
5383	6229-UOLQL	Male	0	Yes	Yes
5384	2362-IBOOY	Male	0	No	No
5385	3137-LUPIX	Female	0	No	No
5386	0843-WTBXE	Male	0	No	No
5387	6143-JQKEA	Male	0	No	No
5388	8676-OOQEJ	Male	0	No	No
5389	5515-IDEJJ	Male	0	Yes	Yes
5390	9701-CDXHR	Female	0	Yes	No
5391	7450-NWRTR	Male	1	No	No
5392	8124-NZVGJ	Female	0	No	No
5393	2162-FRZAA	Male	0	Yes	Yes
5394	5376-DEQCP	Female	0	No	No
5395	5118-MUEYH	Female	0	Yes	No
5396	9095-HFAFX	Female	0	No	No
5397	5627-TVBPP	Female	0	No	Yes
5398	2379-ENZGV	Male	0	No	No
5399	3936-QQFLL	Male	0	No	No
5400	2589-AYCRP	Female	0	No	No
5401	4067-HLYQI	Female	0	No	No
5402	5124-EOGYE	Male	0	No	No
5403	5057-RKGLH	Female	0	Yes	Yes
5404	0292-WEGCH	Female	0	Yes	Yes
5405	8910-ICHIU	Female	0	No	No
5406	4097-YODCF	Male	0	No	Yes
5407	9715-WZCLW	Male	0	Yes	Yes
5408	9786-YWNHU	Female	0	Yes	Yes
5409	6407-GSJNL	Female	0	No	No
5410	6005-OBZPH	Female	1	No	No
5411	4049-ZPALD	Female	0	Yes	No
5412	7932-WPTDS	Female	1	Yes	No
5413	3733-UOCWF	Male	1	Yes	No
5414	6833-JMZYP	Female	0	No	No
5415	2722-VOJQL	Male	0	No	No
5416	1310-QRITU	Female	0	No	No
5417	8961-QDZZJ	Female	0	Yes	Yes
5418	9715-SBVSU	Male	0	Yes	Yes
5419	8490-BXHEO	Male	1	No	No
5420	7173-TETGO	Female	1	Yes	No
5421	7929-SKFGK	Male	0	Yes	No
5422	2300-RQGOI	Female	0	No	No
5423	3563-SVYLG	Male	0	Yes	Yes
5424	5228-EXCET	Male	0	No	No
5425	6435-VWCCY	Male	1	Yes	No
5426	4998-IKFSE	Female	0	No	No
5427	8630-QSGXK	Male	0	Yes	No
5428	2455-USLMV	Female	0	No	No
5429	7394-FKDNK	Female	0	Yes	No
5430	9488-FVZCC	Female	0	Yes	Yes
5431	6331-LWDTQ	Male	0	No	No
5432	5995-WWKKG	Female	0	No	No
5433	1597-FZREH	Female	0	No	No
5434	7879-CGSFV	Male	0	No	No
5435	9921-EZKBY	Male	0	No	Yes
5436	7432-FFVAR	Female	0	Yes	Yes
5437	7246-ZGQDF	Female	0	No	Yes
5438	7000-WCEVQ	Female	1	No	No
5439	0727-IWKVK	Male	0	Yes	No
5440	5959-BELXA	Male	1	No	No
5441	4456-RHSNB	Female	0	Yes	Yes
5442	3512-IZIKN	Female	0	Yes	No
5443	2481-SBOYW	Female	0	No	Yes
5444	7109-MFBYV	Male	0	No	No
5445	1833-TCXKK	Male	0	Yes	No
5446	1832-PEUTS	Male	0	Yes	Yes
5447	6141-OOXUQ	Male	0	No	No
5448	8660-BUETV	Female	0	No	No
5449	0580-PIQHM	Female	0	Yes	Yes
5450	5696-CEIQJ	Male	0	Yes	Yes
5451	7503-ZGUZJ	Male	0	No	No
5452	1696-HXOWK	Female	0	Yes	No
5453	3026-ATZYV	Female	0	Yes	Yes
5454	4012-YCFAI	Male	0	Yes	No
5455	2506-TNFCO	Female	1	Yes	No
5456	9970-QBCDA	Female	0	No	No
5457	8718-PTMEZ	Female	0	No	No
5458	9496-IVVRP	Female	0	Yes	Yes
5459	2207-OBZNX	Male	0	No	No
5460	2657-VPXTA	Female	0	Yes	Yes
5461	6551-VLJMV	Male	0	Yes	No
5462	1221-GHZEP	Female	0	No	No
5463	9289-LBQVU	Male	0	Yes	No
5464	6142-VSJQO	Female	0	Yes	Yes
5465	3458-IDMFK	Male	0	No	No
5466	6933-FHBZC	Female	0	No	No
5467	0221-NAUXK	Male	0	No	Yes
5468	9770-KXGQU	Female	0	No	No
5469	6437-UKHMV	Female	0	No	No
5470	6538-POCHL	Male	0	No	No
5471	6726-NNFWD	Female	1	Yes	No
5472	3002-WQZWT	Female	0	No	No
5473	4277-UDIEF	Male	0	Yes	Yes
5474	1208-NBVFH	Male	0	Yes	Yes
5475	4912-PIGUY	Female	0	No	No
5476	1114-CENIM	Male	0	No	Yes
5477	6060-DRTNL	Female	1	No	No
5478	2725-TTRIQ	Female	0	Yes	Yes
5479	3374-TTZTK	Male	0	Yes	No
5480	8990-ZXLSU	Female	0	No	No
5481	2275-RBYQS	Female	0	No	No
5482	8473-VUVJN	Male	1	No	No
5483	6289-CPNLD	Male	0	Yes	Yes
5484	5536-SLHPM	Female	0	Yes	No
5485	4419-UJMUS	Male	0	Yes	Yes
5486	7794-JASDG	Male	0	No	No
5487	7609-YBPXG	Male	0	No	No
5488	5519-TEEUH	Male	0	No	Yes
5489	7856-GANIL	Male	1	Yes	No
5490	0804-XBFBV	Female	0	No	Yes
5491	2676-OXPPQ	Male	0	No	No
5492	3703-TTEPD	Male	0	No	No
5493	2799-TSLAG	Female	0	Yes	Yes
5494	0196-VULGZ	Female	1	Yes	No
5495	8837-VVWLQ	Female	0	No	No
5496	2696-NARTR	Male	0	No	No
5497	2208-NKVVH	Male	0	Yes	Yes
5498	7614-QVWQL	Male	0	Yes	Yes
5499	1976-CFOCS	Female	1	Yes	No
5500	4631-OACRM	Male	1	No	No
5501	7139-JZFVG	Male	0	Yes	Yes
5502	4987-GQWPO	Male	0	No	No
5503	3755-JBMNH	Male	1	Yes	No
5504	1757-TCATG	Male	0	Yes	Yes
5505	6345-ULYRW	Male	1	Yes	No
5506	4776-XSKYQ	Female	0	Yes	Yes
5507	8048-DSDFQ	Male	0	No	No
5508	5753-QQWPW	Female	0	No	No
5509	6010-DDPPW	Male	0	Yes	No
5510	1809-DMJHQ	Female	0	No	Yes
5511	6693-FRIRW	Male	0	No	No
5512	6586-MYGKD	Male	0	Yes	No
5513	3173-NVMPX	Female	0	Yes	Yes
5514	0248-PGHBZ	Female	1	No	No
5515	0623-GDISB	Female	0	No	No
5516	2892-GESUL	Female	0	Yes	Yes
5517	6923-EFPNL	Male	0	No	No
5518	7472-EQOAV	Male	1	Yes	Yes
5519	9574-RKJIF	Male	0	Yes	Yes
5520	2043-WVTQJ	Male	0	Yes	No
5521	8034-RYTVV	Female	0	No	No
5522	3863-QSTYI	Male	0	No	No
5523	2619-WFQWU	Female	0	No	No
5524	5044-LRQAQ	Female	0	Yes	No
5525	1716-LSAMB	Male	0	Yes	Yes
5526	1333-PBMXB	Female	0	Yes	Yes
5527	6546-OPBBH	Male	0	Yes	Yes
5528	5985-BEHZK	Female	1	Yes	No
5529	9127-QRZMH	Male	0	Yes	No
5530	5919-VCZYM	Male	0	No	No
5531	9644-KVCNC	Female	0	No	No
5532	2137-DQMEV	Male	0	Yes	Yes
5533	8174-LNWMW	Female	0	No	No
5534	9279-CJEOJ	Female	1	No	No
5535	7964-VEXDG	Male	0	No	Yes
5536	2404-JIBFC	Female	0	Yes	Yes
5537	0778-NELLA	Male	0	No	No
5538	8029-XYPWT	Male	1	Yes	No
5539	4614-NUVZD	Female	0	No	No
5540	4632-PAOYU	Male	0	Yes	Yes
5541	3803-KMQFW	Female	0	Yes	Yes
5542	6804-GDMOI	Female	0	No	No
5543	2990-OGYTD	Female	0	Yes	No
5544	6646-JPPHA	Female	1	No	No
5545	9572-MTILT	Male	0	Yes	No
5546	7658-UYUQS	Male	1	Yes	No
5547	7880-XSOJX	Male	0	No	No
5548	9611-CTWIH	Female	0	No	No
5549	4589-IUAJB	Male	0	Yes	No
5550	0329-GTIAJ	Female	0	No	No
5551	8746-BFOAJ	Male	1	No	No
5552	8457-XIGKN	Male	0	No	No
5553	6072-NUQCB	Male	0	Yes	Yes
5554	6629-CZTTH	Male	0	No	No
5555	8838-GPHZP	Female	0	No	No
5556	8750-QWZAJ	Female	0	Yes	Yes
5557	5364-EVNIB	Male	0	No	No
5558	6918-UMQCG	Female	0	No	No
5559	0675-NCDYU	Female	0	Yes	Yes
5560	6339-DKLMK	Female	0	No	No
5561	1346-PJWTK	Male	0	Yes	No
5562	5088-QZLRL	Male	0	No	No
5563	8023-QHAIO	Female	1	Yes	No
5564	4397-FRLTA	Female	0	No	No
5565	3057-VJJQE	Male	0	No	No
5566	5087-SUURX	Female	0	Yes	No
5567	2302-OUZXB	Male	0	Yes	No
5568	8133-ANHHJ	Female	1	No	No
5569	2270-CHBFN	Female	0	Yes	No
5570	0013-EXCHZ	Female	1	Yes	No
5571	5982-FPVQN	Female	0	Yes	Yes
5572	9107-UKCKY	Male	0	Yes	No
5573	4654-ULTTN	Male	0	Yes	No
5574	5550-VFRLC	Female	1	No	No
5575	5546-BYZSM	Female	0	No	No
5576	1492-KGETH	Male	0	Yes	Yes
5577	4929-BSTRX	Female	0	No	No
5578	4163-HFTUK	Male	0	No	No
5579	8215-NGSPE	Female	0	Yes	Yes
5580	2225-ZRGSG	Female	0	Yes	Yes
5581	8859-YSTWS	Male	0	No	No
5582	5271-YNWVR	Male	0	Yes	Yes
5583	7601-DHFWZ	Female	0	No	No
5584	2657-ALMWY	Female	1	Yes	No
5585	6330-JKLPC	Male	0	Yes	No
5586	4667-OHGKG	Male	0	No	No
5587	1998-VHJHK	Female	0	No	No
5588	1707-HABPF	Female	1	No	No
5589	1660-HSOOQ	Male	0	No	No
5590	7253-UVNDW	Female	0	No	No
5591	0487-VVUVK	Male	0	Yes	Yes
5592	7228-OMTPN	Male	0	No	No
5593	5063-IUOKK	Male	0	No	No
5594	4508-OEBEY	Male	0	Yes	No
5595	0027-KWYKW	Female	0	Yes	Yes
5596	2308-STERM	Female	0	No	No
5597	5982-XMDEX	Female	0	No	No
5598	6284-AHOOQ	Male	1	No	No
5599	6051-PTVNS	Female	0	Yes	Yes
5600	2344-JMOGN	Male	0	Yes	No
5601	3799-ISUZQ	Male	0	Yes	Yes
5602	2877-VDUER	Female	0	Yes	Yes
5603	9152-AMKAK	Male	0	No	No
5604	1794-HBQTJ	Female	0	No	No
5605	9432-VOFYX	Male	0	No	No
5606	8049-WJCLQ	Male	0	Yes	Yes
5607	6586-PSJOX	Male	0	No	Yes
5608	2460-FPSYH	Female	1	No	No
5609	9705-ZJBCG	Female	0	Yes	Yes
5610	4818-DRBQT	Male	0	Yes	No
5611	1320-HTRDR	Female	0	No	No
5612	6847-KJLTS	Female	1	Yes	No
5613	9670-BPNXF	Female	0	No	No
5614	3913-FCUUW	Female	0	Yes	Yes
5615	3301-VKTGC	Male	0	Yes	Yes
5616	1493-AMTIE	Male	0	No	No
5617	9555-SAHUZ	Female	0	Yes	Yes
5618	0816-TSPHQ	Male	0	No	No
5619	9932-WBWIK	Male	0	No	No
5620	4619-EVPHY	Female	1	Yes	No
5621	5286-YHCVC	Male	0	Yes	No
5622	6424-ELEYH	Female	0	Yes	No
5623	4391-RESHN	Male	0	No	No
5624	9115-YQHGA	Male	0	No	No
5625	4462-CYWMH	Male	1	Yes	No
5626	8963-MQVYN	Female	0	No	Yes
5627	2458-EOMRE	Female	0	No	No
5628	9334-GWGOW	Male	1	Yes	No
5629	6821-BUXUX	Female	0	No	No
5630	5028-HTLJB	Male	1	No	No
5631	9801-GDWGV	Female	0	No	No
5632	6542-LWGXJ	Male	0	Yes	No
5633	5567-GZKQY	Male	0	No	No
5634	1222-LRYKO	Male	0	No	Yes
5635	2320-JRSDE	Female	0	Yes	Yes
5636	2087-QAREY	Female	0	Yes	No
5637	0601-WZHJF	Male	0	Yes	No
5638	4423-JWZJN	Male	0	Yes	Yes
5639	5143-WMWOG	Male	0	No	No
5640	6490-FGZAT	Male	0	No	No
5641	5393-RXQSZ	Male	0	No	No
5642	7452-FOLON	Male	0	No	Yes
5643	2320-TZRRH	Female	0	No	No
5644	0231-LXVAP	Male	0	No	No
5645	9444-JTXHZ	Male	0	Yes	No
5646	4942-VZZOM	Male	0	Yes	No
5647	5510-BOIUJ	Male	0	No	Yes
5648	7502-BNYGS	Female	0	Yes	No
5649	4291-HYEBC	Female	1	Yes	Yes
5650	6147-CBCRA	Female	0	Yes	No
5651	6047-SUHPR	Male	0	Yes	Yes
5652	4471-KXAUH	Female	0	Yes	No
5653	9752-ZNQUT	Female	0	No	No
5654	7638-QVMVY	Female	0	No	No
5655	1576-PFZIW	Male	1	Yes	No
5656	5666-MBJPT	Male	0	No	No
5657	7312-XSBAT	Male	0	No	No
5658	3096-GKWEB	Male	0	Yes	No
5659	2371-JQHZZ	Male	0	Yes	No
5660	0674-GCDXG	Male	0	No	No
5661	1121-QSIVB	Female	0	No	Yes
5662	4396-KLSEH	Male	0	No	No
5663	3244-DCJWY	Female	0	No	No
5664	2824-MYYBN	Female	0	Yes	Yes
5665	0875-CABNR	Female	1	No	No
5666	6345-HOVES	Male	0	No	No
5667	8318-LCNBW	Male	0	Yes	No
5668	6469-QJKZW	Female	0	Yes	No
5669	0147-ESWWR	Female	1	Yes	No
5670	1217-VASWC	Male	1	Yes	No
5671	7812-FZHPE	Female	0	Yes	Yes
5672	6370-ZVHDV	Female	0	Yes	No
5673	5915-DGNVC	Female	0	Yes	No
5674	6260-XLACS	Male	0	No	No
5675	3566-CAAYU	Female	0	Yes	Yes
5676	4983-CCWMC	Male	0	No	No
5677	9103-CXVOK	Male	0	Yes	Yes
5678	2896-TBNBE	Male	0	Yes	No
5679	4797-AXPXK	Female	0	No	Yes
5680	5229-PRWKT	Male	0	No	No
5681	6982-UQZLY	Female	1	Yes	No
5682	2522-WLNSF	Female	1	Yes	No
5683	3841-CONLJ	Female	0	Yes	No
5684	5057-LCOUI	Female	0	No	No
5685	0193-ESZXP	Female	1	Yes	No
5686	4475-NVTLU	Male	0	Yes	Yes
5687	4369-HTUIF	Male	1	No	No
5688	9386-LDCZR	Male	0	No	No
5689	9585-KKMFD	Male	0	Yes	Yes
5690	5399-ZIMKF	Male	0	No	No
5691	0336-KXKFK	Male	0	No	No
5692	5619-XZZKR	Male	0	No	No
5693	3948-FVVRP	Male	0	Yes	Yes
5694	5327-XOKKY	Male	1	Yes	No
5695	0983-TATYJ	Female	0	Yes	No
5696	1813-JYWTO	Female	0	Yes	No
5697	0156-FVPTA	Male	0	Yes	No
5698	1984-FCOWB	Female	0	Yes	No
5699	0654-HMSHN	Male	0	Yes	Yes
5700	6719-OXYBR	Male	0	No	No
5701	3312-ZWLGF	Male	1	Yes	No
5702	6476-YHMGA	Female	0	Yes	Yes
5703	5287-QWLKY	Male	1	Yes	Yes
5704	0795-XCCTE	Male	1	No	No
5705	0168-XZKBB	Female	0	Yes	No
5706	3785-NRHYR	Male	0	No	No
5707	5196-SGOAK	Female	0	No	No
5708	4537-DKTAL	Female	0	No	No
5709	7072-MBHEV	Female	1	Yes	Yes
5710	5602-BVFMK	Female	0	No	No
5711	6297-NOOPG	Female	0	Yes	No
5712	1891-UAWWU	Female	1	Yes	No
5713	8204-TIFGJ	Female	0	No	No
5714	8050-DVOJX	Male	1	No	No
5715	6108-OQZDQ	Female	0	Yes	Yes
5716	0363-QJVFX	Male	0	No	No
5717	8903-XEBGX	Male	0	No	Yes
5718	8169-SAEJD	Male	1	Yes	No
5719	9840-DVNDC	Male	0	No	No
5720	1089-XZWHH	Female	0	Yes	Yes
5721	2325-WINES	Female	0	No	No
5722	6064-ZATLR	Female	0	No	No
5723	3096-JRDSO	Female	1	Yes	No
5724	7824-PANSQ	Male	0	No	No
5725	8042-JVNFH	Male	0	No	No
5726	9648-BCHKM	Female	0	Yes	Yes
5727	2888-ADFAO	Female	0	Yes	Yes
5728	8707-HOEDG	Female	0	Yes	Yes
5729	3374-LXDEV	Female	0	No	No
5730	4072-IPYLT	Female	0	Yes	Yes
5731	7167-PCEYD	Male	0	No	No
5732	4936-YPJNK	Female	0	No	No
5733	1580-BMCMR	Male	1	No	No
5734	4817-KEQSP	Female	0	Yes	Yes
5735	6408-WHTEF	Male	0	Yes	Yes
5736	9251-AWQGT	Female	0	Yes	Yes
5737	8749-CLJXC	Male	0	No	No
5738	7989-VCQOH	Male	0	Yes	Yes
5739	5049-GLYVG	Male	0	No	No
5740	4199-QHJNM	Male	1	Yes	No
5741	8882-TLVRW	Male	0	Yes	Yes
5742	5883-GTGVD	Male	0	No	No
5743	5135-GRQJV	Male	1	Yes	No
5744	2384-OVPSA	Female	1	No	No
5745	1371-WEPDS	Male	1	Yes	No
5746	3580-GICBM	Female	0	Yes	Yes
5747	4817-QRJSX	Female	0	No	No
5748	9730-DRTMJ	Male	0	Yes	No
5749	4686-UXDML	Female	0	No	No
5750	3349-ANQNH	Female	1	No	No
5751	2398-YPMUR	Female	1	Yes	No
5752	0932-YIXYU	Female	0	No	No
5753	7480-SPLEF	Male	0	Yes	Yes
5754	7636-XUHWW	Male	0	No	No
5755	1431-CYWMH	Female	0	Yes	Yes
5756	5937-EORGB	Male	1	Yes	No
5757	6349-JDHQP	Female	0	No	No
5758	5539-HIVAK	Female	1	Yes	No
5759	5847-MXBEO	Male	0	No	No
5760	9985-MWVIX	Female	0	No	No
5761	4583-PARNH	Male	1	Yes	No
5762	1116-FRYVH	Female	0	Yes	Yes
5763	1421-HCERK	Male	1	Yes	No
5764	9633-XQABV	Female	0	No	No
5765	0716-BQNDX	Male	1	No	No
5766	1265-XTECC	Female	1	Yes	No
5767	1183-CANVH	Female	0	Yes	No
5768	1972-XMUWV	Female	0	Yes	No
5769	8679-LZBMD	Male	0	Yes	No
5770	3407-JMJQQ	Female	0	Yes	Yes
5771	6252-DFGTK	Female	0	Yes	No
5772	1539-LNKHM	Female	0	No	No
5773	8645-KOMJQ	Male	0	Yes	Yes
5774	0289-IVARM	Female	0	No	No
5775	9761-XUJWD	Male	0	No	No
5776	4057-FKCZK	Male	0	Yes	Yes
5777	4291-TPNFG	Male	0	Yes	No
5778	6087-YPWHO	Male	0	Yes	No
5779	3090-QFUVD	Female	0	No	No
5780	2237-ZFSMY	Female	0	No	No
5781	1722-LDZJS	Male	0	Yes	Yes
5782	1818-ESQMW	Female	0	No	No
5783	4871-JTKJF	Female	1	No	No
5784	1415-YFWLT	Female	1	No	No
5785	7401-RUBNK	Female	0	Yes	No
5786	0506-YLVKJ	Male	0	Yes	Yes
5787	8661-BOYNW	Female	0	Yes	No
5788	6711-VTNRE	Female	0	No	No
5789	4815-GBTCD	Female	0	Yes	No
5790	2805-AUFQN	Female	0	No	No
5791	0980-PVMRC	Female	0	Yes	Yes
5792	7233-DRTRF	Male	0	Yes	No
5793	3500-RMZLT	Female	1	No	No
5794	3873-NFTGI	Male	0	No	No
5795	1162-ECVII	Male	1	Yes	No
5796	7048-GXDAY	Male	0	No	No
5797	8571-ZCMCX	Female	0	Yes	Yes
5798	1169-WCVAK	Male	0	Yes	No
5799	4548-SDBKE	Female	0	No	No
5800	8066-POXGX	Female	0	No	No
5801	7129-CAKJW	Female	0	No	No
5802	8695-ARGXZ	Male	1	Yes	No
5803	3570-YUEKJ	Female	0	No	No
5804	4143-OOBWZ	Male	0	Yes	No
5805	1555-HAPSU	Female	0	Yes	Yes
5806	1697-NVVGY	Male	1	Yes	No
5807	7854-EKTJL	Female	0	No	Yes
5808	8464-EETCQ	Male	0	No	No
5809	2419-FSORS	Male	0	Yes	No
5810	8132-YPVBX	Female	0	No	No
5811	9102-IAYHT	Female	0	Yes	Yes
5812	6754-LZUKA	Male	0	Yes	No
5813	3422-LYEPQ	Male	0	Yes	Yes
5814	8099-MZPUJ	Male	0	Yes	Yes
5815	0787-LHDYT	Male	0	No	No
5816	2642-DTVCO	Male	1	No	No
5817	0374-IOEGQ	Female	0	No	No
5818	4361-JEIVL	Male	0	No	Yes
5819	3197-NNYNB	Male	0	No	No
5820	3396-DKDEL	Female	0	Yes	Yes
5821	1752-OZXFY	Male	0	Yes	No
5822	9066-QRSDU	Female	0	Yes	No
5823	9112-WSNPU	Female	1	No	No
5824	9867-NNXLC	Female	0	No	No
5825	5321-NTRKC	Male	0	Yes	Yes
5826	1363-TXLSL	Male	1	Yes	No
5827	9507-EXLTT	Female	0	Yes	No
5828	3161-GETRM	Male	0	Yes	Yes
5829	0402-OAMEN	Female	0	Yes	Yes
5830	6933-VLYFX	Male	0	Yes	Yes
5831	6754-WKSHP	Male	0	No	Yes
5832	9846-GKXAS	Female	0	No	No
5833	6017-PPLPX	Male	0	Yes	Yes
5834	4976-LNFVV	Male	1	Yes	No
5835	5055-MGMGF	Female	0	Yes	No
5836	4641-FROLU	Female	0	Yes	Yes
5837	2862-JVEOY	Male	0	No	No
5838	2969-QWUBZ	Female	0	No	No
5839	9822-BIIGN	Male	0	Yes	Yes
5840	2077-MPJQO	Male	1	Yes	No
5841	1534-OULXE	Female	0	Yes	Yes
5842	7136-RVDTZ	Male	1	No	No
5843	2971-SGAFL	Female	0	No	No
5844	1480-IVEVR	Male	1	Yes	No
5845	2905-KFQUV	Female	0	Yes	No
5846	4581-SSPWD	Female	0	No	No
5847	3370-HXOPH	Female	0	No	No
5848	9391-YZEJW	Female	0	No	No
5849	9958-MEKUC	Male	0	Yes	Yes
5850	0281-CNTZX	Male	0	Yes	No
5851	6927-WTFIV	Male	1	No	No
5852	4118-CEVPF	Female	1	No	No
5853	3398-ZOUAA	Male	1	Yes	No
5854	9114-VEPUF	Male	0	Yes	No
5855	7876-BEUTG	Female	0	No	No
5856	2338-BQEZT	Female	0	No	No
5857	9873-MNDKV	Female	0	No	No
5858	0378-NHQXU	Female	0	Yes	Yes
5859	8241-JUIQO	Female	0	No	No
5860	2194-IIQOF	Female	0	Yes	No
5861	4512-ZUIYL	Female	0	No	No
5862	9631-RXVJM	Male	0	No	No
5863	9584-EXCDZ	Female	0	No	No
5864	7969-AULMZ	Female	0	No	No
5865	5093-FEGLU	Female	0	Yes	No
5866	2621-UDNLU	Female	0	Yes	No
5867	7526-IVLYU	Male	0	No	No
5868	2428-HYUNX	Male	1	Yes	No
5869	9214-EKVXR	Female	0	No	No
5870	3410-MHHUM	Female	0	Yes	Yes
5871	0568-ONFPC	Male	0	Yes	Yes
5872	0733-VUNUW	Male	0	No	No
5873	4550-EVXNY	Female	0	No	Yes
5874	2122-YWVYA	Female	0	No	No
5875	2968-SSGAA	Female	0	No	No
5876	2296-DKZFP	Female	0	Yes	No
5877	4844-JJWUY	Female	1	No	No
5878	6777-TGHTM	Female	0	No	No
5879	8909-BOLNL	Male	0	No	No
5880	6603-YRDCJ	Male	0	Yes	No
5881	3538-WZPHD	Male	0	No	No
5882	3229-USWAR	Female	0	No	No
5883	2138-VFAPZ	Female	0	Yes	Yes
5884	6131-JLWZM	Female	0	No	No
5885	4785-QRJHC	Male	1	Yes	No
5886	0269-XFESX	Male	0	Yes	Yes
5887	1709-EJDOX	Female	0	Yes	Yes
5888	4316-XCSLJ	Male	0	No	Yes
5889	8610-WFCJF	Female	0	Yes	Yes
5890	9693-XMUOB	Male	1	Yes	No
5891	0383-CLDDA	Female	0	No	No
5892	4905-JEFDW	Male	0	No	No
5893	2709-UQGNP	Male	0	No	No
5894	3549-ZTMNH	Male	0	Yes	Yes
5895	7881-INRLC	Male	0	No	No
5896	8033-ATFAS	Female	0	Yes	Yes
5897	1635-NZATJ	Male	1	Yes	No
5898	0562-HKHML	Male	0	Yes	Yes
5899	8277-RVRSV	Female	0	Yes	Yes
5900	9943-VSZUV	Male	1	No	No
5901	0117-LFRMW	Male	0	Yes	Yes
5902	6172-FECYY	Male	0	Yes	Yes
5903	7054-ENNGU	Female	0	Yes	No
5904	1455-HFBXA	Male	0	Yes	No
5905	9402-CXWPL	Female	0	No	No
5906	1628-BIZYP	Male	0	No	No
5907	1965-AKTSX	Female	1	No	No
5908	0082-LDZUE	Male	0	No	No
5909	4786-UKSNZ	Male	0	No	No
5910	5343-SGUBI	Female	0	No	No
5911	0856-NAOES	Male	0	No	No
5912	1976-AZZPJ	Male	0	Yes	No
5913	7248-VZQLC	Female	1	No	No
5914	6156-UZDLF	Female	0	No	No
5915	3099-OONVS	Male	0	Yes	Yes
5916	9500-WBGRP	Male	0	No	No
5917	5183-KLYEM	Female	0	No	No
5918	5144-PQCDZ	Male	0	No	No
5919	8514-VZHEB	Male	0	Yes	Yes
5920	6625-IUTTT	Male	0	No	No
5921	9355-NPPFS	Female	1	No	No
5922	0068-FIGTF	Female	0	No	No
5923	5965-GGPRW	Male	0	Yes	Yes
5924	8035-PWSEV	Female	0	No	No
5925	2236-HILPA	Male	0	Yes	Yes
5926	1840-BIUOG	Male	0	No	No
5927	1356-MKYSK	Male	0	No	No
5928	6080-LNESI	Male	0	No	No
5929	1830-IPXVJ	Female	0	Yes	Yes
5930	5828-DWPIL	Male	1	Yes	No
5931	8398-TBIYD	Female	0	No	No
5932	0011-IGKFF	Male	1	Yes	No
5933	4192-GORJT	Male	0	Yes	No
5934	6496-SLWHQ	Male	1	No	No
5935	9912-GVSEQ	Female	1	Yes	No
5936	2931-FSOHN	Male	1	No	No
5937	9418-RUKPH	Female	0	Yes	Yes
5938	5383-MMTWC	Female	1	Yes	No
5939	9971-ZWPBF	Male	1	Yes	Yes
5940	4712-AUQZO	Male	0	No	No
5941	9711-FJTBX	Male	0	Yes	Yes
5942	2908-ZTPNF	Female	0	No	No
5943	7240-ETPTR	Female	0	Yes	No
5944	2202-CUYXZ	Male	0	No	No
5945	5995-OIGLP	Male	0	No	No
5946	8421-WZOOW	Female	1	Yes	Yes
5947	6261-RCVNS	Female	0	No	No
5948	7951-QKZPL	Female	0	Yes	Yes
5949	1414-YADCW	Male	0	Yes	No
5950	8756-RDDLT	Female	0	No	No
5951	2862-PFNIK	Male	0	No	Yes
5952	5816-QVHRX	Female	0	No	No
5953	4430-YHXGG	Female	0	No	Yes
5954	6888-SBYAI	Male	0	No	No
5955	7395-XWZOY	Male	0	No	No
5956	7169-YWAMK	Male	0	Yes	Yes
5957	3640-PHQXK	Female	0	No	No
5958	6877-LGWXO	Male	1	Yes	No
5959	6859-RKMZJ	Male	0	Yes	No
5960	2729-VNVAP	Female	0	Yes	Yes
5961	2957-JIRMN	Female	1	No	No
5962	2049-BAFNW	Female	0	No	No
5963	3842-QTGDL	Male	0	Yes	No
5964	7163-OCEQI	Male	0	Yes	Yes
5965	9782-LGXMC	Female	0	Yes	Yes
5966	5975-BAICR	Male	0	Yes	Yes
5967	8019-ENHXU	Male	0	Yes	No
5968	5167-GBFRE	Male	1	No	No
5969	9033-EOXWV	Female	0	No	No
5970	4673-KKSLS	Female	0	No	No
5971	4853-OITSN	Male	0	Yes	No
5972	9800-OUIGR	Male	0	Yes	Yes
5973	1324-NLTJE	Female	1	No	No
5974	2324-EFHVG	Male	0	No	No
5975	7094-MSZAO	Male	0	Yes	Yes
5976	1522-VVDMG	Male	0	Yes	Yes
5977	6907-CQGPN	Male	0	No	No
5978	0780-XNZFN	Male	0	No	No
5979	0239-OXEXL	Female	0	No	No
5980	2675-IJRGJ	Male	0	No	No
5981	7049-GKVZY	Female	0	No	No
5982	8577-QSOCG	Female	0	Yes	Yes
5983	3721-CNZHX	Male	0	No	No
5984	0212-ISBBF	Female	0	No	No
5985	9185-TQCVP	Male	0	Yes	No
5986	3585-YNADK	Female	0	Yes	No
5987	5271-DBYSJ	Male	1	No	No
5988	1099-GODLO	Female	0	Yes	Yes
5989	6828-HMKWP	Male	0	Yes	Yes
5990	5567-WSELE	Male	1	Yes	No
5991	1472-TNCWL	Male	0	No	Yes
5992	8063-RJYNF	Male	0	No	No
5993	0687-ZVTHB	Male	0	Yes	Yes
5994	2080-GKCWQ	Male	0	No	No
5995	9661-ACXBS	Female	0	No	No
5996	2193-SFWQW	Male	0	Yes	Yes
5997	5656-JAMLX	Male	0	No	No
5998	3462-BJQQA	Female	0	No	No
5999	0442-TDYUO	Male	0	Yes	No
6000	6733-LRIZX	Male	0	No	No
6001	9503-XJUME	Male	0	No	Yes
6002	4367-NHWMM	Female	0	No	No
6003	3727-RJMEO	Male	0	Yes	No
6004	3779-OSWCF	Female	0	Yes	No
6005	6736-DHUQI	Female	0	Yes	Yes
6006	3915-ODIYG	Male	1	No	No
6007	1360-RCYRT	Male	0	Yes	Yes
6008	2724-FJDYW	Male	0	No	Yes
6009	4451-RWASJ	Male	0	Yes	Yes
6010	6646-VRFOL	Male	1	Yes	No
6011	3460-TJBWI	Male	0	Yes	Yes
6012	5917-HBSDW	Female	0	Yes	Yes
6013	5685-IIXLY	Female	0	Yes	Yes
6014	5671-UUNXD	Female	1	Yes	No
6015	0956-ACVZC	Female	0	No	No
6016	2325-NBPZG	Female	0	No	No
6017	4250-ZBWLV	Male	0	No	No
6018	4482-FTFFX	Male	0	No	No
6019	8859-DZTGQ	Male	0	No	No
6020	0440-MOGPM	Female	0	No	No
6021	0020-JDNXP	Female	0	Yes	Yes
6022	3752-CQSJI	Female	0	Yes	Yes
6023	5025-GOOKI	Female	0	No	No
6024	4698-KVLLG	Female	1	No	No
6025	5095-AESKG	Female	0	Yes	No
6026	2887-JPYLU	Female	0	No	Yes
6027	4770-QAZXN	Female	0	No	No
6028	4896-CPRPF	Male	0	Yes	Yes
6029	1871-MOWRM	Male	0	Yes	No
6030	9714-EDSUC	Male	0	No	No
6031	2027-OAQQC	Female	0	No	No
6032	0282-NVSJS	Female	1	Yes	Yes
6033	9090-SGQXL	Male	1	Yes	No
6034	6595-YGXIT	Male	1	No	No
6035	7353-YOWFP	Female	0	No	No
6036	9835-ZIITK	Male	1	Yes	No
6037	8008-ESFLK	Female	0	Yes	No
6038	7537-CBQUZ	Male	1	No	No
6039	1555-DJEQW	Female	0	Yes	Yes
6040	5649-TJHOV	Male	1	Yes	No
6041	0519-XUZJU	Female	0	No	No
6042	3363-EWLGO	Female	0	No	No
6043	4750-UKWJK	Female	1	Yes	No
6044	6338-AVWCY	Male	0	No	No
6045	1689-YQBYY	Female	0	No	Yes
6046	4487-ZYJZK	Female	0	Yes	Yes
6047	2959-FENLU	Female	0	No	No
6048	0708-LGSMF	Male	0	Yes	No
6049	9253-QXKBE	Male	1	Yes	No
6050	7634-HLQJR	Female	0	Yes	Yes
6051	0487-RPVUM	Male	0	Yes	No
6052	4079-ULGFR	Male	0	No	No
6053	2516-XSJKX	Female	0	Yes	Yes
6054	0057-QBUQH	Female	0	No	Yes
6055	9445-SZLCH	Female	0	Yes	Yes
6056	6599-SFQVE	Female	0	No	No
6057	8331-ZXFOE	Female	0	No	No
6058	4003-FUSHP	Male	0	No	No
6059	0356-ERHVT	Male	0	Yes	No
6060	7325-ENZFI	Female	0	No	No
6061	4884-ZTHVF	Female	1	No	No
6062	3920-HIHMQ	Female	0	No	Yes
6063	3055-OYMSE	Female	1	No	No
6064	0613-WUXUM	Female	0	Yes	Yes
6065	7568-PODML	Male	0	No	No
6066	4458-KVRBJ	Male	0	No	No
6067	5349-IECLD	Male	0	No	No
6068	1397-XKKWR	Male	0	No	No
6069	3945-GFWQL	Female	0	No	Yes
6070	8097-OMULG	Male	0	Yes	Yes
6071	6013-BHCAW	Male	0	Yes	Yes
6072	0401-WDBXM	Male	0	Yes	Yes
6073	3387-PLKUI	Female	0	Yes	Yes
6074	6096-EGVTU	Female	0	Yes	Yes
6075	3797-VTIDR	Male	0	Yes	No
6076	5081-NWSUP	Female	0	No	No
6077	2580-ATZSQ	Female	0	Yes	Yes
6078	8085-MSNLK	Female	0	Yes	No
6079	9691-HKOVS	Female	0	Yes	No
6080	9881-VCZEP	Female	0	Yes	No
6081	9526-BIHHD	Male	0	No	No
6082	8757-TFHHJ	Male	0	No	No
6083	4523-WXCEF	Female	0	Yes	No
6084	1468-DEFNC	Male	1	Yes	Yes
6085	5119-KEPFY	Male	0	Yes	No
6086	8364-TRMMK	Female	0	No	No
6087	0916-KNFAJ	Male	0	Yes	No
6088	8319-QBEHW	Male	0	No	Yes
6089	3063-QFSZL	Female	0	No	No
6090	8775-LHDJH	Female	1	Yes	No
6091	9625-QNLUX	Male	0	Yes	Yes
6092	3097-NQYSN	Male	1	Yes	No
6093	4024-CSNBY	Female	0	Yes	No
6094	7110-BDTWG	Female	0	Yes	No
6095	7493-GVFIO	Male	0	No	No
6096	0690-SRQID	Male	0	No	No
6097	9605-WGJVW	Female	1	No	No
6098	9114-DPSIA	Male	0	Yes	Yes
6099	4700-UBQMV	Male	0	Yes	Yes
6100	7711-GQBZC	Female	0	Yes	Yes
6101	3565-UNOCC	Female	1	Yes	No
6102	4627-MIHJH	Female	1	No	No
6103	9795-NREXC	Female	0	Yes	No
6104	8573-CGOCC	Male	0	No	No
6105	7356-AYNJP	Female	0	No	No
6106	9249-FXSCK	Female	0	No	No
6107	5493-SDRDQ	Male	0	No	No
6108	6286-SUUWT	Male	0	No	No
6109	4819-HJPIW	Male	0	No	No
6110	8654-DHAOW	Female	0	No	No
6111	5438-QMDDL	Female	0	Yes	No
6112	9812-GHVRI	Female	0	No	No
6113	5553-AOINX	Female	1	Yes	Yes
6114	1228-ZLNBX	Male	0	No	No
6115	4226-KKDON	Male	0	No	No
6116	3831-YCPUO	Female	0	Yes	Yes
6117	7445-WMRBW	Female	0	No	No
6118	3308-DGHKL	Male	0	No	No
6119	9924-JPRMC	Male	0	No	No
6120	0080-EMYVY	Female	0	No	No
6121	6218-KNUBD	Male	0	No	No
6122	7337-CINUD	Female	0	Yes	Yes
6123	7609-NRNCA	Female	0	No	No
6124	0623-EJQEG	Male	0	No	No
6125	7153-CHRBV	Female	0	Yes	Yes
6126	0871-URUWO	Male	0	Yes	No
6127	9190-MFJLN	Male	1	No	No
6128	6198-PNNSZ	Female	0	Yes	No
6129	3317-VLGQT	Female	0	Yes	No
6130	4132-POCZS	Male	0	Yes	No
6131	5614-DNZCE	Female	0	No	No
6132	1095-JUDTC	Female	1	No	No
6133	3896-RCYYE	Female	0	No	No
6134	9638-JIQYA	Male	0	No	No
6135	3258-SANFR	Male	1	No	No
6136	3726-TBHQT	Male	0	Yes	Yes
6137	3190-ITQXP	Female	0	Yes	Yes
6138	0870-VEMYL	Female	0	No	No
6139	4833-QTJNO	Male	1	Yes	No
6140	3039-MJSLN	Male	0	No	Yes
6141	0178-CIIKR	Female	0	No	No
6142	5385-SUIRI	Male	1	Yes	No
6143	3982-XWFZQ	Female	0	Yes	No
6144	5774-QPLTF	Male	0	Yes	Yes
6145	2322-VCZHZ	Male	1	Yes	No
6146	5010-IPEAQ	Female	0	Yes	Yes
6147	4009-ALQFH	Female	0	No	No
6148	6383-ZTSIW	Female	1	Yes	No
6149	8990-YOZLV	Female	0	No	No
6150	3069-SSVSN	Female	0	No	No
6151	5222-IMUKT	Male	0	No	No
6152	3627-FCRDW	Female	0	No	No
6153	7562-GSUHK	Female	0	No	No
6154	6685-XSHHU	Male	0	Yes	Yes
6155	8901-UPRHR	Female	0	Yes	Yes
6156	4903-UYAVB	Male	0	Yes	No
6157	0118-JPNOY	Female	1	No	No
6158	6776-TLWOI	Male	0	No	No
6159	3845-FXCYS	Male	0	No	No
6160	5857-XRECV	Female	0	No	Yes
6161	0725-CXOTM	Female	0	No	No
6162	4343-EJVQB	Male	0	No	No
6163	9000-PLFUZ	Female	1	Yes	No
6164	3427-GGZZI	Female	0	Yes	No
6165	7779-ORAEL	Male	1	Yes	No
6166	0644-OQMDK	Male	1	No	No
6167	4077-CROMM	Female	0	Yes	Yes
6168	3154-CFSZG	Male	0	Yes	Yes
6169	2868-MZAGQ	Male	0	No	No
6170	4847-QNOKA	Female	0	No	No
6171	2220-IAHLS	Female	0	No	No
6172	1658-XUHBX	Female	1	Yes	Yes
6173	6379-RXJRQ	Male	0	Yes	No
6174	2378-HTWFW	Male	1	No	No
6175	8650-RHRKE	Male	0	No	No
6176	4377-VDHYI	Male	0	Yes	Yes
6177	0475-RIJEP	Male	0	No	No
6178	1260-TTRXI	Male	0	No	No
6179	3719-TDVQB	Female	1	Yes	No
6180	6328-ZPBGN	Female	1	No	No
6181	0201-MIBOL	Female	1	No	No
6182	4937-QPZPO	Male	0	Yes	Yes
6183	2925-VDZHY	Male	0	Yes	Yes
6184	6981-TDRFT	Male	0	Yes	Yes
6185	3413-CSSTH	Male	0	No	No
6186	8033-VCZGH	Male	0	Yes	No
6187	4789-KWMXN	Male	0	Yes	No
6188	0224-NIJLP	Male	0	Yes	Yes
6189	7542-CYDDM	Male	0	No	No
6190	4718-WXBGI	Male	0	Yes	Yes
6191	2867-UIMSS	Male	0	No	No
6192	8495-PRWFH	Female	1	No	No
6193	0439-IFYUN	Female	1	No	No
6194	5716-LIBJC	Female	0	No	Yes
6195	2868-LLSKM	Female	0	Yes	Yes
6196	8111-RKSPX	Male	0	No	No
6197	2988-QRAJY	Male	0	No	No
6198	1585-MQSSU	Male	0	No	No
6199	0071-NDAFP	Male	0	Yes	Yes
6200	2856-NNASM	Male	1	No	No
6201	7328-ZJAJO	Female	0	Yes	Yes
6202	6458-CYIDZ	Female	1	No	No
6203	8559-CIZFV	Male	0	Yes	Yes
6204	1090-PYKCI	Female	0	Yes	Yes
6205	3058-WQDRE	Male	0	No	No
6206	7547-EKNFS	Male	0	Yes	No
6207	2279-AXJJK	Male	0	Yes	No
6208	6769-DYBQN	Male	1	No	No
6209	0909-SELIE	Male	0	Yes	No
6210	3417-TSCIC	Male	0	No	No
6211	1042-HFUCW	Female	0	No	Yes
6212	4439-JMPMT	Female	0	Yes	Yes
6213	6537-OTKMY	Male	0	No	No
6214	8999-EXMNO	Female	0	Yes	Yes
6215	6725-TPKJO	Male	0	No	No
6216	2446-BEGGB	Female	1	No	No
6217	7162-WPHPM	Male	0	Yes	Yes
6218	1599-MMYRQ	Male	0	Yes	Yes
6219	8821-KVZKQ	Female	0	Yes	Yes
6220	1496-GGSUK	Female	1	No	No
6221	6434-TTGJP	Male	0	Yes	Yes
6222	0042-JVWOJ	Male	0	No	No
6223	0130-SXOUN	Male	0	No	No
6224	2575-GFSOE	Female	0	Yes	Yes
6225	2330-PQGDQ	Male	0	Yes	Yes
6226	1452-UZOSF	Male	0	Yes	Yes
6227	2097-YVPKN	Male	0	No	No
6228	2842-JTCCU	Male	0	No	No
6229	8597-CTXVJ	Male	0	No	Yes
6230	6631-HMANX	Male	0	Yes	No
6231	9962-BFPDU	Female	0	Yes	Yes
6232	3296-SILRA	Female	1	Yes	No
6233	9681-OXGVC	Female	0	No	No
6234	6394-HHHZM	Male	0	No	No
6235	5995-LFTLE	Male	0	No	No
6236	5180-UCIIQ	Male	1	Yes	Yes
6237	1932-UEDCX	Male	1	Yes	No
6238	7153-OANIO	Male	0	No	No
6239	5188-HGMLP	Male	1	Yes	No
6240	0665-XHDJU	Male	0	Yes	No
6241	6521-YYTYI	Male	0	No	Yes
6242	8878-HMWBV	Male	0	No	No
6243	8265-HKSOW	Female	0	Yes	Yes
6244	3544-FBCAS	Female	0	Yes	Yes
6245	5331-RGMTT	Male	1	Yes	No
6246	4759-PXTAN	Female	0	Yes	No
6247	7054-DMVAS	Male	0	No	No
6248	3428-MMGUB	Male	0	No	No
6249	6549-BTYPG	Female	0	Yes	No
6250	7823-JSOAG	Male	0	No	No
6251	3705-RHRFR	Female	0	Yes	No
6252	9374-YOLBJ	Female	0	Yes	Yes
6253	9074-KGVOX	Male	0	Yes	Yes
6254	6128-DAFVY	Female	0	No	No
6255	9933-QRGTX	Female	0	Yes	No
6256	4476-OSWTN	Male	1	Yes	No
6257	3751-KTZEL	Female	0	No	No
6258	1977-STDKI	Female	1	No	No
6259	5066-GFJMM	Female	0	Yes	No
6260	2661-GKBTK	Male	0	Yes	Yes
6261	0458-HEUZG	Female	0	No	No
6262	7268-WNTCP	Male	0	Yes	Yes
6263	0824-VWDPO	Female	0	No	No
6264	8409-WQJUX	Female	0	No	No
6265	2578-JQPHZ	Male	0	No	No
6266	3278-FSIXX	Female	0	No	No
6267	5813-UECBU	Male	1	No	No
6268	0328-GRPMV	Female	0	No	No
6269	9746-UGFAC	Female	0	No	No
6270	2946-KIQSP	Female	0	No	No
6271	0625-AFOHS	Female	0	Yes	Yes
6272	6726-WEXXK	Male	1	Yes	No
6273	4636-OLWOE	Male	0	No	Yes
6274	4342-HENTK	Female	1	No	No
6275	4685-ERGHK	Male	0	No	No
6276	0885-HMGPY	Male	0	No	No
6277	5003-OKNNK	Female	0	Yes	Yes
6278	4195-SMMNX	Male	0	No	No
6279	7208-PSIHR	Female	0	Yes	No
6280	4012-ZTHBR	Female	0	Yes	Yes
6281	0489-WMEMG	Female	0	No	Yes
6282	7435-ZNUYY	Male	0	No	No
6283	1354-YZFNB	Male	0	Yes	Yes
6284	6956-SMUCM	Female	0	No	No
6285	2985-FMWYF	Female	0	No	No
6286	2812-ENYMO	Male	0	No	No
6287	2717-HVIZY	Female	0	No	Yes
6288	3223-WZWJM	Male	0	No	No
6289	3422-GALYP	Male	0	No	No
6290	9053-JZFKV	Male	0	No	No
6291	2530-ENDWQ	Female	0	Yes	No
6292	2890-WFBHU	Female	0	No	No
6293	0327-WFZSY	Male	0	Yes	Yes
6294	7977-HXJKU	Male	0	No	Yes
6295	6615-ZGEDR	Male	0	No	No
6296	7033-CLAMM	Female	0	Yes	Yes
6297	4023-RTIQM	Female	1	Yes	No
6298	0864-FVJNJ	Female	0	Yes	Yes
6299	7356-IWLFW	Male	0	Yes	Yes
6300	9541-PWTWO	Female	0	No	No
6301	3967-VQOGC	Female	0	Yes	Yes
6302	7872-RDDLZ	Female	1	No	No
6303	9250-WYPLL	Female	0	No	No
6304	6308-CQRBU	Female	0	Yes	No
6305	2754-XBHTB	Female	0	No	No
6306	1597-LHYNC	Female	1	No	No
6307	0186-CAERR	Male	0	No	No
6308	3043-SUDUA	Female	0	No	No
6309	5442-BHQNG	Female	0	No	No
6310	2169-RRLFW	Female	0	Yes	No
6311	5872-OEQNH	Female	0	No	No
6312	3162-KKZXO	Female	1	No	No
6313	7055-VKGDA	Male	0	No	No
6314	0754-UKWQP	Male	0	No	No
6315	8873-GLDMH	Female	0	No	No
6316	5696-JVVQY	Female	0	Yes	Yes
6317	8946-BFWSG	Male	0	Yes	Yes
6318	7493-TPUWZ	Male	0	No	No
6319	0547-HURJB	Male	0	No	Yes
6320	8904-OPDCK	Male	1	Yes	No
6321	8845-LWKGE	Female	0	Yes	Yes
6322	1577-HKTFG	Female	0	Yes	No
6323	8752-STIVR	Female	0	No	No
6324	0691-NIKRI	Female	0	No	No
6325	5022-JNQEQ	Female	0	Yes	Yes
6326	4558-FANTW	Female	0	Yes	Yes
6327	3249-VHRIP	Female	0	No	No
6328	3736-BLEPA	Male	0	No	No
6329	4701-LKOZD	Female	0	No	No
6330	6603-QWSPR	Female	0	No	No
6331	9921-QFQUL	Female	0	Yes	No
6332	1929-ZCBHE	Male	0	Yes	Yes
6333	4378-MYPGO	Male	0	Yes	Yes
6334	8651-ENBZX	Female	1	No	No
6335	4129-LYCOI	Female	0	No	Yes
6336	7798-JVXYM	Female	0	No	No
6337	8647-SDTWQ	Male	0	Yes	Yes
6338	2696-ECXKC	Female	0	Yes	Yes
6339	2081-KJSQF	Male	0	No	No
6340	7623-TRNQN	Male	0	No	Yes
6341	3323-CPBWR	Male	0	No	No
6342	9330-IJWIO	Female	0	No	No
6343	3384-CTMSF	Male	0	Yes	No
6344	0902-RFHOF	Male	0	No	No
6345	9286-DOJGF	Female	1	Yes	No
6346	6048-QBXKL	Female	1	No	No
6347	9661-MHUMO	Male	1	Yes	Yes
6348	7718-RXDGG	Male	0	Yes	No
6349	1025-FALIX	Female	0	No	No
6350	3451-VAWLI	Female	0	Yes	Yes
6351	3407-QGWLG	Male	0	No	Yes
6352	1842-EZJMK	Male	0	Yes	Yes
6353	2347-WKKAE	Male	0	Yes	No
6354	8735-DCXNF	Male	0	Yes	No
6355	3214-IYUUQ	Female	0	Yes	No
6356	1936-UAFEH	Female	0	No	No
6357	3587-PMCOY	Male	0	No	No
6358	8079-XRJRS	Male	0	Yes	No
6359	1027-LKKQQ	Female	0	Yes	Yes
6360	7148-XZPHA	Male	0	Yes	Yes
6361	8073-IJDCM	Female	0	No	No
6362	5309-TAIKL	Female	0	No	No
6363	6856-RAURS	Female	0	No	No
6364	8778-LMWTJ	Female	0	No	No
6365	9717-IOAAF	Male	0	No	Yes
6366	8884-ADFVN	Male	1	Yes	No
6367	2845-KDHVX	Female	0	Yes	No
6368	0848-SOMKO	Male	0	No	No
6369	2720-WGKHP	Male	1	No	No
6370	6734-FQAJX	Male	1	No	No
6371	2869-ADAWR	Female	0	No	No
6372	1535-VTJOQ	Female	0	No	No
6373	6368-TZZDT	Male	0	Yes	Yes
6374	0943-ZQPXH	Male	0	Yes	Yes
6375	1293-BSEUN	Female	0	Yes	Yes
6376	9894-EZEWG	Female	0	No	No
6377	1302-TPUBN	Male	0	No	No
6378	7851-FLGGQ	Male	0	No	No
6379	0637-UBJRP	Male	0	Yes	Yes
6380	0940-OUQEC	Male	0	No	No
6381	2378-VTKDH	Male	1	Yes	No
6382	0927-CNGRH	Male	0	No	Yes
6383	8608-OZTLB	Male	0	Yes	Yes
6384	2335-GSODA	Male	0	No	Yes
6385	1952-DVVSW	Female	0	Yes	No
6386	0702-PGIBZ	Male	0	No	Yes
6387	6656-GULJQ	Male	0	Yes	Yes
6388	9853-JFZDU	Female	0	Yes	No
6389	1963-VAUKV	Female	0	No	No
6390	3777-XROBG	Female	0	Yes	Yes
6391	6994-FGRHH	Male	0	Yes	Yes
6392	4000-VGMQP	Male	0	Yes	Yes
6393	3999-WRNGR	Female	0	Yes	Yes
6394	3466-RITXD	Male	0	No	No
6395	2680-XKKNJ	Female	0	No	No
6396	3058-HJCUY	Male	0	Yes	Yes
6397	2974-GGUXS	Female	1	Yes	No
6398	7994-XIRTR	Male	1	No	No
6399	3259-FDWOY	Male	0	Yes	Yes
6400	2101-RANCD	Female	0	No	No
6401	7921-BEPCI	Female	0	No	No
6402	0807-ZABDG	Female	0	No	Yes
6403	8510-TMWYB	Female	0	Yes	Yes
6404	3258-ZKPAI	Male	0	Yes	Yes
6405	1428-IEDPR	Male	0	No	No
6406	5298-GSTLM	Female	1	No	No
6407	4450-YOOHP	Female	0	No	No
6408	6728-CZFEI	Female	0	No	No
6409	5748-RNCJT	Male	0	No	No
6410	3653-NCRDJ	Male	0	Yes	Yes
6411	6121-TNHBO	Female	1	No	No
6412	5119-NZPTV	Male	1	Yes	No
6413	6519-ZHPXP	Female	0	Yes	Yes
6414	7739-LAXOG	Female	0	Yes	Yes
6415	3472-QPRCH	Male	0	Yes	Yes
6416	8224-UAXBZ	Female	0	Yes	No
6417	9610-WCESF	Male	0	No	No
6418	9776-CLUJA	Female	1	Yes	No
6419	2486-WYVVE	Male	0	Yes	No
6420	3865-ZYKAD	Male	1	Yes	No
6421	1422-DGUBX	Male	0	Yes	No
6422	2999-AANRQ	Female	0	No	No
6423	8668-KNZTI	Male	0	No	No
6424	0480-KYJVA	Female	0	Yes	Yes
6425	6034-ZRYCV	Female	0	Yes	No
6426	9746-YKGXB	Male	0	Yes	Yes
6427	3926-YZVVX	Female	0	No	No
6428	6000-UKLWI	Male	0	No	No
6429	2079-FBMZK	Female	0	No	No
6430	6332-FBZRI	Male	0	Yes	Yes
6431	2096-XOTMO	Female	0	Yes	Yes
6432	3266-FTKHB	Male	0	No	No
6433	8221-EQDGL	Male	0	Yes	No
6434	2346-LOCWC	Female	0	Yes	Yes
6435	6608-QQLVK	Male	0	No	No
6436	0298-XACET	Male	0	Yes	Yes
6437	7560-QJAVJ	Female	0	No	No
6438	2995-YWTCD	Female	0	Yes	Yes
6439	3551-HUAZH	Male	1	No	No
6440	9137-UIYPG	Female	0	Yes	Yes
6441	2809-ZMYOQ	Female	0	No	No
6442	5084-OOVCJ	Female	0	Yes	Yes
6443	0254-WWRKD	Female	0	Yes	Yes
6444	7727-SHVZV	Female	0	No	No
6445	6302-JGYRJ	Male	0	No	Yes
6446	5339-PXDVH	Male	0	No	No
6447	2205-LPVGL	Male	1	Yes	Yes
6448	8782-NUUOL	Male	0	No	No
6449	3685-YLCMQ	Male	0	No	No
6450	7601-WFVZV	Male	0	No	No
6451	4609-KNNWG	Female	0	Yes	Yes
6452	4868-AADLV	Male	1	Yes	Yes
6453	9529-OFXHY	Male	0	No	No
6454	8634-MPHTR	Male	1	Yes	No
6455	2669-QVCRG	Female	0	No	No
6456	2478-EEWWM	Male	0	Yes	No
6457	9174-IHETN	Female	0	No	Yes
6458	2233-TXSIU	Male	0	Yes	Yes
6459	9644-UMGQA	Male	0	Yes	Yes
6460	3256-EZDBI	Male	1	Yes	No
6461	8761-NSOBC	Male	0	No	No
6462	0419-YAAPX	Male	0	Yes	No
6463	8413-VONUO	Male	0	No	No
6464	0872-CASZJ	Male	0	Yes	No
6465	4726-DLWQN	Male	1	No	No
6466	8164-OCKUJ	Female	0	Yes	Yes
6467	3094-JOJAI	Male	0	No	No
6468	9494-MRNYX	Male	0	No	No
6469	2599-CZABP	Male	0	Yes	No
6470	7945-PRBVF	Male	0	No	No
6471	4544-RXFMG	Male	0	Yes	Yes
6472	0859-YGKFW	Male	0	Yes	Yes
6473	1150-FTQGN	Female	0	Yes	Yes
6474	9223-UCPVT	Female	0	No	No
6475	7196-LIWRH	Female	0	No	No
6476	5448-VWNAM	Female	0	No	Yes
6477	1177-XZBJL	Male	0	Yes	Yes
6478	3518-FSTWG	Male	1	Yes	No
6479	9330-VOFSZ	Female	0	Yes	No
6480	4351-QLCSU	Female	0	No	No
6481	0939-EREMR	Female	0	No	Yes
6482	9389-ACWBI	Female	0	Yes	Yes
6483	5419-JPRRN	Male	0	No	No
6484	3644-QXEHN	Male	0	Yes	Yes
6485	2911-IJORQ	Male	0	No	No
6486	5921-NGYRH	Male	0	Yes	No
6487	2100-BDNSN	Female	0	Yes	No
6488	5998-DZLYR	Female	0	Yes	No
6489	0488-GSLFR	Female	0	No	No
6490	9318-NKNFC	Male	0	No	No
6491	3985-HOYPM	Male	0	No	No
6492	9728-FTTVZ	Female	0	No	No
6493	9548-LERKT	Male	0	Yes	No
6494	6576-FBXOJ	Male	0	Yes	No
6495	4310-KEDTB	Female	0	No	Yes
6496	7254-IQWOZ	Male	0	No	No
6497	2474-BRUCM	Male	1	Yes	No
6498	4062-HBMOS	Male	0	No	No
6499	0742-NXBGR	Female	0	No	No
6500	2676-ISHSF	Male	0	No	No
6501	9236-NDUCW	Female	0	No	No
6502	4753-PADAS	Female	0	Yes	No
6503	6103-QCKFX	Female	0	Yes	Yes
6504	7781-EWARA	Male	0	Yes	Yes
6505	6110-OHIHY	Male	0	No	No
6506	7018-FPXHH	Male	0	Yes	Yes
6507	5889-LFOLL	Female	0	No	No
6508	5708-EVONK	Female	0	Yes	Yes
6509	8708-XPXHZ	Female	0	Yes	Yes
6510	0616-ATFGB	Male	1	Yes	No
6511	0572-ZJKLT	Female	0	Yes	Yes
6512	5135-RDDQL	Female	0	Yes	Yes
6513	1353-LJWEM	Male	0	No	No
6514	1794-SWWKL	Male	0	Yes	Yes
6515	6166-YIPFO	Male	0	Yes	No
6516	7016-BPGEU	Female	0	No	No
6517	6876-ADESB	Male	0	No	Yes
6518	9332-GYWLO	Female	0	Yes	Yes
6519	1963-SVUCV	Male	0	No	No
6520	4184-VODJZ	Male	0	Yes	Yes
6521	0220-EBGCE	Male	0	No	No
6522	1092-WPIVQ	Female	0	Yes	Yes
6523	7233-IOQNP	Female	0	Yes	No
6524	2834-JKOOW	Female	0	No	No
6525	2754-VDLTR	Male	0	No	Yes
6526	2400-FEQME	Male	0	Yes	Yes
6527	3190-XFANI	Male	0	No	Yes
6528	7551-DACSP	Male	0	Yes	Yes
6529	4957-SREEC	Male	0	Yes	Yes
6530	7235-NXZCP	Male	1	No	No
6531	0230-UBYPQ	Male	1	Yes	No
6532	4923-ADWXJ	Female	0	No	No
6533	1763-KUAAW	Female	1	No	No
6534	1104-TNLZA	Male	1	Yes	No
6535	5195-KPUNQ	Female	1	No	No
6536	0520-FDVVT	Male	0	No	No
6537	3439-GVUSX	Male	0	No	No
6538	1444-VVSGW	Male	0	Yes	No
6539	5712-PTIWW	Male	0	No	No
6540	5949-HGVJL	Female	0	Yes	No
6541	5203-XEHAX	Female	0	No	No
6542	1635-HDGFT	Female	0	No	Yes
6543	3315-TOTBP	Male	0	No	No
6544	8050-XGRVL	Female	0	Yes	Yes
6545	6661-HBGWL	Female	1	No	No
6546	1518-VOWAV	Female	0	No	No
6547	9828-QHFBK	Male	0	No	No
6548	3908-MKIMJ	Male	1	Yes	No
6549	5012-YSPJJ	Male	0	Yes	Yes
6550	5909-ECHUI	Female	0	No	No
6551	1309-BXVOQ	Male	0	Yes	No
6552	6728-VOIFY	Female	0	Yes	No
6553	9317-WZPGV	Female	1	No	No
6554	4891-NLUBA	Female	0	Yes	Yes
6555	2856-HYAPG	Female	0	No	No
6556	8969-PRHFK	Male	0	No	No
6557	0661-KQHNK	Female	0	Yes	Yes
6558	8709-KRDVL	Female	0	No	No
6559	4488-PSYCG	Male	0	No	No
6560	1427-VERSM	Female	0	Yes	No
6561	9801-NOSHQ	Male	0	No	Yes
6562	6339-YPSAH	Male	0	No	No
6563	3621-CEOVK	Female	1	Yes	No
6564	6906-ANDWJ	Male	0	Yes	Yes
6565	2159-TURXX	Male	0	No	No
6566	1548-FEHVL	Male	0	Yes	No
6567	3795-CAWEX	Male	0	Yes	Yes
6568	6215-NQCPY	Male	0	No	No
6569	5647-URDKA	Male	0	Yes	Yes
6570	2229-DPMBI	Female	0	Yes	Yes
6571	9626-WEQRM	Female	0	No	No
6572	2188-SXWVT	Female	0	No	No
6573	6258-PVZWJ	Male	0	Yes	No
6574	1094-BKOSX	Female	0	Yes	Yes
6575	6969-MVBAI	Female	1	No	No
6576	2978-XXSOG	Female	0	No	No
6577	2342-CKIAO	Female	0	No	No
6578	6953-PBDIN	Male	0	Yes	No
6579	3898-BSJYF	Female	0	No	Yes
6580	3938-YFPXD	Male	0	No	No
6581	7696-AMHOD	Female	0	Yes	Yes
6582	2453-SAFNS	Female	1	No	No
6583	9558-IHEZX	Female	0	No	No
6584	9617-UDPEU	Female	0	No	No
6585	6340-DACFT	Female	0	Yes	Yes
6586	4955-VCWBI	Female	0	Yes	Yes
6587	6813-GZQCG	Female	0	Yes	Yes
6588	7426-GSWPO	Male	1	No	No
6589	3389-KTRXV	Female	0	Yes	Yes
6590	3118-UHVVQ	Female	0	Yes	No
6591	1031-IIDEO	Female	0	No	No
6592	5832-XKAES	Male	0	No	No
6593	3205-MXZRA	Male	0	No	No
6594	4701-AHWMW	Male	0	Yes	No
6595	8317-BVKSO	Male	0	No	No
6596	5702-KVQRD	Male	0	Yes	No
6597	0083-PIVIK	Male	0	No	No
6598	9210-IAHGH	Female	0	No	No
6599	6169-PGNCD	Female	0	No	No
6600	0023-XUOPT	Female	0	Yes	No
6601	4592-IWTJI	Female	0	Yes	Yes
6602	4909-JOUPP	Male	1	Yes	No
6603	4657-FWVFY	Female	0	Yes	Yes
6604	2257-BOVXD	Male	0	Yes	No
6605	7729-JTEEC	Male	0	Yes	Yes
6606	7632-MNYOY	Male	1	No	No
6607	6518-LGAOV	Female	0	Yes	No
6608	7242-QZLXF	Male	0	No	Yes
6609	4576-CSAJH	Male	0	No	No
6610	1000-AJSLD	Male	0	No	No
6611	9696-RMYBA	Male	0	No	No
6612	8690-UPCZI	Male	0	Yes	Yes
6613	1062-LHZOD	Male	0	Yes	Yes
6614	9770-LXDBK	Female	0	No	No
6615	4086-WITJG	Male	0	Yes	Yes
6616	8344-WFMFH	Male	0	No	Yes
6617	9600-NAXZN	Male	0	No	No
6618	8822-KNBHV	Female	0	No	No
6619	8404-FYDIB	Male	0	No	No
6620	2791-SFVEW	Female	0	No	No
6621	6457-USBER	Male	0	No	No
6622	6762-NSODU	Female	0	Yes	Yes
6623	4662-EKDPQ	Male	0	No	No
6624	9248-OJYKK	Male	1	No	No
6625	9888-ZCUMM	Male	0	Yes	Yes
6626	3398-FSHON	Female	1	No	No
6627	3319-DWOEP	Male	1	Yes	No
6628	1074-WVEVG	Female	0	Yes	No
6629	9979-RGMZT	Female	0	No	No
6630	6437-UDQJM	Female	1	Yes	No
6631	1226-IENZN	Male	1	No	No
6632	2108-GLPQB	Male	0	Yes	No
6633	9259-PACGQ	Female	0	Yes	No
6634	4415-IJZTP	Female	0	No	No
6635	1465-VINDH	Female	0	Yes	Yes
6636	5474-LAMUQ	Male	0	Yes	No
6637	3468-DRVQJ	Female	0	Yes	Yes
6638	1122-YJBCS	Male	0	Yes	No
6639	4990-ALDGW	Male	0	No	No
6640	4816-OKWNX	Male	0	Yes	Yes
6641	3315-IKYZQ	Male	0	Yes	Yes
6642	2810-FTLEM	Female	0	No	No
6643	4747-LCAQL	Male	0	No	No
6644	3411-WLRSQ	Female	1	Yes	No
6645	0898-XCGTF	Male	0	Yes	No
6646	8006-PYCSW	Female	0	No	No
6647	8249-THVEC	Male	0	Yes	Yes
6648	8722-PRFDV	Female	0	Yes	Yes
6649	2164-SOQXL	Female	0	Yes	Yes
6650	4020-KIUDI	Male	0	Yes	Yes
6651	5850-BDWCY	Female	0	No	No
6652	2038-YSEZE	Female	0	No	No
6653	0827-ITJPH	Male	0	No	No
6654	8799-OXZMD	Female	0	No	No
6655	1925-TIBLE	Female	0	Yes	No
6656	1705-GUHPV	Female	0	No	No
6657	4779-ZGICK	Male	0	Yes	Yes
6658	0048-PIHNL	Female	0	Yes	No
6659	0818-OCPZO	Male	1	No	No
6660	3967-KXAPS	Male	0	Yes	No
6661	1447-GIQMR	Male	0	Yes	No
6662	3704-IEAXF	Female	0	Yes	Yes
6663	6810-VCAEX	Female	0	No	No
6664	0674-EYYZV	Female	0	No	No
6665	4480-MBMLB	Female	0	No	No
6666	1395-OFUWC	Male	0	Yes	Yes
6667	0822-QGCXA	Female	1	Yes	No
6668	0872-NXJYS	Female	0	No	No
6669	2832-KJCRD	Female	0	No	No
6670	3588-WSTTJ	Female	1	No	No
6671	4075-WKNIU	Female	0	Yes	Yes
6672	5090-EMGTC	Female	0	Yes	No
6673	2346-CZYIL	Male	0	No	No
6674	3798-EPWRR	Female	1	No	No
6675	6258-NGCNG	Male	0	No	No
6676	4186-ZBUEW	Female	0	No	No
6677	5274-XHAKY	Female	0	Yes	Yes
6678	1442-BQPVU	Female	0	No	No
6679	3978-YNKDD	Male	0	No	Yes
6680	4940-KHCWD	Female	0	Yes	No
6681	9412-ARGBX	Female	0	No	Yes
6682	1389-CXMLU	Male	1	No	No
6683	9589-ABEPT	Male	0	Yes	No
6684	9388-ZEYVT	Male	0	No	No
6685	0305-SQECB	Female	0	No	Yes
6686	7605-SNLQG	Female	0	Yes	No
6687	4670-TABXH	Male	0	Yes	No
6688	5561-NWEVX	Female	1	Yes	No
6689	0064-SUDOG	Female	0	Yes	Yes
6690	8561-NMTBD	Female	0	Yes	Yes
6691	5161-XEUVX	Male	0	Yes	No
6692	8292-FRFZQ	Female	0	No	No
6693	8591-NXRCV	Female	0	No	No
6694	7895-VONWT	Female	0	No	No
6695	4526-RMTLL	Male	0	Yes	Yes
6696	6253-GNHWH	Female	0	Yes	Yes
6697	4566-NECEV	Male	0	No	No
6698	8080-POTJR	Female	0	No	No
6699	6906-MPARY	Male	0	No	No
6700	3662-FXJFO	Female	0	No	No
6701	8107-RZLNV	Male	0	Yes	No
6702	0516-OOHAR	Male	0	Yes	Yes
6703	2027-CWDNU	Male	0	Yes	Yes
6704	2737-WFVYW	Female	0	No	No
6705	9912-OMZDS	Female	0	Yes	Yes
6706	3733-ZEECP	Male	0	Yes	Yes
6707	7878-RTCZG	Female	0	No	No
6708	2452-MRMZF	Female	1	Yes	No
6709	2272-QAGFO	Female	1	No	No
6710	7103-IPXPJ	Male	0	Yes	No
6711	4342-HFXWS	Female	0	Yes	Yes
6712	3545-CNWRG	Female	0	Yes	Yes
6713	1785-BPHTP	Male	0	Yes	Yes
6714	4989-LIXVT	Male	1	No	No
6715	7315-WYOAW	Male	0	No	No
6716	1173-XZPYF	Female	0	No	No
6717	9850-OWRHQ	Female	0	Yes	No
6718	3768-NLUBH	Male	1	Yes	No
6719	8676-TRMJS	Male	0	No	No
6720	2509-TFPJU	Male	0	Yes	No
6721	9530-GRMJG	Male	0	Yes	Yes
6722	6898-RBTLU	Female	0	Yes	Yes
6723	5481-NTDOH	Female	1	Yes	No
6724	2068-WWXQZ	Male	0	No	No
6725	7359-SSBJK	Female	1	No	No
6726	2061-VVFST	Female	0	Yes	No
6727	0685-MLYYM	Female	1	No	No
6728	0749-IRGQE	Female	1	Yes	No
6729	2380-DAMQP	Female	0	Yes	No
6730	2256-YLYLP	Male	0	Yes	Yes
6731	1272-ILHFG	Male	0	Yes	Yes
6732	0164-XAIRP	Female	0	No	No
6733	5666-CYCYZ	Female	0	No	No
6734	4011-ARPHK	Male	0	No	No
6735	8182-PNAGI	Male	0	No	No
6736	6365-HITVU	Female	0	Yes	Yes
6737	7558-IMLMT	Male	0	Yes	Yes
6738	9488-FYQAU	Female	0	Yes	No
6739	3590-TCXTB	Male	0	No	No
6740	6994-KERXL	Male	0	No	No
6741	7957-RYHQD	Female	1	No	No
6742	2180-DXNEG	Female	0	No	No
6743	1960-UOTYM	Male	0	Yes	Yes
6744	2740-JFBOK	Male	0	No	No
6745	6500-JVEGC	Male	0	No	No
6746	5515-AKOAJ	Female	0	No	No
6747	8976-OQHGT	Female	0	Yes	Yes
6748	5245-VDBUR	Female	0	Yes	No
6749	6230-BSUXY	Female	1	No	No
6750	8469-SNFFH	Male	0	Yes	No
6751	2144-ESWKO	Male	0	No	No
6752	1241-FPMOF	Male	0	No	No
6753	9928-BZVLZ	Female	0	No	No
6754	4114-QMKVN	Female	0	Yes	Yes
6755	2775-SEFEE	Male	0	No	Yes
6756	9003-CPATH	Male	0	No	No
6757	1754-GKYPY	Male	1	Yes	No
6758	5294-CDGWY	Male	0	Yes	Yes
6759	7956-XQWGU	Male	0	No	No
6760	1591-MQJTP	Male	1	Yes	No
6761	5295-PCJOO	Male	0	No	Yes
6762	2369-FEVNO	Male	0	No	No
6763	9863-JZAIC	Male	0	No	No
6764	7471-MQPOS	Male	1	Yes	Yes
6765	7660-HDPJV	Female	0	No	No
6766	5115-SQAAU	Female	0	Yes	Yes
6767	9845-QOMAD	Male	0	Yes	Yes
6768	7672-VFMXZ	Male	0	Yes	No
6769	9739-JLPQJ	Female	0	Yes	Yes
6770	9916-AYHTC	Male	0	No	No
6771	3855-ONCAR	Female	0	Yes	Yes
6772	1488-SYSFC	Male	0	Yes	Yes
6773	7931-PXHFC	Male	0	No	No
6774	3990-QYKBE	Male	1	Yes	No
6775	0970-QXPXW	Female	0	No	No
6776	3259-KNMRR	Male	1	No	No
6777	6120-RJKLU	Female	1	Yes	No
6778	9572-WUKSB	Male	0	Yes	No
6779	5893-KCLGT	Female	0	No	Yes
6780	0076-LVEPS	Male	0	No	Yes
6781	3640-JQGJG	Male	0	Yes	Yes
6782	4919-MOAVT	Male	0	No	Yes
6783	1596-OQSPS	Female	0	No	No
6784	9867-XOBQA	Female	0	No	Yes
6785	9546-KDTRB	Female	0	No	No
6786	3090-HAWSU	Male	0	No	No
6787	9820-RMCQV	Female	0	No	No
6788	3174-RKMOW	Male	0	Yes	Yes
6789	1760-CAZHT	Male	0	No	Yes
6790	7839-QRKXN	Female	0	No	No
6791	8441-SHIPE	Female	0	No	No
6792	5204-QZXPU	Male	0	No	No
6793	4597-ELFTS	Male	0	No	No
6794	1320-GVNHT	Male	0	Yes	Yes
6795	1047-RNXZV	Male	0	No	No
6796	3541-ZNUHK	Female	0	Yes	Yes
6797	8450-JOVAH	Male	0	Yes	Yes
6798	8725-JEDFD	Male	0	No	No
6799	7562-UXTPG	Female	0	No	No
6800	8071-SBTRN	Female	0	No	No
6801	1113-IUJYX	Female	0	Yes	No
6802	6668-CNMFP	Female	0	Yes	Yes
6803	5626-MGTUK	Female	0	No	No
6804	5681-LLOEI	Male	0	Yes	Yes
6805	8212-DJRCH	Male	0	Yes	Yes
6806	4323-OHFOW	Female	1	Yes	No
6807	4933-BSAIP	Female	0	Yes	No
6808	2030-BTZRO	Male	0	Yes	Yes
6809	1116-DXXDF	Male	0	No	No
6810	9274-CNFMO	Male	1	Yes	No
6811	7758-XKCBS	Male	0	No	No
6812	8992-JQYUN	Male	0	Yes	No
6813	6563-VNPMN	Female	1	No	No
6814	0617-AQNWT	Female	0	Yes	No
6815	2267-WTPYD	Female	1	Yes	No
6816	0270-THENM	Male	0	Yes	Yes
6817	2446-PLQVO	Male	0	No	No
6818	4707-MAXGU	Male	0	Yes	No
6819	2710-WYVXG	Female	0	No	No
6820	3005-NFMTA	Male	1	No	No
6821	6300-BWMJX	Female	0	Yes	No
6822	8784-CGILN	Female	0	No	No
6823	5389-FFVKB	Male	1	Yes	No
6824	7009-LGECI	Female	0	No	No
6825	8444-WRIDW	Female	1	No	No
6826	5022-KVDQT	Male	0	No	No
6827	7976-CICYS	Male	0	No	No
6828	1036-GUDCL	Male	0	Yes	Yes
6829	2005-DWQZJ	Female	0	Yes	Yes
6830	8148-WOCMK	Male	0	Yes	Yes
6831	7815-PDTHL	Male	0	No	No
6832	9451-LPGOO	Male	0	No	No
6833	9173-IVZVP	Female	0	Yes	Yes
6834	9129-UXERG	Female	1	No	No
6835	3635-JBPSG	Female	0	No	No
6836	7964-ZRKKG	Male	0	Yes	No
6837	5868-YWPDW	Male	1	Yes	No
6838	6229-LSCKB	Male	1	No	No
6839	2025-JKFWI	Male	0	No	No
6840	4078-SAYYN	Female	0	No	No
6841	1724-IQWNM	Male	0	No	Yes
6842	8217-QYOHV	Male	0	No	No
6843	5546-QUERU	Male	0	No	No
6844	9940-HPQPG	Female	0	Yes	No
6845	6897-UUBNU	Male	0	No	No
6846	6127-IYJOZ	Male	1	No	No
6847	6618-RYATB	Female	0	No	No
6848	8930-XOTDP	Female	0	Yes	Yes
6849	5916-QEWPT	Female	0	Yes	No
6850	5060-TQUQN	Male	0	Yes	Yes
6851	0531-XBKMM	Male	0	No	Yes
6852	8465-SBRXP	Male	0	Yes	Yes
6853	2408-PSJVE	Male	0	Yes	Yes
6854	9079-YEXQJ	Female	0	No	No
6855	9700-ZCLOT	Male	0	No	No
6856	8738-JOKAR	Female	0	No	No
6857	4534-WGCIR	Female	0	Yes	Yes
6858	1930-WNXSB	Male	0	Yes	Yes
6859	2685-SREOM	Female	0	Yes	Yes
6860	3508-CFVZL	Female	0	No	No
6861	0402-CQAJN	Female	0	No	No
6862	6692-UDPJC	Female	0	Yes	Yes
6863	1273-MTETI	Female	1	No	No
6864	0657-DOGUM	Female	0	Yes	No
6865	5480-HPRRX	Female	1	No	No
6866	8792-AOROI	Female	0	Yes	No
6867	0295-PPHDO	Male	0	No	No
6868	5146-YYFRZ	Male	0	No	No
6869	1195-OIYEJ	Male	0	No	No
6870	5906-CVLHP	Female	0	Yes	Yes
6871	3452-SRFEG	Male	0	No	No
6872	4070-OKWVH	Female	0	Yes	No
6873	5297-MDOIR	Female	0	Yes	No
6874	6369-MCAKO	Female	0	Yes	Yes
6875	4926-UMJZD	Female	0	Yes	No
6876	6848-HJTXY	Female	0	Yes	No
6877	6341-AEVKX	Female	0	Yes	No
6878	4501-EQDRN	Female	0	No	No
6879	2990-HWIML	Female	0	No	No
6880	0682-USIXD	Female	0	Yes	No
6881	6976-BWGLQ	Female	0	Yes	Yes
6882	7078-NVFAM	Female	0	Yes	Yes
6883	8065-QBYTO	Female	1	No	No
6884	2133-TSRRM	Female	0	No	Yes
6885	7384-GHBPI	Male	0	Yes	No
6886	7603-USHJS	Male	0	No	Yes
6887	7234-FECYN	Female	1	No	No
6888	2511-ALLCS	Female	0	Yes	Yes
6889	3191-CSNMG	Female	0	Yes	Yes
6890	7952-OBOYL	Male	0	No	No
6891	7470-DYNOE	Male	0	No	No
6892	7853-OETYL	Female	0	Yes	No
6893	1545-ACTAS	Female	0	Yes	Yes
6894	5876-HZVZM	Female	0	Yes	Yes
6895	1400-MMYXY	Male	1	Yes	No
6896	5126-RCXYW	Male	0	Yes	Yes
6897	3085-QUOZK	Female	0	No	No
6898	2363-BJLSL	Male	0	No	No
6899	1956-YIFGE	Male	0	Yes	Yes
6900	3926-CUQZX	Male	0	No	No
6901	7921-LMDFQ	Male	1	No	No
6902	2925-MXLSX	Female	0	No	No
6903	5820-PTRYM	Female	1	Yes	No
6904	9609-BENEA	Male	0	Yes	No
6905	6211-WHMYA	Female	1	No	No
6906	4459-BBGHE	Male	0	No	Yes
6907	9945-PSVIP	Female	0	Yes	Yes
6908	1041-RXHRA	Female	0	No	No
6909	1750-CSKKM	Male	0	No	Yes
6910	9108-EJFJP	Female	0	Yes	No
6911	0530-IJVDB	Male	0	No	Yes
6912	0508-SQWPL	Female	0	Yes	Yes
6913	2215-ZAFGX	Male	0	No	No
6914	8213-TAZPM	Female	0	Yes	Yes
6915	7142-HVGBG	Male	1	Yes	No
6916	1304-SEGFY	Female	0	Yes	No
6917	7242-EDTYC	Male	0	No	Yes
6918	2904-GGUAZ	Female	0	Yes	No
6919	8267-ZNYVZ	Female	0	Yes	No
6920	5136-GFPMB	Male	0	No	No
6921	2595-KIWPV	Male	0	No	Yes
6922	5243-SAOTC	Male	0	No	No
6923	9398-MMQTO	Male	0	No	No
6924	7619-PLRLP	Female	0	Yes	No
6925	6457-GIRWB	Male	0	No	No
6926	6508-NJYRO	Male	0	Yes	No
6927	1450-SKCVI	Female	0	No	No
6928	4710-NKCAW	Male	0	Yes	Yes
6929	5306-BVTKJ	Male	0	Yes	Yes
6930	0357-NVCRI	Female	0	No	Yes
6931	5570-PTWEH	Female	0	Yes	No
6932	2371-KFUOG	Male	0	No	No
6933	0463-ZSDNT	Male	0	No	No
6934	6502-MJQAE	Male	0	No	No
6935	6257-DTAYD	Male	0	Yes	No
6936	4616-ULAOA	Female	0	Yes	Yes
6937	7693-LCKZL	Male	0	Yes	Yes
6938	7746-AWNQW	Female	0	No	No
6939	5996-EBTKM	Female	0	Yes	Yes
6940	2758-RNWXS	Male	0	No	No
6941	2314-TNDJQ	Female	0	Yes	Yes
6942	2405-LBMUW	Female	0	Yes	Yes
6943	3454-JFUBC	Male	1	No	No
6944	0032-PGELS	Female	0	Yes	Yes
6945	9039-ZVJDC	Male	0	No	No
6946	6797-LNAQX	Male	0	Yes	Yes
6947	9013-AQORL	Female	0	No	Yes
6948	2898-MRKPI	Male	0	Yes	Yes
6949	2750-BJLSB	Female	0	No	No
6950	3648-GZPHF	Male	0	Yes	Yes
6951	2075-RMJIK	Female	0	Yes	Yes
6952	9588-YRFHY	Male	0	No	No
6953	6394-MFYNG	Female	0	No	No
6954	1564-NTYXF	Female	1	No	No
6955	9364-YKUVW	Male	0	No	No
6956	5392-AKEMH	Female	0	No	No
6957	2451-YMUXS	Male	1	No	No
6958	3914-FDRHP	Male	0	No	No
6959	3078-ZKNTS	Female	0	Yes	Yes
6960	1024-KPRBB	Female	0	No	No
6961	4690-PKDQG	Female	1	Yes	No
6962	8155-IBNHG	Female	0	Yes	No
6963	0886-QGENL	Female	1	Yes	No
6964	9547-ITEFG	Male	0	Yes	Yes
6965	1264-FUHCX	Female	0	Yes	No
6966	7789-CRUVC	Female	1	Yes	No
6967	6598-KELSS	Male	0	No	Yes
6968	8739-WWKDU	Male	1	No	No
6969	8685-WHQPW	Female	1	No	No
6970	4745-LSPLO	Male	0	No	No
6971	8083-YTZES	Male	0	No	No
6972	7240-FQLHE	Female	1	Yes	No
6973	6664-FPDAC	Female	1	No	No
6974	9972-VAFJJ	Female	1	Yes	No
6975	0422-UXFAP	Female	0	Yes	No
6976	1904-WAJAA	Female	0	Yes	Yes
6977	5130-YPIRV	Female	0	Yes	No
6978	2843-CQMEG	Male	0	No	No
6979	6439-PKTRR	Female	0	Yes	Yes
6980	5351-QESIO	Male	0	No	Yes
6981	0786-VSSUD	Male	1	No	No
6982	5568-DMXZS	Female	0	No	No
6983	8468-FZTOE	Female	0	Yes	Yes
6984	6633-SYEUS	Female	0	No	No
6985	6447-GORXK	Male	0	No	Yes
6986	6967-PEJLL	Male	0	Yes	Yes
6987	3976-BWUCK	Female	0	Yes	No
6988	5981-ZVXOT	Female	1	No	No
6989	1684-FLBGS	Female	0	Yes	Yes
6990	1389-WNUIB	Female	0	Yes	Yes
6991	0376-OIWME	Male	0	Yes	No
6992	3585-ISXZP	Female	0	No	No
6993	0218-QNVAS	Male	0	Yes	Yes
6994	6583-QGCSI	Female	1	Yes	No
6995	0804-YGEQV	Female	0	Yes	Yes
6996	7164-BPTUT	Male	0	No	Yes
6997	4174-LPGTI	Female	0	Yes	Yes
6998	2523-EWWZL	Female	0	Yes	No
6999	0928-XUTSN	Female	0	No	No
7000	2108-XWMPY	Male	0	No	No
7001	0052-YNYOT	Female	0	No	No
7002	6304-IJFSQ	Male	0	No	No
7003	9586-JGQKH	Female	0	Yes	No
7004	4501-VCPFK	Male	0	No	No
7005	6075-SLNIL	Male	0	No	No
7006	9347-AERRL	Male	0	Yes	No
7007	0093-XWZFY	Male	0	No	No
7008	2274-XUATA	Male	1	Yes	No
7009	1980-KXVPM	Female	1	No	No
7010	7703-ZEKEF	Male	0	No	No
7011	0723-DRCLG	Female	1	Yes	No
7012	5482-NUPNA	Female	0	No	No
7013	6691-CCIHA	Female	0	Yes	No
7014	1685-BQULA	Female	0	No	No
7015	9053-EJUNL	Male	0	No	No
7016	0666-UXTJO	Male	1	Yes	No
7017	1471-GIQKQ	Female	0	No	No
7018	4807-IZYOZ	Female	0	No	No
7019	1122-JWTJW	Male	0	Yes	Yes
7020	9710-NJERN	Female	0	No	No
7021	9837-FWLCH	Male	0	Yes	Yes
7022	1699-HPSBG	Male	0	No	No
7023	7203-OYKCT	Male	0	No	No
7024	1035-IPQPU	Female	1	Yes	No
7025	7398-LXGYX	Male	0	Yes	No
7026	2823-LKABH	Female	0	No	No
7027	8775-CEBBJ	Female	0	No	No
7028	0550-DCXLH	Male	0	No	No
7029	9281-CEDRU	Female	0	Yes	No
7030	2235-DWLJU	Female	1	No	No
7031	0871-OPBXW	Female	0	No	No
7032	3605-JISKB	Male	1	Yes	No
7033	6894-LFHLY	Male	1	No	No
7034	9767-FFLEM	Male	0	No	No
7035	0639-TSIQW	Female	0	No	No
7036	8456-QDAVC	Male	0	No	No
7037	7750-EYXWZ	Female	0	No	No
7038	2569-WGERO	Female	0	No	No
7039	6840-RESVB	Male	0	Yes	Yes
7040	2234-XADUH	Female	0	Yes	Yes
7041	4801-JZAZL	Female	0	Yes	Yes
7042	8361-LTMKD	Male	1	Yes	No
7043	3186-AJIEK	Male	0	No	No
\.


--
-- Data for Name: dim_payment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY legacy.dim_payment (payment_key, payment_method) FROM stdin;
1	Bank transfer (automatic)
2	Credit card (automatic)
3	Electronic check
4	Mailed check
\.


--
-- Data for Name: dim_service; Type: TABLE DATA; Schema: public; Owner: -
--

COPY legacy.dim_service (service_key, phone_service, multiple_lines, internet_service, online_security, online_backup, device_protection, tech_support, streaming_tv, streaming_movies) FROM stdin;
1	No	No phone service	DSL	No	No	No	No	No	No
2	No	No phone service	DSL	No	No	No	No	No	Yes
3	No	No phone service	DSL	No	No	No	No	Yes	No
4	No	No phone service	DSL	No	No	No	No	Yes	Yes
5	No	No phone service	DSL	No	No	No	Yes	No	No
6	No	No phone service	DSL	No	No	No	Yes	No	Yes
7	No	No phone service	DSL	No	No	No	Yes	Yes	No
8	No	No phone service	DSL	No	No	No	Yes	Yes	Yes
9	No	No phone service	DSL	No	No	Yes	No	No	No
10	No	No phone service	DSL	No	No	Yes	No	No	Yes
11	No	No phone service	DSL	No	No	Yes	No	Yes	No
12	No	No phone service	DSL	No	No	Yes	No	Yes	Yes
13	No	No phone service	DSL	No	No	Yes	Yes	No	No
14	No	No phone service	DSL	No	No	Yes	Yes	No	Yes
15	No	No phone service	DSL	No	No	Yes	Yes	Yes	No
16	No	No phone service	DSL	No	No	Yes	Yes	Yes	Yes
17	No	No phone service	DSL	No	Yes	No	No	No	No
18	No	No phone service	DSL	No	Yes	No	No	No	Yes
19	No	No phone service	DSL	No	Yes	No	No	Yes	No
20	No	No phone service	DSL	No	Yes	No	No	Yes	Yes
21	No	No phone service	DSL	No	Yes	No	Yes	No	No
22	No	No phone service	DSL	No	Yes	No	Yes	No	Yes
23	No	No phone service	DSL	No	Yes	No	Yes	Yes	No
24	No	No phone service	DSL	No	Yes	No	Yes	Yes	Yes
25	No	No phone service	DSL	No	Yes	Yes	No	No	No
26	No	No phone service	DSL	No	Yes	Yes	No	No	Yes
27	No	No phone service	DSL	No	Yes	Yes	No	Yes	No
28	No	No phone service	DSL	No	Yes	Yes	No	Yes	Yes
29	No	No phone service	DSL	No	Yes	Yes	Yes	No	No
30	No	No phone service	DSL	No	Yes	Yes	Yes	No	Yes
31	No	No phone service	DSL	No	Yes	Yes	Yes	Yes	No
32	No	No phone service	DSL	No	Yes	Yes	Yes	Yes	Yes
33	No	No phone service	DSL	Yes	No	No	No	No	No
34	No	No phone service	DSL	Yes	No	No	No	No	Yes
35	No	No phone service	DSL	Yes	No	No	No	Yes	No
36	No	No phone service	DSL	Yes	No	No	No	Yes	Yes
37	No	No phone service	DSL	Yes	No	No	Yes	No	No
38	No	No phone service	DSL	Yes	No	No	Yes	No	Yes
39	No	No phone service	DSL	Yes	No	No	Yes	Yes	No
40	No	No phone service	DSL	Yes	No	No	Yes	Yes	Yes
41	No	No phone service	DSL	Yes	No	Yes	No	No	No
42	No	No phone service	DSL	Yes	No	Yes	No	No	Yes
43	No	No phone service	DSL	Yes	No	Yes	No	Yes	No
44	No	No phone service	DSL	Yes	No	Yes	No	Yes	Yes
45	No	No phone service	DSL	Yes	No	Yes	Yes	No	No
46	No	No phone service	DSL	Yes	No	Yes	Yes	No	Yes
47	No	No phone service	DSL	Yes	No	Yes	Yes	Yes	No
48	No	No phone service	DSL	Yes	No	Yes	Yes	Yes	Yes
49	No	No phone service	DSL	Yes	Yes	No	No	No	No
50	No	No phone service	DSL	Yes	Yes	No	No	No	Yes
51	No	No phone service	DSL	Yes	Yes	No	No	Yes	No
52	No	No phone service	DSL	Yes	Yes	No	No	Yes	Yes
53	No	No phone service	DSL	Yes	Yes	No	Yes	No	No
54	No	No phone service	DSL	Yes	Yes	No	Yes	No	Yes
55	No	No phone service	DSL	Yes	Yes	No	Yes	Yes	No
56	No	No phone service	DSL	Yes	Yes	No	Yes	Yes	Yes
57	No	No phone service	DSL	Yes	Yes	Yes	No	No	No
58	No	No phone service	DSL	Yes	Yes	Yes	No	No	Yes
59	No	No phone service	DSL	Yes	Yes	Yes	No	Yes	No
60	No	No phone service	DSL	Yes	Yes	Yes	No	Yes	Yes
61	No	No phone service	DSL	Yes	Yes	Yes	Yes	No	No
62	No	No phone service	DSL	Yes	Yes	Yes	Yes	No	Yes
63	No	No phone service	DSL	Yes	Yes	Yes	Yes	Yes	No
64	No	No phone service	DSL	Yes	Yes	Yes	Yes	Yes	Yes
65	Yes	No	DSL	No	No	No	No	No	No
66	Yes	No	DSL	No	No	No	No	No	Yes
67	Yes	No	DSL	No	No	No	No	Yes	No
68	Yes	No	DSL	No	No	No	No	Yes	Yes
69	Yes	No	DSL	No	No	No	Yes	No	No
70	Yes	No	DSL	No	No	No	Yes	No	Yes
71	Yes	No	DSL	No	No	No	Yes	Yes	No
72	Yes	No	DSL	No	No	No	Yes	Yes	Yes
73	Yes	No	DSL	No	No	Yes	No	No	No
74	Yes	No	DSL	No	No	Yes	No	No	Yes
75	Yes	No	DSL	No	No	Yes	No	Yes	No
76	Yes	No	DSL	No	No	Yes	No	Yes	Yes
77	Yes	No	DSL	No	No	Yes	Yes	No	No
78	Yes	No	DSL	No	No	Yes	Yes	No	Yes
79	Yes	No	DSL	No	No	Yes	Yes	Yes	No
80	Yes	No	DSL	No	No	Yes	Yes	Yes	Yes
81	Yes	No	DSL	No	Yes	No	No	No	No
82	Yes	No	DSL	No	Yes	No	No	No	Yes
83	Yes	No	DSL	No	Yes	No	No	Yes	No
84	Yes	No	DSL	No	Yes	No	No	Yes	Yes
85	Yes	No	DSL	No	Yes	No	Yes	No	No
86	Yes	No	DSL	No	Yes	No	Yes	No	Yes
87	Yes	No	DSL	No	Yes	No	Yes	Yes	No
88	Yes	No	DSL	No	Yes	No	Yes	Yes	Yes
89	Yes	No	DSL	No	Yes	Yes	No	No	No
90	Yes	No	DSL	No	Yes	Yes	No	No	Yes
91	Yes	No	DSL	No	Yes	Yes	No	Yes	No
92	Yes	No	DSL	No	Yes	Yes	No	Yes	Yes
93	Yes	No	DSL	No	Yes	Yes	Yes	No	No
94	Yes	No	DSL	No	Yes	Yes	Yes	No	Yes
95	Yes	No	DSL	No	Yes	Yes	Yes	Yes	No
96	Yes	No	DSL	No	Yes	Yes	Yes	Yes	Yes
97	Yes	No	DSL	Yes	No	No	No	No	No
98	Yes	No	DSL	Yes	No	No	No	No	Yes
99	Yes	No	DSL	Yes	No	No	No	Yes	No
100	Yes	No	DSL	Yes	No	No	No	Yes	Yes
101	Yes	No	DSL	Yes	No	No	Yes	No	No
102	Yes	No	DSL	Yes	No	No	Yes	No	Yes
103	Yes	No	DSL	Yes	No	No	Yes	Yes	No
104	Yes	No	DSL	Yes	No	No	Yes	Yes	Yes
105	Yes	No	DSL	Yes	No	Yes	No	No	No
106	Yes	No	DSL	Yes	No	Yes	No	No	Yes
107	Yes	No	DSL	Yes	No	Yes	No	Yes	No
108	Yes	No	DSL	Yes	No	Yes	No	Yes	Yes
109	Yes	No	DSL	Yes	No	Yes	Yes	No	No
110	Yes	No	DSL	Yes	No	Yes	Yes	No	Yes
111	Yes	No	DSL	Yes	No	Yes	Yes	Yes	No
112	Yes	No	DSL	Yes	No	Yes	Yes	Yes	Yes
113	Yes	No	DSL	Yes	Yes	No	No	No	No
114	Yes	No	DSL	Yes	Yes	No	No	No	Yes
115	Yes	No	DSL	Yes	Yes	No	No	Yes	No
116	Yes	No	DSL	Yes	Yes	No	No	Yes	Yes
117	Yes	No	DSL	Yes	Yes	No	Yes	No	No
118	Yes	No	DSL	Yes	Yes	No	Yes	No	Yes
119	Yes	No	DSL	Yes	Yes	No	Yes	Yes	No
120	Yes	No	DSL	Yes	Yes	No	Yes	Yes	Yes
121	Yes	No	DSL	Yes	Yes	Yes	No	No	No
122	Yes	No	DSL	Yes	Yes	Yes	No	No	Yes
123	Yes	No	DSL	Yes	Yes	Yes	No	Yes	No
124	Yes	No	DSL	Yes	Yes	Yes	No	Yes	Yes
125	Yes	No	DSL	Yes	Yes	Yes	Yes	No	No
126	Yes	No	DSL	Yes	Yes	Yes	Yes	No	Yes
127	Yes	No	DSL	Yes	Yes	Yes	Yes	Yes	No
128	Yes	No	DSL	Yes	Yes	Yes	Yes	Yes	Yes
129	Yes	No	Fiber optic	No	No	No	No	No	No
130	Yes	No	Fiber optic	No	No	No	No	No	Yes
131	Yes	No	Fiber optic	No	No	No	No	Yes	No
132	Yes	No	Fiber optic	No	No	No	No	Yes	Yes
133	Yes	No	Fiber optic	No	No	No	Yes	No	No
134	Yes	No	Fiber optic	No	No	No	Yes	No	Yes
135	Yes	No	Fiber optic	No	No	No	Yes	Yes	No
136	Yes	No	Fiber optic	No	No	No	Yes	Yes	Yes
137	Yes	No	Fiber optic	No	No	Yes	No	No	No
138	Yes	No	Fiber optic	No	No	Yes	No	No	Yes
139	Yes	No	Fiber optic	No	No	Yes	No	Yes	No
140	Yes	No	Fiber optic	No	No	Yes	No	Yes	Yes
141	Yes	No	Fiber optic	No	No	Yes	Yes	No	No
142	Yes	No	Fiber optic	No	No	Yes	Yes	No	Yes
143	Yes	No	Fiber optic	No	No	Yes	Yes	Yes	No
144	Yes	No	Fiber optic	No	No	Yes	Yes	Yes	Yes
145	Yes	No	Fiber optic	No	Yes	No	No	No	No
146	Yes	No	Fiber optic	No	Yes	No	No	No	Yes
147	Yes	No	Fiber optic	No	Yes	No	No	Yes	No
148	Yes	No	Fiber optic	No	Yes	No	No	Yes	Yes
149	Yes	No	Fiber optic	No	Yes	No	Yes	No	No
150	Yes	No	Fiber optic	No	Yes	No	Yes	No	Yes
151	Yes	No	Fiber optic	No	Yes	No	Yes	Yes	No
152	Yes	No	Fiber optic	No	Yes	No	Yes	Yes	Yes
153	Yes	No	Fiber optic	No	Yes	Yes	No	No	No
154	Yes	No	Fiber optic	No	Yes	Yes	No	No	Yes
155	Yes	No	Fiber optic	No	Yes	Yes	No	Yes	No
156	Yes	No	Fiber optic	No	Yes	Yes	No	Yes	Yes
157	Yes	No	Fiber optic	No	Yes	Yes	Yes	No	No
158	Yes	No	Fiber optic	No	Yes	Yes	Yes	No	Yes
159	Yes	No	Fiber optic	No	Yes	Yes	Yes	Yes	No
160	Yes	No	Fiber optic	No	Yes	Yes	Yes	Yes	Yes
161	Yes	No	Fiber optic	Yes	No	No	No	No	No
162	Yes	No	Fiber optic	Yes	No	No	No	No	Yes
163	Yes	No	Fiber optic	Yes	No	No	No	Yes	No
164	Yes	No	Fiber optic	Yes	No	No	No	Yes	Yes
165	Yes	No	Fiber optic	Yes	No	No	Yes	No	No
166	Yes	No	Fiber optic	Yes	No	No	Yes	No	Yes
167	Yes	No	Fiber optic	Yes	No	No	Yes	Yes	No
168	Yes	No	Fiber optic	Yes	No	No	Yes	Yes	Yes
169	Yes	No	Fiber optic	Yes	No	Yes	No	No	No
170	Yes	No	Fiber optic	Yes	No	Yes	No	No	Yes
171	Yes	No	Fiber optic	Yes	No	Yes	No	Yes	No
172	Yes	No	Fiber optic	Yes	No	Yes	No	Yes	Yes
173	Yes	No	Fiber optic	Yes	No	Yes	Yes	No	No
174	Yes	No	Fiber optic	Yes	No	Yes	Yes	No	Yes
175	Yes	No	Fiber optic	Yes	No	Yes	Yes	Yes	No
176	Yes	No	Fiber optic	Yes	No	Yes	Yes	Yes	Yes
177	Yes	No	Fiber optic	Yes	Yes	No	No	No	No
178	Yes	No	Fiber optic	Yes	Yes	No	No	No	Yes
179	Yes	No	Fiber optic	Yes	Yes	No	No	Yes	No
180	Yes	No	Fiber optic	Yes	Yes	No	No	Yes	Yes
181	Yes	No	Fiber optic	Yes	Yes	No	Yes	No	No
182	Yes	No	Fiber optic	Yes	Yes	No	Yes	No	Yes
183	Yes	No	Fiber optic	Yes	Yes	No	Yes	Yes	No
184	Yes	No	Fiber optic	Yes	Yes	No	Yes	Yes	Yes
185	Yes	No	Fiber optic	Yes	Yes	Yes	No	No	No
186	Yes	No	Fiber optic	Yes	Yes	Yes	No	No	Yes
187	Yes	No	Fiber optic	Yes	Yes	Yes	No	Yes	No
188	Yes	No	Fiber optic	Yes	Yes	Yes	No	Yes	Yes
189	Yes	No	Fiber optic	Yes	Yes	Yes	Yes	No	No
190	Yes	No	Fiber optic	Yes	Yes	Yes	Yes	No	Yes
191	Yes	No	Fiber optic	Yes	Yes	Yes	Yes	Yes	No
192	Yes	No	Fiber optic	Yes	Yes	Yes	Yes	Yes	Yes
193	Yes	No	No	No internet service	No internet service	No internet service	No internet service	No internet service	No internet service
194	Yes	Yes	DSL	No	No	No	No	No	No
195	Yes	Yes	DSL	No	No	No	No	No	Yes
196	Yes	Yes	DSL	No	No	No	No	Yes	No
197	Yes	Yes	DSL	No	No	No	No	Yes	Yes
198	Yes	Yes	DSL	No	No	No	Yes	No	No
199	Yes	Yes	DSL	No	No	No	Yes	No	Yes
200	Yes	Yes	DSL	No	No	No	Yes	Yes	No
201	Yes	Yes	DSL	No	No	No	Yes	Yes	Yes
202	Yes	Yes	DSL	No	No	Yes	No	No	No
203	Yes	Yes	DSL	No	No	Yes	No	No	Yes
204	Yes	Yes	DSL	No	No	Yes	No	Yes	No
205	Yes	Yes	DSL	No	No	Yes	No	Yes	Yes
206	Yes	Yes	DSL	No	No	Yes	Yes	No	No
207	Yes	Yes	DSL	No	No	Yes	Yes	No	Yes
208	Yes	Yes	DSL	No	No	Yes	Yes	Yes	No
209	Yes	Yes	DSL	No	No	Yes	Yes	Yes	Yes
210	Yes	Yes	DSL	No	Yes	No	No	No	No
211	Yes	Yes	DSL	No	Yes	No	No	No	Yes
212	Yes	Yes	DSL	No	Yes	No	No	Yes	No
213	Yes	Yes	DSL	No	Yes	No	No	Yes	Yes
214	Yes	Yes	DSL	No	Yes	No	Yes	No	No
215	Yes	Yes	DSL	No	Yes	No	Yes	No	Yes
216	Yes	Yes	DSL	No	Yes	No	Yes	Yes	No
217	Yes	Yes	DSL	No	Yes	No	Yes	Yes	Yes
218	Yes	Yes	DSL	No	Yes	Yes	No	No	No
219	Yes	Yes	DSL	No	Yes	Yes	No	No	Yes
220	Yes	Yes	DSL	No	Yes	Yes	No	Yes	No
221	Yes	Yes	DSL	No	Yes	Yes	No	Yes	Yes
222	Yes	Yes	DSL	No	Yes	Yes	Yes	No	No
223	Yes	Yes	DSL	No	Yes	Yes	Yes	No	Yes
224	Yes	Yes	DSL	No	Yes	Yes	Yes	Yes	No
225	Yes	Yes	DSL	No	Yes	Yes	Yes	Yes	Yes
226	Yes	Yes	DSL	Yes	No	No	No	No	No
227	Yes	Yes	DSL	Yes	No	No	No	No	Yes
228	Yes	Yes	DSL	Yes	No	No	No	Yes	No
229	Yes	Yes	DSL	Yes	No	No	No	Yes	Yes
230	Yes	Yes	DSL	Yes	No	No	Yes	No	No
231	Yes	Yes	DSL	Yes	No	No	Yes	No	Yes
232	Yes	Yes	DSL	Yes	No	No	Yes	Yes	No
233	Yes	Yes	DSL	Yes	No	No	Yes	Yes	Yes
234	Yes	Yes	DSL	Yes	No	Yes	No	No	No
235	Yes	Yes	DSL	Yes	No	Yes	No	No	Yes
236	Yes	Yes	DSL	Yes	No	Yes	No	Yes	No
237	Yes	Yes	DSL	Yes	No	Yes	No	Yes	Yes
238	Yes	Yes	DSL	Yes	No	Yes	Yes	No	No
239	Yes	Yes	DSL	Yes	No	Yes	Yes	No	Yes
240	Yes	Yes	DSL	Yes	No	Yes	Yes	Yes	No
241	Yes	Yes	DSL	Yes	No	Yes	Yes	Yes	Yes
242	Yes	Yes	DSL	Yes	Yes	No	No	No	No
243	Yes	Yes	DSL	Yes	Yes	No	No	No	Yes
244	Yes	Yes	DSL	Yes	Yes	No	No	Yes	No
245	Yes	Yes	DSL	Yes	Yes	No	No	Yes	Yes
246	Yes	Yes	DSL	Yes	Yes	No	Yes	No	No
247	Yes	Yes	DSL	Yes	Yes	No	Yes	No	Yes
248	Yes	Yes	DSL	Yes	Yes	No	Yes	Yes	No
249	Yes	Yes	DSL	Yes	Yes	No	Yes	Yes	Yes
250	Yes	Yes	DSL	Yes	Yes	Yes	No	No	No
251	Yes	Yes	DSL	Yes	Yes	Yes	No	No	Yes
252	Yes	Yes	DSL	Yes	Yes	Yes	No	Yes	No
253	Yes	Yes	DSL	Yes	Yes	Yes	No	Yes	Yes
254	Yes	Yes	DSL	Yes	Yes	Yes	Yes	No	No
255	Yes	Yes	DSL	Yes	Yes	Yes	Yes	No	Yes
256	Yes	Yes	DSL	Yes	Yes	Yes	Yes	Yes	No
257	Yes	Yes	DSL	Yes	Yes	Yes	Yes	Yes	Yes
258	Yes	Yes	Fiber optic	No	No	No	No	No	No
259	Yes	Yes	Fiber optic	No	No	No	No	No	Yes
260	Yes	Yes	Fiber optic	No	No	No	No	Yes	No
261	Yes	Yes	Fiber optic	No	No	No	No	Yes	Yes
262	Yes	Yes	Fiber optic	No	No	No	Yes	No	No
263	Yes	Yes	Fiber optic	No	No	No	Yes	No	Yes
264	Yes	Yes	Fiber optic	No	No	No	Yes	Yes	No
265	Yes	Yes	Fiber optic	No	No	No	Yes	Yes	Yes
266	Yes	Yes	Fiber optic	No	No	Yes	No	No	No
267	Yes	Yes	Fiber optic	No	No	Yes	No	No	Yes
268	Yes	Yes	Fiber optic	No	No	Yes	No	Yes	No
269	Yes	Yes	Fiber optic	No	No	Yes	No	Yes	Yes
270	Yes	Yes	Fiber optic	No	No	Yes	Yes	No	No
271	Yes	Yes	Fiber optic	No	No	Yes	Yes	No	Yes
272	Yes	Yes	Fiber optic	No	No	Yes	Yes	Yes	No
273	Yes	Yes	Fiber optic	No	No	Yes	Yes	Yes	Yes
274	Yes	Yes	Fiber optic	No	Yes	No	No	No	No
275	Yes	Yes	Fiber optic	No	Yes	No	No	No	Yes
276	Yes	Yes	Fiber optic	No	Yes	No	No	Yes	No
277	Yes	Yes	Fiber optic	No	Yes	No	No	Yes	Yes
278	Yes	Yes	Fiber optic	No	Yes	No	Yes	No	No
279	Yes	Yes	Fiber optic	No	Yes	No	Yes	No	Yes
280	Yes	Yes	Fiber optic	No	Yes	No	Yes	Yes	No
281	Yes	Yes	Fiber optic	No	Yes	No	Yes	Yes	Yes
282	Yes	Yes	Fiber optic	No	Yes	Yes	No	No	No
283	Yes	Yes	Fiber optic	No	Yes	Yes	No	No	Yes
284	Yes	Yes	Fiber optic	No	Yes	Yes	No	Yes	No
285	Yes	Yes	Fiber optic	No	Yes	Yes	No	Yes	Yes
286	Yes	Yes	Fiber optic	No	Yes	Yes	Yes	No	No
287	Yes	Yes	Fiber optic	No	Yes	Yes	Yes	No	Yes
288	Yes	Yes	Fiber optic	No	Yes	Yes	Yes	Yes	No
289	Yes	Yes	Fiber optic	No	Yes	Yes	Yes	Yes	Yes
290	Yes	Yes	Fiber optic	Yes	No	No	No	No	No
291	Yes	Yes	Fiber optic	Yes	No	No	No	No	Yes
292	Yes	Yes	Fiber optic	Yes	No	No	No	Yes	No
293	Yes	Yes	Fiber optic	Yes	No	No	No	Yes	Yes
294	Yes	Yes	Fiber optic	Yes	No	No	Yes	No	No
295	Yes	Yes	Fiber optic	Yes	No	No	Yes	No	Yes
296	Yes	Yes	Fiber optic	Yes	No	No	Yes	Yes	No
297	Yes	Yes	Fiber optic	Yes	No	No	Yes	Yes	Yes
298	Yes	Yes	Fiber optic	Yes	No	Yes	No	No	No
299	Yes	Yes	Fiber optic	Yes	No	Yes	No	No	Yes
300	Yes	Yes	Fiber optic	Yes	No	Yes	No	Yes	No
301	Yes	Yes	Fiber optic	Yes	No	Yes	No	Yes	Yes
302	Yes	Yes	Fiber optic	Yes	No	Yes	Yes	No	No
303	Yes	Yes	Fiber optic	Yes	No	Yes	Yes	No	Yes
304	Yes	Yes	Fiber optic	Yes	No	Yes	Yes	Yes	No
305	Yes	Yes	Fiber optic	Yes	No	Yes	Yes	Yes	Yes
306	Yes	Yes	Fiber optic	Yes	Yes	No	No	No	No
307	Yes	Yes	Fiber optic	Yes	Yes	No	No	No	Yes
308	Yes	Yes	Fiber optic	Yes	Yes	No	No	Yes	No
309	Yes	Yes	Fiber optic	Yes	Yes	No	No	Yes	Yes
310	Yes	Yes	Fiber optic	Yes	Yes	No	Yes	No	No
311	Yes	Yes	Fiber optic	Yes	Yes	No	Yes	No	Yes
312	Yes	Yes	Fiber optic	Yes	Yes	No	Yes	Yes	No
313	Yes	Yes	Fiber optic	Yes	Yes	No	Yes	Yes	Yes
314	Yes	Yes	Fiber optic	Yes	Yes	Yes	No	No	No
315	Yes	Yes	Fiber optic	Yes	Yes	Yes	No	No	Yes
316	Yes	Yes	Fiber optic	Yes	Yes	Yes	No	Yes	No
317	Yes	Yes	Fiber optic	Yes	Yes	Yes	No	Yes	Yes
318	Yes	Yes	Fiber optic	Yes	Yes	Yes	Yes	No	No
319	Yes	Yes	Fiber optic	Yes	Yes	Yes	Yes	No	Yes
320	Yes	Yes	Fiber optic	Yes	Yes	Yes	Yes	Yes	No
321	Yes	Yes	Fiber optic	Yes	Yes	Yes	Yes	Yes	Yes
322	Yes	Yes	No	No internet service	No internet service	No internet service	No internet service	No internet service	No internet service
\.


--
-- Data for Name: fact_customer_churn; Type: TABLE DATA; Schema: public; Owner: -
--

COPY legacy.fact_customer_churn (fact_key, customer_key, contract_key, service_key, payment_key, churn_key, tenure, monthly_charges, total_charges) FROM stdin;
1	1	2	17	3	1	1	29.85	29.85
2	2	3	105	4	1	34	56.95	1889.50
3	3	2	113	4	2	2	53.85	108.15
4	4	3	45	1	1	45	42.30	1840.75
5	5	2	129	3	2	2	70.70	151.65
6	6	2	269	3	2	8	99.65	820.50
7	7	2	276	2	1	22	89.10	1949.40
8	8	1	33	4	1	10	29.75	301.90
9	9	2	273	3	2	28	104.80	3046.05
10	10	3	113	1	1	62	56.15	3487.95
11	11	2	97	4	1	13	49.95	587.45
12	12	5	193	2	1	16	18.95	326.80
13	13	3	269	2	1	58	100.35	5681.10
14	14	2	285	1	2	49	103.70	5036.30
15	15	2	176	3	1	25	105.50	2686.05
16	16	5	321	2	1	69	113.25	7895.15
17	17	3	193	4	1	52	20.65	1022.95
18	18	5	301	1	1	71	106.70	7382.25
19	19	1	77	2	2	10	55.20	528.35
20	20	2	154	3	1	21	90.05	1862.90
21	21	2	10	3	2	1	39.65	39.65
22	22	3	193	1	1	12	19.80	202.25
23	23	1	193	4	2	1	20.15	20.15
24	24	6	214	2	1	58	59.90	3505.10
25	25	1	117	2	1	49	59.60	2970.30
26	26	2	113	1	1	30	55.30	1530.60
27	27	2	277	3	2	47	99.35	4749.15
28	28	1	17	3	2	1	30.20	30.20
29	29	6	257	2	1	72	90.25	6369.45
30	30	2	68	4	2	17	64.70	1093.10
31	31	6	318	2	1	71	96.35	6766.95
32	32	2	140	2	1	2	95.50	181.65
33	33	3	125	4	1	27	66.15	1874.45
34	34	1	193	1	1	1	20.20	20.20
35	35	1	65	1	1	1	45.25	45.25
36	36	5	312	1	1	72	99.90	7251.70
37	37	2	129	3	2	5	69.70	316.90
38	38	2	137	2	1	46	74.80	3548.30
39	39	2	285	3	2	34	106.35	3549.25
40	40	2	269	1	2	11	97.85	1105.40
41	41	3	81	4	1	10	49.55	475.70
42	42	6	244	2	1	70	69.20	4872.35
43	43	3	193	4	1	17	20.75	418.25
44	44	6	256	2	1	63	79.85	4861.45
45	45	2	248	3	1	13	76.20	981.45
46	46	2	259	3	1	49	84.50	3906.70
47	47	1	81	4	1	2	49.25	97.00
48	48	2	131	3	2	2	80.65	144.15
49	49	6	233	2	1	52	79.75	4217.80
50	50	6	238	2	1	69	64.15	4254.10
51	51	2	276	3	1	43	90.25	3838.75
52	52	2	180	2	2	15	99.10	1426.40
53	53	2	232	2	1	25	69.50	1752.65
54	54	2	274	2	2	8	80.65	633.30
55	55	4	126	2	1	60	74.85	4456.35
56	56	2	261	3	2	18	95.45	1752.55
57	57	4	293	2	1	63	99.65	6311.20
58	58	4	289	3	1	66	108.45	7076.35
59	59	5	322	2	1	34	24.95	894.30
60	60	6	273	2	1	72	107.50	7853.70
61	61	2	269	3	1	47	100.50	4707.10
62	62	2	276	1	1	60	89.90	5450.70
63	63	5	57	1	1	72	42.10	2962.00
64	64	4	77	2	1	18	54.40	957.10
65	65	1	261	3	2	9	94.40	857.25
66	66	2	88	3	1	3	75.30	244.10
67	67	4	274	3	1	47	78.90	3650.35
68	68	5	96	4	1	31	79.20	2497.20
69	69	5	193	1	1	50	20.15	930.90
70	70	2	169	4	1	10	79.85	887.35
71	71	1	69	4	1	1	49.05	49.05
72	72	4	193	3	1	52	20.40	1090.65
73	73	6	305	1	1	64	111.60	7099.00
74	74	6	322	1	1	62	24.25	1424.60
75	75	2	102	1	1	3	64.50	177.40
76	76	3	317	3	1	56	110.50	6139.50
77	77	3	66	2	1	46	55.65	2688.85
78	78	1	113	4	1	8	54.65	482.25
79	79	2	116	3	1	30	74.75	2111.30
80	80	4	322	2	1	45	25.90	1216.60
81	81	2	131	3	2	1	79.35	79.35
82	82	1	36	3	1	11	50.55	565.35
83	83	2	137	1	2	7	75.15	496.90
84	84	2	160	1	1	42	103.80	4327.50
85	85	6	193	1	1	49	20.15	973.35
86	86	2	277	2	1	9	99.30	918.75
87	87	4	99	1	1	35	62.15	2215.45
88	88	5	193	1	1	48	20.65	1057.00
89	89	6	193	4	1	46	19.95	927.10
90	90	1	3	4	1	29	33.75	1009.25
91	91	1	153	1	1	30	82.05	2570.20
92	92	1	133	3	1	1	74.70	74.70
93	93	6	241	4	1	66	84.00	5714.25
94	94	2	317	2	1	65	111.05	7107.00
95	95	6	285	1	1	72	100.90	7459.05
96	96	2	290	3	2	12	78.95	927.35
97	97	4	246	2	1	71	66.85	4748.70
98	98	1	193	4	2	5	21.05	113.85
99	99	5	193	1	1	52	21.00	1107.20
100	100	2	156	3	2	25	98.50	2514.50
101	101	1	193	4	1	1	20.20	20.20
102	102	1	193	3	1	1	19.45	19.45
103	103	3	272	1	1	38	95.00	3605.60
104	104	3	27	1	1	66	45.55	3027.25
105	105	6	289	1	2	68	110.00	7611.85
106	106	1	1	4	1	5	24.30	100.20
107	107	4	309	3	1	72	104.15	7303.05
108	108	3	33	4	1	32	30.15	927.65
109	109	3	261	4	1	43	94.35	3921.30
110	110	5	193	2	1	72	19.40	1363.25
111	111	2	308	3	2	55	96.75	5238.90
112	112	3	109	2	1	52	57.95	3042.25
113	113	2	155	3	1	43	91.65	3954.10
114	114	2	258	3	2	37	76.50	2868.15
115	115	6	24	3	1	64	54.60	3423.50
116	116	1	179	3	1	3	89.85	248.40
117	117	5	33	1	1	36	31.05	1126.35
118	118	2	293	3	2	10	100.25	1064.65
119	119	5	193	4	1	41	20.65	835.15
120	120	2	278	2	1	27	85.20	2151.60
121	121	4	269	2	1	56	99.80	5515.45
122	122	1	193	4	1	6	20.70	112.75
123	123	2	258	3	2	3	74.40	229.55
124	124	1	97	4	1	7	50.70	350.35
125	125	1	193	4	1	4	20.85	62.90
126	126	6	167	3	1	33	88.95	3027.65
127	127	2	266	3	2	27	78.05	2135.50
128	128	6	322	1	1	72	23.55	1723.95
129	129	1	193	4	1	1	19.75	19.75
130	130	4	52	3	1	71	56.45	3985.35
131	131	2	259	3	1	13	85.95	1215.65
132	132	2	60	2	2	25	58.60	1502.65
133	133	5	69	1	1	67	50.55	3260.10
134	134	2	2	3	2	1	35.45	35.45
135	135	1	65	3	2	2	44.35	81.25
136	136	6	322	2	1	43	25.70	1188.20
137	137	2	161	1	1	23	75.00	1778.50
138	138	5	193	4	1	64	20.20	1277.75
139	139	6	193	4	1	57	19.60	1170.55
140	140	2	129	4	2	1	70.45	70.45
141	141	6	257	2	1	72	88.05	6425.65
142	142	1	231	3	2	8	71.15	563.65
143	143	6	277	1	1	61	101.05	5971.25
144	144	4	306	2	1	64	84.30	5289.05
145	145	5	322	1	1	71	23.95	1756.20
146	146	6	312	2	1	65	99.05	6416.70
147	147	3	193	4	1	3	19.60	61.35
148	148	2	65	3	2	1	45.65	45.65
149	149	3	91	2	1	30	64.50	1929.95
150	150	2	94	4	1	15	69.50	1071.40
151	151	2	72	3	1	8	68.55	564.35
152	152	1	261	4	2	7	95.00	655.50
153	153	4	317	2	1	70	108.15	7930.55
154	154	5	128	3	1	62	86.10	5215.25
155	155	1	193	4	1	6	19.70	113.50
156	156	2	130	1	1	14	80.90	1152.80
157	157	2	260	1	1	22	84.15	1821.95
158	158	3	193	4	1	22	20.15	419.90
159	159	5	107	4	1	16	64.25	1024.00
160	160	5	322	1	1	10	25.70	251.60
161	161	2	113	3	1	13	56.00	764.55
162	162	1	290	3	2	20	82.40	1592.35
163	163	2	129	3	1	2	69.70	135.20
164	164	6	223	1	1	53	73.90	3958.25
165	165	3	193	4	1	11	20.60	233.90
166	166	5	193	4	1	69	19.90	1363.45
167	167	2	129	1	2	4	70.90	273.00
168	168	6	257	1	1	72	89.05	6254.45
169	169	2	26	3	2	58	45.30	2651.20
170	170	1	193	3	1	16	20.40	321.40
171	171	4	173	1	1	43	84.25	3539.25
172	172	2	273	3	2	2	104.40	242.80
173	173	5	96	4	1	14	81.95	1181.75
174	174	4	140	1	2	53	94.85	5000.20
175	175	3	193	1	1	32	20.55	654.55
176	176	1	322	3	1	34	24.70	780.20
177	177	2	258	4	2	15	74.45	1145.70
178	178	1	161	1	2	7	76.45	503.60
179	179	2	285	1	1	15	105.35	1559.25
180	180	4	193	2	1	61	20.55	1252.00
181	181	1	17	1	2	1	29.95	29.95
182	182	1	65	4	1	1	45.30	45.30
183	183	1	259	1	2	8	84.50	662.65
184	184	3	108	2	1	33	74.75	2453.30
185	185	2	153	3	2	13	79.25	1111.65
186	186	2	1	3	2	1	24.80	24.80
187	187	2	81	4	1	20	51.80	1023.85
188	188	1	5	3	1	3	30.40	82.15
189	189	3	193	3	1	13	19.65	244.80
190	190	1	210	2	1	40	56.60	2379.10
191	191	4	231	2	1	43	71.90	3173.35
192	192	2	154	3	2	6	91.00	531.00
193	193	5	193	1	1	69	19.75	1375.40
194	194	5	317	2	1	72	109.70	8129.30
195	195	5	193	2	1	59	19.30	1192.70
196	196	2	183	3	1	20	96.55	1901.65
197	197	6	322	1	1	24	24.10	587.40
198	198	2	289	3	1	59	111.35	6519.75
199	199	6	289	1	1	72	112.25	8041.65
200	200	1	193	4	1	1	20.75	20.75
201	201	4	168	2	1	27	101.90	2681.15
202	202	2	149	2	1	14	80.05	1112.30
203	203	5	301	3	1	71	105.55	7405.50
204	204	2	131	2	1	13	78.30	1033.95
205	205	1	129	2	1	44	68.85	2958.95
206	206	4	149	1	1	33	79.95	2684.85
207	207	6	62	2	1	72	55.45	4179.20
208	208	1	130	3	2	1	79.90	79.90
209	209	2	176	3	2	19	106.60	1934.45
210	210	4	160	2	1	64	102.45	6654.10
211	211	2	65	2	2	2	46.00	84.50
212	212	1	1	3	1	1	25.25	25.25
213	213	5	193	4	1	61	19.75	1124.20
214	214	3	193	3	1	29	20.00	540.05
215	215	1	259	3	1	23	86.80	1975.85
216	216	2	60	1	1	57	58.75	3437.45
217	217	5	61	2	1	72	45.25	3139.80
218	218	6	63	1	1	66	56.60	3789.20
219	219	6	225	1	1	65	84.20	5324.50
220	220	2	131	1	1	8	80.00	624.60
221	221	2	129	3	2	4	70.15	268.35
222	222	5	322	1	1	71	24.75	1836.90
223	223	4	193	3	1	1	20.20	20.20
224	224	1	69	4	2	4	50.05	179.35
225	225	4	193	1	1	12	19.35	219.35
226	226	4	36	4	1	24	50.60	1288.75
227	227	4	112	4	1	31	81.15	2545.75
228	228	1	67	4	2	1	55.20	55.20
229	229	2	263	2	1	30	89.90	2723.15
230	230	6	249	2	1	47	85.30	4107.25
231	231	6	313	2	1	54	108.00	5760.65
232	232	2	182	2	1	50	93.50	4747.50
233	233	2	162	4	2	1	84.60	84.60
234	234	5	193	2	1	72	20.25	1566.90
235	235	1	322	3	1	29	25.15	702.00
236	236	2	210	4	2	2	54.40	114.10
237	237	6	5	4	1	10	29.60	299.05
238	238	2	258	3	1	18	73.15	1305.95
239	239	2	148	3	2	11	95.00	1120.30
240	240	5	193	4	1	16	19.75	284.35
241	241	5	225	1	1	72	86.60	6350.50
242	242	5	289	1	1	72	109.20	7878.30
243	243	4	104	2	1	41	74.70	3187.65
244	244	1	186	3	1	65	94.40	6126.15
245	245	2	89	3	1	13	54.80	731.30
246	246	1	161	3	1	4	75.35	273.40
247	247	3	203	4	1	41	65.00	2531.80
248	248	2	145	3	2	15	74.40	1074.30
249	249	2	97	4	2	1	48.55	48.55
250	250	4	315	3	1	42	99.00	4298.45
251	251	4	187	3	1	51	93.50	4619.55
252	252	1	129	3	2	2	70.40	147.15
253	253	1	19	3	2	1	40.20	40.20
254	254	3	225	2	1	32	83.70	2633.30
255	255	2	193	4	1	10	19.85	193.05
256	256	6	32	3	1	67	59.55	4103.90
257	257	5	321	2	1	61	115.10	7008.15
258	258	3	321	2	1	50	114.35	5791.10
259	259	2	65	2	2	2	44.60	80.55
260	260	2	42	3	1	29	45.00	1228.65
261	261	2	10	3	2	3	41.15	132.20
262	262	2	285	3	2	13	106.90	1364.30
263	263	2	275	3	1	57	89.85	4925.35
264	264	6	54	1	1	31	49.85	1520.10
265	265	3	321	4	1	45	113.30	5032.25
266	266	5	257	4	1	61	88.10	5526.75
267	267	5	322	1	1	50	24.90	1195.25
268	268	2	184	4	1	19	105.00	2007.25
269	269	5	193	4	2	59	19.35	1099.60
270	270	6	322	2	1	71	24.25	1732.95
271	271	2	136	3	2	16	94.45	1511.20
272	272	6	117	3	1	57	59.75	3450.15
273	273	1	1	1	2	1	24.80	24.80
274	274	1	281	3	1	20	107.05	2172.05
275	275	1	129	4	2	1	70.60	70.60
276	276	2	278	3	2	5	85.40	401.10
277	277	2	285	3	2	52	105.05	5624.85
278	278	2	114	1	1	21	64.95	1339.80
279	279	2	16	3	1	14	55.00	771.95
280	280	1	81	1	1	5	50.55	244.75
281	281	1	113	4	1	6	55.15	322.90
282	282	1	81	3	1	10	51.20	498.25
283	283	1	322	4	1	1	25.40	25.40
284	284	1	226	4	1	68	54.45	3687.75
285	285	1	140	4	2	18	95.15	1779.95
286	286	4	258	2	1	22	76.00	1783.60
287	287	2	65	3	1	20	44.35	927.15
288	288	1	129	3	2	1	70.00	70.00
289	289	2	145	3	2	8	74.50	606.55
290	290	2	65	2	2	10	44.85	435.40
291	291	2	258	3	2	24	76.10	1712.70
292	292	3	121	4	1	35	61.20	2021.20
293	293	3	157	4	1	23	86.80	1940.80
294	294	2	132	3	1	6	89.35	567.80
295	295	1	193	4	1	12	19.70	220.35
296	296	1	193	4	1	1	20.25	20.25
297	297	5	137	3	1	71	76.05	5436.45
298	298	2	269	3	1	35	100.80	3437.50
299	299	2	205	3	1	40	74.55	3015.75
300	300	2	161	4	2	1	73.60	73.60
301	301	4	68	1	1	23	64.90	1509.80
302	302	2	261	3	2	4	95.45	396.10
303	303	2	142	3	1	4	90.40	356.65
304	304	5	32	2	1	68	60.30	4109.00
305	305	2	274	4	1	38	81.85	3141.70
306	306	5	322	4	1	52	24.80	1229.10
307	307	2	258	3	2	32	74.90	2303.35
308	308	5	80	4	1	29	75.55	2054.40
309	309	1	277	3	1	38	101.15	3741.85
310	310	4	237	2	1	48	78.75	3682.45
311	311	2	193	1	1	1	19.25	19.25
312	312	2	166	3	1	22	89.05	1886.25
313	313	5	321	2	1	43	115.05	4895.10
314	314	2	129	3	1	5	69.35	341.60
315	315	2	131	3	2	5	80.60	415.55
316	316	3	313	2	1	51	110.05	5686.40
317	317	6	193	2	1	71	19.90	1355.10
318	318	3	120	2	2	38	80.30	3058.65
319	319	2	140	3	2	24	93.15	2231.05
320	320	2	264	2	1	35	91.50	3236.35
321	321	3	249	1	2	54	82.45	4350.10
322	322	6	32	3	1	72	60.00	4264.00
323	323	2	65	3	1	1	44.80	44.80
324	324	3	97	4	1	9	48.60	422.30
325	325	6	56	1	1	69	60.05	4176.70
326	326	2	281	2	1	52	102.70	5138.10
327	327	2	135	3	1	11	82.90	880.05
328	328	2	129	3	2	2	70.35	139.05
329	329	2	3	3	1	28	35.90	973.65
330	330	2	266	2	1	17	82.65	1470.05
331	331	6	193	4	1	35	19.85	739.35
332	332	4	193	4	1	8	19.20	161.95
333	333	4	284	2	1	46	94.90	4422.95
334	334	2	258	3	2	7	73.85	511.25
335	335	1	266	4	2	2	80.60	155.80
336	336	4	223	1	2	68	75.80	5293.95
337	337	6	285	3	2	43	104.60	4759.85
338	338	6	257	3	1	68	88.15	6148.45
339	339	2	148	2	1	36	94.80	3565.65
340	340	2	285	3	2	63	103.40	6603.00
341	341	1	85	1	1	32	54.65	1830.10
342	342	5	257	2	1	71	85.75	6223.80
343	343	2	250	1	1	66	67.45	4508.65
344	344	3	193	4	1	63	20.50	1328.15
345	345	4	193	2	1	41	20.25	865.00
346	346	2	258	3	1	1	72.10	72.10
347	347	2	132	3	2	2	90.40	168.20
348	348	5	193	1	1	70	19.45	1303.50
349	349	2	4	3	1	23	44.95	996.85
350	350	3	186	1	1	64	97.00	6430.90
351	351	6	238	2	1	37	62.80	2278.75
352	352	3	65	4	1	17	44.60	681.40
353	353	2	132	3	1	7	89.15	574.35
354	354	2	282	1	2	4	84.80	371.90
355	355	2	35	3	2	21	41.90	840.10
356	356	2	130	1	2	10	80.25	846.00
357	357	2	226	3	1	16	54.10	889.00
358	358	6	281	3	1	64	105.25	6823.40
359	359	1	33	2	2	27	30.75	805.10
360	360	3	293	3	1	42	97.10	4016.75
361	361	1	193	4	1	5	20.20	83.75
362	362	6	152	1	1	41	98.80	3959.15
363	363	3	73	2	1	58	50.30	2878.55
364	364	6	193	4	1	47	20.55	945.70
365	365	2	133	1	1	18	75.90	1373.05
366	366	1	140	1	2	5	96.50	492.55
367	367	2	98	1	1	23	59.95	1406.00
368	368	1	193	4	1	1	19.15	19.15
369	369	4	269	2	1	71	98.65	6962.85
370	370	6	321	2	1	72	112.60	8126.65
371	371	3	193	4	1	33	20.60	690.25
372	372	2	260	3	2	2	85.65	181.50
373	373	5	37	4	1	24	35.75	830.80
374	374	4	287	2	1	56	99.75	5608.40
375	375	2	148	2	1	37	96.10	3646.80
376	376	3	225	2	1	43	85.10	3662.25
377	377	1	1	4	1	1	25.35	25.35
378	378	2	273	1	2	25	104.95	2566.50
379	379	5	257	3	1	61	89.65	5308.70
380	380	3	270	3	1	17	86.75	1410.25
381	381	4	157	1	1	41	86.20	3339.05
382	382	1	81	4	2	1	50.65	50.65
383	383	6	64	1	1	72	64.80	4732.35
384	384	2	275	2	2	1	90.85	90.85
385	385	6	285	1	1	48	108.10	5067.45
386	386	1	193	4	2	11	19.95	214.75
387	387	2	282	3	2	55	85.45	4874.70
388	388	4	62	3	1	42	54.75	2348.45
389	389	2	267	4	1	44	90.40	4063.00
390	390	1	65	3	1	1	44.00	44.00
391	391	2	261	1	1	27	95.60	2595.25
392	392	2	225	1	1	27	84.80	2309.55
393	393	2	65	3	1	2	44.30	89.30
394	394	1	193	4	1	19	19.90	367.55
395	395	2	261	3	1	42	95.05	3944.50
396	396	6	257	2	1	66	90.05	5965.95
397	397	2	305	1	1	33	109.90	3694.70
398	398	2	145	2	2	34	73.95	2524.45
399	399	2	16	3	1	33	54.60	1803.70
400	400	3	193	4	1	23	20.05	415.10
401	401	3	193	1	1	32	19.75	624.15
402	402	3	193	2	1	11	20.05	237.70
403	403	2	269	2	2	69	99.45	7007.60
404	404	3	101	1	1	68	55.90	3848.80
405	405	6	193	4	1	20	19.70	419.40
406	406	6	193	2	1	72	19.80	1468.75
407	407	4	300	1	1	60	95.40	5812.00
408	408	2	148	4	1	32	93.95	2861.45
409	409	2	193	4	2	1	19.90	19.90
410	410	2	193	4	2	1	19.60	19.60
411	411	2	274	3	2	3	81.35	233.70
412	412	4	322	1	1	46	24.45	1066.15
413	413	2	258	3	1	29	74.95	2149.05
414	414	2	286	3	1	51	87.35	4473.00
415	415	2	129	1	1	48	70.65	3545.05
416	416	1	145	1	1	16	73.25	1195.75
417	417	6	287	1	1	70	98.70	6858.90
418	418	6	322	4	1	40	24.80	1024.70
419	419	1	146	3	2	22	83.30	1845.90
420	420	2	137	1	2	1	75.30	75.30
421	421	2	322	4	1	5	24.30	132.25
422	422	2	129	1	1	7	69.85	515.45
423	423	3	287	2	1	29	100.55	2830.45
424	424	3	322	4	1	44	25.70	1110.50
425	425	1	57	1	1	10	40.70	449.30
426	426	1	194	1	1	55	51.65	2838.55
427	427	4	285	1	1	52	105.10	5376.40
428	428	1	259	3	1	10	85.95	858.60
429	429	2	258	1	1	18	75.60	1395.05
430	430	3	230	1	1	68	58.25	3975.70
431	431	2	193	4	2	61	19.40	1182.55
432	432	6	64	2	1	72	65.20	4784.45
433	433	1	105	3	1	2	53.45	119.50
434	434	2	65	1	2	12	45.40	518.90
435	435	6	193	3	1	41	19.75	899.45
436	436	2	15	2	1	26	44.45	1183.80
437	437	3	193	1	1	36	20.85	720.05
438	438	6	321	2	1	72	114.05	8468.20
439	439	2	263	1	1	35	89.85	3161.20
440	440	1	77	4	1	1	55.05	55.05
441	441	2	305	3	1	16	112.95	1882.55
442	442	1	293	2	1	49	101.55	5070.40
443	443	4	321	4	1	54	114.65	6049.50
444	444	1	227	3	1	18	64.80	1166.70
445	445	1	130	3	1	36	80.40	2937.65
446	446	2	285	3	2	60	105.90	6396.45
447	447	1	129	4	2	1	69.55	69.55
448	448	6	322	1	1	52	25.05	1270.25
449	449	2	140	3	1	8	94.75	759.55
450	450	5	184	1	1	72	105.50	7611.55
451	451	3	322	4	1	64	24.70	1642.75
452	452	2	110	4	1	22	69.75	1545.40
453	453	2	32	1	1	60	60.20	3582.40
454	454	2	130	3	2	28	81.05	2227.10
455	455	5	322	4	1	61	24.40	1417.90
456	456	2	285	3	1	24	104.15	2494.65
457	457	3	159	1	1	28	92.90	2768.35
458	458	5	96	1	1	30	80.80	2369.30
459	459	1	193	4	1	2	20.00	38.00
460	460	2	258	3	1	1	75.10	75.10
461	461	1	193	4	1	6	19.65	100.90
462	462	2	84	1	1	24	69.45	1614.05
463	463	1	269	3	2	4	101.15	385.90
464	464	2	277	3	2	7	99.80	673.25
465	465	6	321	1	1	72	116.05	8404.90
466	466	6	6	4	1	70	40.05	2799.75
467	467	5	273	3	1	64	102.10	6538.45
468	468	4	276	3	1	72	89.70	6588.95
469	469	5	193	4	1	44	19.90	868.10
470	470	1	66	3	2	13	55.95	734.35
471	471	3	193	4	1	17	20.65	330.60
472	472	2	66	3	2	1	55.00	55.00
473	473	2	76	4	1	9	70.05	564.40
474	474	1	101	4	1	24	53.60	1315.35
475	475	2	145	3	2	1	74.70	74.70
476	476	2	274	3	2	24	80.25	1861.50
477	477	2	88	3	1	35	76.05	2747.20
478	478	2	127	3	1	7	75.70	554.05
479	479	2	136	3	2	5	96.10	453.40
480	480	1	129	1	2	15	69.00	994.80
481	481	5	193	4	1	11	19.65	225.75
482	482	2	42	1	2	48	45.30	2145.00
483	483	2	130	3	1	20	81.45	1671.60
484	484	4	289	1	1	72	108.50	8003.80
485	485	2	147	3	2	8	83.55	680.05
486	486	6	259	2	1	72	84.50	6130.85
487	487	2	277	3	1	15	100.15	1415.00
488	488	6	225	1	1	72	88.60	6201.95
489	489	6	47	1	1	0	52.55	\N
490	490	2	258	3	2	1	74.35	74.35
491	491	6	285	1	1	63	104.80	6597.25
492	492	2	83	3	1	2	59.00	114.15
493	493	2	161	3	2	2	74.40	139.40
494	494	3	211	1	1	61	64.05	3902.60
495	495	1	193	4	1	1	20.40	20.40
496	496	4	26	1	2	22	43.75	903.60
497	497	1	117	4	1	28	60.90	1785.65
498	498	5	193	1	1	70	19.80	1397.65
499	499	1	17	3	2	5	28.45	131.05
500	500	2	315	1	2	12	99.70	1238.45
501	501	3	321	2	1	34	116.25	3899.05
502	502	6	290	2	1	71	80.70	5676.00
503	503	3	227	1	1	70	65.20	4543.15
504	504	2	173	1	1	52	84.05	4326.80
505	505	6	256	2	1	69	79.45	5502.55
506	506	2	283	3	2	20	94.10	1782.40
507	507	2	266	4	1	11	78.00	851.80
508	508	2	136	3	2	2	94.20	167.50
509	509	2	262	3	2	6	80.50	502.85
510	510	1	193	4	1	1	19.85	19.85
511	511	3	174	2	1	20	94.30	1818.30
512	512	2	301	3	1	61	106.45	6300.15
513	513	2	258	3	2	5	74.35	334.80
514	514	2	281	1	1	56	105.45	5916.95
515	515	2	318	2	1	30	95.00	2852.40
516	516	1	273	1	2	40	104.80	4131.95
517	517	3	101	4	1	28	54.30	1546.30
518	518	1	129	3	1	5	70.05	302.60
519	519	2	161	1	2	27	75.20	1929.35
520	520	1	193	2	1	12	20.05	265.45
521	521	4	285	3	1	67	105.40	6989.45
522	522	2	194	3	1	29	51.60	1442.00
523	523	1	259	1	1	55	85.50	4713.40
524	524	1	258	1	2	23	75.60	1758.60
525	525	2	269	3	2	34	100.05	3480.00
526	526	3	171	3	1	52	91.25	4738.30
527	527	6	321	2	1	72	115.75	8399.15
528	528	4	280	2	1	58	94.70	5430.35
529	529	5	193	4	1	35	19.60	686.95
530	530	6	288	1	1	56	99.90	5706.30
531	531	6	193	2	1	24	21.10	490.65
532	532	5	193	2	1	70	20.05	1360.25
533	533	2	131	3	1	2	79.95	174.45
534	534	4	273	2	1	68	107.15	7379.80
535	535	2	259	3	2	1	85.00	85.00
536	536	2	268	3	1	12	89.55	1021.75
537	537	2	274	1	1	63	81.55	5029.05
538	538	4	121	4	1	33	58.45	1955.40
539	539	4	148	2	1	69	95.65	6744.20
540	540	6	96	1	1	60	80.60	4946.70
541	541	6	321	1	1	72	113.10	8248.50
542	542	2	195	4	1	11	58.95	601.60
543	543	1	193	4	1	1	19.55	19.55
544	544	2	260	1	2	10	86.05	834.10
545	545	2	39	2	2	13	45.55	597.00
546	546	4	130	1	1	34	78.95	2647.20
547	547	2	147	4	2	39	86.30	3266.00
548	548	4	281	1	1	65	105.05	6744.25
549	549	4	316	1	1	50	101.90	5265.50
550	550	1	193	4	1	15	19.75	311.60
551	551	6	317	1	1	72	110.30	7966.90
552	552	6	321	1	1	72	115.60	8220.40
553	553	5	193	1	1	55	19.35	1153.25
554	554	6	322	2	1	23	25.60	514.75
555	555	2	274	1	2	32	80.35	2596.15
556	556	4	235	1	1	56	68.75	3808.00
557	557	1	193	1	1	1	19.90	19.90
558	558	3	119	4	1	38	70.60	2708.20
559	559	1	129	3	1	11	70.20	760.05
560	560	2	69	3	1	1	49.30	49.30
561	561	4	281	3	1	56	107.25	6033.30
562	562	2	322	4	1	3	23.60	89.05
563	563	1	100	2	1	7	69.70	516.15
564	564	6	269	2	1	59	99.50	5861.75
565	565	1	79	1	1	7	64.30	445.95
566	566	6	110	2	1	71	70.85	4973.40
567	567	3	168	3	1	15	101.90	1667.25
568	568	5	248	2	1	71	73.50	5357.75
569	569	2	269	3	2	35	100.25	3527.60
570	570	4	29	2	1	11	40.40	422.60
571	571	6	193	2	1	60	19.25	1103.25
572	572	5	214	1	1	47	59.60	2754.00
573	573	3	78	2	1	11	64.90	697.25
574	574	3	277	2	2	56	100.30	5614.45
575	575	2	289	3	1	28	110.85	3204.40
576	576	6	120	4	1	61	81.05	4747.65
577	577	3	300	1	1	31	98.05	3082.10
578	578	2	129	3	1	9	70.50	597.90
579	579	2	307	3	1	35	94.55	3365.40
580	580	2	193	4	1	2	19.65	38.80
581	581	1	193	4	2	12	19.00	233.55
582	582	1	161	4	2	1	75.30	75.30
583	583	2	268	3	2	4	89.20	346.20
584	584	2	193	4	1	1	19.00	19.00
585	585	2	193	4	1	3	20.00	61.70
586	586	2	260	3	2	1	85.70	85.70
587	587	6	115	2	1	52	63.25	3342.45
588	588	3	193	4	1	5	20.10	85.10
589	589	6	315	3	1	72	99.15	7422.10
590	590	5	257	3	1	71	90.40	6668.05
591	591	6	305	2	1	72	111.90	8071.05
592	592	3	322	3	1	46	24.90	1174.80
593	593	5	253	2	1	63	83.50	5435.00
594	594	2	185	2	1	30	84.30	2438.60
595	595	1	65	4	1	1	45.60	45.60
596	596	2	238	4	2	12	61.65	713.75
597	597	5	63	4	1	16	54.85	916.15
598	598	1	199	4	1	4	65.55	237.20
599	599	4	275	2	1	51	90.35	4614.55
600	600	6	193	2	1	65	20.40	1414.45
601	601	2	133	2	1	16	74.55	1170.50
602	602	3	193	4	1	2	19.95	47.70
603	603	4	258	1	1	66	74.25	4859.25
604	604	5	289	3	1	46	108.65	4903.20
605	605	4	305	1	1	32	109.55	3608.00
606	606	5	241	2	1	72	86.65	6094.25
607	607	5	112	2	1	38	81.00	3084.90
608	608	3	69	2	1	51	47.85	2356.75
609	609	5	321	1	1	72	114.55	8306.05
610	610	1	301	1	2	65	105.25	6786.40
611	611	2	17	3	2	9	29.95	248.95
612	612	1	125	4	2	9	65.00	663.05
613	613	5	193	4	1	66	20.55	1357.10
614	614	4	317	2	1	44	109.80	4860.35
615	615	5	207	1	1	50	69.50	3418.20
616	616	1	194	4	1	15	48.85	631.40
617	617	2	1	2	1	8	25.25	186.30
618	618	4	273	2	1	66	102.85	6976.75
619	619	2	310	1	1	57	87.55	4884.85
620	620	2	274	1	1	7	78.55	522.95
621	621	2	2	1	1	10	34.55	362.60
622	622	4	314	3	1	62	92.05	5755.80
623	623	4	139	3	1	40	85.05	3355.65
624	624	5	193	4	1	20	19.70	406.95
625	625	1	193	1	2	7	20.00	137.60
626	626	2	136	3	1	25	95.15	2395.70
627	627	1	282	3	1	23	84.25	1968.10
628	628	3	285	2	1	66	104.60	6819.45
629	629	5	289	3	1	72	111.65	7943.45
630	630	1	275	2	2	49	90.05	4547.25
631	631	2	289	1	2	43	110.75	4687.90
632	632	1	226	1	1	46	55.00	2473.95
633	633	5	257	2	1	72	89.85	6562.90
634	634	3	193	4	1	10	20.35	176.30
635	635	4	40	1	1	40	54.55	2236.20
636	636	2	285	3	2	65	105.50	6985.65
637	637	5	144	1	1	31	99.45	3109.90
638	638	5	254	2	1	68	70.90	4911.35
639	639	4	301	1	2	56	104.55	5794.65
640	640	2	259	3	2	10	85.25	855.30
641	641	5	322	1	1	68	25.40	1620.20
642	642	1	67	3	2	43	56.15	2499.30
643	643	2	132	3	2	1	89.55	89.55
644	644	4	154	1	1	49	89.85	4287.20
645	645	2	322	3	1	15	25.25	394.85
646	646	2	261	3	2	20	94.55	1899.65
647	647	2	65	4	2	1	45.70	45.70
648	648	4	208	3	1	50	69.65	3442.15
649	649	1	275	3	2	2	89.50	161.50
650	650	1	129	2	1	24	70.00	1732.60
651	651	2	129	1	2	3	69.55	222.30
652	652	2	137	4	2	1	74.60	74.60
653	653	5	193	4	1	35	20.10	655.30
654	654	1	322	4	1	17	24.80	475.25
655	655	1	193	3	2	8	19.65	164.30
656	656	2	136	2	1	10	95.10	865.10
657	657	6	257	2	1	68	88.85	6132.70
658	658	3	124	1	1	45	78.80	3597.50
659	659	3	193	4	2	2	19.85	35.90
660	660	1	193	1	1	37	20.35	697.65
661	661	2	1	4	2	4	24.25	96.05
662	662	1	65	4	1	10	45.25	428.70
663	663	1	193	4	1	1	20.05	20.05
664	664	6	243	4	1	65	69.55	4459.15
665	665	5	193	1	1	57	19.50	1167.60
666	666	2	137	4	1	3	74.75	238.10
667	667	1	129	3	2	2	69.65	145.15
668	668	2	9	1	1	49	30.20	1453.10
669	669	1	65	4	2	4	45.65	191.05
670	670	5	32	1	1	70	57.80	4039.30
671	671	4	193	1	1	53	19.85	1039.45
672	672	5	322	2	1	53	25.55	1336.10
673	673	2	258	4	2	1	75.05	75.05
674	674	2	322	2	1	22	24.85	493.40
675	675	2	20	3	2	52	49.15	2550.90
676	676	6	305	3	1	65	110.35	7246.15
677	677	3	322	1	1	48	24.55	1203.95
678	678	2	2	3	2	2	34.70	62.25
679	679	1	285	4	1	3	107.95	313.60
680	680	1	274	1	1	45	81.40	3775.85
681	681	1	130	3	2	1	80.00	80.00
682	682	6	80	1	1	61	73.80	4616.05
683	683	2	103	2	1	3	64.40	195.65
684	684	4	273	2	1	40	103.75	4188.40
685	685	1	129	4	1	1	71.10	71.10
686	686	2	69	3	1	1	49.90	49.90
687	687	4	322	1	1	51	24.60	1266.40
688	688	2	97	3	2	2	49.25	91.10
689	689	3	17	4	1	52	30.10	1623.40
690	690	1	259	1	1	51	83.40	4149.45
691	691	2	193	4	1	1	20.45	20.45
692	692	4	247	1	1	31	75.25	2344.50
693	693	3	193	2	1	47	20.55	1013.05
694	694	2	258	2	2	3	75.10	270.70
695	695	4	193	4	1	22	20.05	417.00
696	696	2	193	4	1	1	20.65	20.65
697	697	6	225	1	1	72	85.15	6316.20
698	698	2	73	3	2	3	50.15	168.15
699	699	4	147	1	1	47	84.95	4018.05
700	700	6	238	2	1	72	66.50	4811.60
701	701	6	204	1	1	66	63.30	4189.70
702	702	1	260	3	1	35	83.15	2848.45
703	703	2	259	3	1	29	84.90	2516.20
704	704	2	193	4	1	2	20.55	33.60
705	705	1	81	4	1	4	49.25	208.45
706	706	2	177	1	2	25	79.85	2015.35
707	707	6	117	4	1	65	59.60	3739.80
708	708	4	281	1	1	27	104.65	2964.00
709	709	2	137	2	1	29	75.30	2263.40
710	710	1	221	2	1	29	80.10	2211.80
711	711	1	193	4	2	1	19.55	19.55
712	712	2	141	4	1	20	81.00	1683.70
713	713	6	322	2	1	58	24.70	1519.00
714	714	2	294	4	1	14	86.00	1164.05
715	715	5	322	4	1	72	25.40	1710.90
716	716	2	292	2	1	46	89.15	4245.55
717	717	5	32	1	1	71	58.25	4145.90
718	718	2	259	1	1	32	85.65	2664.30
719	719	2	12	2	1	26	50.35	1277.50
720	720	2	266	2	1	68	80.35	5589.30
721	721	3	193	4	1	2	20.20	34.75
722	722	5	193	2	1	61	20.55	1305.95
723	723	2	259	3	2	4	85.95	381.30
724	724	2	65	3	2	3	45.35	141.50
725	725	2	261	3	2	33	94.50	3105.55
726	726	2	193	4	1	9	21.25	204.55
727	727	5	322	4	1	22	26.25	605.90
728	728	2	131	3	1	5	80.85	356.10
729	729	1	314	2	2	30	91.70	2758.15
730	730	6	223	2	1	65	74.20	4805.65
731	731	2	270	3	2	45	87.25	3941.70
732	732	1	193	4	1	5	20.35	92.75
733	733	2	145	3	1	25	75.50	1901.05
734	734	5	290	1	1	72	79.05	5730.70
735	735	1	267	1	1	27	90.15	2423.40
736	736	1	12	2	1	32	50.60	1653.45
737	737	3	289	2	1	30	110.45	3327.05
738	738	5	190	2	1	70	101.00	7085.50
739	739	2	274	1	1	42	79.35	3344.10
740	740	6	257	1	1	72	89.85	6697.35
741	741	6	238	4	1	47	65.00	2879.90
742	742	2	169	3	1	2	80.45	137.10
743	743	1	293	3	2	10	98.55	1008.55
744	744	6	322	4	1	61	24.10	1551.60
745	745	2	65	2	1	5	44.05	202.15
746	746	6	289	2	1	72	110.80	7882.25
747	747	6	321	1	1	72	114.95	8196.40
748	748	1	137	4	1	3	75.05	202.90
749	749	5	193	4	1	48	19.25	855.10
750	750	4	143	2	1	63	90.05	5817.00
751	751	2	113	4	1	27	56.70	1652.95
752	752	6	124	2	1	70	80.15	5600.15
753	753	2	110	2	1	7	71.35	515.75
754	754	5	193	4	1	0	20.25	\N
755	755	1	179	3	1	2	90.35	190.50
756	756	2	269	3	2	20	98.55	1842.80
757	757	5	193	1	1	66	19.70	1253.80
758	758	1	193	4	1	3	19.85	57.20
759	759	2	146	1	2	15	85.90	1269.55
760	760	6	310	1	1	72	90.35	6563.40
761	761	1	193	4	1	1	20.80	20.80
762	762	1	132	3	2	22	89.25	1907.85
763	763	2	129	3	2	3	70.30	208.85
764	764	5	238	1	1	72	66.85	4758.80
765	765	5	193	4	1	65	19.90	1292.60
766	766	2	3	4	1	11	35.80	363.15
767	767	2	274	4	1	22	78.85	1600.25
768	768	3	193	1	1	14	20.40	275.70
769	769	2	133	3	1	41	74.25	3089.10
770	770	3	114	4	1	17	64.80	1175.60
771	771	2	193	2	1	11	20.45	237.30
772	772	2	261	3	2	15	93.35	1444.65
773	773	1	193	4	2	1	19.90	19.90
774	774	2	170	4	2	5	88.90	454.15
775	775	4	140	3	2	33	95.80	3036.75
776	776	6	317	2	1	72	110.65	8065.65
777	777	1	18	4	1	3	40.30	92.50
778	778	2	274	3	2	2	82.00	184.65
779	779	4	319	2	1	59	107.00	6152.30
780	780	1	65	3	2	2	45.35	89.50
781	781	6	88	2	1	71	73.35	5154.50
782	782	1	65	4	1	5	44.80	220.45
783	783	2	113	2	1	27	54.75	1510.30
784	784	2	69	3	2	1	52.20	52.20
785	785	4	53	1	1	63	40.60	2588.95
786	786	4	317	3	2	46	110.00	4874.80
787	787	5	226	1	1	72	55.30	3983.60
788	788	2	230	1	1	34	60.85	2003.60
789	789	3	245	3	1	24	78.40	1832.40
790	790	5	254	1	1	72	69.65	4908.25
791	791	5	48	2	1	60	59.85	3590.20
792	792	4	251	2	1	68	76.90	5023.00
793	793	6	193	4	1	8	19.85	146.60
794	794	5	111	2	1	34	67.65	2339.30
795	795	1	4	2	1	6	45.00	298.70
796	796	2	86	4	1	2	64.20	143.65
797	797	3	262	2	1	31	81.70	2548.65
798	798	2	322	1	1	20	25.55	507.40
799	799	1	193	3	1	1	20.00	20.00
800	800	4	269	3	2	62	96.75	6125.40
801	801	6	258	2	1	70	75.65	5411.40
802	802	2	265	3	2	10	98.50	1058.25
803	803	6	322	4	1	39	23.80	903.80
804	804	6	87	2	1	46	64.20	3009.50
805	805	2	147	3	2	6	85.35	489.45
806	806	6	205	1	1	72	76.80	5468.45
807	807	1	77	2	1	18	55.20	1058.10
808	808	6	305	2	1	71	108.55	7616.00
809	809	2	277	3	2	40	101.30	4113.10
810	810	2	129	3	2	1	69.55	69.55
811	811	4	285	1	2	58	103.25	6017.65
812	812	6	297	2	2	70	104.00	7250.15
813	813	5	322	3	1	42	25.25	1108.20
814	814	3	33	1	1	34	30.40	938.65
815	815	1	193	1	1	5	20.05	94.15
816	816	2	260	4	1	25	84.60	2088.05
817	817	2	138	4	2	2	86.20	178.70
818	818	4	160	1	1	55	103.70	5656.75
819	819	2	289	3	2	21	111.20	2317.10
820	820	6	310	2	1	70	88.00	5986.45
821	821	2	273	3	1	61	106.35	6751.35
822	822	6	112	2	1	43	79.15	3566.60
823	823	4	285	3	1	47	103.10	4889.30
824	824	2	79	2	1	5	63.95	318.10
825	825	6	322	2	1	62	25.80	1563.95
826	826	2	155	2	2	16	89.45	1430.25
827	827	2	261	1	2	7	95.60	644.35
828	828	1	322	4	1	14	25.55	372.45
829	829	3	155	3	2	60	90.95	5453.40
830	830	2	15	3	1	34	44.85	1442.60
831	831	3	313	3	2	50	108.55	5610.70
832	832	5	322	2	1	38	25.05	963.95
833	833	3	126	2	1	70	74.10	5222.30
834	834	2	276	3	1	37	88.80	3340.55
835	835	2	131	3	2	4	78.85	292.80
836	836	2	307	3	1	60	93.25	5774.55
837	837	3	110	2	1	62	71.40	4487.30
838	838	1	65	4	2	1	44.40	44.40
839	839	2	112	2	1	36	79.20	2854.95
840	840	5	193	2	1	44	20.40	905.55
841	841	4	269	3	2	55	100.00	5509.30
842	842	6	301	2	1	72	105.00	7589.80
843	843	3	193	1	2	12	19.80	229.60
844	844	2	33	1	1	13	30.85	394.10
845	845	2	132	3	2	1	89.90	89.90
846	846	3	193	4	1	15	20.55	295.95
847	847	6	128	1	1	65	84.85	5459.20
848	848	3	37	2	1	12	33.15	444.75
849	849	6	257	2	1	72	92.00	6782.15
850	850	5	257	2	1	72	89.80	6510.45
851	851	6	321	1	1	72	115.80	8476.50
852	852	6	249	4	1	52	85.15	4461.85
853	853	1	322	4	1	2	24.85	62.00
854	854	2	103	3	1	5	64.35	352.65
855	855	5	193	2	1	68	20.50	1424.90
856	856	4	269	3	2	62	100.15	6413.65
857	857	5	249	2	1	72	86.05	6309.65
858	858	1	81	3	2	1	50.80	50.80
859	859	3	310	3	1	66	89.00	5898.60
860	860	6	64	2	1	72	64.80	4719.75
861	861	3	193	2	1	26	19.80	457.30
862	862	5	299	1	1	64	93.40	5822.30
863	863	2	145	3	2	20	73.65	1463.50
864	864	2	148	3	2	3	95.10	307.40
1189	1189	4	144	3	1	35	99.25	3532.00
865	865	2	261	2	2	22	94.65	2104.55
866	866	2	141	4	2	4	80.60	319.15
867	867	6	7	1	1	62	39.00	2337.45
868	868	2	193	4	1	5	20.50	104.30
869	869	3	259	3	2	59	85.55	5084.65
870	870	6	322	4	1	3	26.40	121.25
871	871	6	304	1	1	72	98.20	7015.90
872	872	4	156	2	1	57	97.55	5598.00
873	873	5	193	2	1	66	19.95	1269.10
874	874	2	20	3	2	60	50.80	3027.40
875	875	5	269	1	1	45	99.70	4634.35
876	876	2	3	2	1	3	34.80	113.95
877	877	1	176	3	2	15	105.10	1582.75
878	878	3	48	1	1	51	60.15	3077.00
879	879	3	238	3	1	60	64.75	4039.50
880	880	2	210	1	1	33	54.65	1665.20
881	881	2	192	3	2	10	110.10	1043.30
882	882	3	193	2	1	26	19.30	504.20
883	883	1	138	3	2	6	83.90	497.55
884	884	4	305	3	1	67	111.25	7511.65
885	885	4	37	2	1	49	35.80	1782.00
886	886	2	193	4	1	1	20.05	20.05
887	887	2	139	3	1	7	84.35	609.65
888	888	4	317	1	1	27	110.50	2857.60
889	889	3	132	2	1	37	91.20	3247.55
890	890	2	316	3	2	63	100.55	6215.35
891	891	1	302	3	1	31	89.30	2823.00
892	892	2	285	1	2	50	103.85	5017.90
893	893	2	266	2	1	32	81.10	2619.25
894	894	1	1	3	2	1	24.60	24.60
895	895	4	262	2	1	63	81.20	4965.10
896	896	2	307	2	1	30	94.30	2679.70
897	897	6	321	1	1	71	116.10	8310.55
898	898	5	285	3	1	53	105.55	5682.25
899	899	2	168	1	2	12	98.90	1120.95
900	900	2	307	2	1	50	94.40	4914.90
901	901	1	193	4	1	2	19.50	27.55
902	902	1	269	2	2	9	98.30	923.50
903	903	1	164	3	2	17	93.85	1625.65
904	904	4	188	2	1	56	105.60	6068.65
905	905	5	124	2	1	67	81.35	5398.60
906	906	2	269	3	2	9	100.50	918.60
907	907	2	67	3	1	4	56.40	234.85
908	908	4	86	1	1	19	65.35	1231.85
909	909	1	193	4	1	8	19.95	170.90
910	910	6	289	3	1	71	111.25	7984.15
911	911	2	145	3	2	10	72.85	688.65
912	912	1	276	2	1	15	89.00	1288.30
913	913	4	301	1	1	72	106.10	7848.50
914	914	3	193	2	1	12	20.05	267.00
915	915	6	322	1	1	72	25.20	1798.90
916	916	2	258	3	2	1	73.55	73.55
917	917	2	161	1	1	23	75.40	1643.55
918	918	6	64	1	1	72	65.55	4807.45
919	919	2	266	3	1	26	80.70	2193.00
920	920	4	160	4	1	21	104.55	2239.40
921	921	3	322	1	1	60	24.15	1505.90
922	922	1	193	4	1	12	20.45	255.35
923	923	2	258	3	1	16	75.40	1189.40
924	924	4	245	2	1	63	79.70	4786.15
925	925	1	177	3	1	22	81.70	1820.90
926	926	1	126	1	1	32	76.30	2404.15
927	927	2	274	3	2	3	79.40	205.05
928	928	2	153	3	2	13	81.15	952.30
929	929	6	281	2	1	68	103.75	7039.45
930	930	3	138	3	1	30	86.45	2538.05
931	931	1	145	1	1	16	75.10	1212.85
932	932	5	149	1	1	33	80.60	2651.10
933	933	5	193	2	1	72	19.30	1304.80
934	934	2	259	3	2	4	84.60	360.10
935	935	4	37	4	1	12	33.60	435.45
936	936	2	260	3	1	4	83.25	308.05
937	937	5	124	4	1	0	80.85	\N
938	938	2	290	3	2	6	79.05	434.50
939	939	4	289	2	1	65	108.05	7118.90
940	940	1	193	4	1	15	19.90	320.45
941	941	3	193	1	1	24	21.05	531.55
942	942	1	17	3	1	13	30.15	382.20
943	943	2	130	2	1	24	79.85	2001.00
944	944	5	64	1	1	72	65.50	4919.70
945	945	2	309	1	1	54	104.10	5645.80
946	946	1	258	1	2	3	74.40	215.80
947	947	2	193	4	1	4	20.50	77.60
948	948	2	268	4	1	32	91.35	2896.55
949	949	2	269	3	2	35	99.05	3395.80
950	950	5	193	1	1	35	20.50	759.35
951	951	1	65	4	2	2	44.95	85.15
952	952	1	145	3	1	8	75.60	535.55
953	953	1	101	4	1	22	55.10	1253.15
954	954	1	109	3	1	15	58.95	955.15
955	955	2	261	3	1	22	95.10	2162.60
956	956	1	65	2	2	1	44.70	44.70
957	957	5	322	1	1	71	25.45	1813.35
958	958	1	105	3	1	4	56.75	245.15
959	959	1	255	1	1	25	81.75	2028.80
960	960	2	147	3	1	32	86.10	2723.75
961	961	1	33	1	1	7	29.80	220.45
962	962	4	193	4	1	17	20.50	365.80
963	963	1	99	1	1	8	60.90	551.95
964	964	5	239	1	1	56	73.25	4054.20
965	965	2	65	4	2	1	45.70	45.70
966	966	1	168	2	2	8	100.30	832.35
967	967	1	193	3	2	7	19.25	112.30
968	968	1	193	4	1	3	20.85	60.65
969	969	5	127	2	1	71	77.35	5550.10
970	970	2	261	3	2	2	96.00	174.80
971	971	1	132	3	2	1	90.55	90.55
972	972	2	308	1	1	49	93.85	4733.10
973	973	5	95	1	1	58	70.10	4048.95
974	974	2	17	3	2	44	30.35	1359.70
975	975	6	88	2	1	59	75.95	4542.35
976	976	6	305	3	2	71	108.05	7532.15
977	977	2	129	3	2	1	69.90	69.90
978	978	1	258	3	1	11	75.25	888.65
979	979	4	285	3	2	62	103.75	6383.35
980	980	4	101	1	1	35	54.95	1916.00
981	981	2	193	1	1	20	19.50	413.00
982	982	5	193	4	1	40	19.60	808.95
983	983	4	97	3	1	39	47.85	1886.40
984	984	2	259	3	2	1	86.60	86.60
985	985	5	322	1	1	72	23.75	1679.25
986	986	2	274	1	2	33	80.60	2656.50
987	987	1	65	1	1	12	43.80	540.95
988	988	1	193	1	1	1	19.75	19.75
989	989	1	193	4	1	27	19.15	537.35
990	990	3	193	2	1	34	19.60	678.80
991	991	5	169	1	1	56	80.30	4513.65
992	992	5	322	2	1	58	24.35	1423.85
993	993	5	322	2	1	22	25.25	555.40
994	994	5	322	2	1	10	26.10	225.55
995	995	5	193	2	1	13	20.00	268.45
996	996	1	278	2	2	35	85.30	2917.50
997	997	2	129	2	2	34	70.00	2416.10
998	998	2	261	3	2	4	94.30	424.45
999	999	5	193	1	1	72	20.70	1492.10
1000	1000	1	72	3	1	2	70.30	132.40
1001	1001	2	140	3	2	7	95.35	660.90
1002	1002	2	258	3	2	27	75.50	1893.95
1003	1003	2	129	4	1	4	69.55	284.90
1004	1004	5	193	4	1	37	19.85	784.25
1005	1005	1	193	4	1	21	20.00	417.70
1006	1006	4	261	2	1	53	95.85	5016.25
1007	1007	2	263	3	2	18	90.10	1612.75
1008	1008	1	129	3	2	2	68.95	119.75
1009	1009	2	293	2	2	32	99.55	3204.65
1010	1010	4	193	3	1	23	20.75	485.20
1011	1011	2	97	4	1	3	50.15	160.85
1012	1012	5	56	4	1	71	58.65	4145.25
1013	1013	2	136	1	1	9	95.90	827.45
1014	1014	1	81	3	1	1	49.50	49.50
1015	1015	1	74	3	2	18	57.45	990.85
1016	1016	3	66	2	2	12	53.65	696.35
1017	1017	6	255	4	1	71	80.10	5585.40
1018	1018	4	322	1	1	64	24.40	1601.20
1019	1019	2	6	3	1	4	40.05	162.45
1020	1020	2	193	4	1	23	19.50	470.20
1021	1021	1	97	2	1	39	51.05	2066.00
1022	1022	3	101	4	1	28	54.35	1426.45
1023	1023	2	147	3	1	5	84.70	392.50
1024	1024	2	138	3	1	45	86.10	3861.45
1025	1025	2	129	4	1	37	70.35	2552.90
1026	1026	6	192	1	1	60	110.00	6668.35
1027	1027	2	269	3	2	8	100.60	819.40
1028	1028	3	300	2	1	47	94.90	4615.25
1029	1029	2	260	3	2	26	83.75	2070.60
1030	1030	2	167	4	2	3	88.30	273.75
1031	1031	2	129	1	1	50	69.75	3557.70
1032	1032	1	201	1	1	27	71.60	1957.10
1033	1033	2	140	3	2	8	92.10	729.95
1034	1034	5	322	1	1	62	23.65	1416.75
1035	1035	5	112	1	1	71	81.85	5924.40
1036	1036	5	322	4	1	66	25.10	1697.70
1037	1037	6	321	1	1	68	114.70	7849.85
1038	1038	1	12	3	1	13	49.15	649.40
1039	1039	4	130	3	1	56	80.90	4557.50
1040	1040	2	177	3	2	38	79.45	3013.05
1041	1041	1	132	2	2	14	90.45	1266.10
1042	1042	4	193	1	1	16	19.30	360.35
1043	1043	1	129	3	1	14	70.20	1046.50
1044	1044	2	129	1	2	32	69.75	2347.90
1045	1045	3	101	1	1	8	54.25	447.75
1046	1046	2	269	1	1	43	99.30	4209.95
1047	1047	3	240	2	1	52	74.00	3877.65
1048	1048	2	69	4	1	3	50.25	152.30
1049	1049	4	193	4	1	29	19.80	572.20
1050	1050	1	193	4	2	1	19.65	19.65
1051	1051	2	14	3	2	12	43.65	526.95
1052	1052	2	2	2	1	16	35.50	552.70
1053	1053	4	209	4	1	40	80.75	3208.65
1054	1054	1	10	3	2	5	39.50	210.75
1055	1055	2	261	1	2	40	97.10	3706.95
1056	1056	3	193	4	1	36	19.55	620.75
1057	1057	2	130	3	2	5	80.00	412.50
1058	1058	2	163	4	2	10	84.70	832.05
1059	1059	2	132	1	2	2	89.55	185.55
1060	1060	2	264	3	2	23	90.60	1943.20
1061	1061	4	193	1	1	26	20.05	505.90
1062	1062	6	317	3	1	72	112.40	8046.85
1063	1063	1	69	1	1	34	50.20	1815.30
1064	1064	1	103	1	1	10	62.25	612.95
1065	1065	3	101	4	1	14	55.70	795.15
1066	1066	2	292	1	2	23	90.05	2169.80
1067	1067	5	193	4	1	47	19.65	973.10
1068	1068	2	166	3	1	24	89.25	2210.20
1069	1069	2	277	1	2	49	99.05	4853.75
1070	1070	3	101	4	1	20	54.00	1055.90
1071	1071	1	129	1	2	2	69.75	144.55
1072	1072	2	81	2	2	2	49.05	91.10
1073	1073	5	16	1	1	22	56.75	1304.85
1074	1074	2	269	1	2	7	98.05	713.00
1075	1075	1	193	4	1	1	21.10	21.10
1076	1076	2	279	1	1	59	96.65	5580.80
1077	1077	4	322	2	1	58	24.50	1497.90
1078	1078	2	321	1	2	41	114.50	4527.45
1079	1079	6	274	2	1	59	79.20	4590.35
1080	1080	2	129	3	1	3	69.55	200.20
1081	1081	6	193	1	1	32	20.05	614.45
1082	1082	2	269	3	1	46	98.85	4564.90
1083	1083	5	322	4	1	0	25.75	\N
1084	1084	2	130	3	2	2	80.95	171.15
1085	1085	3	193	2	1	52	19.60	1012.40
1086	1086	2	137	3	2	13	74.30	940.35
1087	1087	1	132	1	2	11	89.70	1047.70
1088	1088	1	294	1	1	32	87.65	2766.40
1089	1089	2	269	2	2	17	100.45	1622.45
1090	1090	2	258	2	1	16	74.75	1129.35
1091	1091	3	317	1	1	51	107.45	5680.90
1092	1092	4	80	1	1	29	75.35	2243.90
1093	1093	5	125	2	1	70	64.95	4523.25
1094	1094	5	303	3	1	71	100.45	7159.70
1095	1095	3	220	1	1	41	68.50	2839.95
1096	1096	2	131	3	1	1	80.55	80.55
1097	1097	1	112	1	1	7	81.25	580.10
1098	1098	4	132	3	2	25	90.40	2178.60
1099	1099	3	310	3	1	67	89.55	6038.55
1100	1100	2	198	4	1	5	55.70	259.40
1101	1101	2	322	3	1	15	24.80	324.15
1102	1102	1	193	3	1	20	20.00	417.65
1103	1103	2	89	4	2	3	56.15	168.15
1104	1104	4	281	3	1	54	105.20	5637.85
1105	1105	4	193	4	1	42	19.55	839.40
1106	1106	2	130	3	1	9	79.75	769.10
1107	1107	5	277	1	1	63	97.45	6253.00
1108	1108	5	322	1	1	69	24.25	1641.80
1109	1109	5	322	2	1	69	24.60	1678.05
1110	1110	2	81	4	1	40	50.15	2058.50
1111	1111	5	57	1	1	60	39.60	2424.50
1112	1112	2	174	1	2	4	94.40	387.20
1113	1113	5	257	4	1	71	89.85	6293.45
1114	1114	2	266	2	2	37	78.95	2839.65
1115	1115	2	277	2	1	32	98.85	3145.90
1116	1116	6	198	2	1	39	53.85	2200.70
1117	1117	4	322	3	1	38	24.25	914.40
1118	1118	6	267	2	1	52	89.45	4577.75
1119	1119	2	309	2	1	48	105.25	4997.50
1120	1120	5	48	1	1	70	59.50	4144.80
1121	1121	1	129	2	1	20	70.55	1493.55
1122	1122	4	241	2	1	50	82.50	4179.10
1123	1123	4	4	2	2	19	44.85	893.55
1124	1124	4	121	1	1	25	61.60	1611.00
1125	1125	2	81	1	1	12	49.05	593.05
1126	1126	2	285	3	2	39	105.65	4284.80
1127	1127	1	137	4	2	7	74.65	544.55
1128	1128	4	125	4	1	23	66.25	1533.80
1129	1129	2	193	3	1	27	19.40	529.80
1130	1130	2	260	2	1	47	86.05	3865.60
1131	1131	6	193	2	1	26	19.15	515.75
1132	1132	2	228	1	2	14	64.70	941.00
1133	1133	2	273	1	2	11	104.05	1133.65
1134	1134	1	193	4	1	2	19.25	48.35
1135	1135	1	177	3	1	26	81.95	2070.05
1136	1136	6	321	1	1	72	114.65	8333.95
1137	1137	5	193	2	1	63	20.00	1209.25
1138	1138	5	193	4	1	71	19.80	1396.25
1139	1139	2	228	1	1	11	65.15	723.35
1140	1140	3	193	4	1	14	19.65	228.65
1141	1141	5	257	2	1	13	88.95	1161.75
1142	1142	2	193	4	1	6	20.20	98.35
1143	1143	2	258	2	1	11	75.20	775.30
1144	1144	1	210	2	1	18	56.80	1074.65
1145	1145	2	2	3	2	1	35.55	35.55
1146	1146	2	161	1	1	32	75.50	2324.70
1147	1147	3	37	4	1	29	35.60	1072.60
1148	1148	2	196	3	1	3	60.25	170.50
1149	1149	2	261	3	2	2	95.15	196.90
1150	1150	2	140	4	2	13	96.65	1162.85
1151	1151	2	18	3	1	41	40.35	1677.85
1152	1152	1	193	3	1	1	18.85	18.85
1153	1153	1	67	4	1	7	54.85	370.40
1154	1154	4	107	4	1	52	64.30	3410.60
1155	1155	6	322	1	1	45	24.65	1138.80
1156	1156	5	224	2	1	70	76.10	5264.25
1157	1157	5	193	4	1	53	18.70	1005.70
1158	1158	4	284	2	1	62	97.95	5936.55
1159	1159	2	307	2	1	60	94.10	5475.90
1160	1160	2	131	3	2	3	80.40	224.05
1161	1161	2	164	3	1	23	95.10	2326.05
1162	1162	2	17	4	2	1	31.35	31.35
1163	1163	4	110	1	1	67	72.35	4991.50
1164	1164	2	276	1	2	12	89.75	1052.40
1165	1165	6	255	1	1	71	82.70	5831.20
1166	1166	3	193	2	1	25	19.90	510.80
1167	1167	2	226	3	1	5	53.80	283.95
1168	1168	4	194	2	1	26	51.55	1295.40
1169	1169	3	193	4	1	1	19.65	19.65
1170	1170	4	27	2	1	70	44.05	3011.65
1171	1171	6	321	3	1	72	114.00	8093.15
1172	1172	4	148	3	2	60	94.40	5610.25
1173	1173	2	277	3	1	32	100.40	3217.65
1174	1174	2	193	3	2	1	19.85	19.85
1175	1175	4	210	4	1	14	54.25	773.20
1176	1176	2	290	2	1	13	80.00	1029.35
1177	1177	2	289	2	2	6	109.90	669.45
1178	1178	5	237	4	1	46	79.20	3593.80
1179	1179	2	144	3	2	15	101.35	1553.95
1180	1180	2	280	3	1	43	94.30	3953.15
1181	1181	6	69	1	1	39	49.80	1971.15
1182	1182	2	75	1	2	21	60.05	1236.15
1183	1183	2	44	3	1	57	53.75	3196.00
1184	1184	4	136	3	1	53	93.45	4872.20
1185	1185	2	171	4	1	18	87.90	1500.50
1186	1186	2	195	3	2	1	60.15	60.15
1187	1187	4	230	1	1	58	61.05	3478.75
1188	1188	5	269	1	1	71	104.05	7413.55
1190	1190	1	138	2	1	3	85.70	256.75
1191	1191	4	309	3	1	38	104.85	3887.25
1192	1192	6	254	2	1	35	69.15	2490.15
1193	1193	2	268	3	2	7	90.45	593.45
1194	1194	5	80	4	1	47	74.45	3510.30
1195	1195	1	81	3	1	14	50.45	765.45
1196	1196	2	82	3	1	20	60.00	1259.35
1197	1197	5	249	3	1	66	85.25	5538.35
1198	1198	2	193	2	1	15	19.45	340.85
1199	1199	6	193	1	1	42	20.75	844.45
1200	1200	1	290	3	1	17	78.90	1348.95
1201	1201	4	281	2	1	37	104.50	3778.00
1202	1202	2	81	3	1	12	49.40	611.65
1203	1203	4	148	1	2	53	94.25	4867.95
1204	1204	5	322	4	1	60	25.00	1505.05
1205	1205	1	1	2	1	18	25.55	467.85
1206	1206	2	258	3	2	1	74.90	74.90
1207	1207	2	129	3	1	3	70.15	194.20
1208	1208	2	72	2	1	9	69.40	571.45
1209	1209	2	131	3	2	1	80.25	80.25
1210	1210	4	314	3	1	56	93.15	5253.95
1211	1211	2	129	3	2	17	69.00	1149.65
1212	1212	2	199	3	2	11	66.35	740.80
1213	1213	2	129	3	1	7	69.55	521.35
1214	1214	5	193	1	1	69	20.20	1412.65
1215	1215	2	259	1	2	19	86.00	1532.45
1216	1216	2	130	3	2	3	80.30	250.05
1217	1217	5	193	2	1	54	20.40	1090.60
1218	1218	4	322	2	1	62	23.75	1446.80
1219	1219	2	276	2	2	24	90.55	2282.55
1220	1220	2	197	2	1	62	70.45	4300.45
1221	1221	1	227	1	1	17	65.75	1111.20
1222	1222	2	1	4	1	9	24.60	190.10
1223	1223	5	111	4	1	64	69.25	4447.75
1224	1224	2	258	3	2	2	75.90	143.35
1225	1225	2	65	4	2	1	45.85	45.85
1226	1226	2	8	3	2	16	49.95	810.20
1227	1227	5	322	1	1	72	24.65	1830.05
1228	1228	3	314	1	1	30	90.40	2820.65
1229	1229	2	293	4	1	49	100.85	4847.35
1230	1230	5	239	2	1	61	75.35	4729.30
1231	1231	1	276	3	1	47	87.20	4017.45
1232	1232	1	106	2	1	20	64.40	1398.60
1233	1233	1	131	3	2	34	78.30	2564.30
1234	1234	5	322	1	1	70	24.70	1685.90
1235	1235	4	184	3	1	54	105.85	5826.65
1236	1236	4	288	4	1	61	98.30	6066.55
1237	1237	2	258	3	2	3	76.95	228.40
1238	1238	3	193	4	1	13	19.45	270.20
1239	1239	2	261	3	2	16	96.15	1529.20
1240	1240	2	83	2	1	3	58.70	168.60
1241	1241	2	193	4	1	25	20.15	536.35
1242	1242	2	227	4	1	30	64.50	1888.45
1243	1243	1	33	3	1	21	28.50	629.35
1244	1244	1	65	3	2	1	45.30	45.30
1245	1245	1	193	1	2	15	19.40	289.30
1246	1246	2	132	3	1	23	90.45	2117.25
1247	1247	2	309	3	1	45	105.15	4730.90
1248	1248	3	282	1	1	24	83.15	2033.05
1249	1249	1	264	3	2	11	90.15	987.95
1250	1250	1	65	4	2	1	45.05	45.05
1251	1251	5	273	1	1	56	103.20	5744.35
1252	1252	1	145	3	2	1	75.80	75.80
1253	1253	1	193	3	1	1	19.45	19.45
1254	1254	2	130	3	2	7	79.30	523.15
1255	1255	5	143	2	1	55	88.80	4805.30
1256	1256	2	5	3	2	2	30.90	59.05
1257	1257	6	241	2	1	72	85.90	6110.75
1258	1258	3	2	3	1	45	34.20	1596.60
1259	1259	5	193	4	1	47	20.15	1046.20
1260	1260	3	148	2	2	46	95.25	4424.20
1261	1261	2	81	4	1	2	50.30	92.75
1262	1262	2	165	3	1	2	80.15	194.55
1263	1263	2	81	3	1	12	51.25	612.10
1264	1264	2	275	1	2	68	89.60	6127.60
1265	1265	6	136	2	1	69	95.20	6671.70
1266	1266	3	164	2	1	56	94.80	5264.30
1267	1267	2	290	3	1	4	80.25	303.70
1268	1268	6	224	1	1	64	76.10	4818.80
1269	1269	4	317	3	2	59	110.15	6448.05
1270	1270	5	321	1	1	62	115.55	7159.05
1271	1271	5	322	2	1	63	24.65	1574.50
1272	1272	4	63	3	1	53	53.60	2879.20
1273	1273	1	193	4	1	5	19.45	86.05
1274	1274	2	314	3	1	49	88.20	4159.45
1275	1275	6	293	1	1	62	101.15	6638.35
1276	1276	5	117	4	1	55	56.80	3112.05
1277	1277	6	191	3	1	71	99.40	7168.25
1278	1278	6	193	2	1	72	20.10	1326.25
1279	1279	3	48	2	1	36	60.70	2234.55
1280	1280	4	193	1	1	25	20.95	495.15
1281	1281	6	321	1	1	72	114.85	8317.95
1282	1282	4	193	1	1	36	19.25	679.80
1283	1283	2	68	4	1	1	62.80	62.80
1284	1284	6	301	3	1	72	105.50	7544.00
1285	1285	5	193	4	1	59	19.85	1188.25
1286	1286	2	132	3	2	7	89.50	676.70
1287	1287	3	80	2	1	1	74.10	74.10
1288	1288	2	289	3	1	30	107.50	3242.50
1289	1289	5	193	4	1	64	19.55	1240.15
1290	1290	3	254	1	1	63	68.80	4111.35
1291	1291	5	253	2	1	72	84.45	5899.85
1292	1292	1	161	3	2	8	75.00	632.95
1293	1293	5	225	1	1	62	84.50	5193.20
1294	1294	6	289	1	1	67	111.20	7530.80
1295	1295	1	65	3	2	6	44.75	270.95
1296	1296	6	233	1	1	70	80.60	5460.20
1297	1297	1	131	1	1	20	80.70	1614.20
1298	1298	1	258	3	1	5	75.60	402.50
1299	1299	3	60	3	1	24	57.60	1367.75
1300	1300	2	65	3	2	11	44.05	483.70
1301	1301	6	289	2	1	72	110.60	7962.20
1302	1302	6	117	2	1	66	58.20	3810.80
1303	1303	6	112	4	1	45	81.00	3533.60
1304	1304	5	193	1	1	69	19.70	1396.90
1305	1305	2	259	1	2	15	85.60	1345.55
1306	1306	2	75	1	1	28	59.55	1646.45
1307	1307	3	321	2	2	70	115.55	8127.60
1308	1308	4	126	4	1	36	75.55	2680.15
1309	1309	2	260	3	2	16	86.60	1281.00
1310	1310	2	260	3	2	18	85.20	1553.90
1311	1311	2	261	3	2	34	97.65	3207.55
1312	1312	4	26	2	1	42	45.10	2049.05
1313	1313	4	231	1	1	48	70.95	3629.20
1314	1314	2	289	3	2	47	109.55	5124.55
1315	1315	4	286	3	2	39	89.55	3474.45
1316	1316	5	193	2	1	11	20.90	202.30
1317	1317	2	193	4	1	7	19.95	147.50
1318	1318	1	322	4	1	3	24.60	86.35
1319	1319	2	106	3	1	8	66.70	579.00
1320	1320	2	193	4	2	1	19.45	19.45
1321	1321	3	186	4	1	32	94.80	3131.55
1322	1322	4	125	1	1	60	65.85	3928.30
1323	1323	2	193	1	1	10	19.95	187.75
1324	1324	6	322	1	1	71	24.65	1710.15
1325	1325	1	193	4	2	4	20.35	76.35
1326	1326	2	129	3	2	1	69.25	69.25
1327	1327	4	55	1	1	43	51.25	2151.60
1328	1328	4	269	1	2	59	99.50	5961.10
1329	1329	1	77	3	1	23	54.25	1221.55
1330	1330	5	193	1	1	72	19.40	1496.45
1331	1331	4	101	2	1	22	56.25	1292.20
1332	1332	2	1	4	1	1	25.15	25.15
1333	1333	5	322	1	1	69	23.95	1713.10
1334	1334	4	37	4	1	50	35.40	1748.90
1335	1335	2	1	3	2	1	25.20	25.20
1336	1336	2	65	4	2	2	45.00	96.45
1337	1337	1	145	1	1	15	75.35	1114.55
1338	1338	5	193	1	1	31	20.40	609.10
1339	1339	1	193	4	2	1	20.15	20.15
1340	1340	2	285	2	2	66	105.00	7133.25
1341	1341	5	63	2	1	0	56.05	\N
1342	1342	2	67	2	2	3	54.70	169.45
1343	1343	5	193	4	1	8	20.00	141.60
1344	1344	4	108	2	1	64	73.05	4688.65
1345	1345	1	193	4	1	28	20.50	563.05
1346	1346	4	269	2	1	57	100.75	5985.00
1347	1347	2	267	3	2	14	87.25	1258.60
1348	1348	6	193	4	1	19	19.95	373.50
1349	1349	2	131	3	2	10	79.95	857.20
1350	1350	2	20	3	1	51	49.65	2553.35
1351	1351	5	250	4	1	67	65.65	4322.85
1352	1352	2	193	3	1	11	20.45	250.80
1353	1353	5	48	1	1	72	60.95	4549.05
1354	1354	4	193	3	1	66	20.35	1359.50
1355	1355	2	264	3	2	18	88.35	1639.30
1356	1356	2	193	3	1	9	19.50	178.85
1357	1357	2	258	2	1	9	75.20	633.85
1358	1358	2	317	1	1	48	111.45	5315.10
1359	1359	1	129	4	1	10	70.15	735.50
1360	1360	2	261	3	2	9	94.75	889.90
1361	1361	2	261	3	2	13	95.05	1290.00
1362	1362	1	274	3	2	4	78.45	330.05
1363	1363	2	129	3	2	4	70.20	237.95
1364	1364	5	257	1	1	72	92.00	6474.40
1365	1365	5	128	2	1	51	85.50	4421.95
1366	1366	2	18	1	2	59	41.05	2452.70
1367	1367	2	260	3	2	10	85.60	813.85
1368	1368	2	274	3	1	61	82.15	4904.85
1369	1369	3	173	3	1	54	84.40	4484.05
1370	1370	2	242	4	1	33	60.90	2033.85
1371	1371	6	193	1	1	27	20.25	538.20
1372	1372	2	131	3	2	1	79.20	79.20
1373	1373	1	148	4	1	23	95.30	2192.90
1374	1374	1	193	4	1	1	19.85	19.85
1375	1375	6	128	4	1	45	84.35	3858.05
1376	1376	6	193	1	1	39	19.85	854.80
1377	1377	4	76	4	2	5	70.00	347.40
1378	1378	5	256	1	1	72	82.30	5815.15
1379	1379	2	212	1	1	58	66.80	3970.40
1380	1380	6	61	1	1	70	44.60	3058.15
1381	1381	4	152	1	1	61	98.45	6145.20
1382	1382	1	129	4	1	2	70.70	129.20
1383	1383	3	322	4	1	46	24.95	1165.90
1384	1384	2	194	1	2	1	49.95	49.95
1385	1385	2	129	3	2	22	69.25	1554.00
1386	1386	6	176	2	1	48	102.50	4904.25
1387	1387	5	225	2	1	64	86.55	5632.55
1388	1388	5	322	1	1	72	24.30	1643.25
1389	1389	2	75	2	1	12	58.35	740.55
1390	1390	2	283	3	2	34	94.25	3217.55
1391	1391	5	122	2	1	72	68.75	4888.20
1392	1392	2	282	3	1	29	85.80	2440.25
1393	1393	3	193	2	1	33	20.10	620.55
1394	1394	1	193	4	1	1	20.35	20.35
1395	1395	4	289	3	1	62	110.80	6840.95
1396	1396	4	205	3	2	41	73.00	3001.20
1397	1397	4	269	2	2	64	100.05	6254.20
1398	1398	2	138	2	1	4	82.85	319.60
1399	1399	2	294	3	1	24	84.35	1938.05
1400	1400	3	193	4	1	14	19.55	294.50
1401	1401	1	193	4	1	3	19.95	58.30
1402	1402	2	156	2	2	4	99.80	442.85
1403	1403	2	2	3	2	18	35.00	553.00
1404	1404	2	68	3	1	8	66.25	546.45
1405	1405	5	322	1	1	35	23.30	797.10
1406	1406	1	258	3	2	1	76.00	76.00
1407	1407	6	322	2	1	66	25.30	1673.80
1408	1408	6	38	4	1	8	44.55	343.45
1409	1409	4	301	2	1	71	104.10	7412.25
1410	1410	2	267	1	1	43	92.55	4039.00
1411	1411	2	261	3	2	2	93.85	170.85
1412	1412	2	156	1	1	29	101.45	2948.60
1413	1413	2	139	3	2	15	84.30	1308.40
1414	1414	5	318	2	1	65	94.55	6078.75
1415	1415	1	272	3	1	35	95.50	3418.20
1416	1416	4	180	2	1	64	100.30	6603.80
1417	1417	6	16	2	1	58	55.50	3166.90
1418	1418	2	81	2	1	18	49.85	865.75
1419	1419	2	275	1	1	67	89.55	6373.10
1420	1420	6	193	4	1	63	19.15	1177.05
1421	1421	2	277	3	1	60	99.80	5985.75
1422	1422	2	259	2	2	9	84.40	732.50
1423	1423	6	321	2	1	70	113.05	7869.05
1424	1424	2	269	3	2	15	101.10	1504.05
1425	1425	3	193	4	1	48	19.95	936.70
1426	1426	2	80	3	1	12	74.15	741.40
1427	1427	4	318	3	1	71	92.00	6585.20
1428	1428	1	137	3	1	44	73.85	3122.40
1429	1429	2	194	3	2	1	50.45	50.45
1430	1430	5	322	4	1	45	24.45	1088.25
1431	1431	3	322	2	1	23	24.80	615.35
1432	1432	4	200	1	1	43	64.85	2908.20
1433	1433	1	193	1	1	35	20.75	739.90
1434	1434	2	119	4	1	9	68.95	593.85
1435	1435	2	265	4	2	12	99.95	1132.75
1436	1436	2	317	2	1	65	109.40	7227.45
1437	1437	2	268	3	2	2	91.40	193.60
1438	1438	1	194	4	1	27	49.00	1291.35
1439	1439	4	73	4	1	40	50.25	2023.55
1440	1440	2	137	2	2	5	75.55	349.65
1441	1441	3	193	2	1	8	19.90	153.95
1442	1442	4	277	1	1	58	97.80	5458.80
1443	1443	3	172	3	1	52	100.30	5244.45
1444	1444	2	77	4	1	3	55.80	154.55
1445	1445	6	192	3	1	41	111.15	4507.15
1446	1446	2	265	4	1	20	98.55	2031.95
1447	1447	2	194	3	1	1	50.05	50.05
1448	1448	1	262	2	2	4	80.80	332.45
1449	1449	1	193	3	1	23	20.85	473.90
1450	1450	1	193	1	1	6	19.50	106.80
1451	1451	2	193	4	1	8	19.35	152.60
1452	1452	1	236	4	1	18	69.50	1199.40
1453	1453	2	36	2	1	52	48.80	2555.05
1454	1454	2	148	3	1	31	94.50	2979.20
1455	1455	2	193	4	1	29	20.65	654.85
1456	1456	6	319	2	1	36	106.05	3834.40
1457	1457	2	277	3	2	16	100.00	1534.75
1458	1458	4	273	3	1	42	108.30	4586.15
1459	1459	1	193	3	2	1	20.55	20.55
1460	1460	6	156	3	1	60	99.65	5941.05
1461	1461	2	282	3	2	5	85.30	424.15
1462	1462	1	296	2	1	22	95.90	2234.95
1463	1463	3	193	4	1	36	20.00	666.75
1464	1464	1	129	3	2	4	70.40	281.00
1465	1465	1	102	4	1	9	64.95	547.80
1466	1466	1	145	2	1	1	74.60	74.60
1467	1467	2	97	3	1	12	49.20	571.15
1468	1468	4	201	4	1	23	73.75	1756.60
1469	1469	4	307	1	1	62	92.30	5731.45
1470	1470	1	265	1	2	37	98.80	3475.55
1471	1471	1	193	4	1	8	19.20	156.85
1472	1472	1	268	2	1	31	88.65	2683.20
1473	1473	2	258	2	2	13	74.40	896.75
1474	1474	2	269	3	2	24	98.75	2407.30
1475	1475	2	283	1	1	45	95.95	4456.65
1476	1476	5	281	2	1	69	105.40	6998.95
1477	1477	1	193	4	1	2	20.25	36.80
1478	1478	4	309	3	2	61	106.00	6547.70
1479	1479	2	285	3	2	41	104.70	4346.40
1480	1480	4	12	3	1	44	49.05	2265.00
1481	1481	3	13	4	1	39	35.55	1309.15
1482	1482	6	64	2	1	72	65.10	4754.30
1483	1483	2	140	3	1	13	96.85	1235.55
1484	1484	4	118	2	1	51	69.75	3562.50
1485	1485	6	156	3	1	71	99.20	7213.75
1486	1486	2	261	3	2	22	96.70	2082.95
1487	1487	2	85	2	2	2	55.05	102.75
1488	1488	4	285	3	1	56	106.80	5914.40
1489	1489	1	97	4	1	1	51.25	51.25
1490	1490	4	117	4	1	23	57.75	1282.85
1491	1491	4	220	1	1	66	70.85	4738.85
1492	1492	1	193	4	1	1	19.55	19.55
1493	1493	2	276	3	2	19	88.20	1775.80
1494	1494	2	169	1	1	11	79.50	795.65
1495	1495	4	193	4	2	8	19.75	145.00
1496	1496	1	315	1	1	52	98.15	4993.40
1497	1497	2	193	3	1	3	20.25	61.45
1498	1498	2	177	1	1	51	79.15	4018.55
1499	1499	1	258	3	2	15	75.65	1146.65
1500	1500	2	283	3	1	64	94.25	6081.40
1501	1501	2	10	2	1	37	40.20	1478.85
1502	1502	5	193	4	1	13	19.95	243.65
1503	1503	4	226	3	1	49	55.35	2633.95
1504	1504	4	269	1	1	45	102.15	4735.35
1505	1505	2	129	3	1	18	71.10	1247.75
1506	1506	2	258	3	2	1	74.70	74.70
1507	1507	6	44	1	1	68	54.10	3794.50
1508	1508	5	193	2	1	54	19.65	1008.70
1509	1509	2	154	1	1	23	88.45	2130.55
1510	1510	2	137	3	2	17	76.65	1313.55
1511	1511	5	255	2	1	71	80.40	5727.15
1512	1512	6	193	1	1	67	19.25	1372.90
1513	1513	2	260	3	1	14	84.80	1203.90
1514	1514	2	1	4	2	1	25.80	25.80
1515	1515	5	193	2	1	63	19.50	1215.10
1516	1516	4	207	3	1	41	68.60	2877.05
1517	1517	1	261	3	1	17	92.60	1579.70
1518	1518	4	293	3	1	56	100.55	5514.95
1519	1519	1	193	2	1	5	20.55	96.10
1520	1520	2	50	3	2	2	42.60	72.40
1521	1521	2	193	4	1	3	19.60	55.25
1522	1522	3	254	3	1	37	67.45	2443.30
1523	1523	2	122	1	2	29	68.85	1970.50
1524	1524	1	65	4	1	8	43.55	335.40
1525	1525	2	289	2	1	63	109.85	7002.95
1526	1526	1	193	4	1	7	20.65	158.95
1527	1527	1	148	3	1	3	95.40	293.15
1528	1528	5	193	1	1	72	21.00	1493.75
1529	1529	2	66	3	1	19	56.20	1093.40
1530	1530	5	193	1	1	59	18.40	1057.85
1531	1531	1	142	2	2	2	90.00	190.05
1532	1532	2	322	3	1	35	25.75	882.55
1533	1533	1	193	2	1	14	19.60	300.40
1534	1534	1	137	3	2	14	75.35	1025.95
1535	1535	5	193	2	1	69	19.80	1436.95
1536	1536	1	246	3	1	7	64.20	475.00
1537	1537	6	127	1	1	69	75.75	5388.15
1538	1538	6	217	3	1	72	78.95	5730.15
1539	1539	1	277	3	2	8	100.85	819.55
1540	1540	1	97	3	1	4	50.30	217.10
1541	1541	2	153	2	1	63	80.30	4896.35
1542	1542	5	193	1	1	72	19.85	1434.10
1543	1543	6	193	3	1	46	21.10	937.10
1544	1544	1	129	3	2	5	69.95	330.15
1545	1545	2	73	4	1	30	50.00	1474.90
1546	1546	6	285	1	1	63	104.75	6536.50
1547	1547	5	193	1	1	60	19.85	1128.10
1548	1548	4	285	3	2	63	107.50	6873.75
1549	1549	1	135	3	1	25	85.90	2199.05
1550	1550	2	65	4	2	1	45.85	45.85
1551	1551	2	266	3	1	6	80.80	457.10
1552	1552	5	322	4	1	22	25.25	566.50
1553	1553	5	217	1	1	31	80.55	2471.60
1554	1554	2	141	1	1	39	81.50	3107.30
1555	1555	1	193	4	1	26	20.90	518.30
1556	1556	4	188	1	2	53	106.10	5769.75
1557	1557	1	151	3	2	1	91.70	91.70
1558	1558	2	246	3	1	12	67.25	832.30
1559	1559	2	283	2	2	16	95.60	1555.65
1560	1560	1	193	4	1	2	20.35	45.30
1561	1561	3	39	1	1	39	45.05	1790.60
1562	1562	2	258	3	2	1	74.95	74.95
1563	1563	1	37	4	1	7	34.65	246.60
1564	1564	1	129	3	1	4	69.35	261.65
1565	1565	2	261	3	2	10	95.35	898.35
1566	1566	2	153	3	1	55	81.55	4509.50
1567	1567	6	92	1	1	72	75.40	5480.25
1568	1568	2	76	2	1	10	67.80	653.15
1569	1569	2	289	3	1	11	111.40	1183.05
1570	1570	1	65	3	1	15	46.30	639.45
1571	1571	5	193	1	1	23	20.40	478.75
1572	1572	1	193	4	1	1	20.05	20.05
1573	1573	1	65	3	2	3	45.00	127.10
1574	1574	4	186	3	1	47	96.10	4391.45
1575	1575	3	193	4	1	15	19.65	270.60
1576	1576	1	156	3	2	66	99.50	6710.50
1577	1577	4	93	1	1	68	60.65	3975.90
1578	1578	3	144	1	2	17	98.60	1704.95
1579	1579	2	71	4	2	7	59.50	415.95
1580	1580	2	130	3	2	12	80.45	950.20
1581	1581	3	219	1	1	21	71.70	1497.05
1582	1582	2	21	4	1	21	36.00	780.15
1583	1583	3	228	1	1	56	65.20	3512.15
1584	1584	2	194	2	1	6	48.95	273.25
1585	1585	6	28	1	1	65	53.50	3517.90
1586	1586	3	233	2	1	42	80.45	3375.90
1587	1587	6	305	1	1	68	109.05	7508.55
1588	1588	5	322	1	1	48	26.30	1245.05
1589	1589	4	281	3	1	50	106.80	5347.95
1590	1590	2	91	3	1	7	64.95	493.65
1591	1591	5	193	3	1	63	19.35	1263.85
1592	1592	1	193	2	1	17	21.10	385.55
1593	1593	2	131	2	2	42	77.95	3384.00
1594	1594	1	193	4	1	4	18.85	84.20
1595	1595	5	322	1	1	62	26.00	1638.70
1596	1596	2	145	3	2	2	74.70	165.40
1597	1597	2	129	3	1	2	70.35	120.25
1598	1598	6	316	1	1	48	96.90	4473.45
1599	1599	5	193	1	1	27	19.55	520.55
1600	1600	6	96	1	1	70	80.40	5717.85
1601	1601	2	268	3	2	1	88.80	88.80
1602	1602	4	284	3	1	46	94.65	4312.50
1603	1603	2	132	3	2	30	90.25	2755.35
1604	1604	2	227	1	2	15	64.65	994.55
1605	1605	3	284	2	1	69	95.75	6511.25
1606	1606	6	193	2	1	65	19.55	1218.65
1607	1607	6	176	2	1	72	104.10	7447.70
1608	1608	2	150	1	2	13	89.05	1169.35
1609	1609	4	193	4	1	17	20.10	279.50
1610	1610	4	305	3	1	51	111.55	5720.35
1611	1611	5	117	2	1	51	60.50	3121.45
1612	1612	6	257	1	1	72	90.95	6468.60
1613	1613	3	282	3	2	67	87.40	5918.80
1614	1614	1	193	4	1	34	19.70	675.60
1615	1615	6	54	1	1	67	50.95	3521.70
1616	1616	4	193	1	1	49	20.05	923.10
1617	1617	6	193	4	1	53	19.40	1110.35
1618	1618	1	206	3	1	27	59.45	1611.65
1619	1619	2	148	3	2	23	94.75	2293.60
1620	1620	6	255	2	1	69	81.50	5553.25
1621	1621	1	5	1	1	2	29.05	44.75
1622	1622	2	260	3	2	35	86.45	3029.10
1623	1623	3	118	4	1	46	70.60	3231.05
1624	1624	6	277	1	1	54	97.20	5129.45
1625	1625	4	277	3	2	56	98.25	5508.35
1626	1626	2	137	1	2	9	75.75	655.90
1627	1627	1	230	1	1	20	59.20	1191.20
1628	1628	2	145	4	1	11	75.90	866.40
1629	1629	2	276	3	1	30	90.05	2627.20
1630	1630	5	122	1	1	68	70.95	4741.45
1631	1631	2	285	3	1	38	102.60	4009.20
1632	1632	2	298	1	2	17	85.35	1463.45
1633	1633	4	285	2	2	48	106.10	5082.80
1634	1634	1	65	3	1	1	43.80	43.80
1635	1635	5	60	3	1	63	59.00	3707.60
1636	1636	4	76	3	1	3	69.95	220.45
1637	1637	3	322	1	1	48	24.35	1133.70
1638	1638	3	5	2	1	66	29.45	1983.15
1639	1639	6	282	2	1	68	84.40	5746.75
1640	1640	2	65	3	2	17	45.05	770.60
1641	1641	3	193	4	1	7	20.65	134.05
1642	1642	6	257	1	1	72	87.10	6230.10
1643	1643	1	193	4	1	29	19.85	573.05
1644	1644	2	142	3	1	37	90.35	3419.30
1645	1645	2	317	4	2	34	109.80	3587.25
1646	1646	2	260	3	2	42	84.65	3541.35
1647	1647	3	246	4	1	59	65.50	3801.30
1648	1648	2	131	1	2	11	79.50	868.50
1649	1649	2	290	3	1	60	80.95	4859.10
1650	1650	2	85	4	1	27	56.15	1439.35
1651	1651	1	259	4	2	1	85.80	85.80
1652	1652	2	131	3	2	1	79.10	79.10
1653	1653	1	41	4	1	17	34.40	592.75
1654	1654	5	193	4	1	58	20.75	1185.95
1655	1655	3	193	4	1	1	18.80	18.80
1656	1656	1	65	4	2	3	44.30	134.50
1657	1657	1	314	3	1	53	90.80	4921.20
1658	1658	2	322	3	1	35	25.60	901.25
1659	1659	1	301	2	2	50	105.95	5341.80
1660	1660	5	215	2	1	68	70.80	4859.95
1661	1661	1	322	3	1	47	25.40	1139.20
1662	1662	2	285	1	1	65	108.80	7082.45
1663	1663	2	129	3	2	5	69.75	324.60
1664	1664	2	261	3	2	51	94.65	4812.75
1665	1665	1	261	1	2	46	96.05	4399.50
1666	1666	2	258	3	1	9	76.85	663.55
1667	1667	5	193	4	1	8	20.25	174.65
1668	1668	4	322	2	1	14	24.80	321.70
1669	1669	2	321	3	1	45	115.65	5125.50
1670	1670	2	258	2	1	8	74.60	548.90
1671	1671	2	73	4	2	1	50.15	50.15
1672	1672	4	188	1	1	66	103.15	7031.30
1673	1673	5	254	2	1	72	72.10	5016.65
1674	1674	2	321	1	2	41	113.60	4594.95
1675	1675	5	322	4	1	23	25.10	611.45
1676	1676	2	131	3	2	29	78.90	2384.15
1677	1677	2	290	3	1	4	80.15	319.85
1678	1678	5	322	4	1	6	25.40	153.30
1679	1679	4	319	2	1	67	105.40	7035.60
1680	1680	2	65	4	1	7	45.75	344.20
1681	1681	4	322	4	1	56	24.45	1431.65
1682	1682	5	322	2	1	72	25.00	1849.20
1683	1683	6	253	3	1	72	85.25	6083.10
1684	1684	5	193	2	1	23	19.60	426.65
1685	1685	1	194	4	1	35	50.15	1655.35
1686	1686	2	129	3	1	27	70.55	1943.90
1687	1687	2	214	3	2	26	60.05	1616.15
1688	1688	3	322	4	1	12	26.40	314.95
1689	1689	5	193	4	1	40	20.15	804.85
1690	1690	1	60	4	1	7	58.85	465.70
1691	1691	2	308	2	1	70	97.55	6669.05
1692	1692	5	193	2	1	60	19.65	1161.75
1693	1693	4	1	2	1	39	25.25	947.75
1694	1694	5	321	2	1	72	114.45	8375.05
1695	1695	2	3	3	2	1	34.70	34.70
1696	1696	4	216	3	1	54	70.70	3770.00
1697	1697	2	259	3	2	3	85.30	264.80
1698	1698	5	127	2	1	63	75.55	4707.85
1699	1699	6	278	3	1	71	84.80	6152.40
1700	1700	4	193	4	1	42	20.65	958.10
1701	1701	5	193	1	1	47	20.45	943.00
1702	1702	4	285	2	2	66	102.45	6615.15
1703	1703	2	301	1	2	21	104.40	2200.25
1704	1704	2	21	3	1	11	35.65	425.10
1705	1705	2	269	3	2	1	99.75	99.75
1706	1706	1	286	3	1	55	90.45	5044.80
1707	1707	6	288	2	1	69	97.65	6743.55
1708	1708	1	137	3	1	3	73.85	196.40
1709	1709	2	80	3	2	4	74.40	299.70
1710	1710	6	208	2	1	30	69.10	2093.90
1711	1711	2	270	3	1	5	82.75	417.75
1712	1712	6	322	2	1	71	24.40	1725.40
1713	1713	4	210	3	1	29	55.25	1620.20
1714	1714	1	214	1	1	52	61.35	3169.55
1715	1715	3	251	2	1	68	76.75	5233.25
1716	1716	5	193	4	1	46	19.40	967.85
1717	1717	2	66	2	1	8	54.75	438.05
1718	1718	5	193	2	1	72	19.70	1421.90
1719	1719	3	193	1	1	17	19.90	323.15
1720	1720	2	160	3	1	3	107.95	318.60
1721	1721	2	147	1	1	2	83.80	163.70
1722	1722	2	161	2	2	9	74.25	639.65
1723	1723	4	28	2	1	51	56.40	2928.50
1724	1724	5	193	4	1	6	20.10	100.35
1725	1725	1	261	3	1	3	94.90	273.20
1726	1726	2	261	3	1	17	94.20	1608.15
1727	1727	1	194	3	1	30	49.90	1441.95
1728	1728	2	216	3	1	31	71.05	2168.15
1837	1837	2	136	3	2	24	96.00	2122.45
1729	1729	5	112	1	1	45	81.65	3618.70
1730	1730	3	314	1	1	64	89.45	5692.65
1731	1731	2	196	3	2	1	59.85	59.85
1732	1732	2	129	3	2	1	69.60	69.60
1733	1733	3	277	3	1	61	99.00	5969.30
1734	1734	1	193	4	1	1	19.05	19.05
1735	1735	2	4	3	2	9	45.40	418.80
1736	1736	5	321	1	1	72	114.45	8100.55
1737	1737	1	193	4	2	1	19.50	19.50
1738	1738	2	65	4	1	7	44.25	313.45
1739	1739	4	286	1	1	66	90.55	6130.95
1740	1740	2	129	3	2	1	69.90	69.90
1741	1741	2	193	1	1	40	20.40	745.30
1742	1742	2	219	1	1	16	71.40	1212.10
1743	1743	2	147	1	2	2	87.15	183.75
1744	1744	5	322	2	1	67	24.85	1583.50
1745	1745	4	188	1	1	41	104.45	4162.05
1746	1746	6	193	2	1	56	19.80	1119.90
1747	1747	6	321	1	1	72	116.45	8013.55
1748	1748	2	259	1	2	3	84.75	264.85
1749	1749	5	193	2	1	54	20.05	1102.40
1750	1750	2	289	3	1	52	110.75	5832.00
1751	1751	6	142	1	1	50	89.70	4304.50
1752	1752	2	264	3	2	14	89.95	1178.40
1753	1753	3	97	2	1	27	48.70	1421.75
1754	1754	6	318	1	1	72	96.60	6827.50
1755	1755	4	116	2	1	62	74.30	4698.05
1756	1756	2	85	3	1	12	54.30	654.50
1757	1757	3	80	1	1	44	74.85	3268.05
1758	1758	6	149	1	1	54	79.95	4362.05
1759	1759	5	193	1	1	68	20.05	1386.90
1760	1760	1	193	4	1	20	19.40	415.40
1761	1761	3	202	1	1	50	54.90	2614.10
1762	1762	6	322	2	1	58	24.45	1513.60
1763	1763	2	276	1	1	35	89.65	3161.60
1764	1764	2	65	3	1	2	45.40	80.95
1765	1765	5	239	4	1	63	75.70	4676.70
1766	1766	4	317	2	1	58	110.65	6526.65
1767	1767	4	193	4	1	27	20.55	583.30
1768	1768	6	321	2	1	71	115.15	8078.10
1769	1769	3	74	2	1	63	58.55	3503.50
1770	1770	2	283	1	1	71	93.25	6669.45
1771	1771	2	317	3	2	41	113.20	4689.50
1772	1772	2	132	3	2	13	90.50	1201.15
1773	1773	1	131	3	2	2	79.00	143.65
1774	1774	6	193	1	1	68	19.35	1292.65
1775	1775	2	97	4	1	1	48.75	48.75
1776	1776	6	305	3	1	65	109.05	7108.20
1777	1777	6	322	1	1	72	25.00	1802.55
1778	1778	2	198	2	1	28	54.90	1505.15
1779	1779	5	322	2	1	72	24.75	1859.10
1780	1780	2	179	3	1	2	91.15	168.50
1781	1781	3	193	1	2	18	20.15	390.85
1782	1782	4	285	3	1	60	104.35	6339.45
1783	1783	2	199	3	1	26	66.05	1652.40
1784	1784	2	129	3	2	1	71.65	71.65
1785	1785	1	193	4	2	4	20.35	77.50
1786	1786	6	257	2	1	68	92.20	6392.85
1787	1787	2	157	2	2	38	84.25	3264.50
1788	1788	4	301	1	1	42	105.20	4599.15
1789	1789	6	193	1	1	57	19.60	1134.25
1790	1790	1	17	3	1	54	30.40	1621.35
1791	1791	1	130	1	2	12	78.10	947.30
1792	1792	4	121	4	1	44	61.50	2722.20
1793	1793	2	244	1	1	42	69.40	3058.30
1794	1794	5	322	1	1	72	24.75	1769.60
1795	1795	5	257	4	1	71	91.05	6293.75
1796	1796	1	267	4	2	19	89.65	1761.05
1797	1797	2	201	2	1	23	73.65	1642.75
1798	1798	5	193	2	1	30	19.40	578.50
1799	1799	3	322	1	1	35	26.20	954.90
1800	1800	2	293	3	2	10	98.70	973.25
1801	1801	2	65	1	1	1	43.85	43.85
1802	1802	2	129	4	1	22	69.70	1490.40
1803	1803	5	57	4	1	7	38.55	280.00
1804	1804	6	62	4	1	36	53.10	1901.25
1805	1805	1	193	4	1	34	20.65	716.40
1806	1806	5	250	2	1	72	64.45	4720.00
1807	1807	5	322	2	1	36	25.10	930.95
1808	1808	1	137	3	2	1	76.35	76.35
1809	1809	2	274	3	2	23	79.15	1676.95
1810	1810	2	259	3	2	32	85.00	2642.05
1811	1811	4	318	2	1	71	95.15	6770.85
1812	1812	2	266	4	1	23	79.35	1835.30
1813	1813	4	140	1	1	17	96.65	1588.25
1814	1814	2	80	3	1	1	75.50	75.50
1815	1815	5	193	4	1	12	19.70	258.35
1816	1816	5	193	2	1	72	20.50	1502.25
1817	1817	1	193	4	1	1	19.20	19.20
1818	1818	5	277	1	1	72	98.35	6929.40
1819	1819	1	258	1	1	60	74.35	4453.30
1820	1820	5	31	2	1	61	51.35	3244.40
1821	1821	1	65	4	1	6	45.65	323.45
1822	1822	1	259	3	2	32	85.30	2661.10
1823	1823	2	260	2	2	31	86.55	2697.40
1824	1824	2	145	2	2	19	73.85	1424.50
1825	1825	5	193	1	1	72	20.30	1401.15
1826	1826	2	210	3	1	32	54.20	1739.60
1827	1827	2	275	3	1	65	90.65	5931.00
1828	1828	2	36	1	1	45	50.90	2333.85
1829	1829	3	322	3	1	42	25.05	949.85
1830	1830	2	258	3	1	8	74.85	572.45
1831	1831	5	193	4	1	32	20.50	696.80
1832	1832	2	246	4	1	22	63.55	1381.80
1833	1833	2	4	3	2	57	44.85	2572.95
1834	1834	1	97	3	1	1	47.95	47.95
1835	1835	1	65	3	2	1	45.10	45.10
1836	1836	2	65	3	1	1	45.00	45.00
1838	1838	1	193	1	2	1	20.05	20.05
1839	1839	2	275	3	1	54	90.05	4931.80
1840	1840	6	322	2	1	4	25.30	116.95
1841	1841	5	305	1	2	65	108.65	6937.95
1842	1842	3	322	3	1	56	24.30	1261.70
1843	1843	2	108	3	1	45	75.95	3273.80
1844	1844	5	193	2	1	71	19.70	1415.85
1845	1845	3	123	2	1	59	66.40	3958.20
1846	1846	4	25	1	1	69	35.75	2492.25
1847	1847	3	193	4	1	19	18.80	279.20
1848	1848	5	193	2	1	55	19.40	1083.00
1849	1849	3	193	4	1	38	19.30	755.50
1850	1850	2	65	3	2	10	45.55	402.60
1851	1851	2	250	2	1	47	67.45	3252.00
1852	1852	2	2	3	2	2	35.10	68.75
1853	1853	1	65	2	2	1	46.20	46.20
1854	1854	1	65	3	2	1	45.15	45.15
1855	1855	2	26	3	2	1	43.30	43.30
1856	1856	6	193	4	1	46	20.10	936.85
1857	1857	2	113	2	2	38	57.15	2250.65
1858	1858	5	109	2	1	65	58.90	3857.10
1859	1859	2	161	3	2	19	73.20	1441.10
1860	1860	2	146	3	2	52	85.35	4338.60
1861	1861	5	193	4	1	71	19.45	1378.45
1862	1862	1	65	4	2	1	45.95	45.95
1863	1863	2	31	3	1	52	50.50	2566.30
1864	1864	3	322	4	1	6	25.10	171.00
1865	1865	3	74	4	1	26	60.70	1597.40
1866	1866	4	277	3	1	48	99.00	4744.35
1867	1867	4	297	1	1	64	104.40	6721.60
1868	1868	1	147	3	2	3	83.75	247.25
1869	1869	2	65	1	1	1	44.05	44.05
1870	1870	5	322	2	1	72	24.10	1734.65
1871	1871	2	65	4	1	1	45.55	45.55
1872	1872	2	307	3	1	51	93.80	4539.35
1873	1873	5	193	1	1	41	19.70	804.25
1874	1874	6	123	2	1	72	70.65	5011.15
1875	1875	5	249	2	1	43	86.45	3574.50
1876	1876	6	321	2	1	72	114.10	8086.40
1877	1877	4	261	2	1	47	95.20	4563.00
1878	1878	5	257	2	1	72	88.55	6362.35
1879	1879	2	193	2	1	3	20.75	67.10
1880	1880	2	129	3	2	1	70.05	70.05
1881	1881	2	259	3	2	2	86.00	165.45
1882	1882	2	50	1	1	26	44.65	1156.55
1883	1883	2	98	4	1	29	60.20	1834.15
1884	1884	2	312	1	2	35	100.50	3653.35
1885	1885	3	113	1	1	27	55.45	1477.65
1886	1886	2	118	2	1	24	70.30	1706.45
1887	1887	6	109	1	1	67	60.40	3953.70
1888	1888	1	258	3	2	16	72.65	1194.30
1889	1889	3	89	1	1	23	55.80	1327.85
1890	1890	2	17	4	1	14	31.10	419.70
1891	1891	2	193	3	2	1	21.00	21.00
1892	1892	1	65	4	2	1	45.10	45.10
1893	1893	2	20	2	1	4	50.95	207.35
1894	1894	2	243	3	1	16	69.10	1083.70
1895	1895	2	4	3	1	46	43.95	2007.85
1896	1896	6	249	1	1	68	86.50	5882.75
1897	1897	1	254	3	1	38	69.95	2657.55
1898	1898	2	81	1	2	30	50.40	1527.50
1899	1899	1	130	3	2	5	78.95	378.40
1900	1900	2	154	2	1	17	90.95	1612.20
1901	1901	5	193	4	1	4	19.90	76.65
1902	1902	3	193	3	1	12	20.15	260.70
1903	1903	6	257	2	1	72	90.60	6441.85
1904	1904	2	132	3	1	3	92.00	266.80
1905	1905	2	279	3	2	56	94.45	5124.60
1906	1906	4	322	4	1	41	24.85	962.25
1907	1907	3	21	2	1	40	36.00	1382.90
1908	1908	2	120	3	1	7	78.50	571.05
1909	1909	5	193	2	1	69	19.95	1399.35
1910	1910	3	193	4	1	7	20.65	150.00
1911	1911	2	17	3	1	5	30.50	167.20
1912	1912	5	320	2	1	72	106.10	7657.40
1913	1913	4	193	1	1	44	20.50	865.05
1914	1914	4	284	3	1	65	95.50	6153.85
1915	1915	1	200	3	1	3	64.60	174.20
1916	1916	2	69	2	1	24	51.10	1269.60
1917	1917	2	282	1	2	44	84.80	3862.55
1918	1918	5	257	2	1	72	89.10	6352.40
1919	1919	1	101	3	1	24	54.95	1348.50
1920	1920	1	73	4	2	1	50.90	50.90
1921	1921	2	193	1	1	22	20.45	471.55
1922	1922	6	225	2	1	70	85.95	5931.75
1923	1923	1	196	3	1	25	60.35	1404.65
1924	1924	5	193	1	1	37	19.80	726.10
1925	1925	1	260	1	1	22	85.35	1961.60
1926	1926	6	208	1	1	59	72.10	4194.85
1927	1927	2	269	3	2	49	99.80	4872.45
1928	1928	2	273	1	2	47	107.35	5118.95
1929	1929	2	193	4	2	31	19.55	658.95
1930	1930	2	130	3	1	1	81.05	81.05
1931	1931	2	193	3	1	3	20.50	76.95
1932	1932	4	289	1	1	53	111.80	5809.75
1933	1933	1	193	4	1	1	20.20	20.20
1934	1934	4	193	4	1	20	19.70	415.90
1935	1935	2	177	3	2	3	79.10	246.50
1936	1936	4	193	1	1	51	19.85	996.95
1937	1937	4	117	1	1	51	60.50	3145.15
1938	1938	5	193	4	1	13	19.55	265.30
1939	1939	1	193	4	1	1	20.90	20.90
1940	1940	2	193	4	1	1	21.05	21.05
1941	1941	3	254	3	1	63	71.50	4576.30
1942	1942	1	66	4	1	3	54.65	189.10
1943	1943	5	193	2	1	46	19.20	908.15
1944	1944	2	194	2	1	1	49.80	49.80
1945	1945	1	1	4	2	8	25.50	215.20
1946	1946	5	193	1	1	71	20.50	1500.95
1947	1947	2	268	2	1	55	90.40	5099.15
1948	1948	4	286	1	1	70	90.25	6385.95
1949	1949	1	130	3	2	2	80.75	159.45
1950	1950	5	297	1	1	67	104.60	6885.75
1951	1951	2	276	1	2	65	91.85	5940.85
1952	1952	1	73	2	1	14	50.20	668.85
1953	1953	2	271	1	1	20	95.50	1916.20
1954	1954	2	145	3	2	1	75.35	75.35
1955	1955	2	258	3	2	1	75.45	75.45
1956	1956	2	261	1	1	49	95.40	4613.95
1957	1957	6	316	1	1	72	101.30	7261.25
1958	1958	1	226	3	1	46	53.10	2459.80
1959	1959	2	282	1	1	24	84.85	2048.80
1960	1960	1	21	3	1	5	34.25	163.55
1961	1961	1	286	2	1	33	88.60	2888.70
1962	1962	4	242	1	1	42	60.15	2421.60
1963	1963	4	172	2	1	23	99.95	2292.75
1964	1964	1	129	1	1	8	70.70	553.40
1965	1965	4	113	4	1	66	54.80	3465.70
1966	1966	2	97	1	2	24	49.55	1210.40
1967	1967	1	210	2	1	24	54.80	1291.30
1968	1968	4	255	2	2	69	78.60	5356.45
1969	1969	4	156	4	1	53	100.30	5200.80
1970	1970	5	44	3	1	60	53.60	3237.05
1971	1971	2	131	3	2	7	81.10	576.65
1972	1972	4	193	2	1	20	19.35	433.75
1973	1973	1	259	3	1	23	85.60	1868.40
1974	1974	6	112	3	1	72	80.80	5728.55
1975	1975	2	258	3	2	11	74.95	825.70
1976	1976	5	193	4	1	21	19.60	390.40
1977	1977	2	261	3	2	1	93.55	93.55
1978	1978	2	276	3	1	31	90.70	2845.15
1979	1979	5	95	4	1	57	69.75	3894.40
1980	1980	6	193	1	1	45	20.00	886.40
1981	1981	2	283	3	1	10	95.25	1021.55
1982	1982	2	273	2	2	58	102.10	5885.40
1983	1983	1	193	4	1	14	19.95	268.40
1984	1984	3	233	4	1	27	80.85	2204.35
1985	1985	2	275	1	2	14	90.90	1259.00
1986	1986	1	17	4	2	12	29.20	309.10
1987	1987	6	279	1	1	69	93.30	6398.05
1988	1988	2	155	1	2	25	89.15	2257.75
1989	1989	4	317	3	2	58	108.85	6287.25
1990	1990	6	39	2	1	35	46.35	1662.05
1991	1991	2	260	3	2	16	84.75	1350.15
1992	1992	3	221	2	1	45	78.75	3600.65
1993	1993	2	147	3	1	17	83.55	1329.15
1994	1994	2	65	3	2	1	45.70	45.70
1995	1995	3	193	4	1	22	19.60	422.50
1996	1996	2	129	3	2	1	69.95	69.95
1997	1997	5	110	4	1	67	67.85	4627.65
1998	1998	6	273	1	1	67	105.65	6717.90
1999	1999	1	4	3	2	2	44.60	97.10
2000	2000	2	258	3	2	23	74.95	1710.45
2001	2001	1	137	2	1	9	75.50	637.40
2002	2002	1	193	4	1	5	20.15	117.95
2003	2003	5	39	2	1	54	45.20	2460.55
2004	2004	6	140	3	2	57	95.25	5464.65
2005	2005	2	268	4	2	24	89.85	2165.05
2006	2006	3	277	4	2	49	100.45	4941.80
2007	2007	1	194	3	2	5	47.15	223.15
2008	2008	2	130	3	2	2	80.20	181.10
2009	2009	2	270	4	2	4	87.10	341.45
2010	2010	6	256	1	1	70	79.25	5731.85
2011	2011	2	258	1	2	5	75.90	357.75
2012	2012	1	241	3	1	53	85.70	4616.10
2013	2013	2	316	3	2	47	98.75	4533.70
2014	2014	3	193	2	1	31	20.10	589.25
2015	2015	1	93	1	1	13	61.80	750.10
2016	2016	1	194	4	1	28	49.90	1410.25
2017	2017	1	259	3	2	10	86.45	830.85
2018	2018	5	193	1	1	38	20.40	743.50
2019	2019	2	65	4	2	1	45.30	45.30
2020	2020	3	285	3	2	67	104.10	7040.85
2021	2021	4	116	4	1	52	75.40	3865.45
2022	2022	5	192	4	1	62	108.15	6825.65
2023	2023	2	146	3	1	16	86.25	1340.10
2024	2024	2	274	3	2	5	81.00	371.65
2025	2025	3	140	3	1	12	95.70	1184.00
2026	2026	6	321	1	1	72	116.85	8477.70
2027	2027	3	281	1	1	71	105.75	7382.85
2028	2028	3	193	4	1	24	20.15	456.85
2029	2029	5	193	4	1	15	19.60	331.60
2030	2030	4	178	2	2	67	90.60	6056.15
2031	2031	1	242	1	1	2	60.95	134.60
2032	2032	1	1	4	1	5	25.05	125.50
2033	2033	1	132	3	2	15	88.15	1390.60
2034	2034	2	193	4	2	1	20.20	20.20
2035	2035	4	121	1	1	41	60.30	2511.30
2036	2036	2	114	3	1	43	63.95	2737.05
2037	2037	1	258	3	1	1	74.30	74.30
2038	2038	2	129	4	1	1	70.60	70.60
2039	2039	2	132	3	2	26	90.80	2361.80
2040	2040	2	274	3	2	22	79.35	1730.35
2041	2041	5	257	1	1	71	90.55	6404.00
2042	2042	5	193	4	1	7	19.45	165.35
2043	2043	1	222	1	1	28	64.45	1867.60
2044	2044	1	129	3	1	16	69.65	1043.30
2045	2045	3	193	4	1	7	19.50	128.60
2046	2046	6	289	1	1	69	110.50	7455.45
2047	2047	1	1	4	1	1	24.70	24.70
2048	2048	2	108	3	1	3	77.40	206.15
2049	2049	2	140	1	2	21	96.80	2030.30
2050	2050	2	282	1	1	69	85.40	5869.40
2051	2051	6	61	1	1	71	47.60	3377.80
2052	2052	5	193	4	1	69	19.40	1346.20
2053	2053	2	273	3	1	48	103.85	4946.05
2054	2054	2	282	1	2	47	83.35	4065.00
2055	2055	2	194	3	2	2	49.40	106.55
2056	2056	2	305	2	1	45	108.45	4964.70
2057	2057	1	274	1	1	51	81.00	4085.75
2058	2058	2	233	3	2	22	79.20	1742.75
2059	2059	5	257	1	1	72	86.65	6224.80
2060	2060	2	284	3	1	37	92.95	3415.25
2061	2061	5	257	3	1	71	90.35	6325.25
2062	2062	1	73	3	2	7	48.70	340.25
2063	2063	6	322	2	1	66	25.15	1683.60
2064	2064	4	104	1	1	51	76.40	3966.30
2065	2065	3	193	1	1	30	19.55	608.50
2066	2066	1	260	3	1	34	85.35	2896.60
2067	2067	6	322	4	1	64	24.80	1514.85
2068	2068	4	285	1	1	65	103.15	6792.45
2069	2069	1	312	4	1	47	100.75	4669.20
2070	2070	2	164	3	2	1	95.60	95.60
2071	2071	2	242	2	2	49	59.75	2934.30
2072	2072	5	280	2	1	67	94.10	6302.80
2073	2073	3	193	1	1	39	19.35	779.20
2074	2074	1	193	4	1	14	19.90	283.75
2075	2075	2	184	2	2	43	108.15	4600.70
2076	2076	2	269	3	1	56	101.05	5594.00
2077	2077	3	70	2	1	14	59.10	772.85
2078	2078	1	129	3	2	1	71.35	71.35
2079	2079	4	113	4	1	16	55.85	857.80
2080	2080	2	309	3	1	70	106.05	7554.05
2081	2081	6	253	2	1	72	84.10	5981.65
2082	2082	2	137	2	1	23	75.30	1702.90
2083	2083	1	322	4	1	21	24.70	467.15
2084	2084	2	193	4	2	1	20.15	20.15
2085	2085	1	129	1	2	1	69.75	69.75
2086	2086	2	261	3	2	32	93.20	2931.00
2087	2087	1	131	3	2	17	80.85	1400.85
2088	2088	2	49	3	2	4	33.65	137.85
2089	2089	3	202	3	1	36	55.80	1941.50
2090	2090	5	29	2	1	50	39.70	1932.75
2091	2091	2	5	2	1	48	29.50	1423.05
2092	2092	5	193	2	1	50	20.15	970.85
2093	2093	5	255	2	1	72	79.55	5810.90
2094	2094	1	322	2	1	10	24.80	223.90
2095	2095	1	193	4	1	18	19.65	391.70
2096	2096	2	131	3	2	1	79.95	79.95
2097	2097	1	193	3	2	1	19.30	19.30
2098	2098	2	140	3	1	9	94.05	811.65
2099	2099	1	291	4	1	2	90.75	174.75
2100	2100	2	262	2	1	40	78.85	3126.85
2101	2101	3	269	1	1	69	99.50	6841.45
2102	2102	4	303	3	2	37	99.20	3754.60
2103	2103	2	266	2	1	18	80.55	1406.65
2104	2104	2	129	3	1	11	70.20	834.70
2105	2105	2	259	2	2	8	85.20	627.40
2106	2106	1	258	3	2	3	75.25	242.00
2107	2107	3	98	2	1	55	59.45	3157.00
2108	2108	2	283	3	1	33	93.35	3092.00
2109	2109	1	65	1	1	46	44.95	2168.90
2110	2110	5	322	1	1	34	26.10	980.35
2111	2111	1	193	3	1	3	20.20	65.95
2112	2112	5	193	4	1	30	21.25	711.90
2113	2113	3	230	3	1	33	59.40	1952.80
2114	2114	4	283	2	1	45	95.00	4368.85
2115	2115	2	117	4	1	40	61.90	2647.10
2116	2116	6	321	3	1	71	118.65	8477.60
2117	2117	1	202	3	2	1	54.35	54.35
2118	2118	5	64	1	1	72	64.45	4528.00
2119	2119	2	130	3	1	22	80.15	1790.65
2120	2120	4	193	1	1	46	20.20	845.60
2121	2121	5	193	4	1	55	21.00	1210.30
2122	2122	1	193	4	1	1	20.45	20.45
2123	2123	4	201	4	1	12	75.85	854.45
2124	2124	2	274	3	1	31	80.45	2429.10
2125	2125	2	1	3	2	5	24.95	100.40
2126	2126	6	229	3	1	67	75.50	5229.45
2127	2127	1	65	4	1	1	44.45	44.45
2128	2128	4	57	3	2	40	42.35	1716.45
2129	2129	2	252	2	1	41	74.55	3023.55
2130	2130	2	258	3	2	1	75.30	75.30
2131	2131	4	308	3	2	51	94.80	4837.60
2132	2132	5	47	2	1	42	48.15	2032.30
2133	2133	3	193	4	1	23	19.65	436.90
2134	2134	2	129	3	2	1	70.55	70.55
2135	2135	1	193	4	1	1	20.15	20.15
2136	2136	2	309	2	1	56	106.60	5893.95
2137	2137	2	276	3	1	15	91.00	1430.05
2138	2138	6	322	1	1	12	25.40	313.00
2139	2139	5	110	1	1	54	69.95	3871.85
2140	2140	2	68	3	1	7	66.85	458.10
2141	2141	1	259	2	2	33	86.15	2745.70
2142	2142	1	193	3	1	16	20.15	341.35
2143	2143	3	106	4	1	21	64.85	1336.80
2144	2144	5	205	3	1	30	74.85	2181.75
2145	2145	2	69	4	1	3	50.50	147.75
2146	2146	1	137	3	1	11	72.90	818.45
2147	2147	4	321	2	1	62	115.05	7133.45
2148	2148	1	193	3	1	18	19.00	348.80
2149	2149	1	193	4	1	6	19.55	128.60
2150	2150	4	269	3	1	46	101.10	4674.40
2151	2151	2	259	3	1	21	84.10	1737.45
2152	2152	6	322	1	1	68	24.15	1498.85
2153	2153	2	194	3	1	1	50.10	50.10
2154	2154	2	137	3	1	25	74.60	1797.75
2155	2155	5	193	4	1	24	19.75	498.10
2156	2156	2	259	3	2	30	85.00	2624.25
2157	2157	1	130	3	2	2	80.55	184.10
2158	2158	4	285	1	1	51	106.80	5498.80
2159	2159	6	241	3	1	57	84.50	4845.40
2160	2160	5	322	1	1	15	25.05	369.10
2161	2161	6	128	1	1	72	83.70	6096.90
2486	2486	2	266	3	2	14	80.45	1072.00
2162	2162	2	137	3	2	2	75.80	160.75
2163	2163	1	284	2	1	28	96.60	2684.35
2164	2164	2	269	3	2	29	98.50	3004.15
2165	2165	6	191	2	1	70	101.10	6994.80
2166	2166	3	193	4	1	13	20.20	273.25
2167	2167	4	318	3	1	59	94.05	5483.90
2168	2168	2	261	3	2	13	95.25	1233.65
2169	2169	2	258	4	2	7	74.40	527.90
2170	2170	5	112	4	1	62	81.00	4985.90
2171	2171	4	109	3	1	21	60.25	1258.35
2172	2172	1	74	3	1	2	60.85	111.40
2173	2173	1	65	2	1	1	43.95	43.95
2174	2174	1	138	3	1	4	86.05	308.10
2175	2175	3	193	2	1	19	20.25	383.65
2176	2176	1	135	3	2	30	85.15	2555.90
2177	2177	6	193	2	1	67	19.40	1284.20
2178	2178	6	315	2	1	72	102.65	7550.30
2179	2179	5	193	2	1	53	19.90	1110.05
2180	2180	3	193	3	1	5	19.55	99.60
2181	2181	6	158	2	1	71	95.50	6707.15
2182	2182	4	225	2	1	50	84.15	4164.40
2183	2183	6	273	3	1	56	103.20	5873.75
2184	2184	2	69	2	1	2	50.20	109.25
2185	2185	2	267	3	2	2	88.55	179.25
2186	2186	1	226	3	2	24	54.75	1338.15
2187	2187	5	193	2	1	46	19.95	862.40
2188	2188	6	321	3	1	71	116.25	8564.75
2189	2189	2	5	3	1	29	31.20	926.20
2190	2190	5	322	1	1	69	24.45	1718.20
2191	2191	5	225	2	1	71	84.20	5956.85
2192	2192	2	132	3	2	1	91.30	91.30
2193	2193	6	128	1	1	56	85.65	4824.45
2194	2194	4	193	4	1	56	21.20	1238.65
2195	2195	2	131	3	2	1	79.50	79.50
2196	2196	3	322	4	1	28	25.55	672.20
2197	2197	1	193	4	1	19	20.20	382.20
2198	2198	1	199	3	1	66	63.85	4264.60
2199	2199	4	206	4	1	17	61.95	1070.70
2200	2200	5	322	4	1	52	25.75	1345.85
2201	2201	3	83	3	1	19	58.20	1045.25
2202	2202	3	128	1	1	36	85.85	3003.55
2203	2203	2	129	4	2	7	70.10	467.55
2204	2204	4	319	2	1	72	104.90	7537.50
2205	2205	4	317	3	2	67	111.30	7482.10
2206	2206	4	156	3	1	34	99.85	3343.15
2207	2207	2	283	1	2	57	95.25	5427.05
2208	2208	2	139	3	2	7	86.25	587.10
2209	2209	2	269	3	2	1	100.80	100.80
2210	2210	2	193	1	1	8	19.55	161.15
2211	2211	5	273	3	1	69	104.00	7028.50
2212	2212	4	301	4	1	50	104.40	5232.90
2213	2213	3	193	4	1	10	19.50	225.85
2214	2214	5	322	2	1	12	25.25	274.70
2215	2215	2	146	3	2	14	86.30	1180.95
2216	2216	6	46	1	1	70	49.85	3370.20
2217	2217	2	305	1	1	64	108.95	7111.30
2218	2218	5	257	2	1	66	89.90	5958.85
2219	2219	6	112	2	1	71	82.00	5999.85
2220	2220	1	132	3	1	20	89.95	1648.45
2221	2221	6	120	1	1	72	79.35	5753.25
2222	2222	5	125	2	1	71	64.05	4492.90
2223	2223	2	269	2	1	38	101.15	3956.70
2224	2224	2	275	3	2	28	89.95	2625.55
2225	2225	2	145	3	2	17	76.45	1233.40
2226	2226	4	19	3	1	33	39.10	1309.00
2227	2227	5	37	4	1	23	34.60	813.45
2228	2228	4	193	3	1	58	19.55	1108.80
2229	2229	6	281	1	1	70	104.45	7349.35
2230	2230	1	129	3	1	4	70.50	294.20
2231	2231	5	193	4	1	45	20.35	929.20
2232	2232	2	129	3	2	10	70.00	740.00
2233	2233	5	193	2	1	36	19.45	754.50
2234	2234	2	119	4	1	54	69.90	3883.30
2235	2235	5	214	4	1	23	59.70	1414.20
2236	2236	4	252	2	1	41	78.35	3211.20
2237	2237	2	129	4	1	5	71.45	371.60
2238	2238	4	26	2	1	27	45.85	1246.40
2239	2239	2	136	3	1	1	95.85	95.85
2240	2240	5	37	2	1	67	35.70	2545.70
2241	2241	6	257	2	1	72	89.55	6448.85
2242	2242	6	322	2	1	56	24.95	1468.90
2243	2243	3	322	3	1	44	24.85	1013.60
2244	2244	2	277	3	1	66	100.80	6690.75
2245	2245	4	246	4	2	34	64.40	2088.75
2246	2246	5	273	1	1	69	105.35	7240.65
2247	2247	2	301	3	2	1	102.45	102.45
2248	2248	5	193	2	1	40	19.65	830.25
2249	2249	2	226	1	1	30	54.45	1588.70
2250	2250	1	72	4	1	11	70.50	829.30
2251	2251	3	193	2	1	15	20.10	302.45
2252	2252	2	76	3	1	11	69.35	712.25
2253	2253	3	193	1	1	64	19.80	1336.65
2254	2254	5	127	1	1	72	74.40	5360.75
2255	2255	6	318	1	1	72	93.05	6735.05
2256	2256	1	97	4	1	1	51.20	51.20
2257	2257	3	125	2	1	15	65.60	1010.00
2258	2258	3	209	2	1	60	80.55	4847.05
2259	2259	3	105	4	1	56	52.70	3019.70
2260	2260	5	193	4	1	8	20.85	161.65
2261	2261	1	141	2	2	3	80.10	217.55
2262	2262	2	194	2	1	49	52.15	2583.75
2263	2263	2	131	3	2	2	80.20	146.05
2264	2264	2	190	1	2	6	98.15	567.45
2265	2265	6	321	1	1	70	114.95	7711.25
2266	2266	2	289	4	2	12	112.95	1384.75
2267	2267	4	176	1	1	52	104.45	5481.25
2268	2268	6	321	2	1	72	113.65	8124.20
2269	2269	6	193	1	1	40	20.60	827.30
2270	2270	1	129	4	2	1	70.90	70.90
2271	2271	2	139	3	2	3	86.85	220.95
2272	2272	2	132	3	1	40	91.55	3673.60
2273	2273	2	73	3	1	1	49.85	49.85
2274	2274	3	193	2	1	30	19.80	576.65
2275	2275	2	168	3	2	23	99.85	2331.30
2276	2276	2	258	3	2	1	74.50	74.50
2277	2277	1	273	3	1	44	104.15	4495.65
2278	2278	2	289	3	2	65	109.15	6941.20
2279	2279	2	97	3	1	7	48.20	340.35
2280	2280	6	322	2	1	72	25.10	1789.90
2281	2281	2	265	2	1	8	100.15	908.55
2282	2282	2	203	2	2	16	65.20	1043.35
2283	2283	2	269	2	2	66	99.50	6822.15
2284	2284	2	129	4	2	1	71.55	71.55
2285	2285	1	105	4	1	3	55.90	157.55
2286	2286	1	299	3	2	53	93.90	5029.20
2287	2287	2	78	2	1	8	64.40	581.70
2288	2288	6	289	1	2	69	108.40	7318.20
2289	2289	2	147	4	1	5	85.30	420.45
2290	2290	5	305	4	1	72	107.45	7576.70
2291	2291	2	12	1	2	13	48.75	633.40
2292	2292	2	260	3	2	4	85.65	321.65
2293	2293	5	257	2	1	54	91.30	4965.00
2294	2294	5	225	1	1	72	85.95	6151.90
2295	2295	2	285	3	2	12	106.70	1253.90
2296	2296	2	1	3	2	1	25.15	25.15
2297	2297	1	65	3	1	1	45.20	45.20
2298	2298	3	289	3	2	54	110.35	5893.15
2299	2299	6	266	2	1	69	79.20	5420.65
2300	2300	5	113	2	1	48	55.50	2627.35
2301	2301	4	309	2	2	48	103.25	5037.55
2302	2302	2	263	3	1	8	90.25	743.75
2303	2303	6	257	4	1	71	91.25	6589.60
2304	2304	2	97	3	2	2	47.80	92.45
2305	2305	4	180	2	1	67	100.90	6733.15
2306	2306	2	277	1	1	34	97.70	3410.00
2307	2307	2	129	3	1	3	69.85	199.85
2308	2308	4	87	4	1	9	65.60	593.30
2309	2309	4	188	1	1	71	104.65	7288.40
2310	2310	6	264	2	1	57	90.45	5229.80
2311	2311	6	64	1	1	72	63.70	4464.80
2312	2312	2	176	3	1	48	104.50	5068.05
2313	2313	3	193	4	1	18	20.10	401.85
2314	2314	4	273	2	1	43	104.30	4451.85
2315	2315	6	257	1	1	72	93.25	6688.95
2316	2316	4	201	1	1	35	73.45	2661.10
2317	2317	1	193	4	1	4	20.70	73.05
2318	2318	5	322	4	1	49	25.25	1211.65
2319	2319	5	316	1	1	71	100.50	7030.65
2320	2320	1	132	3	1	11	90.60	1020.20
2321	2321	6	257	2	1	63	89.40	5597.65
2322	2322	2	284	1	1	65	95.45	6223.30
2323	2323	5	193	2	1	49	20.45	1024.65
2324	2324	2	269	2	2	29	98.60	2933.20
2325	2325	2	270	3	2	15	83.05	1258.30
2326	2326	2	193	3	1	4	19.95	82.90
2327	2327	3	289	2	1	72	109.15	7789.60
2328	2328	2	139	2	1	26	85.70	2067.00
2329	2329	1	269	1	1	35	102.05	3452.55
2330	2330	3	279	3	1	57	94.70	5468.95
2331	2331	1	211	3	1	28	64.40	1802.15
2332	2332	4	322	4	1	25	26.80	733.55
2333	2333	4	107	2	1	47	66.05	3021.45
2334	2334	1	246	1	1	57	65.20	3687.85
2335	2335	2	260	2	1	16	85.05	1391.15
2336	2336	2	105	4	1	5	55.80	274.35
2337	2337	2	129	1	2	17	70.40	1214.05
2338	2338	4	285	1	2	56	104.75	5510.65
2339	2339	5	193	1	1	72	19.95	1322.85
2340	2340	2	261	3	2	21	94.25	1973.75
2341	2341	3	42	2	1	48	45.00	2196.30
2342	2342	5	321	1	1	68	114.90	7843.55
2343	2343	1	297	1	1	30	106.40	3211.90
2344	2344	2	65	4	1	3	46.10	130.15
2345	2345	5	45	4	1	14	39.70	692.35
2346	2346	2	193	1	1	4	20.05	85.50
2347	2347	6	283	2	1	71	95.75	6849.40
2348	2348	3	322	4	1	8	24.40	203.95
2349	2349	1	41	1	1	61	33.60	2117.20
2350	2350	5	286	1	1	72	90.45	6565.85
2351	2351	2	260	3	1	5	84.00	424.75
2352	2352	5	125	1	1	49	67.40	3306.85
2353	2353	2	193	1	1	8	19.70	168.90
2354	2354	2	130	3	1	3	80.35	253.80
2355	2355	5	193	4	1	9	19.60	197.40
2356	2356	6	113	1	1	67	54.20	3838.20
2357	2357	2	65	2	1	46	45.20	2065.15
2358	2358	3	251	4	1	67	75.10	5064.45
2359	2359	3	193	3	1	55	19.70	1140.05
2360	2360	2	252	1	1	33	72.75	2447.45
2361	2361	5	193	2	1	62	20.05	1263.90
2362	2362	1	65	4	2	1	45.95	45.95
2363	2363	2	34	3	1	49	39.20	1838.15
2364	2364	2	65	3	1	1	44.75	44.75
2365	2365	2	282	3	1	14	82.65	1185.00
2366	2366	1	272	1	1	18	93.90	1743.90
2367	2367	2	129	3	2	1	70.15	70.15
2368	2368	2	139	2	2	1	85.55	85.55
2369	2369	6	321	2	1	72	117.15	8529.50
2370	2370	5	303	2	1	64	99.25	6549.45
2371	2371	6	321	1	1	69	112.55	7806.50
2372	2372	2	322	3	1	1	25.70	25.70
2373	2373	5	257	2	1	71	90.30	6287.30
2374	2374	4	69	2	1	66	49.40	3251.85
2375	2375	1	193	4	1	2	19.40	50.60
2376	2376	6	192	1	1	71	109.70	7904.25
2377	2377	4	83	3	1	11	61.25	729.95
2378	2378	2	113	3	1	47	55.30	2654.05
2379	2379	2	129	3	2	35	70.30	2416.55
2380	2380	1	285	1	2	32	106.35	3520.75
2381	2381	2	281	1	1	60	103.75	5969.95
2382	2382	3	193	4	1	11	19.50	226.80
2383	2383	3	53	2	1	29	39.50	1082.75
2384	2384	2	1	3	1	21	26.05	565.75
2385	2385	2	267	2	1	48	91.05	4370.75
2386	2386	1	17	4	1	3	29.65	90.05
2387	2387	1	81	4	1	43	50.20	2169.40
2388	2388	1	285	3	1	5	105.30	550.60
2389	2389	2	66	3	1	1	55.45	55.45
2390	2390	3	241	3	1	71	85.45	6300.85
2391	2391	3	193	3	1	8	19.80	160.05
2392	2392	2	196	3	1	8	59.25	436.60
2393	2393	2	268	2	1	20	90.70	1781.35
2394	2394	4	301	4	2	33	103.70	3467.00
2395	2395	4	274	2	1	71	79.05	5552.50
2396	2396	4	268	3	1	31	90.70	2835.50
2397	2397	3	307	2	1	38	95.00	3591.25
2398	2398	2	132	3	2	1	88.35	88.35
2399	2399	2	17	4	1	2	30.25	63.75
2400	2400	2	12	1	1	12	49.85	617.15
2401	2401	1	174	1	1	9	93.00	870.25
2402	2402	2	85	3	1	11	54.55	601.25
2403	2403	1	193	4	1	6	19.70	111.65
2404	2404	4	128	1	1	71	84.80	6046.10
2405	2405	4	308	2	1	42	94.45	3923.80
2406	2406	2	140	3	2	8	94.20	777.30
2407	2407	2	148	3	2	5	96.25	512.45
2408	2408	2	129	3	2	2	70.70	141.45
2409	2409	5	193	4	1	45	20.85	892.15
2410	2410	4	32	2	1	28	60.00	1682.05
2411	2411	1	274	3	1	43	80.45	3398.90
2412	2412	6	241	3	1	60	84.95	4984.85
2413	2413	3	21	4	2	42	33.55	1445.30
2414	2414	5	46	2	1	7	49.65	305.55
2415	2415	4	193	1	1	25	20.20	507.90
2416	2416	2	261	2	2	40	94.55	3640.45
2417	2417	4	269	1	1	27	100.50	2673.45
2418	2418	1	21	3	1	10	35.75	389.80
2419	2419	2	282	1	1	27	86.45	2401.05
2420	2420	3	77	1	1	11	53.80	651.55
2421	2421	1	35	2	1	4	38.55	156.10
2422	2422	2	10	1	1	68	39.90	2796.35
2423	2423	2	129	3	1	1	70.05	70.05
2424	2424	3	193	4	1	18	20.10	407.05
2425	2425	6	317	1	2	57	112.95	6465.00
2426	2426	2	193	3	1	26	20.30	511.25
2427	2427	2	25	2	1	17	35.65	646.05
2428	2428	1	2	3	2	1	35.90	35.90
2429	2429	2	269	1	2	38	99.25	3777.15
2430	2430	4	185	2	1	59	82.95	4903.15
2431	2431	6	105	4	1	30	55.65	1653.85
2432	2432	2	1	4	2	2	24.45	47.50
2433	2433	3	322	3	1	50	25.20	1306.30
2434	2434	3	46	4	1	9	50.80	463.60
2435	2435	1	193	4	1	3	19.65	60.65
2436	2436	2	75	2	1	14	59.80	824.85
2437	2437	2	161	2	1	31	73.55	2094.65
2438	2438	1	121	3	1	7	61.40	438.90
2439	2439	2	297	1	2	8	103.35	847.30
2440	2440	3	193	1	1	17	19.90	329.75
2441	2441	2	193	2	1	32	19.45	674.55
2442	2442	1	131	4	1	2	81.50	162.55
2443	2443	2	260	3	2	7	84.80	546.95
2444	2444	5	317	2	1	72	109.55	7887.25
2445	2445	2	277	3	2	31	99.95	3186.65
2446	2446	1	161	4	1	27	74.40	1972.35
2447	2447	2	276	2	2	18	90.00	1527.35
2448	2448	2	137	3	1	7	74.90	490.55
2449	2449	2	285	3	2	14	104.85	1531.40
2450	2450	2	75	1	1	11	59.65	683.25
2451	2451	6	305	1	1	72	110.45	8058.85
2452	2452	3	309	3	2	28	106.10	2847.40
2453	2453	2	258	2	2	15	74.20	1133.90
2454	2454	2	258	3	1	4	74.45	294.45
2455	2455	5	322	3	1	71	24.55	1719.15
2456	2456	2	150	3	2	5	89.35	461.70
2457	2457	5	322	4	1	47	24.55	1160.45
2458	2458	4	155	3	1	57	90.65	5199.80
2459	2459	6	301	2	1	50	105.05	5163.30
2460	2460	2	193	2	1	8	20.45	162.30
2461	2461	5	193	4	1	48	19.55	883.35
2462	2462	3	193	1	1	70	19.70	1341.50
2463	2463	2	118	1	1	1	70.45	70.45
2464	2464	2	259	1	1	8	85.65	659.45
2465	2465	2	258	3	2	1	77.15	77.15
2466	2466	2	2	1	2	1	35.25	35.25
2467	2467	5	193	4	1	60	20.55	1205.05
2468	2468	4	265	3	1	49	97.95	4917.90
2469	2469	2	20	3	2	4	48.55	201.00
2470	2470	3	193	4	1	29	20.00	599.30
2471	2471	6	322	2	1	67	25.25	1733.15
2472	2472	2	277	2	2	53	98.40	5149.50
2473	2473	5	254	2	1	67	70.90	4677.10
2474	2474	1	193	4	1	6	19.85	119.30
2475	2475	2	285	3	1	47	106.35	4849.10
2476	2476	5	190	4	1	53	99.50	5424.25
2477	2477	6	128	4	1	69	84.70	5878.90
2478	2478	2	162	4	1	3	86.05	244.85
2479	2479	1	65	4	1	4	44.55	220.75
2480	2480	6	247	2	1	56	75.85	4261.20
2481	2481	2	261	1	2	59	93.85	5574.75
2482	2482	5	322	1	1	61	25.00	1501.75
2483	2483	2	65	3	1	2	45.00	89.75
2484	2484	2	316	3	2	46	100.70	4541.20
2485	2485	1	193	4	1	12	20.50	255.50
2487	2487	4	263	3	1	28	90.45	2509.25
2488	2488	1	117	1	1	24	60.45	1440.75
2489	2489	2	77	3	2	31	55.25	1715.65
2490	2490	4	255	3	1	68	78.45	5333.35
2491	2491	5	265	4	1	39	100.55	3895.35
2492	2492	1	193	2	1	42	20.35	869.90
2493	2493	2	40	3	2	13	54.45	706.85
2494	2494	2	275	3	1	6	90.75	512.25
2495	2495	1	258	2	2	35	75.35	2636.05
2496	2496	4	193	2	1	38	20.25	814.75
2497	2497	5	193	2	1	18	20.05	388.60
2498	2498	1	193	4	1	4	19.60	93.45
2499	2499	2	85	3	1	27	53.80	1389.85
2500	2500	3	123	4	1	41	70.20	2894.55
2501	2501	3	104	3	1	50	75.50	4025.60
2502	2502	5	193	3	1	72	20.35	1354.40
2503	2503	3	322	2	1	70	26.05	1856.40
2504	2504	3	193	1	1	44	20.60	926.00
2505	2505	2	161	3	2	2	75.70	189.20
2506	2506	4	193	1	1	34	20.10	682.10
2507	2507	5	322	1	1	72	24.30	1778.70
2508	2508	6	322	3	1	71	24.50	1816.20
2509	2509	6	289	2	1	64	110.50	7069.25
2510	2510	6	322	1	1	72	25.25	1841.20
2511	2511	2	258	4	2	1	74.25	74.25
2512	2512	3	170	1	1	29	90.10	2656.70
2513	2513	4	110	1	1	23	68.75	1689.45
2514	2514	5	193	4	1	52	19.20	1054.75
2515	2515	2	275	3	2	25	89.70	2187.55
2516	2516	6	321	1	1	64	115.10	7334.05
2517	2517	2	261	3	2	16	96.40	1581.20
2518	2518	2	129	1	2	1	69.50	69.50
2519	2519	2	277	1	1	24	99.65	2404.85
2520	2520	2	268	3	1	2	91.45	171.45
2521	2521	5	128	4	1	34	84.75	2839.45
2522	2522	2	259	2	2	36	85.25	3132.75
2523	2523	4	209	4	1	53	78.75	3942.45
2524	2524	5	193	2	1	47	20.25	873.40
2525	2525	5	193	2	1	72	19.90	1529.65
2526	2526	6	311	2	1	72	97.75	6991.60
2527	2527	1	193	4	2	1	19.40	19.40
2528	2528	2	259	3	2	9	83.30	803.30
2529	2529	2	131	1	2	8	80.10	679.30
2530	2530	3	106	2	2	45	62.70	2791.50
2531	2531	2	144	3	1	7	100.40	715.00
2532	2532	6	322	2	1	71	24.45	1681.60
2533	2533	4	144	1	1	41	101.10	4016.20
2534	2534	5	36	2	1	67	50.90	3281.65
2535	2535	4	319	2	1	69	107.20	7317.10
2536	2536	6	257	1	1	70	92.20	6474.45
2537	2537	3	322	1	2	25	25.30	676.35
2538	2538	5	321	1	1	72	113.40	8164.10
2539	2539	6	7	3	1	34	40.55	1325.85
2540	2540	5	322	2	1	65	26.00	1654.85
2541	2541	6	321	2	1	70	111.95	7795.95
2542	2542	6	44	2	1	72	53.80	3952.45
2543	2543	4	72	4	1	35	72.10	2495.15
2544	2544	1	293	4	2	13	98.15	1230.25
2545	2545	3	237	3	1	12	78.85	876.75
2546	2546	4	111	1	1	62	70.75	4263.45
2547	2547	2	104	2	1	25	76.15	1992.95
2548	2548	5	53	4	1	52	39.10	1982.10
2549	2549	2	129	2	1	8	69.95	562.70
2550	2550	1	193	4	1	2	20.05	33.70
2551	2551	5	193	4	1	56	20.05	1090.10
2552	2552	1	193	1	1	12	19.45	227.45
2553	2553	3	322	3	1	47	26.90	1250.85
2554	2554	1	193	3	1	2	19.20	37.20
2555	2555	2	73	4	1	18	50.00	892.70
2556	2556	2	99	3	1	8	60.00	487.75
2557	2557	2	298	4	1	45	84.55	3713.95
2558	2558	1	65	4	1	3	45.45	141.70
2559	2559	3	193	4	1	38	20.05	678.20
2560	2560	6	321	3	1	72	115.55	8425.30
2561	2561	2	307	3	2	46	93.70	4154.80
2562	2562	6	316	2	1	71	99.00	7061.65
2563	2563	5	8	1	1	66	50.55	3364.55
2564	2564	1	285	4	2	25	105.95	2655.25
2565	2565	4	209	2	2	18	82.00	1425.45
2566	2566	6	322	1	1	13	25.00	332.50
2567	2567	5	257	1	1	65	91.55	5963.95
2568	2568	2	284	3	2	60	95.75	5742.90
2569	2569	5	193	4	1	15	19.35	278.85
2570	2570	5	322	2	1	72	24.85	1871.85
2571	2571	2	261	2	2	30	94.05	2866.45
2572	2572	6	144	3	1	42	100.40	4303.65
2573	2573	5	322	1	1	71	25.00	1753.00
2574	2574	2	66	4	2	1	54.75	54.75
2575	2575	2	261	1	2	39	95.65	3759.05
2576	2576	1	193	1	1	35	19.25	617.65
2577	2577	2	160	1	1	53	108.25	5935.10
2578	2578	2	261	3	2	1	94.60	94.60
2579	2579	2	144	3	2	31	98.90	2911.30
2580	2580	5	193	2	1	48	20.15	982.95
2581	2581	2	265	3	1	30	101.30	2974.50
2582	2582	1	193	2	1	10	20.00	198.70
2583	2583	2	285	3	1	12	105.30	1275.65
2584	2584	5	111	1	1	57	69.85	4003.00
2585	2585	2	115	2	1	58	65.25	3791.60
2586	2586	5	193	4	1	37	19.80	813.30
2587	2587	1	193	4	1	44	19.60	780.25
2588	2588	3	193	2	1	27	20.05	552.90
2589	2589	1	69	3	1	8	49.40	408.25
2590	2590	2	258	3	2	3	76.05	231.80
2591	2591	1	154	1	1	25	88.40	2191.15
2592	2592	2	277	3	1	57	100.60	5611.70
2593	2593	1	193	4	1	12	19.45	246.25
2594	2594	5	193	1	1	62	20.30	1296.15
2595	2595	6	289	1	1	65	107.65	7082.85
2596	2596	6	209	1	1	71	80.45	5662.25
2597	2597	4	83	2	1	21	58.85	1215.45
2598	2598	4	317	3	1	71	109.60	7854.15
2599	2599	2	137	3	1	7	75.15	525.00
2600	2600	6	126	2	1	72	73.00	5265.20
2601	2601	1	129	3	1	1	70.10	70.10
2602	2602	6	287	1	1	72	98.65	7129.45
2603	2603	4	289	3	1	64	111.45	7266.95
2604	2604	6	321	3	1	72	114.90	8496.70
2605	2605	1	269	1	1	29	100.55	2878.75
2606	2606	6	193	4	1	13	20.40	261.30
2607	2607	1	309	3	1	31	104.35	3205.60
2608	2608	2	129	3	2	1	69.75	69.75
2609	2609	2	37	3	2	7	34.50	279.25
2610	2610	2	285	3	2	61	105.55	6281.45
2611	2611	1	9	2	2	39	30.10	1131.30
2612	2612	2	129	3	2	10	70.30	738.20
2613	2613	1	217	2	1	14	80.45	1137.05
2614	2614	2	274	4	2	1	80.20	80.20
2615	2615	4	295	2	2	67	94.35	6341.45
2616	2616	6	257	1	1	72	91.35	6697.20
2617	2617	2	65	1	2	6	44.60	260.80
2618	2618	2	193	4	2	1	19.60	19.60
2619	2619	3	193	3	1	25	19.90	505.45
2620	2620	2	289	3	2	33	110.45	3655.45
2621	2621	2	111	3	1	18	68.35	1299.80
2622	2622	6	96	2	1	71	79.10	5564.85
2623	2623	4	194	3	1	28	51.00	1381.80
2624	2624	1	290	2	1	2	80.55	188.10
2625	2625	2	222	4	1	17	66.70	1077.05
2626	2626	2	306	3	1	56	86.40	4922.40
2627	2627	3	58	3	1	60	50.05	2911.50
2628	2628	5	322	2	1	33	25.70	826.10
2629	2629	2	181	4	1	1	83.40	83.40
2630	2630	1	129	2	2	2	70.70	140.70
2631	2631	6	294	2	1	63	84.65	5377.80
2632	2632	2	269	3	2	7	99.25	665.45
2633	2633	6	90	4	1	55	64.75	3617.10
2634	2634	4	312	1	1	65	100.15	6643.50
2635	2635	2	135	3	2	1	84.80	84.80
2636	2636	5	322	4	1	63	25.25	1559.30
2637	2637	6	321	2	1	70	113.00	7987.60
2638	2638	5	45	2	1	36	40.65	1547.35
2639	2639	4	160	1	2	52	105.00	5426.85
2640	2640	2	226	3	2	22	54.45	1127.35
2641	2641	2	158	1	1	22	94.95	2142.80
2642	2642	1	117	2	1	5	59.90	287.85
2643	2643	2	138	3	2	47	85.30	4045.65
2644	2644	2	259	3	2	33	83.35	2757.85
2645	2645	2	25	2	2	18	33.50	600.00
2646	2646	1	193	2	1	1	19.80	19.80
2647	2647	6	96	2	1	56	81.80	4534.45
2648	2648	2	193	4	1	2	20.00	40.90
2649	2649	2	234	3	1	35	59.60	2094.90
2650	2650	5	322	2	1	64	25.00	1584.80
2651	2651	2	298	2	1	15	84.35	1302.65
2652	2652	2	132	3	2	24	90.35	2238.50
2653	2653	1	66	4	1	1	55.55	55.55
2654	2654	5	104	2	1	70	75.35	5437.75
2655	2655	2	132	3	2	1	90.75	90.75
2656	2656	1	276	4	2	4	89.60	365.65
2657	2657	3	70	3	1	39	59.30	2209.15
2658	2658	2	227	3	1	29	66.10	1912.15
2659	2659	5	193	4	1	14	18.80	255.55
2660	2660	5	241	2	1	61	86.45	5175.30
2661	2661	2	97	2	1	13	52.10	670.65
2662	2662	6	61	4	1	66	47.40	3177.25
2663	2663	2	12	3	2	2	49.25	90.35
2664	2664	4	317	2	1	59	109.15	6557.75
2665	2665	4	308	2	1	62	94.95	5791.85
2666	2666	4	182	3	1	33	93.55	3055.50
2667	2667	6	96	2	1	66	79.50	5196.10
2668	2668	5	321	2	1	72	115.05	8405.00
2669	2669	1	193	4	2	1	19.75	19.75
2670	2670	2	307	3	2	19	95.15	1789.25
2671	2671	4	296	4	1	51	95.15	5000.05
2672	2672	1	281	3	1	63	105.40	6713.20
2673	2673	3	193	1	1	27	20.10	562.60
2674	2674	2	293	1	2	22	101.35	2317.10
2675	2675	1	193	4	1	4	20.05	91.45
2676	2676	5	193	4	1	42	20.70	828.85
2677	2677	3	193	4	1	29	20.35	617.35
2678	2678	2	129	2	2	4	70.05	266.90
2679	2679	3	193	4	1	30	19.70	625.05
2680	2680	2	258	3	2	4	74.65	301.40
2681	2681	5	128	1	1	71	85.45	6029.90
2682	2682	5	45	2	1	46	40.40	1842.70
2683	2683	1	194	4	2	4	50.40	206.60
2684	2684	2	290	4	2	7	79.65	604.70
2685	2685	4	281	1	1	69	105.20	7386.05
2686	2686	5	316	1	1	72	100.65	7334.05
2687	2687	2	266	3	2	19	79.85	1471.75
2688	2688	1	142	3	1	28	91.00	2626.15
2689	2689	2	274	3	2	5	78.75	412.10
2690	2690	6	321	2	1	72	116.75	8277.05
2691	2691	2	131	2	2	8	80.45	583.45
2692	2692	4	98	3	1	7	59.10	369.25
2693	2693	2	97	3	1	22	49.80	1049.05
2694	2694	5	193	1	1	72	19.30	1414.80
2695	2695	1	193	2	1	8	19.65	169.75
2696	2696	4	255	2	1	52	81.40	4354.45
2697	2697	5	45	4	1	68	38.90	2719.20
2698	2698	5	257	1	1	71	87.95	6365.35
2699	2699	1	193	4	1	2	19.85	51.60
2700	2700	2	280	3	1	34	96.35	3190.25
2701	2701	1	1	3	1	35	24.15	812.50
2702	2702	3	193	2	1	61	19.10	1143.80
2703	2703	1	65	3	1	1	44.00	44.00
2704	2704	2	194	4	2	1	50.10	50.10
2705	2705	3	74	2	1	53	60.60	3297.00
2706	2706	5	322	1	1	72	25.65	1887.00
2707	2707	1	137	3	2	2	76.40	151.80
2708	2708	2	144	3	2	3	98.70	293.65
2709	2709	2	293	3	2	13	100.80	1308.10
2710	2710	2	28	3	1	41	53.95	2215.40
2711	2711	3	193	2	1	24	20.40	482.80
2712	2712	4	132	1	2	28	90.10	2598.95
2713	2713	1	33	4	1	8	29.35	216.45
2714	2714	2	193	4	1	1	20.45	20.45
2715	2715	6	271	1	1	54	95.10	5064.85
2716	2716	2	322	1	1	41	25.25	996.45
2717	2717	1	65	4	1	19	44.90	839.65
2718	2718	5	257	1	1	72	92.65	6733.00
2719	2719	6	61	1	1	62	43.70	2618.30
2720	2720	6	104	2	1	56	72.60	4084.35
2721	2721	1	194	3	2	15	51.55	765.50
2722	2722	2	130	3	2	10	79.25	793.55
2723	2723	5	193	4	1	32	18.95	613.95
2724	2724	1	193	2	1	21	20.50	402.85
2725	2725	3	193	1	1	62	19.95	1244.80
2726	2726	1	1	3	1	2	24.50	46.40
2727	2727	5	193	4	1	27	20.60	581.85
2728	2728	2	261	1	2	5	94.85	462.80
2729	2729	3	60	3	1	25	61.05	1540.20
2730	2730	2	259	3	2	2	85.70	169.80
2731	2731	4	281	1	1	49	106.65	5168.10
2732	2732	1	317	2	1	63	108.25	6780.10
2733	2733	1	193	2	1	4	20.40	94.50
2734	2734	2	67	4	1	1	55.30	55.30
2735	2735	1	193	4	1	11	20.25	208.00
2736	2736	2	258	1	1	52	72.95	3829.75
2737	2737	1	275	3	1	60	89.45	5294.60
2738	2738	4	273	2	1	64	104.65	6889.80
2739	2739	5	108	1	1	43	75.20	3254.35
2740	2740	3	265	1	1	61	101.15	6383.90
2741	2741	1	65	4	2	1	44.40	44.40
2742	2742	2	132	3	2	5	89.50	477.70
2743	2743	5	254	1	1	66	68.75	4447.55
2744	2744	6	192	3	1	67	111.05	7321.05
2745	2745	6	144	2	1	42	99.00	4135.00
2746	2746	2	260	3	2	1	86.05	86.05
2747	2747	5	193	4	1	31	21.00	697.70
2748	2748	2	193	4	1	7	19.40	168.65
2749	2749	2	4	3	2	4	44.55	174.30
2750	2750	3	205	1	1	34	77.20	2753.80
2751	2751	4	193	4	1	3	19.45	69.25
2752	2752	2	1	4	1	19	24.85	434.80
2753	2753	1	37	1	2	31	35.40	1077.50
2754	2754	1	261	4	2	1	95.65	95.65
2755	2755	1	45	4	1	3	41.35	107.25
2756	2756	1	193	3	1	46	19.60	851.20
2757	2757	1	193	4	2	1	20.95	20.95
2758	2758	3	298	1	1	69	84.45	5848.60
2759	2759	1	193	4	1	5	20.25	109.80
2760	2760	1	193	1	1	1	19.65	19.65
2761	2761	4	193	2	1	26	20.65	595.50
2762	2762	2	2	3	2	10	34.70	329.80
2763	2763	5	144	1	1	25	99.30	2513.50
2764	2764	1	177	3	1	64	81.05	5135.35
2765	2765	1	254	3	1	30	67.60	2000.20
2766	2766	2	129	3	1	13	70.15	931.75
2767	2767	4	321	3	1	64	115.00	7396.15
2768	2768	2	270	1	1	46	84.80	3958.85
2769	2769	3	193	4	1	12	19.70	260.90
2770	2770	1	193	1	2	15	19.75	297.30
2771	2771	2	261	3	2	17	92.55	1515.10
2772	2772	2	106	4	1	13	63.15	816.80
2773	2773	5	248	2	1	67	74.00	4868.40
2774	2774	1	9	3	1	24	29.10	688.00
2775	2775	1	69	4	1	6	50.05	288.35
2776	2776	4	230	3	2	53	60.05	3229.65
2777	2777	2	145	2	2	16	74.30	1178.25
2778	2778	1	193	3	1	10	20.00	185.40
2779	2779	4	145	4	1	13	74.65	966.25
2780	2780	2	260	3	2	9	85.35	758.60
2781	2781	3	127	4	2	25	74.30	1863.80
2782	2782	2	22	3	1	7	44.40	265.80
2783	2783	6	241	1	1	38	85.40	3297.00
2784	2784	2	307	3	1	43	94.10	4107.30
2785	2785	2	144	1	2	4	98.10	396.30
2786	2786	5	289	3	1	25	108.90	2809.05
2787	2787	3	113	4	1	27	56.20	1567.55
2788	2788	5	322	4	1	72	26.10	1851.45
2789	2789	4	306	2	1	71	85.45	6028.95
2790	2790	2	268	2	1	24	88.95	2072.75
2791	2791	6	313	3	2	50	109.65	5551.15
2792	2792	6	108	1	1	57	74.35	4317.35
2793	2793	1	81	3	1	15	48.85	736.80
2794	2794	2	290	3	1	4	80.10	336.15
2795	2795	1	113	3	1	28	56.05	1522.65
2796	2796	2	258	3	2	9	74.55	622.90
2797	2797	2	292	1	1	55	89.80	4959.60
2798	2798	2	269	3	2	3	100.95	329.95
2799	2799	2	140	3	2	10	94.90	1048.85
2800	2800	3	193	1	1	55	19.10	1001.50
2801	2801	1	193	4	1	20	20.35	442.60
2802	2802	4	281	2	1	62	106.05	6703.50
2803	2803	2	273	3	2	32	104.90	3351.55
2804	2804	6	193	1	1	43	19.65	779.25
2805	2805	3	1	1	2	9	24.10	259.80
2806	2806	5	117	1	1	60	59.85	3483.45
2807	2807	6	253	3	1	58	86.10	4890.50
2808	2808	3	193	4	1	7	19.45	136.75
2809	2809	1	164	3	1	2	97.10	184.15
2810	2810	1	25	3	1	37	36.65	1315.00
2811	2811	4	273	1	1	65	103.90	6767.10
2812	2812	5	193	4	1	39	19.75	757.95
2813	2813	4	281	3	2	66	104.05	6890.00
2814	2814	5	322	4	1	68	24.55	1657.40
2815	2815	5	55	1	1	62	48.70	3008.55
2816	2816	2	143	4	2	3	88.35	262.05
2817	2817	6	317	3	1	72	109.55	8165.10
2818	2818	5	193	2	1	41	20.65	875.55
2819	2819	1	164	2	2	29	94.65	2649.15
2820	2820	1	113	3	1	4	55.20	220.65
2821	2821	3	322	1	1	53	24.05	1301.90
2822	2822	2	258	3	2	1	74.40	74.40
2823	2823	1	255	2	2	41	79.90	3326.20
2824	2824	6	193	1	1	39	20.45	790.00
2825	2825	5	193	4	1	63	19.25	1237.65
2826	2826	2	322	3	1	15	26.35	378.60
2827	2827	3	65	3	1	13	43.80	592.65
2828	2828	2	81	4	1	1	50.15	50.15
2829	2829	5	193	4	1	1	20.45	20.45
2830	2830	2	129	3	2	8	69.70	560.85
2831	2831	5	121	3	1	60	61.40	3638.25
2832	2832	2	284	3	2	12	98.10	1060.20
2833	2833	3	216	2	1	40	70.75	2921.75
2834	2834	6	121	1	1	66	61.15	4017.45
2835	2835	3	193	4	1	42	20.25	854.90
2836	2836	4	246	2	1	66	63.85	4174.35
2837	2837	1	277	3	1	49	98.70	4920.55
2838	2838	1	193	4	2	1	20.50	20.50
2839	2839	5	193	4	1	41	20.00	810.30
2840	2840	5	193	1	1	41	19.30	772.40
2841	2841	1	181	4	1	23	84.40	1936.85
2842	2842	1	1	3	1	3	25.10	79.80
2843	2843	1	46	4	1	4	48.25	202.25
2844	2844	5	193	4	1	52	19.85	1070.50
2845	2845	2	293	3	2	4	99.60	347.65
2846	2846	2	158	3	1	11	94.20	999.90
2847	2847	2	98	4	1	2	62.15	113.10
2848	2848	1	274	1	1	26	79.30	2015.80
2849	2849	4	105	2	1	24	56.25	1454.25
2850	2850	1	193	4	1	12	20.30	246.70
2851	2851	2	265	3	1	60	99.00	6017.90
2852	2852	6	257	4	1	64	90.60	5817.45
2853	2853	6	128	1	1	66	85.90	5595.30
2854	2854	4	266	1	1	60	79.20	4765.00
2855	2855	4	236	1	1	17	70.35	1201.65
2856	2856	5	193	4	1	42	19.35	867.30
2857	2857	2	194	3	1	1	50.15	50.15
2858	2858	5	86	1	1	47	63.80	3007.25
2859	2859	2	193	4	1	10	20.55	252.75
2860	2860	6	257	2	1	70	88.55	6306.50
2861	2861	2	269	2	1	67	101.40	6841.05
2862	2862	2	130	3	2	1	81.95	81.95
2863	2863	2	129	3	2	7	69.35	451.10
2864	2864	1	65	4	1	1	44.60	44.60
2865	2865	2	87	1	1	4	63.75	226.20
2866	2866	5	317	1	1	66	109.25	7082.50
2867	2867	2	146	3	1	12	84.60	1017.35
2868	2868	3	193	2	1	24	20.45	527.35
2869	2869	2	147	3	1	26	85.75	2146.50
2870	2870	2	132	3	2	6	91.10	455.30
2871	2871	5	273	3	1	57	107.95	5969.85
2872	2872	2	260	3	2	14	86.10	1235.55
2873	2873	5	322	3	1	42	22.95	1014.25
2874	2874	2	261	1	2	25	94.70	2362.10
2875	2875	5	193	2	1	64	19.45	1225.65
2876	2876	2	259	3	2	22	85.10	1873.70
2877	2877	4	193	2	1	19	19.70	386.50
2878	2878	2	277	3	2	61	99.15	6010.05
2879	2879	2	139	1	1	22	87.00	1850.65
2880	2880	2	285	3	2	70	102.95	7101.50
2881	2881	2	130	1	1	12	79.95	1043.40
2882	2882	4	102	3	1	31	64.00	1910.75
2883	2883	2	68	3	1	11	64.90	716.10
2884	2884	5	322	4	1	68	25.75	1686.15
2885	2885	6	257	1	1	72	90.15	6716.45
2886	2886	6	321	2	1	67	116.10	7839.85
2887	2887	2	176	1	1	60	104.95	6236.75
2888	2888	2	65	4	2	1	45.05	45.05
2889	2889	2	129	3	2	1	71.00	71.00
2890	2890	3	59	4	1	58	50.00	2919.85
2891	2891	1	129	1	2	47	70.55	3309.25
2892	2892	2	130	3	2	1	79.70	79.70
2893	2893	1	193	4	1	1	20.45	20.45
2894	2894	1	242	3	2	22	59.00	1254.70
2895	2895	4	109	2	2	48	60.35	2896.40
2896	2896	4	193	1	1	37	19.85	717.50
2897	2897	4	193	3	1	13	19.95	253.80
2898	2898	5	322	1	1	43	26.45	1110.05
2899	2899	6	64	4	1	6	63.40	348.80
2900	2900	5	63	1	1	71	53.95	3888.65
2901	2901	2	129	3	2	1	69.25	69.25
2902	2902	6	308	3	1	72	95.10	6843.15
2903	2903	2	161	3	1	6	74.10	450.90
2904	2904	1	21	4	1	12	35.50	432.25
2905	2905	1	129	4	2	25	70.95	1767.35
2906	2906	3	141	3	1	21	79.20	1742.45
2907	2907	2	69	4	1	6	48.80	297.35
2908	2908	2	132	4	2	20	89.00	1820.45
2909	2909	2	293	3	2	18	99.40	1742.95
2910	2910	3	85	3	1	43	55.45	2444.25
2911	2911	6	322	2	1	35	25.40	949.80
2912	2912	1	137	1	2	1	73.50	73.50
2913	2913	2	283	3	1	32	93.50	2970.80
2914	2914	5	64	2	1	52	63.90	3334.95
2915	2915	4	68	1	1	32	64.85	2010.95
2916	2916	6	64	1	1	72	63.80	4684.30
2917	2917	2	38	2	1	51	44.45	2181.55
2918	2918	6	193	1	1	68	19.95	1303.25
2919	2919	2	26	4	1	8	43.35	371.40
2920	2920	5	20	2	1	49	49.65	2409.90
2921	2921	5	128	4	1	72	85.10	6155.40
2922	2922	2	261	3	2	9	95.50	829.10
2923	2923	2	164	4	2	28	92.35	2602.90
2924	2924	1	171	4	1	54	89.80	4667.00
2925	2925	2	145	3	2	11	74.55	824.75
2926	2926	3	144	4	1	50	103.05	5153.50
2927	2927	6	321	3	1	69	116.00	8182.85
2928	2928	2	129	3	1	1	69.90	69.90
2929	2929	5	182	1	1	68	95.10	6683.40
2930	2930	3	53	4	1	40	40.25	1564.05
2931	2931	5	322	4	1	31	25.75	755.60
2932	2932	2	285	1	1	33	105.35	3465.05
2933	2933	6	289	3	1	55	113.60	6292.70
2934	2934	6	322	1	1	68	24.00	1664.30
2935	2935	1	193	1	1	12	19.40	198.10
2936	2936	6	128	1	1	71	86.10	6045.90
2937	2937	2	285	4	1	40	102.65	4108.15
2938	2938	4	283	3	1	64	92.85	5980.75
2939	2939	3	279	1	1	53	97.75	5043.20
2940	2940	2	157	4	2	12	83.80	1029.75
2941	2941	2	28	3	2	53	54.45	2854.55
2942	2942	6	316	2	1	72	97.95	7114.25
2943	2943	5	193	3	1	46	19.95	907.05
2944	2944	6	322	4	1	40	24.60	973.95
2945	2945	2	55	1	1	12	50.95	605.75
2946	2946	1	161	3	1	9	75.60	661.55
2947	2947	2	262	3	1	51	80.75	4116.90
2948	2948	2	155	2	1	49	90.40	4494.65
2949	2949	2	269	3	2	41	99.80	4259.30
2950	2950	4	109	2	1	56	60.25	3282.75
2951	2951	2	193	3	1	4	20.20	55.70
2952	2952	4	102	4	1	20	64.15	1274.45
2953	2953	2	193	2	1	26	20.25	493.95
2954	2954	2	285	1	2	20	105.85	2239.65
2955	2955	1	258	4	2	7	75.45	480.75
2956	2956	2	261	3	2	7	93.85	635.60
2957	2957	2	156	3	1	51	99.00	5038.15
2958	2958	2	274	4	1	4	80.30	324.20
2959	2959	1	193	2	1	1	19.55	19.55
2960	2960	1	312	3	1	27	100.75	2793.55
2961	2961	2	293	3	2	22	100.75	2095.00
2962	2962	2	85	4	1	12	53.75	648.65
2963	2963	2	5	4	2	3	31.00	95.05
2964	2964	4	322	2	1	34	25.60	917.15
2965	2965	4	230	3	1	24	58.35	1346.90
2966	2966	1	266	2	2	51	80.00	4242.35
2967	2967	2	4	3	1	14	46.35	672.70
2968	2968	5	321	3	1	59	113.75	6561.25
2969	2969	1	154	3	1	3	90.40	268.45
2970	2970	5	305	3	1	65	109.30	7337.55
2971	2971	2	129	4	2	5	70.25	331.90
2972	2972	5	257	2	1	59	90.30	5194.05
2973	2973	6	64	2	1	72	65.25	4478.85
2974	2974	2	156	3	2	62	100.15	6283.30
2975	2975	2	307	2	2	28	94.50	2659.40
2976	2976	1	70	4	1	3	60.65	196.90
2977	2977	2	322	2	1	19	24.10	439.20
2978	2978	2	193	4	1	1	19.50	19.50
2979	2979	2	157	3	1	24	85.95	2107.15
2980	2980	4	77	3	1	57	53.50	3035.80
2981	2981	5	322	2	1	72	25.45	1866.45
2982	2982	5	193	1	1	67	20.50	1430.95
2983	2983	4	193	2	1	52	20.85	1071.60
2984	2984	5	257	2	1	71	89.90	6457.15
2985	2985	3	322	4	1	26	26.00	684.05
2986	2986	6	321	4	1	35	113.20	3914.05
2987	2987	6	129	2	1	55	69.05	3842.60
2988	2988	5	193	4	1	33	20.10	670.35
2989	2989	6	317	3	1	72	109.65	7880.25
2990	2990	2	193	4	1	1	19.20	19.20
2991	2991	2	2	4	2	10	33.90	298.45
2992	2992	1	143	3	1	37	90.00	3371.75
2993	2993	1	21	4	1	12	34.00	442.45
2994	2994	3	193	4	1	1	20.40	20.40
2995	2995	6	53	2	1	62	38.60	2345.55
2996	2996	1	1	1	1	1	25.25	25.25
2997	2997	2	234	4	1	18	60.60	1156.35
2998	2998	2	276	3	2	69	89.95	6143.15
2999	2999	2	145	3	1	2	74.75	144.80
3000	3000	1	193	4	1	19	20.60	414.95
3001	3001	2	260	3	2	12	84.45	1059.55
3002	3002	1	193	4	1	9	20.40	181.80
3003	3003	3	112	3	1	27	81.70	2212.55
3004	3004	2	262	3	2	27	79.50	2180.55
3005	3005	1	132	4	2	1	89.15	89.15
3006	3006	2	193	4	1	24	20.30	459.95
3007	3007	2	258	3	2	14	74.95	1036.75
3008	3008	2	145	3	2	32	74.40	2276.95
3009	3009	3	193	4	1	11	20.00	211.95
3010	3010	2	322	4	1	1	25.00	25.00
3011	3011	2	290	4	1	38	80.45	3162.65
3012	3012	5	193	4	1	9	19.75	210.65
3013	3013	6	246	2	1	54	65.65	3566.70
3014	3014	4	197	2	1	29	71.00	2080.10
3015	3015	2	268	3	1	44	89.20	4040.20
3016	3016	6	128	3	1	59	86.75	5186.00
3017	3017	2	66	3	2	3	55.30	196.15
3018	3018	4	117	4	1	18	61.50	1087.45
3019	3019	5	322	2	1	67	25.10	1672.15
3020	3020	1	85	3	2	22	55.15	1206.05
3021	3021	3	37	2	1	33	34.05	1113.95
3022	3022	1	193	4	1	5	19.95	107.05
3023	3023	1	193	4	1	2	19.95	38.15
3024	3024	5	257	2	1	72	89.70	6339.30
3025	3025	1	193	4	1	9	20.40	184.10
3026	3026	5	322	4	1	67	26.30	1688.90
5620	5620	4	132	1	1	20	91.00	1859.50
3027	3027	2	260	3	2	16	84.95	1378.25
3028	3028	2	193	4	1	8	20.70	137.60
3029	3029	2	61	4	2	5	43.25	219.00
3030	3030	4	194	2	2	23	48.35	1067.15
3031	3031	2	131	3	2	1	79.55	79.55
3032	3032	2	129	3	2	50	71.05	3444.85
3033	3033	5	193	2	1	17	19.45	369.05
3034	3034	6	317	1	1	68	110.80	7553.60
3035	3035	1	260	3	2	1	84.50	84.50
3036	3036	2	129	3	1	25	69.30	1813.10
3037	3037	4	47	1	1	67	49.35	3321.35
3038	3038	3	193	2	1	32	20.35	707.50
3039	3039	4	309	3	1	67	105.60	7112.15
3040	3040	6	64	2	1	72	64.45	4641.10
3041	3041	6	289	2	2	71	108.60	7690.90
3042	3042	2	81	3	1	1	49.90	49.90
3043	3043	1	17	1	2	46	30.30	1380.10
3044	3044	2	9	3	2	2	30.40	78.65
3045	3045	2	65	4	2	1	45.40	45.40
3046	3046	4	90	3	1	48	65.65	3094.65
3047	3047	4	273	1	1	61	103.30	6518.35
3048	3048	1	146	1	2	32	84.15	2585.95
3049	3049	1	65	3	1	2	44.45	82.70
3050	3050	1	193	3	2	3	19.75	58.85
3051	3051	2	134	2	2	5	85.40	425.90
3052	3052	5	257	1	1	71	89.90	6342.70
3053	3053	2	226	4	1	37	55.05	2030.75
3054	3054	6	273	1	1	65	104.10	6700.05
3055	3055	4	281	1	1	67	106.60	7244.70
3056	3056	1	258	2	2	49	75.20	3678.30
3057	3057	6	232	2	1	50	70.50	3486.65
3058	3058	3	193	3	1	25	19.60	411.15
3059	3059	4	202	4	2	17	55.85	937.50
3060	3060	6	322	4	1	64	24.05	1559.15
3061	3061	4	11	2	1	25	38.10	970.40
3062	3062	2	285	3	2	23	106.40	2483.50
3063	3063	1	13	4	1	24	34.25	828.20
3064	3064	2	269	3	1	37	100.05	3810.55
3065	3065	2	129	3	1	21	68.65	1493.20
3066	3066	2	65	4	1	1	45.80	45.80
3067	3067	2	258	4	1	10	75.75	777.30
3068	3068	2	146	3	2	6	84.40	556.35
3069	3069	4	307	2	1	51	96.40	4911.05
3070	3070	2	193	4	1	10	20.55	187.35
3071	3071	1	54	2	1	6	50.95	307.60
3072	3072	6	257	4	1	47	90.50	4318.35
3073	3073	4	255	3	1	61	79.40	4820.55
3074	3074	6	60	1	1	52	58.75	3038.55
3075	3075	2	242	2	1	35	59.45	2136.90
3076	3076	4	285	1	1	71	105.70	7472.15
3077	3077	1	113	3	2	6	56.25	389.10
3078	3078	5	105	2	1	45	53.30	2296.25
3079	3079	2	260	3	2	2	85.55	187.45
3080	3080	2	84	1	2	4	68.65	261.25
3081	3081	1	1	4	1	2	24.30	38.45
3082	3082	1	131	3	2	4	77.85	299.20
3083	3083	3	230	2	1	51	59.90	3043.60
3084	3084	3	322	2	1	60	23.95	1506.40
3085	3085	4	193	4	1	9	20.15	163.70
3086	3086	2	285	1	2	3	105.35	323.25
3087	3087	2	271	1	1	17	95.65	1640.00
3088	3088	2	260	3	2	8	87.05	762.10
3089	3089	5	112	4	1	46	81.00	3846.35
3090	3090	6	128	2	1	68	82.45	5646.60
3091	3091	2	67	4	2	1	53.50	53.50
3092	3092	3	193	1	1	4	20.50	79.05
3093	3093	2	1	4	2	1	25.10	25.10
3094	3094	4	85	2	1	28	54.40	1516.60
3095	3095	4	83	2	1	39	58.60	2224.50
3096	3096	1	138	3	1	11	84.80	888.75
3097	3097	6	32	2	1	71	61.40	4310.35
3098	3098	1	193	4	1	2	20.40	42.90
3099	3099	2	153	4	2	30	79.65	2365.15
3100	3100	3	193	4	1	17	20.15	353.65
3101	3101	2	284	2	1	55	94.45	5073.10
3102	3102	2	290	1	1	58	79.80	4526.85
3103	3103	1	101	3	2	5	54.20	308.25
3104	3104	2	193	3	2	1	19.45	19.45
3105	3105	2	258	3	1	9	74.05	678.45
3106	3106	1	69	1	1	26	49.15	1237.30
3107	3107	5	193	2	1	50	19.40	1023.95
3108	3108	6	321	1	1	72	113.65	8182.75
3109	3109	4	184	2	1	43	106.00	4532.30
3110	3110	6	322	1	1	56	25.95	1444.05
3111	3111	1	193	4	1	1	19.10	19.10
3112	3112	6	285	3	2	72	103.40	7372.65
3113	3113	6	311	1	1	72	100.55	7325.10
3114	3114	2	261	3	1	36	95.40	3474.20
3115	3115	1	80	1	1	5	75.15	392.65
3116	3116	2	282	3	2	13	84.45	1058.60
3117	3117	3	154	2	1	44	89.15	3990.75
3118	3118	4	289	3	1	70	107.90	7475.85
3119	3119	3	193	2	1	44	19.50	835.50
3120	3120	2	260	2	2	32	85.95	2628.60
3121	3121	6	322	2	1	69	24.95	1718.35
3122	3122	1	71	3	2	16	59.40	1023.90
3123	3123	3	193	1	1	68	19.50	1193.55
3124	3124	2	129	2	1	16	69.95	1205.50
3125	3125	5	120	1	1	68	82.85	5776.45
3126	3126	1	193	4	1	4	19.00	78.90
3127	3127	1	53	2	1	26	38.85	1025.15
3128	3128	2	17	3	2	29	30.60	856.35
3129	3129	1	193	2	1	5	20.35	122.00
3130	3130	4	284	1	1	70	95.00	6602.90
3131	3131	3	104	1	1	24	74.40	1712.90
3132	3132	5	255	1	1	72	78.45	5682.25
3133	3133	2	133	4	1	1	74.30	74.30
3134	3134	4	30	1	1	70	51.05	3635.15
3135	3135	1	193	1	1	36	19.20	702.90
3136	3136	2	265	3	2	38	99.55	3734.25
3137	3137	2	129	3	2	17	70.00	1144.50
3138	3138	4	289	1	1	41	109.10	4454.25
3139	3139	2	65	3	2	1	45.30	45.30
3140	3140	1	5	1	2	2	29.85	75.60
3141	3141	1	137	3	1	14	76.45	1117.55
3142	3142	2	158	2	2	2	95.10	180.25
3143	3143	1	193	4	2	1	19.80	19.80
3144	3144	2	224	3	1	13	72.80	930.05
3145	3145	1	193	4	1	6	18.95	110.15
3146	3146	2	145	1	2	4	76.65	333.60
3147	3147	2	152	4	2	5	99.15	465.05
3148	3148	1	172	3	1	15	101.75	1669.40
3149	3149	1	161	2	1	47	75.45	3545.10
3150	3150	1	78	4	1	8	64.10	504.05
3151	3151	2	1	4	1	17	25.65	440.20
3152	3152	1	161	4	1	15	75.10	1151.55
3153	3153	4	174	1	1	26	95.85	2475.35
3154	3154	1	226	3	1	23	54.40	1249.25
3155	3155	1	145	3	1	4	72.75	317.75
3156	3156	3	193	4	1	29	19.85	535.05
3157	3157	1	193	4	1	25	19.05	461.30
3158	3158	1	65	4	2	9	44.95	431.00
3159	3159	2	73	4	2	18	49.55	878.35
3160	3160	2	261	3	1	3	94.85	335.75
3161	3161	5	61	1	1	69	46.25	3121.40
3162	3162	3	193	4	1	14	19.35	324.80
3163	3163	1	197	4	1	19	69.60	1394.55
3164	3164	1	275	3	1	39	90.70	3413.25
3165	3165	2	156	3	1	31	101.40	3143.65
3166	3166	3	193	4	1	24	20.25	439.75
3167	3167	1	69	1	1	14	48.80	664.40
3168	3168	6	126	4	1	64	74.35	4759.55
3169	3169	4	193	4	1	50	19.35	1033.00
3170	3170	4	95	3	1	52	68.75	3482.85
3171	3171	3	277	3	1	28	100.20	2688.45
3172	3172	6	193	2	1	21	20.85	435.25
3173	3173	2	148	3	2	25	95.90	2448.75
3174	3174	3	193	4	1	17	19.35	307.00
3175	3175	4	4	2	1	58	45.00	2689.35
3176	3176	1	130	1	2	17	81.50	1329.20
3177	3177	5	322	4	1	51	25.50	1281.25
3178	3178	5	47	4	1	72	48.90	3527.00
3179	3179	1	163	3	2	52	84.10	4348.65
3180	3180	6	193	4	1	27	19.60	561.15
3181	3181	1	193	4	1	3	20.00	63.60
3182	3182	6	255	4	1	64	81.30	5129.30
3183	3183	6	136	2	1	45	95.20	4285.80
3184	3184	2	3	4	2	3	36.45	93.70
3185	3185	6	225	2	1	71	83.30	5894.50
3186	3186	1	1	4	2	1	25.05	25.05
3187	3187	5	193	2	1	58	20.30	1160.75
3188	3188	2	155	3	1	34	89.85	3091.75
3189	3189	2	97	3	2	8	49.85	365.55
3190	3190	1	193	4	1	15	19.80	272.95
3191	3191	5	16	1	1	66	54.65	3632.00
3192	3192	2	17	2	1	12	29.35	381.20
3193	3193	6	193	1	1	58	19.15	1035.50
3194	3194	5	193	4	1	3	19.10	52.00
3195	3195	1	28	2	2	43	55.55	2342.20
3196	3196	1	153	3	1	9	80.55	653.90
3197	3197	3	193	4	1	3	20.25	71.20
3198	3198	4	84	1	2	22	69.50	1498.20
3199	3199	4	285	1	1	40	106.00	4178.65
3200	3200	5	322	1	1	68	25.50	1821.80
3201	3201	2	285	3	2	54	104.30	5278.15
3202	3202	6	217	4	1	50	79.60	4024.20
3203	3203	2	66	3	1	1	55.25	55.25
3204	3204	5	257	1	1	72	88.05	6520.80
3205	3205	4	193	1	1	40	20.40	854.90
3206	3206	6	321	1	1	72	117.60	8308.90
3207	3207	1	193	4	1	6	20.00	109.20
3208	3208	2	193	2	1	5	19.65	92.05
3209	3209	4	219	2	1	48	70.55	3420.50
3210	3210	2	261	3	2	1	93.85	93.85
3211	3211	3	103	4	1	64	65.80	4068.00
3212	3212	3	193	2	1	17	20.05	337.90
3213	3213	2	153	3	1	40	80.00	3168.75
3214	3214	3	41	2	1	41	35.40	1412.40
3215	3215	4	274	1	1	51	79.60	3974.70
3216	3216	2	274	3	1	41	80.25	3439.00
3217	3217	1	73	4	2	1	50.45	50.45
3218	3218	2	193	4	1	2	20.45	42.45
3219	3219	3	153	2	1	68	79.60	5461.45
3220	3220	5	322	4	1	24	24.70	571.75
3221	3221	5	239	2	1	70	77.30	5498.20
3222	3222	2	5	3	1	3	29.75	96.85
3223	3223	1	65	1	1	2	44.90	111.05
3224	3224	1	17	2	1	3	29.80	94.40
3225	3225	2	201	3	2	7	74.65	521.10
3226	3226	2	100	3	1	13	71.95	923.85
3227	3227	1	193	4	1	7	20.75	141.10
3228	3228	2	67	4	1	12	56.30	628.65
3229	3229	4	285	3	1	53	105.25	5576.30
3230	3230	2	261	3	2	12	94.20	1046.10
3231	3231	5	193	4	1	63	19.55	1245.60
3232	3232	1	128	4	1	15	84.45	1287.85
3233	3233	3	113	4	1	36	53.65	1939.35
3234	3234	2	9	3	1	4	29.90	118.25
3235	3235	5	193	4	1	24	19.70	452.55
3236	3236	3	61	2	1	61	43.70	2696.55
3237	3237	1	210	3	1	16	55.30	875.35
3238	3238	6	193	2	1	65	19.85	1267.05
3239	3239	5	193	2	1	26	19.65	494.90
3240	3240	2	69	4	1	16	49.45	799.00
3241	3241	3	309	1	2	54	106.55	5763.30
3242	3242	1	193	4	2	1	20.10	20.10
3243	3243	5	193	4	1	5	20.45	106.90
3244	3244	2	18	3	1	19	39.70	710.05
3245	3245	2	226	2	1	10	54.50	568.20
3246	3246	1	157	3	2	23	83.80	1900.25
3247	3247	1	67	4	2	3	55.15	159.15
3248	3248	6	289	1	1	72	111.60	8012.75
3249	3249	2	259	3	2	10	86.65	856.65
3250	3250	2	89	4	1	10	55.55	551.30
3251	3251	4	193	4	1	11	20.55	184.95
3252	3252	2	309	1	2	37	106.75	4056.75
3253	3253	4	230	4	1	17	62.10	1096.65
3254	3254	2	301	2	1	36	104.50	3684.95
3255	3255	2	156	3	1	17	101.80	1752.45
3256	3256	4	313	2	1	66	110.60	7210.85
3257	3257	3	128	1	1	61	84.90	5264.50
3258	3258	2	148	4	1	22	93.20	2157.30
3259	3259	2	1	3	1	1	24.40	24.40
3260	3260	1	129	2	1	6	70.55	433.95
3261	3261	2	149	3	2	31	78.45	2435.15
3262	3262	6	128	2	1	68	85.00	5607.75
3263	3263	1	268	3	2	34	87.45	2874.15
3264	3264	1	157	1	1	52	85.80	4433.30
3265	3265	2	143	3	1	10	91.10	964.35
3266	3266	2	129	3	2	29	70.75	1974.80
3267	3267	5	193	1	1	72	20.10	1460.85
3268	3268	3	193	4	1	47	20.05	951.55
3269	3269	3	229	4	1	24	74.80	1821.20
3270	3270	3	322	2	1	65	24.80	1600.95
3271	3271	2	265	4	1	4	100.85	399.25
3272	3272	2	277	3	2	12	101.35	1218.55
3273	3273	2	290	3	2	1	81.70	81.70
3274	3274	1	129	3	2	33	68.25	2171.15
3275	3275	2	160	3	1	34	105.10	3634.80
3276	3276	5	193	4	1	14	20.40	292.40
3277	3277	2	130	3	2	4	79.15	317.25
3278	3278	3	193	4	1	13	20.00	218.55
3279	3279	6	217	1	1	65	79.40	5071.90
3280	3280	3	101	2	1	23	57.20	1423.35
3281	3281	5	121	3	1	55	58.60	3068.60
3282	3282	6	148	3	1	49	94.80	4690.65
3283	3283	3	285	1	1	60	102.50	6157.60
3284	3284	4	193	2	1	69	20.35	1442.65
3285	3285	2	260	3	1	40	84.90	3369.05
3286	3286	6	118	2	1	67	69.20	4671.65
3287	3287	2	261	3	2	35	95.45	3474.05
3288	3288	4	265	3	2	19	100.95	1875.55
3289	3289	5	193	4	1	13	20.85	272.35
3290	3290	2	276	1	1	41	88.50	3645.05
3291	3291	1	41	4	1	4	35.00	135.75
3292	3292	1	101	3	1	24	55.15	1319.85
3293	3293	2	20	2	1	5	50.95	229.40
3294	3294	2	211	3	1	5	64.00	370.25
3295	3295	2	129	4	2	1	69.10	69.10
3296	3296	5	256	1	1	72	80.20	5714.20
3297	3297	2	73	2	1	24	49.30	1233.25
3298	3298	5	241	2	1	42	84.35	3571.60
3299	3299	1	193	4	1	4	20.05	83.30
3300	3300	4	321	2	1	68	117.20	8035.95
3301	3301	3	193	4	1	33	20.10	579.40
3302	3302	2	129	3	2	1	69.60	69.60
3303	3303	4	285	3	2	31	103.45	3066.45
3304	3304	1	274	1	2	4	77.95	305.55
3305	3305	6	289	3	1	69	109.95	7634.25
3306	3306	1	261	3	1	38	94.75	3653.00
3307	3307	2	149	3	1	3	80.00	241.30
3308	3308	5	217	3	1	48	79.65	3870.30
3309	3309	5	322	4	1	15	25.20	387.90
3310	3310	3	193	2	1	25	19.90	527.50
3311	3311	1	131	3	2	1	78.45	78.45
3312	3312	2	51	3	1	48	44.80	2104.55
3313	3313	1	193	4	1	1	20.30	20.30
3314	3314	1	193	3	1	1	19.20	19.20
3315	3315	3	153	3	1	37	80.05	3019.10
3316	3316	4	289	1	1	66	107.35	7051.95
3317	3317	3	59	1	1	26	47.85	1190.50
3318	3318	3	119	2	1	63	70.80	4448.80
3319	3319	1	9	4	2	10	29.50	255.25
3320	3320	2	100	3	2	2	70.75	146.90
3321	3321	2	98	2	1	18	59.10	1011.05
3322	3322	5	322	4	1	64	25.55	1714.95
3323	3323	2	259	3	2	9	84.45	762.50
3324	3324	1	193	4	1	28	20.25	535.35
3325	3325	1	137	3	1	1	75.55	75.55
3326	3326	2	259	3	2	4	85.65	338.90
3327	3327	4	95	2	2	38	70.15	2497.35
3328	3328	3	283	3	1	66	95.30	6273.40
3329	3329	2	129	3	1	1	70.25	70.25
3330	3330	2	69	4	1	18	50.30	908.75
3331	3331	2	269	3	2	51	97.80	4913.30
3332	3332	5	193	4	1	0	19.85	\N
3333	3333	1	65	4	2	1	46.30	46.30
3334	3334	5	193	1	1	12	19.35	212.30
3335	3335	2	285	3	2	41	106.30	4443.45
3336	3336	1	322	3	1	12	25.00	316.20
3337	3337	5	193	4	1	55	20.30	1079.05
3338	3338	2	258	3	1	7	75.35	564.65
3339	3339	2	142	3	2	12	89.40	1095.65
3340	3340	5	257	2	1	68	88.00	6161.90
3341	3341	2	260	2	2	5	83.15	446.05
3342	3342	1	65	4	1	49	43.80	2106.05
3343	3343	3	60	2	1	40	62.05	2511.55
3344	3344	3	193	1	1	16	20.10	318.60
3345	3345	2	258	4	2	10	74.15	811.80
3346	3346	4	285	3	1	72	101.35	7323.15
3347	3347	2	259	3	1	2	84.05	186.05
3348	3348	5	193	4	1	23	20.90	454.00
3349	3349	4	285	3	1	71	105.90	7521.95
3350	3350	2	269	3	2	11	99.50	1056.95
3351	3351	2	65	4	2	1	44.15	44.15
3352	3352	2	85	4	2	16	53.90	834.15
3353	3353	2	259	4	2	1	85.45	85.45
3354	3354	2	146	2	1	12	85.05	999.80
3355	3355	3	38	1	1	54	44.10	2369.70
3356	3356	5	286	2	1	68	90.20	6297.65
3357	3357	1	194	4	2	4	50.85	239.55
3358	3358	1	74	3	2	1	59.20	59.20
3359	3359	1	101	4	1	27	53.45	1461.45
3360	3360	2	193	4	1	21	19.95	416.40
3361	3361	2	139	3	2	13	83.20	1060.60
3362	3362	1	223	2	1	64	74.65	4869.35
3363	3363	2	113	3	2	1	54.90	54.90
3364	3364	6	32	1	1	57	57.50	3265.95
3365	3365	2	301	3	2	21	103.90	2254.20
3366	3366	5	193	4	1	19	19.65	358.15
3367	3367	4	140	3	1	31	93.80	2939.80
3368	3368	6	257	4	1	52	89.25	4652.40
3369	3369	4	283	3	1	46	94.15	4408.45
3370	3370	2	226	3	1	11	55.60	580.80
3371	3371	2	58	1	1	53	48.70	2495.20
3372	3372	2	193	4	2	11	19.25	180.30
3373	3373	2	281	1	1	57	104.90	5913.95
3374	3374	2	258	4	2	2	75.45	158.40
3375	3375	1	113	4	2	2	54.85	104.20
3376	3376	5	193	1	1	71	19.90	1389.35
3377	3377	2	193	4	1	1	19.40	19.40
3378	3378	5	322	2	1	68	25.05	1629.20
3379	3379	5	128	4	1	72	84.45	6033.10
3380	3380	1	193	4	1	2	19.30	44.40
3381	3381	2	261	3	2	1	95.10	95.10
3382	3382	4	112	1	1	41	79.85	3320.75
3383	3383	5	322	2	1	72	25.55	1867.70
3384	3384	2	258	3	2	6	75.50	438.00
3385	3385	2	137	3	2	4	73.75	325.45
3386	3386	2	261	3	2	12	96.05	1148.10
3387	3387	4	231	3	1	58	68.40	3972.25
3388	3388	1	193	4	1	7	20.65	155.90
3389	3389	2	105	4	1	65	55.15	3673.15
3390	3390	2	129	4	1	1	70.60	70.60
3391	3391	3	193	2	1	56	19.95	1126.75
3392	3392	1	193	4	1	4	19.00	73.45
3393	3393	4	65	4	1	58	44.10	2413.05
3394	3394	6	273	1	1	62	107.60	6912.70
3395	3395	3	242	3	1	26	61.55	1581.95
3396	3396	1	314	1	1	62	90.70	5586.45
3397	3397	3	180	2	1	58	99.25	5846.65
3398	3398	6	257	3	1	68	91.70	6424.70
3399	3399	4	315	2	1	61	100.70	6018.65
3400	3400	6	209	2	1	42	78.45	3373.40
3401	3401	1	260	1	1	18	84.30	1537.90
3402	3402	6	193	1	1	56	19.55	1080.55
3403	3403	2	275	3	2	4	88.95	355.20
3404	3404	1	193	2	1	4	20.45	82.85
3405	3405	3	113	2	1	35	55.60	2016.45
3406	3406	2	294	1	1	64	86.80	5327.25
3407	3407	3	193	4	1	31	20.95	683.25
3408	3408	6	193	1	1	67	20.05	1263.05
3409	3409	1	81	2	2	4	50.70	151.30
3410	3410	6	321	3	1	70	113.65	7714.65
3411	3411	1	67	2	2	3	53.40	188.70
3412	3412	2	277	3	2	53	101.90	5549.40
3413	3413	5	117	4	1	2	59.50	130.50
3414	3414	2	132	2	1	29	87.80	2621.75
3415	3415	5	45	4	1	47	41.90	1875.25
3416	3416	4	260	3	2	68	83.00	5685.80
3417	3417	2	100	4	1	12	69.85	837.50
3418	3418	1	85	1	1	8	56.30	401.50
3419	3419	1	317	3	1	54	109.55	6118.95
3420	3420	6	151	4	1	69	92.15	6480.90
3421	3421	2	244	1	1	26	69.50	1800.05
3422	3422	6	318	1	1	72	97.00	7104.20
3423	3423	6	48	1	1	70	58.35	4214.25
3424	3424	1	97	4	2	1	50.60	50.60
3425	3425	2	132	3	2	10	89.50	863.10
3426	3426	4	129	1	1	28	70.40	1992.20
3427	3427	2	129	3	2	1	69.80	69.80
3428	3428	2	261	3	1	21	94.30	1948.35
3429	3429	2	300	1	2	51	93.80	4750.95
3430	3430	3	193	1	1	53	19.55	1007.90
3431	3431	3	186	3	1	53	95.95	5036.90
3432	3432	2	269	3	2	24	101.05	2391.80
3433	3433	6	257	2	1	70	94.80	6859.05
3434	3434	4	317	3	1	61	107.75	6521.90
3435	3435	4	101	4	1	11	54.60	617.85
3436	3436	2	129	2	1	2	71.30	157.75
3437	3437	4	193	1	1	25	19.50	516.30
3438	3438	4	210	2	1	41	56.30	2364.00
3439	3439	2	261	3	2	18	94.70	1687.95
3440	3440	6	285	1	2	72	104.15	7689.95
3441	3441	6	257	2	1	71	90.55	6239.05
3442	3442	4	121	4	1	34	60.80	2042.05
3443	3443	2	144	2	1	29	98.80	2807.10
3444	3444	4	191	2	1	40	98.15	4116.80
3445	3445	3	41	4	1	36	35.35	1317.95
3446	3446	4	281	3	1	46	103.15	4594.65
3447	3447	4	317	3	1	58	107.75	6332.75
3448	3448	3	274	2	1	39	81.40	3213.75
3449	3449	1	70	2	2	4	61.45	229.55
3450	3450	4	284	2	1	52	95.70	4976.15
3451	3451	4	285	3	1	70	104.80	7308.95
3452	3452	4	129	1	1	65	70.95	4555.20
3453	3453	2	65	4	1	1	44.95	44.95
3454	3454	4	269	3	1	70	97.65	6982.50
3455	3455	2	25	4	1	29	35.65	1025.15
3456	3456	2	132	3	2	1	90.55	90.55
3457	3457	6	241	4	1	67	85.25	5714.20
3458	3458	2	193	4	1	1	19.50	19.50
3459	3459	2	132	1	2	26	88.80	2274.35
3460	3460	6	322	4	1	30	25.10	789.55
3461	3461	2	144	2	1	48	100.05	4834.00
3462	3462	1	113	3	1	55	55.70	3131.80
3463	3463	2	259	4	2	7	85.20	602.55
3464	3464	2	292	3	1	37	91.15	3369.25
3465	3465	2	146	1	1	31	83.85	2674.15
3466	3466	2	65	3	1	4	45.90	199.75
3467	3467	6	322	2	1	72	25.10	1790.80
3468	3468	2	132	3	2	5	91.40	449.75
3469	3469	1	193	4	1	1	19.70	19.70
3470	3470	2	132	3	1	15	91.50	1400.30
3471	3471	2	97	2	1	8	51.30	411.60
3472	3472	3	193	4	1	35	21.10	741.00
3473	3473	1	285	3	1	56	104.75	5841.35
3474	3474	2	273	1	2	42	106.15	4512.70
3475	3475	2	306	3	1	65	85.75	5688.45
3476	3476	3	193	4	1	2	20.30	31.90
3477	3477	4	293	3	1	65	100.75	6674.65
3478	3478	2	258	3	1	18	74.15	1345.75
3479	3479	4	237	3	1	23	78.55	1843.05
3480	3480	2	65	4	2	4	45.30	196.95
3481	3481	5	193	2	1	70	19.85	1433.80
3482	3482	1	194	3	1	4	50.70	214.55
3483	3483	2	65	1	1	19	45.00	865.85
3484	3484	1	153	3	1	18	77.80	1358.60
3485	3485	2	162	3	1	38	83.45	3147.15
3486	3486	2	258	2	2	2	73.25	131.05
3487	3487	3	308	1	1	47	94.80	4535.85
3488	3488	5	193	1	1	52	20.10	1078.75
3489	3489	1	195	4	1	9	59.90	542.40
3490	3490	4	257	2	1	26	90.10	2312.55
3491	3491	2	73	3	2	8	51.05	415.05
3492	3492	4	95	3	1	44	70.95	3250.45
3493	3493	1	17	4	1	3	29.20	98.50
3494	3494	2	65	1	1	2	46.60	87.90
3495	3495	2	260	1	2	9	85.35	754.65
3496	3496	2	258	3	2	1	75.35	75.35
3497	3497	1	161	1	1	25	74.30	1952.25
3498	3498	2	129	3	1	2	69.30	153.80
3499	3499	2	161	3	2	43	75.20	3198.60
3500	3500	1	193	4	2	1	20.90	20.90
3501	3501	4	283	3	1	58	94.30	5610.15
3502	3502	6	240	4	1	59	76.45	4519.50
3503	3503	4	44	3	1	44	54.00	2440.25
3504	3504	4	281	3	1	66	104.25	6860.60
3505	3505	5	193	1	1	68	19.95	1377.70
3506	3506	2	1	3	1	9	24.95	190.25
3507	3507	2	298	3	1	19	84.75	1651.95
3508	3508	1	193	4	1	4	19.75	78.30
3509	3509	6	321	1	1	70	113.65	7939.25
3510	3510	2	65	4	1	1	44.90	44.90
3511	3511	2	258	3	1	8	75.25	576.70
3512	3512	5	322	4	1	53	24.60	1279.00
3513	3513	3	322	1	1	51	25.00	1260.70
3514	3514	1	193	1	1	11	20.95	267.35
3515	3515	6	305	3	1	60	110.60	6586.85
3516	3516	2	113	2	1	17	55.50	934.15
3517	3517	2	65	3	2	3	43.30	123.65
3518	3518	4	192	1	2	70	109.50	7534.65
3519	3519	1	193	4	1	1	19.45	19.45
3520	3520	2	260	3	1	43	84.85	3645.60
3521	3521	1	193	4	1	16	19.60	314.45
3522	3522	3	113	3	1	57	53.45	3053.00
3523	3523	3	193	2	1	37	19.80	677.05
3524	3524	5	321	2	1	72	112.10	7965.95
3525	3525	2	259	2	2	11	84.80	906.85
3526	3526	2	284	3	2	50	95.05	4888.70
3527	3527	1	73	3	2	5	50.35	237.25
3528	3528	2	258	1	2	1	74.60	74.60
3529	3529	2	193	4	2	16	19.70	342.40
3530	3530	2	137	3	1	2	74.20	140.10
3531	3531	2	208	4	1	17	69.00	1108.00
3532	3532	3	193	2	1	16	19.35	295.55
3533	3533	2	74	3	2	15	59.45	892.65
3534	3534	4	193	4	1	10	19.80	198.25
3535	3535	4	184	1	2	46	105.20	4822.85
3536	3536	6	289	2	1	64	109.20	6741.15
3537	3537	2	274	4	1	1	79.15	79.15
3538	3538	3	89	4	1	25	53.65	1355.45
3539	3539	5	191	2	1	71	100.20	7209.00
3540	3540	2	65	4	2	8	45.15	438.40
3541	3541	6	192	1	1	72	108.65	7726.35
3542	3542	1	35	1	1	49	40.65	2070.75
3543	3543	4	62	2	1	29	55.35	1636.95
3544	3544	5	319	1	1	72	105.60	7581.50
3545	3545	1	284	3	2	31	93.80	3019.50
3546	3546	2	261	3	1	50	95.70	4729.75
3547	3547	5	241	3	1	71	83.20	6126.10
3548	3548	5	257	2	1	70	90.05	6333.40
3549	3549	3	295	2	1	71	97.65	6687.85
3550	3550	6	125	1	1	61	68.05	4158.25
3551	3551	2	136	3	2	32	96.20	3183.40
3552	3552	2	130	3	2	1	79.60	79.60
3553	3553	6	315	1	1	68	102.10	7149.35
3554	3554	5	322	1	1	62	23.40	1429.65
3555	3555	2	129	3	1	7	71.05	472.65
3556	3556	2	260	3	2	20	85.25	1734.50
3557	3557	3	193	4	1	6	19.45	113.50
3558	3558	2	60	1	1	33	59.45	1884.65
3559	3559	3	261	1	1	28	92.20	2568.15
3560	3560	5	193	2	1	27	19.85	470.00
3561	3561	1	65	4	1	7	43.90	278.40
3562	3562	2	262	3	2	26	80.50	2088.80
3563	3563	2	275	3	2	5	89.80	502.60
3564	3564	2	291	2	1	30	90.50	2595.85
3565	3565	3	275	2	1	63	90.45	5825.50
3566	3566	2	81	3	2	1	50.75	50.75
3567	3567	4	225	3	1	53	84.60	4449.75
3568	3568	2	150	2	2	14	89.65	1208.35
3569	3569	2	152	1	1	21	99.15	1956.40
3570	3570	3	193	4	1	17	19.95	310.60
3571	3571	5	193	4	1	16	20.50	290.55
3572	3572	2	74	3	1	35	62.10	2096.10
3573	3573	2	130	3	1	32	79.50	2665.00
3574	3574	2	193	1	1	28	19.55	543.80
3575	3575	2	193	4	1	1	20.35	20.35
3576	3576	2	8	3	1	59	51.70	3005.80
3577	3577	4	322	1	1	72	23.30	1623.15
3578	3578	4	86	4	2	36	65.40	2498.40
3579	3579	1	115	4	1	40	65.10	2586.00
3580	3580	2	266	3	1	40	81.20	3292.30
3581	3581	2	80	4	2	9	72.90	651.40
3582	3582	5	127	2	1	63	74.50	4674.55
3583	3583	2	131	3	1	3	80.50	232.35
3584	3584	3	32	4	1	40	60.30	2448.50
3585	3585	2	161	4	1	8	75.00	658.10
3586	3586	3	167	4	1	34	90.15	3128.80
3587	3587	1	45	4	2	5	40.00	223.45
3588	3588	2	277	2	2	9	99.45	919.40
3589	3589	2	219	2	1	9	69.05	653.95
3590	3590	1	195	1	1	31	59.70	1825.50
3591	3591	4	193	1	1	50	19.85	943.10
3592	3592	2	181	3	2	2	86.25	181.65
3593	3593	2	65	3	2	1	45.65	45.65
3594	3594	2	129	4	2	8	70.10	551.35
3595	3595	1	18	3	1	9	40.75	359.40
3596	3596	2	129	1	2	2	70.20	115.95
3597	3597	1	113	3	2	3	55.35	165.20
3598	3598	2	136	2	1	25	95.70	2338.35
3599	3599	1	65	3	1	1	46.30	46.30
3600	3600	1	256	4	1	45	81.30	3541.10
3601	3601	2	282	3	2	51	84.20	4146.05
3602	3602	1	193	2	1	55	20.00	1087.25
3603	3603	2	250	1	1	38	66.15	2522.40
3604	3604	1	65	4	2	2	45.85	81.00
3605	3605	1	193	3	1	38	19.60	717.30
3606	3606	2	81	3	1	34	49.80	1734.20
3607	3607	4	269	3	1	70	101.75	7069.30
3608	3608	3	101	4	1	13	55.15	742.90
3609	3609	1	258	3	2	39	75.25	3017.65
3610	3610	4	285	3	1	61	103.95	6423.00
3611	3611	2	269	1	2	12	100.15	1164.30
3612	3612	6	152	2	1	41	99.65	4220.35
3613	3613	2	258	3	1	21	73.70	1558.70
3614	3614	4	12	1	1	55	50.05	2743.45
3615	3615	5	48	1	1	69	60.25	4055.50
3616	3616	1	285	3	2	26	105.75	2710.25
3617	3617	3	178	2	1	69	87.30	6055.55
3618	3618	2	12	3	2	18	48.35	810.70
3619	3619	1	210	3	1	47	54.25	2538.20
3620	3620	5	128	1	1	72	85.30	6129.20
3621	3621	2	31	3	1	33	50.00	1750.85
3622	3622	2	1	4	2	2	24.40	36.55
3623	3623	5	257	2	1	72	90.95	6652.45
3624	3624	2	129	1	1	37	72.25	2575.45
3625	3625	2	283	2	1	62	96.10	6019.35
3626	3626	5	193	2	1	71	19.85	1379.60
3627	3627	2	85	1	1	23	55.30	1284.20
3628	3628	3	193	4	1	16	20.10	296.15
3629	3629	2	111	4	1	9	69.50	653.25
3630	3630	6	322	4	1	17	25.15	412.60
3631	3631	1	193	1	2	4	20.95	85.50
3632	3632	2	97	3	2	1	49.55	49.55
3633	3633	2	266	4	1	24	79.65	1928.70
3634	3634	2	129	3	1	1	71.25	71.25
3635	3635	5	321	1	1	72	113.80	7845.80
3636	3636	5	322	3	1	72	24.55	1750.70
3637	3637	1	193	2	1	11	19.70	216.20
3638	3638	1	193	4	2	9	20.25	178.50
3639	3639	1	81	2	2	2	50.15	115.10
3640	3640	4	269	2	1	60	100.50	6029.00
3641	3641	2	283	3	2	29	95.90	2745.20
3642	3642	6	80	1	1	49	74.45	3721.90
3643	3643	2	285	3	1	30	104.10	3121.10
3644	3644	3	193	2	1	53	19.05	990.45
3645	3645	5	322	4	1	39	25.00	1004.35
3646	3646	1	193	4	1	9	19.05	157.65
3647	3647	3	141	3	1	39	81.90	3219.75
3648	3648	2	129	3	1	8	69.70	572.85
3649	3649	4	267	3	1	51	90.15	4554.85
3650	3650	5	322	2	1	71	25.35	1847.55
3651	3651	6	322	4	1	71	24.65	1766.75
3652	3652	6	193	2	1	70	19.55	1462.05
3653	3653	1	1	3	2	1	25.25	25.25
3654	3654	6	56	1	1	38	60.00	2193.20
3655	3655	1	154	2	1	28	89.90	2433.50
3656	3656	1	193	1	1	32	19.40	641.15
3657	3657	5	81	4	1	49	49.80	2398.40
3658	3658	6	322	1	1	37	24.10	861.85
3659	3659	1	77	3	1	10	54.25	583.00
3660	3660	3	317	2	1	67	109.90	7332.40
3661	3661	4	13	2	1	7	35.50	249.55
3662	3662	3	132	2	1	51	87.55	4475.90
3663	3663	1	65	3	2	9	45.15	416.45
3664	3664	2	132	4	1	9	88.40	788.60
3665	3665	2	69	4	1	4	50.80	202.30
3666	3666	6	316	3	1	71	99.00	6994.60
3667	3667	2	260	1	2	50	84.40	4116.15
3668	3668	6	140	3	1	24	96.55	2263.45
3669	3669	4	99	1	1	22	59.75	1374.35
3670	3670	2	317	3	1	44	111.50	4915.15
3671	3671	1	322	1	1	33	24.25	838.50
3672	3672	2	258	3	2	1	75.10	75.10
3673	3673	4	197	2	2	54	70.15	3715.65
3674	3674	2	277	3	2	42	101.75	4273.45
3675	3675	1	65	3	2	1	45.80	45.80
3676	3676	1	193	4	1	1	20.50	20.50
3677	3677	3	119	3	1	30	70.40	2044.75
3678	3678	1	5	4	1	1	30.55	30.55
3679	3679	1	249	3	1	16	84.90	1398.25
3680	3680	2	193	4	2	1	20.10	20.10
3681	3681	1	7	4	2	9	40.65	328.95
3682	3682	2	269	3	2	46	101.00	4680.05
3683	3683	2	129	3	2	1	69.10	69.10
3684	3684	5	101	1	1	71	54.50	3778.20
3685	3685	2	258	2	1	43	75.35	3161.40
3686	3686	4	39	1	1	50	44.45	2188.45
3687	3687	2	258	4	2	13	75.00	999.45
3688	3688	3	152	1	2	19	100.00	1888.65
3689	3689	1	269	1	1	41	98.05	3990.60
3690	3690	2	129	3	2	1	71.15	71.15
3691	3691	2	28	2	2	24	54.15	1240.25
3692	3692	3	212	1	1	40	63.90	2635.00
3693	3693	2	220	1	1	3	69.15	235.00
3694	3694	3	228	1	1	37	64.65	2347.85
3695	3695	6	305	2	2	67	108.75	7156.20
3696	3696	2	277	3	1	32	98.85	3089.60
3697	3697	2	69	3	2	6	49.15	270.80
3698	3698	1	292	3	1	32	89.60	2901.80
3699	3699	2	282	3	1	59	83.25	4949.10
3700	3700	3	94	1	1	30	70.25	2198.90
3701	3701	2	193	3	2	20	19.40	374.50
3702	3702	5	322	3	1	27	24.50	761.95
3703	3703	2	290	3	2	20	79.15	1520.90
3704	3704	3	193	4	1	9	20.10	190.25
3705	3705	4	252	2	1	68	73.00	5163.00
3706	3706	5	230	2	1	69	61.40	4059.85
3707	3707	2	270	4	1	26	84.30	2281.60
3708	3708	5	193	1	1	69	19.90	1356.70
3709	3709	5	193	4	1	11	20.40	231.45
3710	3710	1	194	4	1	1	50.75	50.75
3711	3711	3	193	4	1	10	20.45	242.40
3712	3712	4	247	1	1	55	75.75	4264.25
3713	3713	3	103	3	1	44	65.40	2774.55
3714	3714	2	130	3	2	46	80.40	3605.20
3715	3715	6	121	1	1	69	59.75	4069.90
3716	3716	2	130	3	1	11	78.50	874.20
3717	3717	2	277	3	2	11	102.00	1145.35
3718	3718	1	73	1	1	29	48.95	1323.70
3719	3719	2	293	3	1	57	99.65	5497.05
3720	3720	3	193	2	1	28	18.25	534.70
3721	3721	1	105	2	1	42	54.55	2455.05
3722	3722	1	193	4	2	2	20.65	38.70
3723	3723	3	53	1	1	23	40.65	947.40
3724	3724	1	193	4	1	18	20.45	357.00
3725	3725	3	322	1	1	62	24.80	1476.25
3726	3726	2	129	4	2	1	70.80	70.80
3727	3727	2	263	2	2	16	89.05	1448.60
3728	3728	2	261	3	2	3	96.60	291.90
3729	3729	4	257	1	1	67	88.80	5903.15
3730	3730	6	193	2	1	62	20.05	1201.65
3731	3731	2	285	2	2	57	104.50	5921.35
3732	3732	2	129	3	1	2	69.80	146.65
3733	3733	6	240	1	1	23	77.15	1759.40
3734	3734	5	37	1	1	25	35.05	844.45
3735	3735	6	289	1	1	72	108.10	7774.05
3736	3736	2	260	3	1	2	84.05	134.05
3737	3737	4	193	1	1	8	20.20	140.95
3738	3738	2	194	4	2	5	50.60	249.95
3739	3739	1	12	3	1	35	49.20	1701.65
3740	3740	3	322	3	1	24	24.60	592.65
3741	3741	2	129	3	1	2	71.65	135.75
3742	3742	6	319	2	1	72	104.90	7732.65
3743	3743	2	320	3	1	41	106.50	4282.40
3744	3744	1	97	3	2	4	49.35	219.65
3745	3745	3	145	1	1	26	75.50	2018.10
3746	3746	2	148	3	2	7	94.25	669.00
3747	3747	2	129	3	2	1	68.95	68.95
3748	3748	2	214	4	1	4	58.50	224.85
3749	3749	5	96	2	1	48	78.90	3771.50
3750	3750	2	261	3	2	2	93.85	196.75
3751	3751	4	112	3	1	12	79.20	943.85
3752	3752	2	305	1	1	60	109.45	6572.85
3753	3753	6	109	3	1	55	59.20	3175.85
3754	3754	1	5	4	1	1	29.15	29.15
3755	3755	1	193	4	1	1	20.05	20.05
3756	3756	2	258	3	2	4	76.05	318.90
3757	3757	2	1	4	2	1	24.45	24.45
3758	3758	5	78	2	1	42	66.50	2762.75
3759	3759	1	97	1	1	1	49.55	49.55
3760	3760	2	268	2	2	7	89.35	631.85
3761	3761	2	137	2	1	3	73.60	232.50
3762	3762	6	253	2	1	72	82.65	5919.35
3763	3763	2	194	3	1	15	49.00	749.25
3764	3764	2	131	3	2	4	80.35	307.40
3765	3765	3	322	3	1	11	25.20	245.15
3766	3766	1	322	4	1	5	25.45	134.75
3767	3767	2	105	3	2	1	55.80	55.80
3768	3768	6	305	2	1	72	110.90	8240.85
3769	3769	2	274	2	1	55	77.75	4266.40
3770	3770	2	322	3	1	40	26.20	1077.50
3771	3771	5	193	1	1	57	19.90	1115.60
3772	3772	2	131	3	2	1	79.05	79.05
3773	3773	2	164	3	2	1	95.00	95.00
3774	3774	1	1	4	2	1	25.20	25.20
3775	3775	4	221	3	1	52	80.85	4079.55
3776	3776	2	269	3	2	41	98.40	4187.75
3777	3777	4	67	4	1	43	56.35	2391.15
3778	3778	5	193	1	1	47	19.30	890.50
3779	3779	1	194	1	1	3	50.40	137.25
3780	3780	5	256	2	2	66	79.40	5154.60
3781	3781	6	77	2	1	55	55.25	3119.90
3782	3782	3	193	4	1	29	19.10	529.50
3783	3783	2	260	3	1	12	84.05	966.55
3784	3784	2	285	3	1	66	105.20	6936.85
3785	3785	2	269	3	2	35	101.40	3496.30
3786	3786	2	267	3	2	10	89.80	914.30
3787	3787	2	258	1	1	27	75.75	1929.00
3788	3788	2	136	3	1	58	95.30	5817.70
3789	3789	5	192	1	2	54	109.75	6110.20
3790	3790	1	193	4	1	9	19.85	178.80
3791	3791	3	193	2	2	2	19.30	28.30
3792	3792	2	129	3	1	6	69.10	435.00
3793	3793	2	132	3	2	26	91.25	2351.80
3794	3794	1	193	4	1	9	20.25	186.15
3795	3795	2	89	4	1	8	54.75	445.85
3796	3796	2	131	3	1	12	81.45	912.00
3797	3797	2	194	3	2	15	49.10	679.55
3798	3798	4	237	3	1	43	80.20	3581.60
3799	3799	2	265	3	1	42	100.30	4222.95
3800	3800	1	238	2	2	31	65.25	1994.30
3801	3801	6	302	2	1	66	90.95	5930.05
3802	3802	2	278	3	2	18	85.45	1505.85
3803	3803	1	193	4	1	1	20.00	20.00
3804	3804	6	280	3	2	61	94.10	5638.30
3805	3805	1	274	3	1	10	79.85	797.25
3806	3806	2	129	3	2	1	71.65	71.65
3807	3807	2	145	3	1	18	73.55	1359.45
3808	3808	2	285	3	2	24	104.65	2542.45
3809	3809	1	193	4	1	3	19.30	54.70
3810	3810	3	193	2	1	50	20.15	989.05
3811	3811	1	65	3	1	1	44.55	44.55
3812	3812	2	101	4	1	2	54.45	87.30
3813	3813	4	193	1	1	17	19.65	351.55
3814	3814	6	285	3	1	69	105.00	7297.75
3815	3815	6	257	2	1	72	88.70	6301.70
3816	3816	2	258	3	2	3	74.25	210.30
3817	3817	6	251	1	1	50	75.15	3822.45
3818	3818	5	193	4	1	53	20.25	1048.45
3819	3819	6	313	2	1	58	109.10	6393.65
3820	3820	4	33	1	1	46	30.75	1489.30
3821	3821	2	321	2	1	72	112.90	8061.50
3822	3822	2	258	3	2	1	74.20	74.20
3823	3823	2	284	4	1	6	94.05	518.75
3824	3824	5	255	1	1	72	78.85	5763.15
3825	3825	2	66	4	1	4	55.30	238.50
3826	3826	5	193	4	1	52	19.35	1031.70
3827	3827	5	322	4	1	0	25.35	\N
3828	3828	3	193	4	1	2	20.45	34.80
3829	3829	5	193	1	1	65	19.35	1319.95
3830	3830	2	277	3	2	43	101.00	4388.40
3831	3831	2	277	3	2	4	100.20	420.20
3832	3832	4	291	3	2	25	89.05	2177.45
3833	3833	4	217	2	1	51	78.65	3950.85
3834	3834	1	205	1	1	12	74.75	827.05
3835	3835	4	100	1	2	57	70.10	3913.30
3836	3836	3	193	4	1	24	19.90	533.50
3837	3837	3	206	1	1	64	58.35	3756.45
3838	3838	4	160	3	2	4	105.65	443.90
3839	3839	2	269	1	1	26	100.50	2599.95
3840	3840	1	193	4	1	15	20.05	284.30
3841	3841	5	322	2	1	64	25.65	1740.80
3842	3842	2	277	3	2	36	96.50	3436.10
3843	3843	1	261	2	1	27	95.00	2462.55
3844	3844	1	129	4	2	1	70.85	70.85
3845	3845	4	241	2	2	35	85.95	3110.10
3846	3846	2	137	3	2	4	73.90	280.85
3847	3847	2	65	3	1	8	45.45	411.75
3848	3848	2	193	2	1	10	20.00	198.60
3849	3849	1	81	4	1	2	49.20	103.70
3850	3850	6	317	1	2	58	109.45	6144.55
3851	3851	6	128	2	1	51	83.25	4089.45
3852	3852	6	193	4	1	46	19.25	864.20
3853	3853	2	193	1	1	1	19.65	19.65
3854	3854	1	258	1	1	46	72.80	3249.40
3855	3855	2	313	1	1	50	109.65	5405.80
3856	3856	1	87	2	1	53	65.00	3363.80
3857	3857	2	289	3	1	61	114.10	7132.15
3858	3858	1	193	1	1	5	20.65	93.55
3859	3859	4	128	1	1	47	86.95	4138.90
3860	3860	4	284	1	1	54	94.75	5121.75
3861	3861	2	1	2	1	19	25.35	566.10
3862	3862	6	160	3	1	26	105.45	2715.30
3863	3863	5	322	4	1	70	25.40	1782.05
3864	3864	2	285	3	1	17	102.55	1742.50
3865	3865	2	277	3	2	30	100.20	2983.80
3866	3866	1	322	4	1	1	24.00	24.00
3867	3867	5	322	4	1	19	25.60	485.90
3868	3868	6	92	2	1	26	73.50	1905.70
3869	3869	2	145	1	2	21	74.05	1565.70
3870	3870	4	277	3	1	50	98.25	4858.70
3871	3871	4	44	3	1	68	54.40	3723.65
3872	3872	2	269	1	2	3	101.55	298.35
3873	3873	1	144	3	1	9	103.10	970.45
3874	3874	5	37	1	1	51	34.20	1782.00
3875	3875	2	65	3	1	9	43.75	405.70
3876	3876	4	289	3	2	41	111.95	4534.90
3877	3877	2	277	3	1	22	100.65	2415.95
3878	3878	4	44	3	2	21	55.95	1157.05
3879	3879	6	321	1	1	71	116.05	8297.50
3880	3880	1	65	3	2	1	45.75	45.75
3881	3881	4	209	2	1	26	82.00	2083.10
3882	3882	5	246	1	1	71	65.15	4681.75
3883	3883	2	65	2	1	4	44.80	176.20
3884	3884	2	290	3	1	12	79.80	1001.20
3885	3885	2	264	3	1	18	88.85	1594.75
3886	3886	2	258	3	1	3	74.95	212.40
3887	3887	4	309	1	1	72	106.85	7677.40
3888	3888	1	145	3	2	11	74.95	815.50
3889	3889	1	130	2	2	1	80.15	80.15
3890	3890	3	193	2	1	13	19.30	259.65
3891	3891	4	289	3	2	72	109.25	8109.80
3892	3892	3	226	2	1	42	56.10	2386.85
3893	3893	1	193	2	1	17	19.70	340.35
3894	3894	2	81	4	1	7	51.30	419.35
3895	3895	5	321	4	1	68	118.60	7990.05
3896	3896	5	322	1	1	56	24.15	1402.25
3897	3897	3	193	4	1	38	20.30	749.35
3898	3898	6	321	3	1	72	115.50	8425.15
3899	3899	3	322	2	1	48	25.05	1171.50
3900	3900	2	317	3	1	52	109.10	5647.95
3901	3901	3	193	4	1	35	19.65	708.80
3902	3902	6	289	1	1	67	111.30	7567.20
3903	3903	1	33	4	1	1	29.90	29.90
3904	3904	2	149	4	1	53	80.60	4348.10
3905	3905	1	193	4	1	34	20.80	635.90
3906	3906	1	3	2	2	3	35.20	108.95
3907	3907	1	131	3	2	1	78.80	78.80
3908	3908	1	143	4	1	19	89.95	1682.40
3909	3909	6	321	1	1	60	116.05	6925.90
3910	3910	5	193	2	1	11	19.55	223.15
3911	3911	2	285	3	2	47	106.40	5127.95
3912	3912	1	97	3	2	18	49.40	874.80
3913	3913	5	321	2	1	60	115.25	6758.45
3914	3914	5	322	2	1	72	24.80	1874.30
3915	3915	3	193	4	1	39	19.90	791.15
3916	3916	4	169	2	1	59	81.25	4639.45
3917	3917	1	129	4	1	2	69.95	143.90
3918	3918	1	129	3	2	1	69.10	69.10
3919	3919	2	132	3	2	20	90.20	1776.55
3920	3920	2	261	1	2	6	93.55	536.40
3921	3921	6	270	2	1	71	86.40	6172.00
3922	3922	1	250	4	1	24	66.30	1559.45
3923	3923	2	261	2	1	67	94.65	6079.00
3924	3924	2	130	4	2	1	80.85	80.85
3925	3925	4	259	4	2	48	82.05	4029.95
3926	3926	3	215	4	1	37	72.10	2658.40
3927	3927	1	25	4	1	11	34.70	383.55
3928	3928	2	193	2	2	3	20.55	51.15
3929	3929	2	140	2	1	18	95.95	1745.50
3930	3930	4	65	1	1	50	44.80	2230.85
3931	3931	4	305	3	1	67	109.40	7281.60
3932	3932	2	118	4	1	25	71.05	1837.70
3933	3933	2	266	3	2	2	78.55	149.55
3934	3934	1	193	2	1	9	19.70	180.70
3935	3935	3	53	4	1	10	40.25	411.45
3936	3936	5	193	2	1	70	19.85	1328.35
3937	3937	2	110	1	1	9	68.25	576.95
3938	3938	2	193	2	1	4	20.15	68.45
3939	3939	1	97	4	1	2	50.95	123.05
3940	3940	1	130	3	2	1	78.65	78.65
3941	3941	2	1	1	1	19	25.15	468.35
3942	3942	2	193	1	1	7	20.25	174.70
3943	3943	2	65	3	2	1	42.90	42.90
3944	3944	1	65	3	1	1	44.00	44.00
3945	3945	3	193	4	1	9	20.25	172.35
3946	3946	1	37	4	2	3	34.25	139.35
3947	3947	1	48	4	2	9	58.50	539.85
3948	3948	1	105	2	1	5	55.80	300.40
3949	3949	3	132	1	1	56	88.90	4968.00
3950	3950	1	226	4	1	18	57.65	992.70
3951	3951	2	261	3	2	49	96.20	4718.25
3952	3952	5	256	4	1	70	79.15	5536.50
3953	3953	6	289	2	1	72	108.05	7806.60
3954	3954	1	137	3	2	6	74.40	434.10
3955	3955	2	261	3	1	17	94.80	1563.90
3956	3956	2	4	3	1	29	45.90	1332.40
3957	3957	2	285	3	2	6	105.30	545.20
3958	3958	5	269	3	1	63	102.60	6296.75
3959	3959	2	258	1	2	16	73.85	1284.20
3960	3960	4	74	1	1	59	61.35	3645.50
3961	3961	1	75	3	1	3	57.55	161.45
3962	3962	2	17	4	1	8	29.25	226.95
3963	3963	2	259	3	2	7	84.55	646.85
3964	3964	5	193	2	1	68	19.60	1441.65
3965	3965	5	305	2	1	68	111.75	7511.30
3966	3966	4	285	3	1	52	106.50	5621.85
3967	3967	6	313	2	1	72	107.70	7919.80
3968	3968	3	193	4	1	32	19.30	593.20
3969	3969	5	193	1	1	72	20.05	1423.65
3970	3970	2	129	2	1	1	69.95	69.95
3971	3971	3	102	2	1	42	63.70	2763.35
3972	3972	5	322	2	2	25	24.75	692.10
3973	3973	2	97	1	1	45	50.90	2298.55
3974	3974	4	48	2	1	43	60.40	2640.55
3975	3975	3	237	4	1	37	79.25	2911.80
3976	3976	2	259	2	2	20	85.80	1727.50
3977	3977	2	1	3	2	4	24.45	86.60
3978	3978	6	192	2	1	63	110.10	6705.70
3979	3979	1	132	4	1	3	90.70	237.65
3980	3980	6	322	2	1	66	25.30	1672.35
3981	3981	2	285	3	2	28	105.70	2979.50
3982	3982	1	259	3	1	8	85.20	695.75
3983	3983	5	322	4	1	71	24.35	1654.60
3984	3984	2	1	3	2	1	24.25	24.25
3985	3985	5	322	1	1	72	25.10	1857.85
3986	3986	2	113	1	1	16	54.55	825.10
3987	3987	5	318	4	1	66	96.60	6424.25
3988	3988	2	258	3	2	11	76.50	837.95
3989	3989	4	256	2	1	51	81.15	4126.20
3990	3990	2	34	3	1	8	38.50	330.80
3991	3991	2	132	3	1	14	92.90	1337.45
3992	3992	2	279	3	2	4	93.50	362.20
3993	3993	5	253	4	1	70	84.70	5991.05
3994	3994	5	246	3	1	70	66.00	4891.50
3995	3995	4	277	2	2	54	101.50	5373.10
3996	3996	2	161	1	2	28	74.90	2068.55
3997	3997	5	193	4	1	24	20.75	487.05
3998	3998	6	82	2	1	69	61.45	4131.20
3999	3999	1	113	4	1	42	54.50	2301.15
4000	4000	2	129	3	2	2	69.60	131.65
4001	4001	2	269	3	1	39	99.75	4036.00
4002	4002	6	289	1	1	45	109.75	4900.65
4003	4003	6	256	1	1	72	80.85	5727.45
4004	4004	5	193	4	1	38	20.30	743.05
4005	4005	6	254	1	1	72	67.80	4804.65
4006	4006	2	322	4	2	1	24.05	24.05
4007	4007	6	193	2	1	72	19.80	1414.65
4008	4008	5	322	1	1	55	25.70	1443.65
4009	4009	4	16	3	1	51	56.15	2898.95
4010	4010	6	128	1	1	63	86.70	5309.50
4011	4011	1	193	4	1	1	20.40	20.40
4012	4012	6	193	4	1	23	19.65	451.55
4013	4013	1	81	3	2	1	50.55	50.55
4014	4014	2	198	4	1	2	54.35	117.05
4015	4015	1	317	2	1	52	108.10	5839.30
4016	4016	3	226	4	1	36	54.45	1893.50
4017	4017	1	65	4	1	1	45.35	45.35
4018	4018	3	234	4	1	28	59.00	1654.45
4019	4019	3	123	3	1	7	69.45	477.05
4020	4020	2	277	3	2	14	100.55	1415.55
4021	4021	6	64	2	1	72	64.95	4546.00
4022	4022	2	193	4	2	1	20.50	20.50
4023	4023	1	193	4	1	10	18.85	163.20
4024	4024	3	193	1	1	42	19.80	849.90
4025	4025	1	1	1	1	7	25.05	189.95
4026	4026	2	137	1	2	4	74.80	321.90
4027	4027	6	321	2	1	72	114.30	8058.55
4028	4028	2	1	3	2	20	24.45	482.80
4029	4029	5	192	2	1	63	109.20	7049.75
4030	4030	5	61	1	1	56	45.05	2560.10
4031	4031	2	69	4	1	5	51.00	286.80
4032	4032	6	289	1	1	72	110.45	7982.50
4033	4033	2	282	3	1	68	84.65	5683.60
4034	4034	3	117	4	1	67	60.05	3994.05
4035	4035	1	65	1	1	8	44.65	369.15
4036	4036	2	279	1	1	52	93.25	4631.70
4037	4037	2	193	4	1	18	20.25	401.95
4038	4038	5	322	4	1	59	25.45	1534.05
4039	4039	5	193	4	1	60	20.60	1093.00
4040	4040	2	261	3	1	7	94.10	701.30
4041	4041	3	41	4	1	59	34.80	1980.30
4042	4042	6	48	1	1	46	60.75	2893.40
4043	4043	2	81	3	1	5	51.35	262.30
4044	4044	6	48	2	1	59	64.05	3886.85
4045	4045	6	225	1	1	70	84.80	5917.55
4046	4046	2	129	2	2	14	71.00	914.00
4047	4047	2	194	4	1	44	50.15	2139.10
4048	4048	6	300	2	1	64	94.60	5948.70
4049	4049	5	48	4	1	58	59.75	3624.35
4050	4050	3	265	3	1	46	100.25	4753.85
4051	4051	2	277	3	1	58	98.90	5780.70
4052	4052	6	277	2	1	72	97.70	6869.70
4053	4053	2	11	3	2	30	40.30	1172.95
4054	4054	1	242	1	1	11	60.25	662.95
4055	4055	2	28	3	1	34	56.25	1765.95
4056	4056	5	50	1	1	54	46.20	2431.95
4057	4057	2	20	3	2	3	50.60	155.35
4058	4058	5	322	4	1	72	24.90	1859.20
4059	4059	2	270	3	2	40	84.85	3303.05
4060	4060	1	68	4	2	2	65.70	134.35
4061	4061	5	203	2	1	54	63.35	3409.10
4062	4062	1	97	1	1	14	50.10	709.50
4063	4063	1	129	3	2	1	70.50	70.50
4064	4064	2	283	3	2	10	94.85	953.45
4065	4065	1	97	3	1	1	50.15	50.15
4066	4066	1	193	4	2	1	19.75	19.75
4067	4067	4	246	1	1	56	64.65	3665.55
4068	4068	6	120	1	1	68	79.60	5515.80
4069	4069	4	193	4	1	14	19.50	272.00
4070	4070	6	168	3	1	68	99.55	6668.00
4071	4071	2	258	3	1	55	74.00	4052.40
4072	4072	2	35	3	1	16	38.90	664.40
4073	4073	2	130	3	1	9	79.55	718.55
4074	4074	2	115	3	2	14	65.45	937.60
4075	4075	2	269	3	2	58	98.70	5812.60
4076	4076	2	50	1	1	53	46.30	2546.85
4077	4077	6	316	2	1	70	99.35	6944.50
4078	4078	2	261	3	1	14	95.80	1346.30
4079	4079	4	111	1	2	22	67.50	1544.05
4080	4080	2	290	2	1	10	78.15	765.15
4081	4081	5	322	4	1	29	26.10	692.55
4082	4082	2	129	3	2	1	69.60	69.60
4083	4083	3	241	3	2	49	84.35	4059.35
4084	4084	2	277	3	2	68	100.20	6851.65
4085	4085	1	131	3	2	1	78.05	78.05
4086	4086	4	6	2	1	30	40.35	1187.05
4087	4087	5	256	2	1	72	79.20	5401.90
4088	4088	2	193	4	1	10	20.90	247.00
4089	4089	1	258	3	2	7	73.60	520.00
4090	4090	2	258	3	2	9	74.75	706.60
4091	4091	1	97	4	1	1	49.90	49.90
4092	4092	2	215	2	1	20	68.90	1370.35
4093	4093	2	193	4	1	1	20.25	20.25
4094	4094	2	258	2	1	29	76.00	2215.25
4095	4095	1	133	3	1	1	74.00	74.00
4096	4096	2	165	4	1	3	82.30	214.40
4097	4097	2	171	1	1	20	89.40	1871.15
4098	4098	2	152	2	1	64	99.15	6171.20
4099	4099	2	193	4	2	1	20.20	20.20
4100	4100	1	33	1	1	6	29.45	161.45
4101	4101	5	193	3	1	50	19.80	1013.20
4102	4102	2	98	1	1	6	59.15	336.70
4103	4103	1	65	3	1	7	44.75	333.65
4104	4104	6	267	2	1	72	90.80	6511.80
4105	4105	2	81	1	1	8	49.55	393.45
4106	4106	5	297	2	1	67	106.70	7009.50
4107	4107	2	261	3	2	24	93.55	2264.05
4108	4108	6	307	2	1	72	94.45	6921.70
4109	4109	4	193	1	1	33	19.45	600.25
4110	4110	2	1	3	2	2	25.05	56.35
4111	4111	5	118	4	1	70	67.95	4664.15
4112	4112	3	91	1	1	22	65.25	1441.80
4113	4113	2	315	1	1	59	99.45	5623.70
4114	4114	4	193	2	1	36	20.35	695.85
4115	4115	5	193	4	1	51	19.95	1028.75
4116	4116	3	240	1	1	53	77.40	4155.95
4117	4117	3	193	1	1	20	19.70	395.60
4118	4118	5	172	2	1	63	99.70	6330.40
4119	4119	1	145	2	1	40	74.80	2971.70
4120	4120	4	193	4	1	35	19.15	638.00
4121	4121	3	130	1	1	26	78.95	2034.25
4122	4122	2	283	3	2	27	95.55	2510.20
4123	4123	3	117	2	1	53	62.85	3419.50
4124	4124	1	129	2	1	34	71.55	2427.35
4125	4125	2	261	3	1	19	94.95	1760.25
4126	4126	2	185	2	1	43	86.10	3551.65
4127	4127	1	193	4	1	6	19.55	122.90
4128	4128	6	322	4	1	56	24.80	1424.20
4129	4129	2	19	3	2	57	39.30	2111.45
4130	4130	2	139	4	1	34	84.05	2909.95
4131	4131	1	21	3	1	10	36.25	374.00
4132	4132	2	193	4	2	1	20.25	20.25
4133	4133	2	1	3	2	13	23.90	300.80
4134	4134	1	277	3	1	56	98.60	5581.05
4135	4135	2	285	2	1	55	103.65	5676.65
4136	4136	6	257	2	1	36	92.90	3379.25
4137	4137	3	193	1	1	47	19.90	942.95
4138	4138	2	193	2	1	12	20.10	232.40
4139	4139	2	139	3	2	1	85.45	85.45
4140	4140	2	274	3	1	24	80.50	2088.45
4141	4141	3	277	1	2	63	99.90	6137.00
4142	4142	2	11	3	1	35	39.85	1434.60
4143	4143	3	117	2	1	67	60.50	3870.00
4144	4144	2	259	3	2	25	84.80	2043.45
4145	4145	1	301	4	1	21	103.85	2215.00
4146	4146	1	118	1	1	13	67.80	842.25
4147	4147	2	258	3	2	35	75.20	2576.20
4148	4148	5	322	1	1	71	24.85	1901.00
4149	4149	1	193	2	1	29	19.35	601.60
4150	4150	5	20	3	2	71	49.35	3515.25
4151	4151	2	132	3	1	7	89.00	605.45
4152	4152	2	28	3	1	57	55.00	3094.05
4153	4153	5	239	1	1	65	76.15	4929.55
4154	4154	3	193	4	1	27	20.30	595.05
4155	4155	2	258	3	2	6	74.90	469.80
4156	4156	6	321	2	1	72	117.35	8436.25
4157	4157	2	193	4	1	1	19.75	19.75
4158	4158	1	65	2	1	11	45.20	492.00
4159	4159	5	322	4	1	39	25.20	987.95
4160	4160	2	314	3	1	59	89.75	5496.90
4161	4161	3	104	1	1	26	75.00	1908.35
4162	4162	1	73	4	1	2	49.95	107.10
4163	4163	5	64	1	1	72	65.70	4575.35
4164	4164	3	250	2	1	65	67.05	4309.55
4165	4165	5	289	2	1	72	110.90	7922.75
4166	4166	2	263	1	1	6	87.95	522.35
4167	4167	3	193	2	1	32	19.80	587.70
4168	4168	3	205	1	1	50	75.70	3876.20
4169	4169	6	48	4	1	61	62.15	3778.85
4170	4170	2	156	3	2	15	101.25	1457.25
4171	4171	5	321	1	1	72	115.15	8349.45
4172	4172	2	193	4	2	9	18.95	185.60
4173	4173	1	193	4	1	1	19.50	19.50
4174	4174	2	259	3	1	12	86.55	1066.90
4175	4175	1	5	2	2	37	28.60	973.55
4176	4176	3	193	4	1	61	20.40	1226.45
4177	4177	3	193	1	1	18	19.80	342.30
4178	4178	1	65	4	1	21	45.65	985.05
4179	4179	6	62	4	1	68	56.40	3948.45
4180	4180	2	258	2	1	12	73.30	828.05
4181	4181	1	1	3	2	2	24.35	41.85
4182	4182	2	269	3	1	62	101.35	6164.70
4183	4183	1	265	3	2	29	98.65	2862.75
4184	4184	1	21	4	1	1	33.60	33.60
4185	4185	2	266	1	2	5	79.90	343.95
4186	4186	1	193	3	1	1	20.70	20.70
4187	4187	6	273	3	1	62	104.05	6590.50
4188	4188	5	193	1	1	36	20.25	717.95
4189	4189	2	273	3	2	28	103.30	2890.65
4190	4190	3	248	2	1	69	73.70	4885.85
4191	4191	2	296	2	2	11	96.20	1222.05
4192	4192	2	289	3	1	63	108.75	6871.70
4193	4193	3	193	1	1	23	20.15	405.60
4194	4194	1	193	2	1	10	19.75	208.25
4195	4195	6	322	2	1	71	25.95	1801.90
4196	4196	2	231	3	1	45	70.05	3062.45
4197	4197	5	322	4	1	70	24.05	1764.75
4198	4198	2	259	3	1	22	84.75	1816.75
4199	4199	5	322	4	1	52	23.05	1255.10
4200	4200	4	273	3	2	55	104.15	5743.05
4201	4201	5	48	2	1	65	59.95	3921.10
4202	4202	5	193	1	1	72	19.55	1463.45
4203	4203	3	193	1	1	10	19.60	189.45
4204	4204	3	193	4	1	7	20.05	96.80
4205	4205	2	146	3	1	5	85.55	408.50
4206	4206	5	237	2	1	24	78.60	1846.65
4207	4207	6	321	2	1	72	116.80	8456.75
4208	4208	2	39	4	1	21	43.55	1011.50
4209	4209	4	32	2	1	69	60.80	4263.40
4210	4210	2	85	1	1	44	54.90	2549.10
4211	4211	4	204	3	1	61	65.20	3965.05
4212	4212	2	285	2	2	24	102.95	2496.70
4213	4213	1	132	3	2	1	90.60	90.60
4214	4214	2	69	1	2	6	50.80	288.05
4215	4215	2	275	3	2	4	90.05	368.10
4216	4216	6	289	3	1	72	108.20	7840.60
4217	4217	5	257	1	1	72	92.00	6632.75
4218	4218	2	258	3	1	14	75.10	1013.35
4219	4219	2	322	1	1	7	25.05	152.95
4220	4220	3	145	3	1	48	75.15	3772.65
4221	4221	3	193	4	1	55	19.50	1026.35
4222	4222	1	193	2	1	1	19.30	19.30
4223	4223	3	192	2	1	45	112.20	5031.85
4224	4224	2	129	4	1	3	70.30	220.40
4225	4225	5	193	4	1	71	19.60	1416.50
4226	4226	1	193	4	1	8	20.25	158.35
4227	4227	2	258	3	2	3	75.85	256.60
4228	4228	5	120	1	1	69	80.65	5542.55
4229	4229	2	129	3	2	1	68.50	68.50
4230	4230	6	321	2	1	72	115.75	8443.70
4231	4231	2	161	3	2	11	73.50	791.75
4232	4232	5	255	1	1	71	80.60	5708.20
4233	4233	2	129	4	2	1	69.95	69.95
4234	4234	5	48	1	1	33	59.55	2016.30
4235	4235	3	193	4	1	16	19.05	326.65
4236	4236	3	318	3	1	56	95.65	5471.75
4237	4237	1	193	2	1	1	19.95	19.95
4238	4238	2	76	3	2	5	70.05	346.40
4239	4239	3	193	4	1	57	19.40	1061.60
4240	4240	4	25	2	1	56	36.10	1971.50
4241	4241	2	284	3	2	8	94.00	773.65
4242	4242	1	121	4	2	22	61.15	1422.05
4243	4243	1	193	4	1	1	19.75	19.75
4244	4244	2	103	2	1	40	64.10	2460.35
4245	4245	5	193	2	1	46	19.75	856.50
4246	4246	5	193	4	1	63	19.70	1275.85
4247	4247	6	317	3	1	68	110.20	7467.50
4248	4248	6	184	2	1	69	106.35	7261.75
4249	4249	1	286	3	1	56	90.55	5116.60
4250	4250	4	90	4	1	10	65.90	660.05
4251	4251	3	320	2	1	63	104.50	6590.80
4252	4252	6	62	4	1	24	52.50	1208.15
4253	4253	2	202	4	1	19	56.10	1033.90
4254	4254	2	268	3	1	22	88.75	1885.15
4255	4255	2	306	3	2	29	84.45	2467.10
4256	4256	4	205	4	2	13	75.30	989.45
4257	4257	6	322	1	1	70	26.00	2006.95
4258	4258	1	156	3	1	49	99.40	5025.00
4259	4259	4	305	4	2	43	109.55	4830.25
4260	4260	2	193	4	2	3	19.60	59.75
4261	4261	3	80	3	1	42	73.15	3088.25
4262	4262	4	85	4	1	57	54.65	3134.70
4263	4263	1	107	1	2	2	66.40	94.55
4264	4264	6	321	2	1	72	115.55	8312.40
4265	4265	2	285	3	1	46	104.45	4863.85
4266	4266	2	265	2	2	66	100.05	6871.90
4267	4267	3	311	3	2	62	102.00	6529.25
4268	4268	6	257	1	1	72	91.15	6637.90
4269	4269	4	151	3	1	35	89.70	3165.60
4270	4270	1	314	2	2	17	90.20	1454.15
4271	4271	6	257	3	1	72	92.40	6786.10
4272	4272	3	193	4	1	28	19.90	543.00
4273	4273	6	322	2	2	56	25.15	1327.15
4274	4274	2	262	2	2	31	79.85	2404.15
4275	4275	3	193	1	1	45	18.85	867.30
4276	4276	2	322	4	1	1	25.75	25.75
4277	4277	2	81	4	2	2	49.60	114.70
4278	4278	2	193	4	1	6	20.95	109.50
4279	4279	4	156	3	1	48	97.05	4692.95
4280	4280	2	322	1	1	25	25.40	546.85
4281	4281	6	193	1	1	64	19.70	1274.05
4282	4282	2	49	4	1	50	35.00	1782.40
4283	4283	3	269	1	1	52	101.25	5301.10
4284	4284	2	129	3	1	4	70.20	280.35
4285	4285	1	132	3	1	32	90.95	2897.95
4286	4286	5	248	2	1	45	73.85	3371.00
4287	4287	2	291	3	1	9	88.05	801.30
4288	4288	4	273	2	2	66	105.95	6975.25
4289	4289	1	267	3	2	3	91.85	257.05
4290	4290	5	193	4	1	54	20.10	1079.45
4291	4291	1	7	3	2	1	40.10	40.10
4292	4292	5	313	1	1	64	110.30	6997.30
4293	4293	2	258	3	2	31	73.90	2217.15
4294	4294	2	132	4	2	14	89.80	1129.10
4295	4295	4	163	2	1	12	85.15	979.05
4296	4296	4	117	1	1	67	60.95	4119.40
4297	4297	1	240	3	2	35	72.25	2568.55
4298	4298	5	231	4	1	45	73.55	3349.10
4299	4299	1	65	4	1	10	46.00	492.10
4300	4300	2	242	1	1	29	58.55	1718.95
4301	4301	3	322	1	1	24	24.60	605.25
4302	4302	6	193	4	1	66	19.75	1344.50
4303	4303	3	163	4	1	51	86.35	4267.15
4304	4304	5	322	4	1	45	25.50	1121.05
4305	4305	3	193	2	1	49	19.00	918.70
4306	4306	6	193	4	1	29	19.55	521.80
4307	4307	2	313	2	1	40	110.10	4469.10
4308	4308	2	261	3	2	37	96.55	3580.30
4309	4309	1	129	3	1	25	69.75	1729.35
4310	4310	2	12	3	1	22	50.60	1073.30
4311	4311	6	64	1	1	72	65.60	4566.50
4312	4312	2	18	2	2	7	40.10	293.30
4313	4313	5	96	2	1	33	82.10	2603.10
4314	4314	2	149	4	1	23	79.10	1783.75
4315	4315	2	277	3	2	24	101.25	2440.15
4316	4316	1	131	3	2	1	79.55	79.55
4317	4317	5	257	4	1	69	90.65	6322.10
4318	4318	4	193	2	1	3	20.55	57.40
4319	4319	4	88	1	1	56	75.75	4284.65
4320	4320	4	305	2	1	65	110.00	7138.65
4321	4321	3	193	3	1	71	20.85	1539.75
4322	4322	2	266	1	1	14	80.35	1058.10
4323	4323	2	129	3	1	2	70.15	123.80
4324	4324	3	260	3	2	32	84.05	2781.85
4325	4325	1	106	3	1	40	67.45	2731.00
4326	4326	1	193	2	1	1	20.75	20.75
4327	4327	2	132	3	2	1	89.10	89.10
4328	4328	2	129	4	1	7	69.90	497.30
4329	4329	2	194	3	1	15	51.10	711.15
4330	4330	1	300	3	2	17	94.40	1607.20
4331	4331	2	153	3	2	19	78.25	1490.95
4332	4332	5	322	1	1	71	25.55	1898.10
4333	4333	5	230	1	1	54	60.00	3273.95
4334	4334	2	310	2	1	31	90.55	2929.75
4335	4335	1	161	3	1	11	76.40	838.70
4336	4336	2	138	3	1	18	84.95	1443.65
4337	4337	6	313	1	1	72	110.10	7746.70
4338	4338	2	277	2	1	71	99.65	6951.15
4339	4339	1	15	2	1	5	45.40	214.75
4340	4340	3	207	2	1	38	69.00	2669.45
4341	4341	2	69	1	1	5	48.65	235.20
4342	4342	2	65	3	2	2	44.15	92.65
4343	4343	5	234	1	1	52	59.85	3103.25
4344	4344	2	258	3	2	8	75.75	606.25
4345	4345	6	221	3	1	68	80.65	5330.20
4346	4346	4	193	2	1	69	20.55	1403.10
4347	4347	2	246	2	1	42	66.40	2727.80
4348	4348	6	152	4	1	50	100.20	5038.45
4349	4349	2	193	4	2	1	19.10	19.10
4350	4350	2	290	3	2	1	80.30	80.30
4351	4351	2	65	2	1	33	44.55	1462.60
4352	4352	1	193	4	1	7	20.35	150.60
4353	4353	2	314	3	1	64	91.80	5960.50
4354	4354	2	137	3	2	1	74.90	74.90
4355	4355	6	193	1	1	59	20.20	1192.30
4356	4356	1	194	3	1	6	50.35	314.55
4357	4357	1	193	4	1	3	18.80	56.00
4358	4358	1	193	2	1	15	20.45	330.80
4359	4359	4	68	3	1	13	64.75	877.35
4360	4360	2	277	2	1	23	98.70	2249.10
4361	4361	1	292	3	1	31	89.45	2807.65
4362	4362	4	117	3	1	29	58.75	1696.20
4363	4363	3	193	2	1	49	20.70	1032.05
4364	4364	2	260	1	1	56	85.60	4902.80
4365	4365	6	255	2	1	63	80.30	4995.35
4366	4366	5	209	2	1	63	79.80	5034.05
4367	4367	2	290	3	1	24	79.85	1857.75
4368	4368	3	77	2	1	36	54.10	1992.85
4369	4369	2	131	3	2	9	80.85	751.65
4370	4370	1	1	3	2	3	24.75	66.95
4371	4371	3	112	4	1	21	80.90	1714.95
4372	4372	3	322	1	1	13	24.50	343.60
4373	4373	2	193	1	1	1	20.15	20.15
4374	4374	3	193	4	1	25	20.05	520.10
4375	4375	6	193	1	1	71	19.60	1387.45
4376	4376	4	321	1	1	66	114.30	7383.70
4377	4377	4	180	3	1	45	100.30	4483.95
4378	4378	2	131	2	1	22	80.00	1706.45
4379	4379	4	193	1	1	67	20.85	1327.40
4380	4380	6	268	1	1	68	89.95	5974.30
4381	4381	5	193	4	1	0	20.00	\N
4382	4382	2	267	2	2	49	90.85	4515.85
4383	4383	1	194	4	1	4	48.75	179.85
4384	4384	3	255	2	1	63	80.00	5040.20
4385	4385	1	153	1	2	2	79.70	165.00
4386	4386	4	193	4	1	21	20.35	422.70
4387	4387	5	117	1	2	55	57.55	3046.40
4388	4388	2	193	4	1	1	20.25	20.25
4389	4389	5	193	4	1	17	19.40	358.05
4390	4390	2	293	1	1	30	100.40	2936.25
4391	4391	2	117	4	1	22	57.95	1271.80
4392	4392	2	71	1	1	9	59.50	530.05
4393	4393	1	193	4	1	1	19.20	19.20
4394	4394	2	259	3	2	21	86.50	1808.70
4395	4395	1	206	3	1	19	59.55	1144.60
4396	4396	2	285	3	2	69	103.95	7446.90
4397	4397	2	1	3	2	1	25.10	25.10
4398	4398	6	320	1	1	72	103.95	7556.90
4399	4399	5	236	2	1	70	68.95	4858.70
4400	4400	2	319	1	1	66	103.10	6595.00
4401	4401	2	1	3	1	7	24.70	149.05
4402	4402	2	313	3	1	46	110.20	4972.10
4403	4403	2	55	2	2	39	48.95	1880.85
4404	4404	1	218	1	1	32	62.45	2045.55
4405	4405	2	154	3	1	24	89.55	2187.15
4406	4406	2	146	2	2	6	83.55	477.55
4407	4407	2	256	2	1	37	78.90	2976.95
4408	4408	1	193	4	1	8	20.35	178.70
4409	4409	6	236	1	1	72	71.45	5025.85
4410	4410	5	61	2	1	71	46.35	3353.40
4411	4411	2	148	1	1	16	94.65	1461.15
4412	4412	2	46	1	1	57	49.90	2782.40
4413	4413	3	322	1	1	66	25.45	1699.15
4414	4414	2	155	3	2	17	89.15	1496.90
4415	4415	1	193	4	1	21	20.75	452.20
4416	4416	6	250	2	1	66	66.10	4428.45
4417	4417	2	213	1	1	17	75.40	1322.55
4418	4418	2	129	4	2	1	70.45	70.45
4419	4419	3	121	2	2	58	60.30	3563.80
4420	4420	1	193	2	1	8	21.05	139.75
4421	4421	3	111	2	1	27	69.35	1927.30
4422	4422	1	275	4	1	34	88.85	3000.25
4423	4423	4	148	1	1	30	97.00	3021.30
4424	4424	2	91	2	1	33	66.40	2245.40
4425	4425	1	1	3	2	1	24.75	24.75
4426	4426	1	243	4	1	14	69.20	944.65
4427	4427	4	262	2	1	16	79.50	1264.20
4428	4428	5	144	2	1	49	100.65	4917.75
4429	4429	1	273	3	2	19	103.30	2012.70
4430	4430	5	256	1	1	70	79.70	5743.30
4431	4431	1	117	1	1	32	61.40	1864.65
4432	4432	2	129	3	1	18	69.80	1221.65
4433	4433	6	53	4	1	37	40.55	1390.85
4434	4434	2	258	3	1	4	75.65	302.35
4435	4435	1	314	3	1	16	90.70	1374.90
4436	4436	2	274	1	1	17	80.50	1336.90
4437	4437	2	121	3	1	19	60.60	1297.80
4438	4438	5	269	2	1	60	101.15	6067.40
4439	4439	6	322	4	1	51	24.95	1222.25
4440	4440	6	193	2	1	28	20.30	487.95
4441	4441	6	82	3	1	43	60.00	2548.55
4442	4442	5	193	3	1	42	20.25	835.50
4443	4443	2	131	3	2	3	78.50	242.05
4444	4444	1	65	4	1	1	44.75	44.75
4445	4445	1	193	4	2	3	19.85	63.75
4446	4446	5	316	2	1	63	98.00	6218.45
4447	4447	2	131	3	2	3	79.90	260.90
4448	4448	2	313	3	1	68	107.70	7320.90
4449	4449	2	277	3	2	30	99.70	2967.35
4450	4450	5	285	3	1	60	104.70	6333.80
4451	4451	2	214	2	2	15	58.60	939.70
4452	4452	2	261	1	1	45	93.90	4200.25
4453	4453	5	128	2	1	70	86.45	5950.20
4454	4454	2	269	3	2	10	98.50	1037.75
4455	4455	1	193	4	1	4	19.40	93.40
4456	4456	2	73	4	2	1	50.45	50.45
4457	4457	6	322	2	1	68	24.95	1614.90
4458	4458	1	161	1	1	22	75.00	1573.95
4459	4459	2	284	3	2	38	94.65	3624.30
4460	4460	2	277	2	2	1	100.25	100.25
4461	4461	1	141	3	1	18	78.20	1468.75
4462	4462	2	136	3	1	29	94.20	2607.60
4463	4463	2	267	3	2	16	88.45	1422.10
4464	4464	2	129	3	2	1	69.85	69.85
4465	4465	1	169	1	2	12	81.70	858.60
4466	4466	4	12	3	1	31	50.05	1523.40
4467	4467	2	130	3	2	4	79.90	324.30
4468	4468	4	207	4	1	48	69.55	3435.60
4469	4469	2	322	2	2	15	25.40	399.60
4470	4470	4	189	2	1	50	90.10	4549.45
4471	4471	2	65	1	1	7	44.65	322.50
4472	4472	2	298	1	2	41	83.75	3273.55
4473	4473	5	169	2	1	68	80.35	5375.15
4474	4474	2	269	1	1	26	98.10	2510.70
4475	4475	5	16	2	1	57	53.35	3090.05
4476	4476	1	193	3	1	3	19.55	61.05
4477	4477	1	193	4	2	1	20.90	20.90
4478	4478	4	97	1	1	19	48.95	955.60
4479	4479	2	67	3	1	3	54.20	140.40
4480	4480	5	322	3	1	59	24.45	1493.10
4481	4481	2	129	4	2	1	69.40	69.40
4482	4482	2	35	1	1	42	40.15	1626.05
4483	4483	2	258	3	2	7	74.90	541.15
4484	4484	5	322	2	1	67	25.60	1784.90
4485	4485	2	129	3	1	1	70.35	70.35
4486	4486	5	257	1	1	66	91.70	6075.90
4487	4487	1	267	4	1	61	89.20	5500.60
4488	4488	3	322	2	1	4	24.10	73.10
4489	4489	2	161	2	2	42	74.15	3229.40
4490	4490	4	210	1	1	64	53.85	3399.85
4491	4491	4	321	1	1	54	115.60	6431.05
4492	4492	2	193	2	1	1	19.75	19.75
4493	4493	6	322	1	1	54	24.05	1230.90
4494	4494	5	322	2	1	18	25.30	454.65
4495	4495	1	146	3	1	3	84.30	235.05
4496	4496	2	129	3	2	1	70.10	70.10
4497	4497	5	257	2	1	72	89.75	6595.90
4498	4498	4	156	3	1	60	97.95	5867.00
4499	4499	4	193	4	1	11	20.00	196.35
4500	4500	2	290	3	2	12	78.30	909.25
4501	4501	3	160	2	1	61	103.90	6449.15
4502	4502	5	193	2	1	39	20.70	762.45
4503	4503	2	261	3	2	55	96.80	5283.95
4504	4504	2	308	3	2	17	94.40	1617.50
4505	4505	3	193	2	1	37	20.15	785.75
4506	4506	6	322	4	1	72	26.00	1776.00
4507	4507	5	224	2	1	72	77.35	5396.25
4508	4508	1	102	1	1	8	66.05	574.50
4509	4509	1	193	4	1	22	19.90	400.30
4510	4510	1	147	3	2	1	84.30	84.30
4511	4511	1	215	2	1	38	68.15	2656.30
4512	4512	3	96	3	1	17	80.85	1445.95
4513	4513	6	224	1	1	70	75.50	5212.65
4514	4514	5	257	2	2	72	92.45	6440.25
4515	4515	2	130	3	1	28	80.60	2244.95
4516	4516	2	147	1	1	15	83.20	1130.00
4517	4517	6	257	1	1	72	87.55	6463.15
4518	4518	2	269	3	2	11	99.55	1131.20
4519	4519	2	266	3	2	8	81.25	585.95
4520	4520	4	289	1	1	57	109.40	6252.70
4521	4521	1	193	1	2	1	19.95	19.95
4522	4522	1	51	3	1	46	45.55	2062.15
4523	4523	3	193	2	1	30	20.70	587.10
4524	4524	1	161	3	1	10	75.30	720.45
4525	4525	2	316	3	2	23	99.25	2186.40
4526	4526	2	186	2	1	32	93.40	2979.30
4527	4527	2	161	2	1	13	73.75	956.65
4528	4528	6	141	3	2	39	80.45	3201.55
4529	4529	2	155	2	1	44	88.15	3973.20
4530	4530	1	69	4	1	9	49.20	447.90
4531	4531	5	193	4	1	67	19.65	1335.20
4532	4532	2	266	1	2	9	79.35	661.25
4533	4533	2	274	3	2	15	79.75	1111.85
4534	4534	6	285	1	1	71	105.15	7555.00
4535	4535	1	69	2	1	1	49.00	49.00
4536	4536	2	269	3	2	30	100.05	3046.15
4537	4537	2	129	3	2	1	69.35	69.35
4538	4538	2	20	4	1	17	49.80	836.35
4539	4539	1	134	3	2	3	85.80	272.20
4540	4540	6	237	3	2	67	79.70	5293.40
4541	4541	1	193	1	1	1	20.95	20.95
4542	4542	1	194	4	2	1	50.55	50.55
4543	4543	1	266	4	1	32	79.30	2570.00
4544	4544	3	193	1	1	41	19.50	798.20
4545	4545	2	131	3	2	1	80.55	80.55
4546	4546	1	65	1	1	1	44.15	44.15
4547	4547	2	282	3	2	12	84.50	916.90
4548	4548	2	309	3	1	62	105.50	6487.20
4549	4549	2	146	4	2	22	84.30	1855.65
4550	4550	2	286	2	1	17	92.70	1556.85
4551	4551	6	322	1	1	72	26.25	1988.05
4552	4552	2	280	2	1	56	96.95	5432.20
4553	4553	2	193	2	1	9	20.45	147.55
4554	4554	6	321	1	1	72	115.80	8424.90
4555	4555	2	192	1	1	20	108.20	2203.70
4556	4556	5	193	4	1	19	20.20	387.40
4557	4557	2	129	3	2	2	67.75	116.65
4558	4558	3	16	2	1	53	54.90	3045.75
4559	4559	2	259	3	2	27	85.25	2287.25
4560	4560	1	193	1	1	6	20.15	130.50
4561	4561	4	268	3	1	9	90.35	767.90
4562	4562	1	210	3	1	8	55.75	446.80
4563	4563	5	321	1	1	71	114.60	8100.25
4564	4564	2	274	1	2	10	80.05	830.70
4565	4565	1	193	4	2	1	20.00	20.00
4566	4566	3	64	1	1	71	66.80	4689.15
4567	4567	4	152	3	1	68	100.30	6754.35
4568	4568	2	281	3	1	34	105.35	3540.65
4569	4569	4	157	3	1	26	85.20	2184.60
4570	4570	2	97	2	2	22	48.80	1054.60
4571	4571	2	193	4	1	7	18.95	130.55
4572	4572	2	129	1	1	20	69.80	1540.35
4573	4573	2	285	3	1	60	106.15	6411.25
4574	4574	5	193	3	1	72	20.55	1432.55
4575	4575	4	285	2	1	72	105.75	7629.85
4576	4576	1	322	4	1	4	25.25	101.90
4577	4577	1	193	3	1	16	19.75	313.40
4578	4578	4	301	3	1	62	104.85	6312.90
4579	4579	2	70	4	1	10	60.95	629.55
4580	4580	2	274	3	1	31	81.15	2640.55
4581	4581	5	193	2	1	71	19.10	1372.45
4582	4582	5	193	4	1	58	20.80	1212.25
4583	4583	6	257	2	1	70	90.15	6237.05
4584	4584	5	257	3	1	71	90.10	6310.90
4585	4585	5	239	2	1	69	74.10	5031.00
4586	4586	2	259	3	2	1	85.05	85.05
4587	4587	6	321	1	1	72	118.75	8672.45
4588	4588	1	134	2	1	26	85.90	2196.45
4589	4589	2	271	2	1	33	95.00	3008.15
4590	4590	5	193	4	1	10	20.15	220.80
4591	4591	5	303	2	1	57	101.30	5779.60
4592	4592	2	193	3	1	10	21.20	222.65
4593	4593	4	322	4	1	39	24.20	914.60
4594	4594	1	193	1	1	11	20.30	246.30
4595	4595	2	160	3	2	21	102.80	2110.15
4596	4596	5	225	1	1	68	85.30	5560.00
4597	4597	4	268	2	1	18	89.60	1633.00
4598	4598	2	144	4	2	6	99.95	547.65
4599	4599	1	226	4	1	18	56.25	969.85
4600	4600	4	73	1	1	52	50.95	2610.65
4601	4601	5	321	4	1	56	115.85	6567.90
4602	4602	2	273	1	1	45	103.65	4747.85
4603	4603	6	322	4	1	67	26.10	1759.55
4604	4604	1	37	4	1	3	35.10	101.10
4605	4605	2	156	1	1	65	99.10	6496.15
4606	4606	5	215	4	1	63	67.25	4234.15
4607	4607	5	322	4	1	11	25.00	300.70
4608	4608	2	70	4	1	1	59.55	59.55
4609	4609	6	205	1	1	55	77.80	4323.35
4610	4610	4	198	4	1	25	55.10	1466.10
4611	4611	4	321	1	2	72	117.80	8684.80
4612	4612	6	322	2	1	72	24.15	1776.45
4613	4613	5	23	4	1	65	45.25	2933.95
4614	4614	2	274	3	2	54	79.50	4370.25
4615	4615	1	193	4	1	7	20.25	144.35
4616	4616	5	246	1	1	72	64.75	4804.75
4617	4617	1	67	1	1	21	54.60	1125.20
4618	4618	2	193	1	1	2	20.70	39.85
4619	4619	2	140	3	1	4	94.75	422.40
4620	4620	2	262	1	2	3	79.65	251.75
4621	4621	5	321	2	1	72	115.80	8332.15
4622	4622	2	97	3	1	6	49.45	314.60
4623	4623	2	138	2	1	52	83.80	4331.40
4624	4624	2	283	1	1	69	95.35	6382.00
4625	4625	2	140	3	2	8	94.70	740.30
4626	4626	2	137	1	1	8	74.05	600.15
4627	4627	2	267	1	1	63	89.60	5538.80
4628	4628	4	321	2	1	60	116.60	7049.50
4629	4629	1	101	1	1	12	54.20	690.50
4630	4630	2	193	4	1	13	19.30	279.30
4631	4631	1	250	4	1	22	65.05	1427.55
4632	4632	2	268	3	2	5	92.50	452.70
4633	4633	1	193	4	2	1	19.45	19.45
4634	4634	6	322	1	1	72	24.05	1709.15
4635	4635	1	193	1	1	2	18.75	53.15
4636	4636	5	193	1	1	40	20.15	777.35
4637	4637	3	193	1	1	44	20.00	860.85
4638	4638	4	119	1	1	71	71.00	5012.10
4639	4639	2	258	3	2	2	75.55	166.30
4640	4640	2	261	3	1	26	93.60	2404.10
4641	4641	2	129	3	2	1	70.00	70.00
4642	4642	1	1	4	1	1	24.40	24.40
4643	4643	6	104	1	2	65	74.80	4820.15
4644	4644	2	200	4	1	3	65.25	209.90
4645	4645	2	69	4	1	13	50.55	610.75
4646	4646	2	285	3	2	33	104.40	3409.60
4647	4647	2	129	4	1	1	70.70	70.70
4648	4648	1	65	4	1	4	45.25	155.35
4649	4649	2	129	3	1	2	70.30	144.00
4650	4650	6	313	2	1	72	108.95	7875.00
4651	4651	1	322	4	1	37	26.45	911.60
4652	4652	1	163	3	2	15	86.20	1270.20
4653	4653	4	193	2	1	23	19.65	478.10
4654	4654	1	8	2	2	30	51.20	1561.50
4655	4655	4	193	3	1	42	19.05	761.85
4656	4656	3	229	4	1	32	74.75	2282.95
4657	4657	2	258	1	1	22	75.80	1615.10
4658	4658	2	1	2	1	42	25.10	1097.15
4659	4659	1	65	4	1	8	44.45	369.30
4660	4660	6	301	2	1	65	104.30	6725.30
4661	4661	1	193	4	2	2	19.50	31.55
4662	4662	6	257	1	1	70	89.00	6293.20
4663	4663	1	193	2	1	22	20.15	432.50
4664	4664	2	258	3	2	4	74.90	321.75
4665	4665	1	258	2	2	2	74.90	147.15
4666	4666	5	49	1	1	67	36.15	2434.45
4667	4667	2	193	2	1	25	19.20	532.10
4668	4668	1	193	1	1	20	19.25	375.25
4669	4669	2	98	2	1	2	61.20	125.95
4670	4670	5	193	4	1	51	20.45	1042.65
4671	4671	1	49	1	1	46	35.05	1620.25
4672	4672	2	277	3	2	25	100.25	2387.75
4673	4673	1	65	4	1	13	44.00	659.35
4674	4674	2	309	4	2	25	102.80	2660.20
4675	4675	3	73	4	1	26	50.35	1285.80
4676	4676	4	265	3	2	43	100.00	4211.55
4677	4677	2	193	3	1	19	20.00	377.55
4678	4678	2	152	3	2	10	99.85	990.90
4679	4679	2	261	1	2	2	94.20	193.80
4680	4680	6	249	1	1	72	86.40	6058.95
4681	4681	2	242	2	1	18	58.40	964.90
4682	4682	2	259	3	2	9	83.85	790.15
4683	4683	1	267	2	2	27	88.30	2467.75
4684	4684	2	261	3	1	24	94.10	2322.85
4685	4685	4	160	1	2	69	104.05	7262.00
4686	4686	6	289	2	1	46	108.90	4854.30
4687	4687	6	319	1	1	72	107.40	7748.75
4688	4688	2	140	2	2	22	94.70	1914.90
4689	4689	2	291	3	1	70	90.85	6470.10
4690	4690	1	193	3	1	2	19.90	57.40
4691	4691	2	78	2	1	31	66.40	2019.80
4692	4692	2	269	1	2	56	100.65	5688.05
4693	4693	1	172	1	1	16	100.70	1522.70
4694	4694	5	322	2	1	52	25.60	1334.50
4695	4695	2	193	4	1	13	19.85	252.00
4696	4696	3	193	4	1	35	20.75	700.45
4697	4697	5	140	3	1	59	95.80	5655.45
4698	4698	2	140	3	1	72	94.65	6747.35
4699	4699	6	221	1	2	66	80.55	5265.10
4700	4700	5	319	2	1	49	106.65	5174.35
4701	4701	2	65	4	1	2	45.85	105.60
4702	4702	2	285	3	1	21	104.35	2271.85
4703	4703	4	28	3	1	54	55.45	2966.95
4704	4704	2	290	3	2	24	78.85	1772.25
4705	4705	1	242	3	1	1	61.15	61.15
4706	4706	2	177	3	1	6	78.95	494.95
4707	4707	2	65	4	2	1	44.45	44.45
4708	4708	4	317	2	1	49	109.20	5290.45
4709	4709	6	121	2	1	56	61.30	3346.80
4710	4710	2	307	3	1	56	96.85	5219.65
4711	4711	5	29	4	1	6	40.55	217.50
4712	4712	3	193	4	1	32	19.80	607.70
4713	4713	4	317	3	1	50	108.25	5431.40
4714	4714	4	273	1	1	58	105.05	6004.85
4715	4715	6	257	4	1	65	90.45	5957.90
4716	4716	6	257	2	1	64	86.40	5442.05
4717	4717	5	250	1	1	66	66.90	4370.25
4718	4718	4	305	3	1	38	110.70	4428.60
4719	4719	4	193	4	1	20	20.00	416.45
4720	4720	2	259	3	2	36	84.90	3067.20
4721	4721	3	273	3	1	64	102.10	6688.10
4722	4722	1	193	4	2	1	20.25	20.25
4723	4723	4	95	2	1	60	70.15	4224.70
4724	4724	2	145	3	2	1	74.35	74.35
4725	4725	4	255	1	1	50	80.05	4042.20
4726	4726	1	206	4	2	1	62.05	62.05
4727	4727	6	58	3	1	72	49.20	3580.95
4728	4728	6	193	1	1	60	20.50	1198.80
4729	4729	5	45	4	1	46	38.25	1755.35
4730	4730	6	28	2	1	69	54.95	3772.50
4731	4731	2	272	1	1	31	96.60	2877.95
4732	4732	3	193	4	1	19	19.90	357.70
4733	4733	5	193	2	1	71	19.90	1397.30
4734	4734	2	185	3	1	12	84.60	959.90
4735	4735	3	112	2	2	39	80.00	3182.95
4736	4736	4	225	1	1	44	85.25	3704.15
4737	4737	5	256	2	1	56	81.25	4620.40
4738	4738	6	321	1	1	72	115.50	8312.75
4739	4739	1	285	4	2	5	104.10	541.90
4740	4740	2	290	1	1	11	79.00	929.30
4741	4741	1	34	1	2	24	39.10	971.30
4742	4742	2	148	3	1	15	94.65	1285.05
4743	4743	6	193	4	1	72	20.80	1521.20
4744	4744	5	218	2	1	56	59.50	3389.25
4745	4745	6	193	1	1	64	20.05	1198.05
4746	4746	2	269	3	1	34	100.45	3414.65
4747	4747	2	258	3	2	2	76.50	162.45
4748	4748	3	193	1	1	35	20.60	754.00
4749	4749	3	193	2	1	22	20.30	467.15
4750	4750	2	69	3	2	5	49.20	216.90
4751	4751	3	57	4	1	9	39.55	373.00
4752	4752	1	322	2	2	11	23.15	245.20
4753	4753	3	193	4	1	23	20.45	481.10
4754	4754	1	130	3	2	4	80.85	302.75
4755	4755	5	322	1	1	68	25.25	1728.20
4756	4756	1	132	3	1	33	91.25	2964.05
4757	4757	2	127	1	1	31	72.45	2156.25
4758	4758	1	214	4	2	1	60.10	60.10
4759	4759	5	193	1	1	56	19.70	1051.90
4760	4760	2	131	3	2	1	78.95	78.95
4761	4761	4	127	3	1	66	75.10	5013.00
4762	4762	5	322	1	1	72	25.00	1738.90
4763	4763	1	129	2	1	34	69.15	2275.10
4764	4764	2	155	3	1	58	91.55	5511.65
4765	4765	2	65	3	2	2	45.15	98.50
4766	4766	5	3	2	1	37	35.80	1316.90
4767	4767	6	321	2	1	71	113.15	7993.30
4768	4768	3	193	2	1	1	19.85	19.85
4769	4769	5	193	2	1	71	19.80	1388.45
4770	4770	3	193	3	1	35	19.90	666.00
4771	4771	3	193	4	1	6	19.70	94.45
4772	4772	2	131	3	2	3	79.40	244.65
4773	4773	3	93	1	1	69	59.10	4134.70
4774	4774	4	28	4	2	44	53.95	2375.40
4775	4775	4	263	3	1	53	91.15	4862.50
4776	4776	2	156	2	2	24	99.30	2431.35
4777	4777	2	129	3	1	5	68.95	351.50
4778	4778	1	81	4	1	2	51.55	106.20
4779	4779	6	322	4	1	62	24.40	1413.00
4780	4780	2	140	3	1	19	96.80	1743.05
4781	4781	1	129	4	1	9	70.05	657.50
4782	4782	5	193	2	1	53	19.50	1050.50
4783	4783	1	130	4	1	5	78.75	426.35
4784	4784	3	244	3	1	71	69.20	4982.50
4785	4785	2	193	4	1	1	19.55	19.55
4786	4786	2	274	3	2	18	80.65	1451.90
4787	4787	6	285	3	1	72	103.65	7634.80
4788	4788	1	113	4	1	4	54.70	235.05
4789	4789	5	202	2	1	59	54.15	3116.15
4790	4790	1	129	4	2	1	71.10	71.10
4791	4791	2	259	3	1	31	84.85	2633.40
4792	4792	1	193	1	1	3	20.00	49.65
4793	4793	4	285	3	2	65	106.25	6979.80
4794	4794	4	144	2	1	49	99.25	4920.80
4795	4795	1	193	4	1	2	19.35	46.35
4796	4796	3	193	1	2	53	20.80	1021.80
4797	4797	4	164	3	1	55	94.75	5276.10
4798	4798	6	321	2	1	72	114.05	8289.20
4799	4799	2	258	1	1	36	74.90	2659.45
4800	4800	2	193	1	1	10	19.80	196.75
4801	4801	2	261	3	2	1	94.00	94.00
4802	4802	5	255	1	1	72	80.85	5824.75
4803	4803	1	85	1	1	28	54.65	1517.50
4804	4804	1	292	1	1	38	91.70	3479.05
4805	4805	4	321	3	1	61	118.60	7365.70
4806	4806	5	322	4	1	52	24.55	1331.05
4807	4807	4	193	4	1	67	19.45	1195.95
4808	4808	6	321	2	1	34	116.15	3946.90
4809	4809	5	112	3	1	54	80.60	4299.95
4810	4810	2	193	1	1	1	20.30	20.30
4811	4811	1	275	3	2	15	89.85	1424.95
4812	4812	2	65	4	2	4	46.00	193.60
4813	4813	1	87	4	2	9	66.25	620.55
4814	4814	2	156	3	1	46	99.80	4391.25
4815	4815	2	264	3	2	22	90.00	1993.80
4816	4816	4	129	1	2	38	70.45	2597.60
4817	4817	4	248	2	1	55	75.00	4213.90
4818	4818	1	193	4	1	1	19.90	19.90
4819	4819	3	169	2	1	64	80.30	5017.70
4820	4820	5	193	1	2	53	19.75	1052.35
4821	4821	6	241	3	1	58	84.30	4916.40
4822	4822	4	16	1	1	56	54.05	2959.80
4823	4823	6	176	2	1	72	104.90	7559.55
4824	4824	2	101	3	2	1	53.95	53.95
4825	4825	4	277	2	1	72	97.25	7133.10
4826	4826	1	259	3	1	22	83.05	1799.30
4827	4827	2	285	3	2	8	105.50	829.55
4828	4828	2	131	3	2	16	81.00	1312.15
4829	4829	1	29	1	1	39	41.10	1597.05
4830	4830	2	65	1	1	12	45.00	524.35
4831	4831	6	116	1	1	54	74.55	4191.45
4832	4832	4	53	4	1	18	40.20	711.95
4833	4833	3	118	4	1	32	70.50	2201.75
4834	4834	4	193	4	1	41	19.75	806.95
4835	4835	5	322	1	1	67	24.65	1620.45
4836	4836	2	301	3	1	65	104.25	6812.95
4837	4837	2	256	1	1	25	78.35	1837.90
4838	4838	2	129	3	2	1	69.80	69.80
4839	4839	4	289	2	1	67	109.70	7344.45
4840	4840	1	258	4	2	7	73.75	545.15
4841	4841	2	49	2	1	43	33.45	1500.25
4842	4842	2	164	3	1	24	94.60	2283.15
4843	4843	1	226	3	2	9	54.55	494.05
4844	4844	5	193	1	1	69	20.20	1376.50
4845	4845	3	193	1	1	37	20.30	755.40
4846	4846	6	45	2	1	20	39.40	825.40
4847	4847	1	129	1	1	7	69.15	488.65
4848	4848	2	258	3	2	37	76.25	2841.55
4849	4849	2	261	4	2	5	93.90	486.85
4850	4850	4	12	3	1	41	51.35	2075.10
4851	4851	4	180	2	1	54	100.05	5299.65
4852	4852	2	129	3	2	3	70.40	204.70
4853	4853	5	193	2	1	69	20.30	1356.30
4854	4854	4	158	2	1	53	94.45	5042.75
4855	4855	3	27	2	1	18	46.40	812.40
4856	4856	6	184	2	1	64	104.05	6605.55
4857	4857	2	275	3	2	31	91.15	2995.45
4858	4858	1	1	2	1	20	24.90	505.95
4859	4859	3	117	4	1	57	59.60	3509.40
4860	4860	5	317	2	1	63	108.50	6991.90
4861	4861	5	53	4	1	13	40.55	590.35
4862	4862	4	82	1	1	48	58.95	2789.70
4863	4863	2	129	3	2	2	70.95	137.95
4864	4864	5	193	4	1	57	20.75	1123.15
4865	4865	4	289	1	1	71	113.15	7953.25
4866	4866	1	194	3	1	7	48.80	349.80
4867	4867	2	195	1	1	16	63.05	1067.05
4868	4868	1	269	3	1	34	100.85	3527.30
4869	4869	2	269	3	2	37	99.50	3762.00
4870	4870	2	274	4	1	16	80.55	1248.90
4871	4871	4	250	1	1	48	64.40	3035.35
4872	4872	4	88	2	1	58	75.20	4300.80
4873	4873	6	241	1	1	72	84.90	6065.30
4874	4874	1	193	4	1	7	19.30	144.95
4875	4875	2	185	2	2	38	83.90	3233.60
4876	4876	1	321	3	2	48	117.45	5438.90
4877	4877	2	188	3	2	10	104.40	1081.45
4878	4878	3	127	2	1	30	74.65	2308.60
4879	4879	2	196	2	1	31	59.05	1882.80
4880	4880	4	207	2	1	46	69.10	3255.35
4881	4881	5	193	4	1	50	20.55	1067.65
4882	4882	1	133	1	1	28	76.55	2065.40
4883	4883	6	64	1	1	66	62.50	4136.40
4884	4884	2	9	3	2	8	29.40	221.90
4885	4885	2	140	1	1	41	94.90	3848.00
4886	4886	6	289	1	1	72	111.65	8022.85
4887	4887	3	193	4	1	7	19.90	173.15
4888	4888	1	193	4	1	38	20.45	781.25
4889	4889	4	188	3	1	44	106.05	4510.80
4890	4890	4	321	1	1	47	113.45	5317.80
4891	4891	2	151	3	1	53	92.55	4779.45
4892	4892	1	204	3	1	4	65.60	250.10
4893	4893	2	260	3	1	20	84.35	1745.20
4894	4894	1	65	4	2	2	44.65	74.90
4895	4895	4	220	2	1	57	71.10	4140.10
4896	4896	2	181	3	1	44	85.15	3670.50
4897	4897	2	73	4	1	24	49.70	1167.80
4898	4898	2	33	1	1	15	30.20	469.65
4899	4899	1	1	3	2	3	25.25	58.90
4900	4900	1	282	1	2	4	84.05	333.55
4901	4901	2	260	3	2	37	85.70	3171.15
4902	4902	2	145	3	2	1	74.70	74.70
4903	4903	1	101	2	1	24	56.35	1381.20
4904	4904	2	276	3	2	5	90.80	455.50
4905	4905	1	285	3	1	33	107.55	3645.50
4906	4906	6	193	4	1	58	19.85	1158.85
4907	4907	6	308	1	1	72	95.90	6954.15
4908	4908	5	322	4	1	71	23.85	1672.10
4909	4909	2	285	3	2	28	106.15	3152.50
4910	4910	6	128	2	1	51	83.85	4307.10
4911	4911	3	128	1	2	30	85.35	2530.40
4912	4912	6	181	2	1	72	84.80	6141.65
4913	4913	2	292	3	2	36	90.85	3186.70
4914	4914	5	126	1	1	14	76.10	1054.80
4915	4915	5	248	4	1	72	74.55	5430.65
4916	4916	1	19	3	1	22	39.20	849.90
4917	4917	1	274	3	1	2	79.55	151.75
4918	4918	1	193	4	1	15	19.60	299.40
4919	4919	5	193	2	1	51	19.55	1086.75
4920	4920	6	45	2	1	70	39.15	2692.75
4921	4921	5	193	1	1	71	20.10	1389.60
4922	4922	2	265	2	1	39	99.95	3767.40
4923	4923	1	242	3	1	61	59.80	3641.50
4924	4924	2	97	1	1	52	49.75	2535.55
4925	4925	2	3	3	2	1	35.75	35.75
4926	4926	4	305	4	1	64	108.50	6880.85
4927	4927	6	93	2	1	62	60.15	3753.20
4928	4928	5	193	4	1	30	19.05	637.55
4929	4929	1	65	3	2	4	46.00	181.60
4930	4930	4	128	1	1	63	84.00	5329.55
4931	4931	2	65	2	1	1	44.55	44.55
4932	4932	2	273	3	1	15	103.45	1539.80
4933	4933	4	177	2	1	27	80.65	2209.75
4934	4934	2	60	4	1	4	57.20	223.75
4935	4935	6	317	3	1	72	110.75	7751.70
4936	4936	3	322	2	1	45	24.70	1174.35
4937	4937	2	312	3	1	45	97.05	4385.05
4938	4938	4	127	4	1	36	76.35	2606.35
4939	4939	2	171	3	2	17	89.40	1539.45
4940	4940	1	193	4	1	1	18.90	18.90
4941	4941	2	258	1	1	16	74.45	1261.35
4942	4942	2	193	4	2	3	19.80	58.15
4943	4943	2	194	3	2	4	50.90	225.60
4944	4944	6	128	2	1	71	84.40	5969.30
4945	4945	2	322	4	1	10	24.40	253.90
4946	4946	5	193	4	1	20	20.05	400.00
4947	4947	2	131	3	2	4	81.00	340.85
4948	4948	2	269	3	2	26	98.35	2515.30
4949	4949	1	67	2	1	4	55.50	227.35
4950	4950	2	20	4	2	5	51.00	305.95
4951	4951	2	276	3	2	4	91.65	365.40
4952	4952	2	259	3	1	29	84.30	2357.75
4953	4953	1	180	3	1	2	100.20	198.50
4954	4954	5	193	4	1	29	19.40	554.25
4955	4955	2	132	3	2	1	90.85	90.85
4956	4956	1	129	4	2	1	69.40	69.40
4957	4957	2	140	2	2	8	94.45	742.95
4958	4958	2	193	3	1	13	20.40	251.65
4959	4959	2	308	3	1	59	94.75	5597.65
4960	4960	2	193	2	2	1	20.15	20.15
4961	4961	2	261	3	2	50	95.70	4816.70
4962	4962	2	65	1	1	18	44.35	768.05
4963	4963	1	116	4	1	17	74.55	1215.80
4964	4964	5	92	3	1	47	73.60	3522.65
4965	4965	2	258	1	2	26	74.95	1834.95
4966	4966	2	12	3	2	6	47.95	305.10
4967	4967	1	194	2	1	19	50.10	910.45
4968	4968	2	200	3	2	3	63.60	155.65
4969	4969	6	28	3	1	68	53.00	3656.25
4970	4970	1	193	1	1	2	19.85	52.00
4971	4971	4	1	2	1	7	24.35	150.85
4972	4972	2	193	4	1	18	19.55	389.25
4973	4973	5	322	2	1	71	25.05	1873.70
4974	4974	1	307	2	1	13	93.80	1261.00
4975	4975	2	21	4	2	3	36.85	108.70
4976	4976	6	285	1	1	72	103.75	7346.20
4977	4977	6	28	2	1	66	56.75	3708.40
4978	4978	4	193	2	1	24	20.80	469.65
4979	4979	2	65	3	2	1	44.10	44.10
4980	4980	6	322	4	1	56	24.45	1385.85
4981	4981	3	322	1	1	22	25.60	548.80
4982	4982	2	12	3	2	14	50.75	712.75
4983	4983	4	285	2	2	61	104.40	6405.00
4984	4984	2	19	3	2	40	39.30	1637.40
4985	4985	1	121	1	1	42	59.65	2536.55
4986	4986	6	241	1	1	72	83.30	6042.70
4987	4987	2	262	2	1	12	79.55	958.25
4988	4988	5	322	1	1	71	24.45	1730.65
4989	4989	3	193	4	1	26	19.20	459.60
4990	4990	1	33	4	1	7	29.80	201.95
4991	4991	1	65	4	1	6	45.50	285.20
4992	4992	4	188	3	2	58	106.45	6145.85
4993	4993	2	17	2	1	51	30.05	1529.45
4994	4994	6	64	1	1	72	65.65	4664.50
4995	4995	2	164	3	2	18	96.05	1740.70
4996	4996	2	258	1	2	7	75.10	552.95
4997	4997	5	247	4	1	47	74.05	3496.30
4998	4998	2	65	3	2	2	44.70	93.70
4999	4999	4	289	1	1	62	110.75	7053.35
5000	5000	5	193	4	1	16	19.70	301.55
5001	5001	2	69	2	1	6	49.50	312.70
5002	5002	2	77	2	2	19	55.00	1046.50
5003	5003	6	42	2	1	69	43.95	2960.10
5004	5004	2	258	3	2	11	74.35	834.20
5005	5005	2	289	3	1	64	111.15	6953.40
5006	5006	4	176	2	2	39	104.70	4134.85
5007	5007	2	226	4	2	15	55.70	899.80
5008	5008	1	193	4	1	25	20.60	541.50
5009	5009	5	193	2	1	6	19.65	116.85
5010	5010	3	321	1	1	66	115.80	7942.15
5011	5011	5	225	2	1	61	88.65	5321.25
5012	5012	2	308	3	1	43	94.50	4156.80
5013	5013	1	193	4	1	12	20.10	223.60
5014	5014	2	2	1	1	23	34.65	768.45
5015	5015	2	28	1	1	71	52.30	3765.05
5016	5016	1	200	4	1	34	65.00	2157.50
5017	5017	1	193	2	2	5	19.85	108.05
5018	5018	3	21	4	1	41	35.45	1391.65
5019	5019	5	193	2	1	72	19.70	1379.80
5020	5020	2	261	3	1	14	95.60	1273.30
5021	5021	6	193	4	1	41	19.85	810.45
5022	5022	3	290	2	1	23	81.85	1810.85
5023	5023	5	192	2	1	71	109.30	7782.85
5024	5024	2	129	3	2	1	70.30	70.30
5025	5025	5	322	4	1	72	25.40	1797.10
5026	5026	2	129	3	1	6	69.80	377.85
5027	5027	4	193	2	1	23	20.00	445.30
5028	5028	1	259	3	2	10	85.55	851.75
5029	5029	6	192	3	1	72	109.90	7624.20
5030	5030	2	97	1	1	7	50.30	355.10
5031	5031	1	140	4	2	6	94.50	575.45
5032	5032	2	152	3	1	9	101.50	906.85
5033	5033	2	275	3	1	12	89.15	1057.55
5034	5034	2	193	4	1	1	19.40	19.40
5035	5035	3	17	1	1	48	29.90	1388.75
5036	5036	1	131	3	1	20	78.80	1641.30
5037	5037	2	259	2	2	16	85.35	1375.15
5038	5038	2	131	4	2	2	79.65	152.70
5039	5039	4	193	4	1	10	19.30	185.20
5040	5040	2	130	3	2	2	79.60	195.05
5041	5041	1	280	4	1	20	96.80	1826.70
5042	5042	3	193	4	1	20	20.65	417.50
5043	5043	3	193	4	1	19	19.80	344.50
5044	5044	2	292	3	2	19	90.60	1660.00
5045	5045	2	184	3	1	22	104.60	2180.55
5046	5046	1	262	2	1	35	80.05	2835.90
5047	5047	1	65	4	1	1	45.15	45.15
5048	5048	2	258	2	1	39	73.15	2730.85
5049	5049	4	144	3	1	54	99.10	5437.10
5050	5050	2	193	1	2	1	20.20	20.20
5051	5051	6	301	2	2	66	106.05	6981.35
5052	5052	2	297	4	1	56	105.35	5794.45
5053	5053	2	65	2	1	18	45.65	747.20
5054	5054	2	274	2	1	16	79.95	1267.95
5055	5055	4	105	2	1	68	54.45	3674.95
5056	5056	5	322	2	1	53	25.10	1275.60
5057	5057	5	241	2	1	72	84.70	5893.90
5058	5058	2	258	3	1	9	75.85	724.65
5059	5059	2	97	4	1	30	48.80	1536.75
5060	5060	2	277	3	2	36	99.15	3615.60
5061	5061	2	13	3	1	18	35.20	607.30
5062	5062	3	240	3	1	55	76.25	4154.55
5063	5063	1	44	3	2	39	55.90	2184.35
5064	5064	2	274	3	2	21	82.35	1852.85
5065	5065	2	29	2	2	2	40.40	77.15
5066	5066	4	322	1	1	33	24.90	847.80
5067	5067	5	28	1	1	44	54.30	2390.45
5068	5068	1	102	1	1	30	66.30	1923.50
5069	5069	6	193	1	1	71	20.90	1493.20
5070	5070	1	258	3	2	4	75.35	338.10
5071	5071	4	139	3	2	35	85.15	3030.60
5072	5072	1	137	2	1	1	75.35	75.35
5073	5073	2	285	3	1	23	104.45	2184.85
5074	5074	4	12	2	1	22	49.45	1031.40
5075	5075	3	193	2	1	49	19.45	921.30
5076	5076	2	140	3	1	42	92.15	3875.40
5077	5077	4	140	3	2	33	93.80	3124.50
5078	5078	5	193	4	1	7	19.85	144.15
5079	5079	4	303	1	1	67	100.25	6689.00
5080	5080	1	279	3	1	15	95.70	1451.10
5081	5081	6	283	3	1	67	93.15	6368.20
5082	5082	6	119	4	1	53	69.70	3729.60
5083	5083	3	193	4	1	21	19.80	350.10
5084	5084	2	118	4	1	40	71.35	2847.20
5085	5085	3	193	1	1	22	20.75	452.35
5086	5086	2	6	3	1	39	40.60	1494.50
5087	5087	4	193	3	2	45	20.40	930.45
5088	5088	1	193	4	1	2	20.35	41.85
5089	5089	5	193	1	1	57	19.75	1272.05
5090	5090	2	67	3	1	8	54.40	475.10
5091	5091	2	307	2	2	7	94.70	673.10
5092	5092	2	17	2	2	6	30.50	208.70
5093	5093	1	193	4	1	7	20.45	150.75
5094	5094	6	200	1	1	49	66.15	3199.00
5095	5095	4	310	3	1	65	89.85	5844.65
5096	5096	3	65	1	1	55	45.05	2462.60
5097	5097	5	257	1	1	71	86.85	6263.80
5098	5098	2	318	4	1	35	96.75	3403.40
5099	5099	2	258	3	2	3	77.00	237.75
5100	5100	1	193	2	2	11	20.10	221.35
5101	5101	1	137	3	2	1	75.30	75.30
5102	5102	2	320	1	1	17	106.65	1672.10
5103	5103	6	305	2	1	72	110.15	7881.20
5104	5104	4	162	1	1	28	82.85	2320.80
5105	5105	5	193	4	1	18	20.10	370.50
5106	5106	4	152	2	2	40	99.20	4062.20
5107	5107	2	74	3	1	52	59.45	3043.70
5108	5108	2	83	1	1	47	58.60	2723.40
5109	5109	1	73	2	1	23	49.70	1081.25
5110	5110	5	125	4	1	66	65.85	4097.05
5111	5111	2	258	3	1	8	73.50	632.20
5112	5112	1	162	4	2	47	85.50	4042.30
5113	5113	1	193	4	2	7	20.05	164.85
5114	5114	5	321	2	1	71	113.65	8166.80
5115	5115	2	306	3	1	50	83.40	4113.70
5116	5116	5	125	4	1	46	65.65	3047.15
5117	5117	1	129	3	2	1	70.40	70.40
5118	5118	6	48	1	1	66	61.35	4193.40
5119	5119	2	270	2	1	42	85.90	3729.75
5120	5120	2	133	4	1	5	75.65	399.45
5121	5121	4	97	3	2	7	49.75	331.30
5122	5122	3	219	2	1	29	70.90	1964.60
5123	5123	1	81	4	1	27	49.85	1336.15
5124	5124	2	145	2	2	15	75.30	1147.45
5125	5125	5	193	4	1	25	20.10	486.05
5126	5126	2	261	3	2	11	94.00	1078.90
5127	5127	2	320	3	1	57	103.05	5925.75
5128	5128	4	321	1	2	67	118.35	7804.15
5129	5129	1	269	3	1	47	99.70	4747.20
5130	5130	2	131	4	1	13	81.90	1028.90
5131	5131	2	33	3	2	8	30.45	226.45
5132	5132	2	261	3	2	44	96.10	4364.10
5133	5133	4	228	3	1	71	66.20	4692.55
5134	5134	2	285	3	2	24	104.25	2433.90
5135	5135	2	274	3	2	15	80.20	1217.25
5136	5136	1	193	3	1	1	19.75	19.75
5137	5137	2	258	4	1	2	72.60	154.30
5138	5138	2	321	3	1	55	116.50	6382.55
5139	5139	6	281	3	1	71	106.80	7623.20
5140	5140	5	322	4	1	50	24.95	1261.45
5141	5141	2	132	3	1	1	89.25	89.25
5142	5142	2	193	4	1	5	19.25	86.05
5143	5143	4	320	1	1	66	104.55	6779.05
5144	5144	4	128	4	1	49	87.20	4345.00
5145	5145	2	17	3	1	3	30.75	82.85
5146	5146	4	322	2	1	66	25.70	1714.55
5147	5147	1	259	3	1	11	86.20	893.20
5148	5148	2	5	2	1	28	30.10	810.85
5149	5149	6	316	3	1	65	99.35	6347.55
5150	5150	6	193	2	1	62	19.20	1123.65
5151	5151	1	193	1	1	2	20.10	43.15
5152	5152	1	193	2	1	2	20.35	35.10
5153	5153	6	322	2	1	55	25.65	1388.00
5154	5154	2	148	3	1	41	94.55	3851.45
5155	5155	2	301	3	2	17	104.20	1743.50
5156	5156	4	136	1	1	30	94.40	2638.10
5157	5157	3	113	4	1	17	56.10	946.95
5158	5158	5	118	1	1	16	68.25	1114.85
5159	5159	5	322	1	1	72	24.75	1777.60
5160	5160	2	258	3	1	9	76.25	684.85
5161	5161	1	145	3	1	1	74.35	74.35
5162	5162	1	85	3	1	23	54.15	1312.45
5163	5163	1	193	1	1	8	19.45	159.20
5164	5164	2	49	4	1	19	34.95	610.20
5165	5165	2	226	3	1	7	53.65	404.35
5166	5166	2	129	3	2	1	69.65	69.65
5167	5167	3	301	3	1	61	104.00	6363.45
5168	5168	6	119	2	1	57	70.35	4124.65
5169	5169	2	130	3	2	9	80.80	713.10
5170	5170	3	106	4	1	15	64.85	950.75
5171	5171	1	193	4	1	1	19.65	19.65
5172	5172	1	65	1	1	12	45.90	505.95
5173	5173	5	193	4	1	54	20.00	1149.65
5174	5174	1	65	3	1	4	44.80	169.65
5175	5175	2	131	4	2	7	80.30	526.70
5176	5176	3	193	4	1	20	20.35	393.15
5177	5177	1	38	4	1	26	45.80	1147.00
5178	5178	2	259	3	2	36	84.10	3021.60
5179	5179	4	289	1	1	53	108.95	5718.20
5180	5180	2	72	3	2	3	69.35	191.35
5181	5181	5	64	2	1	68	64.35	4539.60
5182	5182	6	257	2	1	72	90.80	6397.60
5183	5183	3	322	2	1	12	24.95	280.40
5184	5184	2	274	4	2	34	79.60	2718.30
5185	5185	6	306	1	1	68	84.70	5711.05
5186	5186	4	111	2	1	50	70.80	3478.15
5187	5187	2	3	3	2	1	36.45	36.45
5188	5188	2	285	3	1	41	104.40	4133.95
5189	5189	2	265	3	1	30	101.50	2917.65
5190	5190	1	210	3	1	1	54.30	54.30
5191	5191	2	269	3	1	29	103.95	2964.80
5192	5192	6	257	2	1	23	91.10	2198.30
5193	5193	5	193	4	1	60	19.95	1189.90
5194	5194	5	322	2	1	72	26.45	1914.50
5195	5195	2	155	3	2	22	89.40	2001.50
5196	5196	6	127	1	1	72	75.10	5336.35
5197	5197	3	285	1	1	66	108.10	7238.60
5198	5198	6	289	3	1	72	110.15	7998.80
5199	5199	1	290	3	2	47	80.35	3825.85
5200	5200	4	289	3	1	51	111.50	5703.25
5201	5201	4	285	3	1	70	106.50	7397.00
5202	5202	4	193	3	1	9	19.90	164.60
5203	5203	6	313	4	1	59	111.10	6555.20
5204	5204	1	72	4	1	3	70.70	225.65
5205	5205	2	1	3	1	38	24.85	955.75
5206	5206	1	314	1	1	37	91.20	3382.30
5207	5207	5	125	1	1	37	65.60	2313.80
5208	5208	2	10	2	2	24	40.65	933.30
5209	5209	1	117	1	1	14	59.45	780.85
5210	5210	6	313	2	1	72	109.95	7852.40
5211	5211	4	32	3	2	53	60.45	3184.25
5212	5212	2	259	3	2	8	84.90	764.95
5213	5213	5	57	2	1	72	38.50	2763.00
5214	5214	2	261	3	1	17	92.55	1614.70
5215	5215	2	145	1	2	2	73.55	145.40
5216	5216	1	193	1	2	8	20.15	156.25
5217	5217	3	25	4	2	48	34.70	1604.50
5218	5218	2	322	4	1	10	24.50	270.15
5219	5219	4	193	4	1	0	19.70	\N
5220	5220	1	193	4	1	1	20.60	20.60
5221	5221	3	109	2	1	29	58.00	1734.50
5222	5222	4	285	3	1	65	107.45	7047.50
5223	5223	2	250	1	1	8	65.50	573.15
5224	5224	5	322	1	1	61	25.45	1538.60
5225	5225	4	269	1	1	45	100.15	4459.80
5226	5226	4	285	2	1	72	104.45	7459.00
5227	5227	2	193	3	1	12	21.15	306.05
5228	5228	1	261	3	1	7	96.20	639.70
5229	5229	2	65	4	1	9	44.40	348.15
5230	5230	4	273	3	2	43	107.55	4533.90
5231	5231	5	271	1	1	58	94.35	5563.65
5232	5232	2	269	3	2	16	98.75	1587.55
5233	5233	1	193	4	1	2	20.30	40.25
5234	5234	1	156	3	2	8	101.15	842.90
5235	5235	3	301	1	1	40	105.75	4228.55
5236	5236	2	290	3	1	9	81.15	784.45
5237	5237	4	151	3	1	41	89.55	3729.75
5238	5238	2	89	2	1	26	54.75	1406.90
5239	5239	4	85	2	1	33	53.75	1857.30
5240	5240	3	160	2	1	68	105.75	7322.50
5241	5241	6	160	2	1	65	105.85	6725.50
5242	5242	4	86	3	1	55	64.20	3627.30
5243	5243	2	268	3	2	20	88.70	1761.45
5244	5244	4	134	2	1	19	87.70	1725.95
5245	5245	2	267	2	1	45	89.30	4192.15
5246	5246	6	193	2	1	70	20.15	1411.20
5247	5247	2	131	3	2	2	79.75	164.50
5248	5248	2	261	4	2	27	94.55	2724.60
5249	5249	6	193	3	1	12	20.05	264.55
5250	5250	5	64	2	1	72	67.20	4671.70
5251	5251	1	261	3	1	12	94.55	1173.55
5252	5252	2	129	4	2	5	69.05	318.50
5253	5253	2	317	3	1	71	107.50	7713.55
5254	5254	4	80	3	1	35	73.00	2471.25
5255	5255	5	321	2	1	70	114.75	7842.30
5256	5256	2	258	3	1	31	76.05	2227.80
5257	5257	6	271	1	2	52	96.25	4990.25
5258	5258	2	269	3	2	37	101.10	3744.05
5259	5259	4	281	1	2	69	104.70	7220.35
5260	5260	1	258	4	1	30	77.90	2351.45
5261	5261	2	291	3	1	33	90.65	2989.60
5262	5262	6	289	3	1	54	110.45	6077.75
5263	5263	3	231	1	1	59	68.70	4070.95
5264	5264	2	51	3	1	55	44.85	2479.05
5265	5265	4	9	2	1	69	29.80	2134.30
5266	5266	4	276	1	1	66	88.90	6000.10
5267	5267	4	109	4	1	37	58.75	2203.10
5268	5268	3	193	2	1	9	19.85	183.15
5269	5269	5	241	1	1	69	86.90	6194.10
5270	5270	2	83	4	1	10	59.65	638.95
5271	5271	2	113	4	2	40	55.25	2139.20
5272	5272	1	68	2	1	13	66.40	831.75
5273	5273	2	276	3	2	6	90.10	521.30
5274	5274	5	193	1	1	69	20.15	1337.50
5275	5275	4	289	2	1	66	108.10	7181.95
5276	5276	1	202	3	2	11	53.75	608.00
5277	5277	3	109	4	1	46	56.90	2560.10
5278	5278	1	132	3	2	6	89.30	577.60
5279	5279	2	305	4	1	56	109.60	5953.00
5280	5280	5	322	2	1	70	25.15	1790.15
5281	5281	4	209	3	1	33	79.15	2531.40
5282	5282	5	246	2	1	72	66.75	4760.30
5283	5283	2	261	3	2	3	95.20	292.85
5284	5284	1	69	4	1	19	48.80	953.65
5285	5285	1	4	3	2	5	45.70	198.00
5286	5286	6	96	2	1	71	80.70	5705.05
5287	5287	2	161	3	2	8	74.50	609.90
5288	5288	1	193	2	1	1	20.55	20.55
5289	5289	2	131	3	2	1	79.65	79.65
5290	5290	4	321	4	1	61	115.10	6993.65
5291	5291	5	56	1	1	71	59.70	4122.65
5292	5292	3	282	2	1	68	86.45	5762.95
5293	5293	3	13	2	1	46	33.70	1537.85
5294	5294	3	290	1	1	33	80.10	2603.30
5295	5295	6	319	1	1	53	104.05	5566.40
5296	5296	1	317	1	1	50	108.75	5431.90
5297	5297	4	45	2	1	57	41.10	2258.25
5298	5298	6	193	1	1	54	20.35	1092.35
5299	5299	2	285	3	1	60	105.90	6401.25
5300	5300	2	265	2	2	28	101.30	2812.20
5301	5301	2	131	4	2	1	80.05	80.05
5302	5302	2	267	3	2	29	89.20	2698.35
5303	5303	2	86	3	1	10	65.50	616.90
5304	5304	2	57	3	1	43	40.45	1912.85
5305	5305	1	129	1	1	13	70.45	849.10
5306	5306	6	112	3	1	43	78.80	3460.30
5307	5307	2	259	3	2	19	83.65	1465.75
5308	5308	2	132	3	1	1	90.10	90.10
5309	5309	6	112	2	1	69	82.45	5555.30
5310	5310	5	193	2	1	61	20.25	1278.80
5311	5311	1	246	1	1	43	66.25	2907.35
5312	5312	1	193	1	2	6	19.50	146.30
5313	5313	1	69	4	2	1	51.25	51.25
5314	5314	1	132	4	1	56	89.70	4952.95
5315	5315	5	64	1	1	70	64.55	4504.90
5316	5316	2	65	3	2	1	45.60	45.60
5317	5317	4	284	3	1	49	93.65	4520.15
5318	5318	2	69	1	2	6	49.65	267.35
5319	5319	5	126	4	1	32	73.60	2316.85
5320	5320	6	305	4	1	72	109.75	8075.35
5321	5321	5	117	2	1	37	61.45	2302.35
5322	5322	4	184	2	1	69	106.40	7251.90
5323	5323	1	96	1	1	26	81.90	2078.55
5324	5324	4	285	2	1	58	105.20	6225.40
5325	5325	3	198	1	1	24	54.60	1242.25
5326	5326	3	193	3	1	5	20.55	99.45
5327	5327	2	193	3	2	15	20.00	288.05
5328	5328	5	193	4	1	30	19.70	599.25
5329	5329	4	246	2	1	55	66.05	3462.10
5330	5330	2	3	1	2	25	34.00	853.00
5331	5331	2	159	4	2	10	92.50	934.10
5332	5332	6	62	2	1	44	54.05	2375.20
5333	5333	4	117	4	1	47	58.90	2813.05
5334	5334	1	132	3	2	13	88.35	1222.80
5335	5335	6	289	1	2	49	107.95	5293.20
5336	5336	4	168	4	1	64	96.90	6314.35
5337	5337	1	193	4	1	1	19.10	19.10
5338	5338	1	69	4	1	20	50.00	1003.05
5339	5339	5	39	3	1	37	45.40	1593.10
5340	5340	1	260	3	1	30	85.45	2509.95
5341	5341	3	253	1	1	38	84.10	3187.65
5342	5342	2	258	4	2	1	74.45	74.45
5343	5343	2	68	3	2	37	64.75	2345.20
5344	5344	5	64	2	1	52	66.25	3330.10
5345	5345	6	127	2	1	71	76.90	5522.70
5346	5346	1	155	3	2	26	89.80	2335.30
5347	5347	6	251	2	1	66	74.60	4798.40
5348	5348	6	321	2	1	72	116.95	8594.40
5349	5349	4	35	2	1	25	40.65	970.55
5350	5350	6	321	1	1	69	114.35	7665.80
5351	5351	5	243	1	1	53	69.70	3686.05
5352	5352	3	140	4	2	12	95.50	1115.15
5353	5353	2	144	3	1	26	98.65	2537.00
5354	5354	1	74	4	1	21	61.65	1393.60
5355	5355	2	132	3	1	1	89.35	89.35
5356	5356	2	295	3	1	48	95.40	4445.30
5357	5357	3	41	2	1	26	35.40	978.60
5358	5358	5	193	4	1	60	19.95	1258.15
5359	5359	1	193	4	1	18	19.25	331.35
5360	5360	2	5	3	2	10	29.65	291.40
5361	5361	2	298	3	2	5	84.50	453.75
5362	5362	4	193	4	1	4	20.40	84.75
5363	5363	5	322	2	1	65	24.75	1715.10
5364	5364	5	322	4	1	70	25.35	1715.15
5365	5365	2	267	2	2	18	90.70	1597.25
5366	5366	5	193	1	1	62	20.00	1250.10
5367	5367	6	99	3	1	66	59.75	3996.80
5368	5368	6	249	1	1	65	82.50	5215.10
5369	5369	2	129	3	2	3	70.30	235.50
5370	5370	1	193	4	1	34	20.35	673.20
5371	5371	2	268	1	1	16	90.80	1442.20
5372	5372	4	301	1	2	54	103.95	5639.05
5373	5373	2	273	3	1	50	104.95	5222.35
5374	5374	6	160	3	1	71	105.25	7291.75
5375	5375	2	258	3	2	10	74.75	799.65
5376	5376	2	69	3	2	1	50.80	50.80
5377	5377	3	322	4	1	18	23.75	424.50
5378	5378	2	71	3	1	4	61.30	249.40
5379	5379	5	240	4	1	58	75.80	4415.75
5380	5380	4	293	3	1	56	98.00	5270.60
5381	5381	2	131	3	2	2	80.25	144.55
5382	5382	2	266	3	2	32	78.90	2447.95
5383	5383	4	55	4	1	56	52.00	2884.90
5384	5384	2	259	3	2	36	84.75	3050.15
5385	5385	2	200	4	1	4	64.40	253.00
5386	5386	1	260	1	2	53	85.45	4517.25
5387	5387	2	65	2	1	10	45.80	436.20
5388	5388	1	5	3	1	4	30.50	118.40
5389	5389	1	193	4	2	1	19.90	19.90
5390	5390	1	129	4	1	51	69.15	3649.60
5391	5391	2	269	3	2	12	99.45	1200.15
5392	5392	4	8	4	1	6	49.25	255.60
5393	5393	5	29	1	1	63	39.35	2395.05
5394	5394	2	129	3	2	1	70.60	70.60
5395	5395	2	281	2	1	48	105.10	5083.55
5396	5396	2	131	2	2	5	81.00	389.60
5397	5397	4	193	2	1	35	20.10	644.50
5398	5398	2	147	3	2	6	84.85	523.50
5399	5399	1	193	4	1	2	19.75	39.30
5400	5400	3	193	1	1	50	19.75	989.05
5401	5401	2	129	1	1	33	70.40	2406.10
5402	5402	5	193	4	1	31	20.45	638.55
5403	5403	5	193	4	1	9	20.35	191.10
5404	5404	2	225	3	1	54	86.20	4524.05
5405	5405	4	187	2	1	46	95.65	4664.20
5406	5406	4	309	3	1	34	103.80	3470.80
5407	5407	6	293	3	1	71	97.20	6910.30
5408	5408	5	125	4	1	63	63.55	4014.20
5409	5409	5	322	1	1	51	24.95	1288.00
5410	5410	2	276	3	2	26	89.15	2277.65
5411	5411	6	172	1	1	64	99.00	6375.80
5412	5412	2	1	3	2	1	24.80	24.80
5413	5413	4	278	1	1	61	85.55	5251.75
5414	5414	2	140	2	1	15	94.00	1505.45
5415	5415	4	281	2	2	64	105.65	6903.10
5416	5416	2	194	3	1	18	50.30	913.30
5417	5417	4	148	3	1	57	95.00	5535.80
5418	5418	6	114	1	1	14	61.40	815.55
5419	5419	2	274	2	1	18	80.55	1411.65
5420	5420	5	290	1	1	72	78.50	5602.25
5421	5421	5	321	2	1	70	114.30	8244.30
5422	5422	5	193	4	1	38	20.05	741.50
5423	5423	5	125	2	1	68	62.65	4375.80
5424	5424	2	130	3	2	13	80.85	1008.70
5425	5425	6	308	2	1	65	92.70	5968.40
5426	5426	1	269	3	1	30	100.45	3096.90
5427	5427	6	201	1	1	51	75.20	3901.25
5428	5428	2	298	2	1	31	84.75	2613.40
5429	5429	1	132	3	2	9	89.45	853.10
5430	5430	6	255	1	1	72	79.50	5661.70
5431	5431	2	197	2	2	10	72.15	794.25
5432	5432	4	193	3	1	37	19.80	695.05
5433	5433	1	80	3	2	2	76.40	160.80
5434	5434	4	180	4	1	55	100.90	5552.05
5435	5435	2	299	1	1	33	95.30	3275.15
5436	5436	3	142	1	1	46	90.95	4236.60
5437	5437	1	101	3	1	1	54.50	54.50
5438	5438	2	195	4	2	20	61.60	1174.35
5439	5439	2	153	3	2	9	79.90	741.70
5440	5440	2	261	2	2	32	96.15	3019.25
5441	5441	2	73	1	1	19	49.60	962.90
5442	5442	5	238	2	2	70	65.30	4759.75
5443	5443	6	322	2	1	61	25.00	1498.35
5444	5444	1	65	3	1	26	45.45	1233.15
5445	5445	2	285	1	1	45	107.75	4882.80
5446	5446	6	268	2	1	62	89.10	5411.65
5447	5447	1	193	4	2	1	19.65	19.65
5448	5448	1	65	4	1	3	44.75	148.05
5449	5449	4	315	1	1	41	101.60	3930.55
5450	5450	5	160	1	1	67	103.15	6895.50
5451	5451	2	260	4	2	1	84.65	84.65
5452	5452	3	308	4	1	71	95.65	6856.95
5453	5453	3	116	1	1	37	75.10	2658.80
5454	5454	6	117	4	1	60	61.35	3766.20
5455	5455	2	129	3	2	1	69.55	69.55
5456	5456	1	193	2	1	6	19.70	129.55
5457	5457	2	17	3	2	13	31.05	347.25
5458	5458	1	97	1	1	11	51.00	581.70
5459	5459	2	97	4	2	7	51.00	354.05
5460	5460	2	132	3	1	10	88.85	929.45
5461	5461	5	193	2	1	34	20.05	679.00
5462	5462	6	102	4	1	62	65.10	3846.75
5463	5463	4	215	4	1	64	70.15	4480.70
5464	5464	2	65	1	2	1	44.35	44.35
5465	5465	6	193	4	1	25	20.75	499.40
5466	5466	4	89	4	1	26	56.05	1553.20
5467	5467	4	193	1	1	10	19.95	219.50
5468	5468	3	316	4	1	53	98.60	5311.85
5469	5469	2	131	3	2	7	79.70	586.05
5470	5470	2	153	2	1	33	79.00	2576.80
5471	5471	5	154	2	1	71	89.45	6435.25
5472	5472	2	258	3	1	29	74.20	1993.25
5473	5473	1	233	1	1	24	81.00	1923.85
5474	5474	2	73	3	1	20	49.60	939.80
5475	5475	2	260	3	1	1	84.60	84.60
5476	5476	2	210	2	2	54	55.00	3092.65
5477	5477	2	139	4	2	5	84.85	415.55
5478	5478	6	241	1	1	72	84.20	5986.55
5479	5479	6	192	3	1	52	106.30	5487.00
5480	5480	1	129	3	1	9	69.05	651.50
5481	5481	2	65	4	1	1	45.40	45.40
5482	5482	2	258	3	2	1	73.65	73.65
5483	5483	4	80	4	2	33	73.90	2405.05
5484	5484	2	266	3	2	55	77.75	4458.15
5485	5485	6	265	3	1	69	99.35	6856.45
5486	5486	2	97	4	1	1	50.75	50.75
5487	5487	5	241	1	1	54	87.10	4735.20
5488	5488	4	193	4	1	33	20.15	682.15
5489	5489	4	288	1	1	45	98.70	4525.80
5490	5490	1	1	3	1	11	25.20	321.05
5491	5491	2	113	1	1	6	55.70	335.65
5492	5492	1	107	1	1	21	65.35	1424.40
5493	5493	6	322	1	1	65	25.30	1748.55
5494	5494	2	259	3	2	6	84.35	474.90
5495	5495	1	163	3	2	8	84.95	668.40
5496	5496	2	133	3	2	11	73.85	926.25
5497	5497	5	322	4	1	43	24.25	1077.95
5498	5498	4	20	1	2	49	51.80	2541.25
5499	5499	1	65	3	2	1	46.00	46.00
5500	5500	2	130	3	2	15	79.40	1156.10
5501	5501	5	121	1	1	60	60.50	3694.45
5502	5502	1	1	2	1	17	25.10	382.80
5503	5503	2	129	1	2	16	71.80	1167.80
5504	5504	3	193	1	1	35	20.05	746.75
5505	5505	3	275	4	2	44	88.40	3912.90
5506	5506	3	5	2	1	12	30.25	368.85
5507	5507	1	193	4	1	1	20.20	20.20
5508	5508	4	117	3	1	28	59.90	1654.70
5509	5509	5	322	1	1	70	25.15	1940.85
5510	5510	1	65	4	2	5	46.00	221.70
5511	5511	1	156	2	1	18	101.30	1794.65
6593	6593	3	71	2	1	26	59.45	1507.00
5512	5512	6	233	2	1	70	76.95	5289.80
5513	5513	2	210	4	1	9	55.30	501.20
5514	5514	6	183	1	1	67	92.45	6140.85
5515	5515	2	97	1	1	1	48.45	48.45
5516	5516	5	193	4	1	18	19.35	309.25
5517	5517	1	194	2	2	4	51.75	201.10
5518	5518	4	185	1	1	71	86.70	6179.35
5519	5519	2	308	3	2	30	94.40	2838.70
5520	5520	1	105	4	1	1	55.70	55.70
5521	5521	4	298	2	1	55	84.25	4589.85
5522	5522	2	79	3	1	59	64.65	3735.45
5523	5523	2	129	4	2	1	70.15	70.15
5524	5524	2	129	1	1	7	69.20	477.55
5525	5525	5	101	1	1	45	54.65	2553.70
5526	5526	4	322	1	1	54	24.75	1342.15
5527	5527	4	322	4	1	51	23.95	1216.35
5528	5528	3	285	2	1	72	105.00	7578.05
5529	5529	4	117	1	1	44	59.85	2603.95
5530	5530	1	193	4	1	2	20.05	42.70
5531	5531	4	268	1	1	66	92.15	6056.90
5532	5532	3	51	4	1	68	44.80	2983.65
5533	5533	5	193	2	1	31	20.90	689.35
5534	5534	2	261	1	1	21	95.40	2025.10
5535	5535	1	290	3	1	21	80.35	1747.20
5536	5536	6	241	1	1	55	85.10	4657.95
5537	5537	2	3	2	2	9	34.70	296.10
5538	5538	6	321	1	1	71	115.05	8016.60
5539	5539	2	130	3	2	1	81.10	81.10
5540	5540	3	193	4	1	22	19.95	433.50
5541	5541	1	193	4	2	1	20.55	20.55
5542	5542	6	273	3	2	61	106.60	6428.40
5543	5543	5	225	1	1	67	86.15	5883.85
5544	5544	1	177	3	1	14	78.85	1043.80
5545	5545	2	320	3	2	59	106.75	6252.90
5546	5546	1	139	1	1	21	86.55	1857.25
5547	5547	1	53	4	1	4	42.40	146.40
5548	5548	2	132	3	2	3	89.45	240.45
5549	5549	5	322	1	1	70	24.25	1724.15
5550	5550	2	152	3	2	3	97.90	315.30
5551	5551	3	193	1	1	21	20.50	429.55
5552	5552	2	193	2	1	20	19.60	356.15
5553	5553	3	193	1	1	22	20.25	488.25
5554	5554	2	66	4	2	1	55.70	55.70
5555	5555	6	193	4	1	63	20.60	1298.70
5556	5556	5	193	1	1	70	19.80	1378.75
5557	5557	2	153	3	2	13	79.80	973.45
5558	5558	1	131	3	1	5	80.20	384.25
5559	5559	6	321	2	1	72	116.40	8543.25
5560	5560	2	17	3	1	13	31.65	389.95
5561	5561	1	158	2	1	61	94.15	5731.85
5562	5562	1	193	3	1	1	20.65	20.65
5563	5563	2	262	1	1	56	76.85	4275.75
5564	5564	1	193	4	1	4	20.15	84.50
5565	5565	5	226	4	1	35	55.25	1924.10
5566	5566	2	11	3	2	18	39.05	669.85
5567	5567	5	221	1	1	72	82.15	5784.30
5568	5568	3	319	1	1	49	103.00	5166.20
5569	5569	2	318	2	1	44	95.10	4060.55
5570	5570	2	135	4	2	3	83.90	267.40
5571	5571	2	283	3	1	37	95.15	3532.85
5572	5572	4	221	3	1	61	79.80	4914.80
5573	5573	6	239	2	1	70	74.80	5315.80
5574	5574	2	129	3	2	1	69.85	69.85
5575	5575	1	193	3	1	41	20.45	775.60
5576	5576	3	255	1	1	70	78.35	5445.95
5577	5577	2	67	4	2	1	53.55	53.55
5578	5578	3	193	3	1	51	19.10	1007.80
5579	5579	5	193	4	1	42	20.00	833.55
5580	5580	5	318	1	2	70	93.90	6579.05
5581	5581	3	193	1	1	48	19.95	1004.50
5582	5582	6	321	3	2	68	113.15	7856.00
5583	5583	5	322	2	1	48	24.00	1183.05
5584	5584	1	146	3	2	26	84.95	2169.75
5585	5585	2	274	1	2	11	80.50	896.90
5586	5586	2	193	4	2	1	19.30	19.30
5587	5587	3	193	4	1	27	19.15	501.35
5588	5588	4	155	1	1	46	91.30	4126.35
5589	5589	2	73	4	2	1	49.65	49.65
5590	5590	5	77	2	2	46	54.35	2460.15
5591	5591	2	193	4	1	25	19.15	477.60
5592	5592	2	132	3	2	4	88.45	370.65
5593	5593	5	193	4	1	13	19.75	265.75
5594	5594	4	126	2	1	31	75.50	2424.45
5595	5595	2	260	3	1	23	83.75	1849.95
5596	5596	1	193	4	1	2	19.40	61.05
5597	5597	5	322	1	1	65	26.50	1698.55
5598	5598	2	264	1	2	22	90.50	1910.60
5599	5599	3	193	2	1	55	19.15	998.10
5600	5600	2	159	4	2	9	94.85	890.60
5601	5601	2	129	1	2	7	69.95	529.50
5602	5602	3	7	4	1	35	40.90	1383.60
5603	5603	6	112	4	1	6	80.25	493.40
5604	5604	2	97	2	2	1	48.60	48.60
5605	5605	2	129	3	1	17	70.80	1207.00
5606	5606	1	75	4	1	10	60.20	563.50
5607	5607	3	77	2	1	15	55.20	864.55
5608	5608	2	52	3	2	40	55.80	2109.35
5609	5609	3	101	1	1	13	54.15	701.05
5610	5610	2	274	1	2	29	80.15	2265.25
5611	5611	2	258	3	2	3	75.50	220.60
5612	5612	2	265	1	1	58	100.40	5749.80
5613	5613	4	117	2	1	45	62.55	2796.45
5614	5614	6	254	1	1	72	70.45	5165.70
5615	5615	4	306	1	1	68	85.50	5696.60
5616	5616	2	193	1	2	1	20.20	20.20
5617	5617	1	113	3	1	38	54.50	2076.05
5618	5618	1	193	4	1	2	20.75	44.20
5619	5619	1	193	4	1	11	20.35	215.25
5621	5621	6	285	1	1	72	104.80	7470.10
5622	5622	2	258	2	2	3	74.75	229.50
5623	5623	2	273	4	2	23	104.05	2470.10
5624	5624	2	69	3	1	40	51.10	2092.90
5625	5625	2	275	1	1	62	89.80	5629.55
5626	5626	2	193	3	1	22	20.55	469.85
5627	5627	1	106	1	1	11	64.05	733.95
5628	5628	2	258	3	1	7	74.85	485.25
5629	5629	2	308	3	2	13	96.65	1244.50
5630	5630	1	193	4	2	1	20.05	20.05
5631	5631	2	285	3	2	39	103.45	3994.45
5632	5632	1	1	4	1	3	25.00	78.25
5633	5633	5	193	2	1	58	20.30	1131.50
5634	5634	1	322	4	1	6	26.35	184.05
5635	5635	2	193	3	2	1	19.90	19.90
5636	5636	2	89	4	1	22	54.70	1178.75
5637	5637	1	4	3	2	14	46.35	667.70
5638	5638	3	267	2	1	64	90.25	5629.15
5639	5639	1	193	3	2	1	19.95	19.95
5640	5640	1	193	4	1	6	20.65	109.30
5641	5641	1	130	3	2	1	79.60	79.60
5642	5642	3	322	1	1	39	25.45	958.45
5643	5643	3	193	4	1	20	19.50	403.15
5644	5644	2	133	3	2	1	75.90	75.90
5645	5645	1	137	3	2	1	76.20	76.20
5646	5646	4	228	2	1	64	66.15	4392.50
5647	5647	1	193	4	2	1	19.25	19.25
5648	5648	2	84	2	1	46	69.10	3168.00
5649	5649	4	18	3	1	28	39.10	1096.60
5650	5650	1	193	4	1	33	20.05	669.45
5651	5651	3	121	3	1	39	59.80	2343.85
5652	5652	2	270	3	2	42	84.30	3588.40
5653	5653	2	81	3	1	1	48.60	48.60
5654	5654	2	131	3	2	7	79.00	522.95
5655	5655	5	188	2	1	70	105.35	7511.90
5656	5656	6	322	1	1	65	25.10	1725.00
5657	5657	1	97	3	1	1	49.75	49.75
5658	5658	2	261	3	1	18	94.75	1691.90
5659	5659	2	261	3	1	24	93.00	2248.05
5660	5660	6	239	1	1	63	71.90	4479.20
5661	5661	4	213	4	1	44	77.55	3471.10
5662	5662	2	193	3	1	4	19.85	63.00
5663	5663	2	129	3	2	1	70.25	70.25
5664	5664	2	261	3	1	37	95.25	3314.15
5665	5665	2	138	2	2	10	84.60	865.55
5666	5666	2	1	1	1	34	25.05	852.70
5667	5667	3	44	2	1	35	53.15	1930.90
5668	5668	1	193	3	1	4	20.15	91.40
5669	5669	2	265	3	1	39	101.25	3949.15
5670	5670	4	156	1	1	43	100.55	4304.00
5671	5671	1	322	4	2	17	24.10	409.90
5672	5672	5	322	1	1	61	25.30	1554.90
5673	5673	3	251	3	1	49	71.80	3472.05
5674	5674	3	193	4	1	4	19.70	117.80
5675	5675	5	30	3	1	64	49.85	3210.35
5676	5676	2	129	4	1	3	69.60	207.40
5677	5677	1	193	3	1	1	19.75	19.75
5678	5678	3	153	3	1	40	80.80	3132.75
5679	5679	2	117	3	2	1	60.00	60.00
5680	5680	2	259	3	2	8	86.55	649.65
5681	5681	2	193	4	2	1	20.85	20.85
5682	5682	3	79	1	1	34	64.20	2106.30
5683	5683	1	2	3	1	1	35.00	35.00
5684	5684	2	12	3	2	39	50.75	2011.40
5685	5685	4	184	2	2	58	105.50	6205.50
5686	5686	5	193	3	1	45	19.20	903.70
5687	5687	2	163	1	2	6	85.15	503.60
5688	5688	4	189	2	1	43	90.65	3882.30
5689	5689	6	193	4	1	41	20.00	879.80
5690	5690	2	145	3	1	5	74.65	383.65
5691	5691	6	48	2	1	72	61.20	4390.25
5692	5692	3	193	4	1	4	19.95	68.20
5693	5693	1	85	4	1	9	54.80	452.80
5694	5694	6	205	2	1	72	73.45	5329.00
5695	5695	4	69	4	1	33	51.45	1758.90
5696	5696	5	290	1	1	72	80.45	5737.60
5697	5697	2	101	3	2	22	54.20	1152.70
5698	5698	4	289	3	2	70	109.50	7674.55
5699	5699	1	285	3	2	21	104.40	2157.95
5700	5700	1	139	3	1	15	85.30	1219.85
5701	5701	2	262	3	1	29	79.30	2414.55
5702	5702	1	96	1	1	15	76.50	1155.60
5703	5703	2	309	2	2	71	105.10	7548.10
5704	5704	5	322	1	1	72	25.40	1809.35
5705	5705	2	260	3	1	19	86.85	1564.40
5706	5706	1	193	4	1	1	19.65	19.65
5707	5707	2	145	3	2	1	75.70	75.70
5708	5708	1	65	3	1	2	45.55	84.40
5709	5709	2	266	2	1	11	78.10	864.85
5710	5710	3	193	4	1	12	19.30	228.75
5711	5711	6	289	3	1	70	110.50	7752.05
5712	5712	1	268	3	2	20	90.80	1951.00
5713	5713	2	193	1	1	23	20.30	470.60
5714	5714	5	255	2	1	49	81.35	4060.90
5715	5715	2	277	3	2	4	97.95	384.50
5716	5716	2	313	2	2	32	108.15	3432.90
5717	5717	2	66	3	1	2	55.30	108.65
5718	5718	5	52	2	1	69	56.55	3952.65
5719	5719	2	131	2	2	6	80.50	463.05
5720	5720	6	193	4	1	24	19.70	494.05
5721	5721	4	285	2	1	32	104.05	3416.85
5722	5722	5	113	1	1	27	52.85	1498.65
5723	5723	2	297	1	2	27	104.30	2867.75
5724	5724	1	262	1	1	58	80.65	4807.35
5725	5725	2	129	4	2	1	71.35	71.35
5726	5726	6	322	2	1	18	24.65	471.35
5727	5727	6	193	1	1	47	21.30	1041.80
5728	5728	6	289	3	1	70	110.20	7689.80
5729	5729	1	286	3	2	13	89.40	1132.35
5730	5730	1	97	2	1	36	51.05	1815.00
5731	5731	6	193	4	1	67	19.80	1311.30
5732	5732	2	193	4	1	10	19.90	199.45
5733	5733	2	162	3	1	19	87.30	1637.30
5734	5734	5	193	1	1	71	19.85	1326.35
5735	5735	6	257	4	1	72	89.40	6376.55
5736	5736	5	193	4	1	48	20.00	935.90
5737	5737	1	193	4	1	1	20.05	20.05
5738	5738	1	112	3	1	18	83.25	1611.15
5739	5739	1	193	4	2	1	20.60	20.60
5740	5740	5	281	1	1	67	102.90	6989.70
5741	5741	5	45	4	1	69	39.10	2779.50
5742	5742	2	277	3	2	19	99.95	1931.75
5743	5743	6	321	4	1	72	114.50	8331.95
5744	5744	5	193	4	1	38	20.20	735.90
5745	5745	3	66	3	1	40	55.80	2283.30
5746	5746	6	322	4	1	61	24.20	1445.20
5747	5747	2	274	2	2	10	81.00	818.05
5748	5748	4	232	2	1	32	72.80	2333.05
5749	5749	2	277	2	1	21	99.85	1992.55
5750	5750	4	269	3	1	59	99.50	5890.00
5751	5751	2	129	3	2	13	70.15	916.75
5752	5752	5	193	2	1	47	20.25	1029.80
5753	5753	6	322	1	1	69	26.00	1796.55
5754	5754	2	193	2	1	2	19.90	33.70
5755	5755	1	193	1	1	22	19.05	454.05
5756	5756	2	300	3	1	15	96.50	1392.25
5757	5757	5	193	2	1	53	19.85	1049.60
5758	5758	1	322	4	1	28	25.70	734.60
5759	5759	3	193	4	1	22	20.30	475.10
5760	5760	2	129	4	2	1	70.15	70.15
5761	5761	2	142	3	1	16	91.55	1540.05
5762	5762	5	53	4	1	48	39.40	1978.65
5763	5763	2	320	1	1	30	105.70	3181.80
5764	5764	2	129	3	1	3	70.25	229.70
5765	5765	5	295	3	1	57	93.75	5625.55
5766	5766	4	307	2	2	68	96.55	6581.90
5767	5767	3	71	1	1	23	60.00	1347.15
5768	5768	6	71	2	1	65	59.80	3808.20
5769	5769	4	132	1	1	44	90.65	3974.15
5770	5770	6	317	1	1	71	109.00	7661.80
5771	5771	3	238	2	1	37	68.10	2479.25
5772	5772	1	193	4	1	12	20.40	266.60
5773	5773	6	225	1	1	69	81.95	5601.40
5774	5774	1	121	3	1	35	60.55	1982.60
5775	5775	2	86	1	1	5	65.60	339.90
5776	5776	5	260	1	1	58	82.50	4828.05
5777	5777	6	255	1	1	72	82.30	5980.55
5778	5778	5	254	4	1	72	68.15	4808.70
5779	5779	1	193	2	1	1	20.30	20.30
5780	5780	4	175	3	2	39	95.55	3692.85
5781	5781	3	193	2	1	53	20.20	1068.15
5782	5782	2	142	3	1	27	89.20	2383.60
5783	5783	2	129	3	2	1	69.65	69.65
5784	5784	2	132	3	2	1	89.30	89.30
5785	5785	1	161	3	1	18	74.80	1438.05
5786	5786	6	193	4	1	46	20.20	917.45
5787	5787	6	241	2	1	72	84.40	6096.45
5788	5788	2	142	3	2	36	87.55	3078.10
5789	5789	2	1	3	1	4	25.15	99.95
5790	5790	5	193	2	1	25	19.80	475.20
5791	5791	2	20	3	1	40	50.85	2036.55
5792	5792	2	285	3	1	63	102.40	6444.05
5793	5793	2	174	4	2	15	96.30	1426.75
5794	5794	2	210	2	1	14	55.50	767.55
5795	5795	6	289	1	1	72	109.75	7932.50
5796	5796	2	309	3	1	39	106.40	4040.65
5797	5797	6	60	2	1	47	60.00	2768.65
5798	5798	2	310	2	1	19	88.80	1672.35
5799	5799	2	260	3	2	5	85.20	474.80
5800	5800	2	2	3	2	13	35.10	446.10
5801	5801	1	266	1	1	17	80.05	1345.65
5802	5802	2	258	3	1	34	75.55	2425.40
5803	5803	2	81	3	1	42	49.55	2077.95
5804	5804	2	274	3	2	5	81.30	416.30
5805	5805	5	322	2	1	71	23.90	1663.50
5806	5806	1	107	1	1	19	66.40	1286.05
5807	5807	2	193	3	2	2	19.60	35.85
5808	5808	5	193	2	1	57	18.80	1094.35
5809	5809	6	289	3	1	72	108.40	7719.50
5810	5810	2	146	4	1	6	85.95	514.60
5811	5811	2	259	3	2	17	85.45	1451.60
5812	5812	5	221	1	1	61	80.90	4932.50
5813	5813	2	129	3	2	1	71.00	71.00
5814	5814	5	321	2	1	48	111.80	5443.65
5815	5815	2	193	2	1	16	20.60	330.25
5816	5816	2	259	3	2	9	85.05	746.50
5817	5817	1	65	3	1	3	44.60	122.70
5818	5818	2	65	3	2	1	44.40	44.40
5819	5819	5	285	2	1	65	105.10	6631.85
5820	5820	6	321	2	1	70	115.15	8250.00
5821	5821	4	99	4	1	60	59.80	3561.15
5822	5822	4	322	3	1	69	26.30	1763.55
5823	5823	1	129	3	1	35	70.55	2419.00
5824	5824	2	193	4	1	22	20.05	470.20
5825	5825	5	221	1	1	66	79.85	5234.95
5826	5826	2	129	3	2	1	70.30	70.30
5827	5827	2	131	1	2	1	79.35	79.35
5828	5828	2	267	2	1	34	90.05	3097.00
5829	5829	5	322	1	1	72	24.45	1709.10
5830	5830	3	48	3	1	31	59.95	1848.80
5831	5831	3	322	1	1	30	25.35	723.30
5832	5832	2	132	1	2	9	90.80	809.75
5833	5833	2	129	3	2	20	70.45	1470.95
5834	5834	2	25	2	1	19	34.30	577.15
5835	5835	2	301	3	1	65	105.05	6914.95
5836	5836	5	193	4	1	30	19.30	602.90
5837	5837	3	193	4	1	6	19.15	124.40
5838	5838	1	20	3	1	2	51.40	96.80
5839	5839	1	231	3	1	53	71.85	3827.90
5840	5840	2	258	3	1	7	75.40	533.05
5841	5841	4	97	1	1	61	49.70	2961.40
5842	5842	4	4	3	2	70	45.25	3264.45
5843	5843	2	237	3	1	13	78.75	995.35
5844	5844	4	266	1	1	35	81.60	2815.25
5845	5845	2	129	2	1	2	70.40	154.80
5846	5846	2	258	3	2	3	75.80	246.30
5847	5847	1	258	3	1	3	76.10	257.60
5848	5848	4	261	1	1	62	94.00	5757.20
5849	5849	5	319	2	1	72	103.95	7517.70
5850	5850	6	193	1	1	63	19.95	1234.80
5851	5851	1	129	2	2	20	71.30	1389.20
5852	5852	4	321	1	1	35	110.80	3836.30
5853	5853	2	129	3	2	21	69.10	1474.75
5854	5854	3	307	3	1	62	96.10	6001.45
5855	5855	2	194	4	1	15	48.80	720.10
5856	5856	2	97	2	1	55	50.55	2832.75
5857	5857	2	65	4	1	11	44.65	472.25
5858	5858	1	268	3	2	17	88.25	1460.65
5859	5859	3	193	1	1	61	19.45	1336.35
5860	5860	5	257	2	1	71	89.30	6388.65
5861	5861	1	129	1	2	2	70.00	153.05
5862	5862	5	193	4	1	35	19.25	677.90
5863	5863	1	129	1	1	17	70.50	1165.60
5864	5864	2	261	3	2	21	97.35	2119.50
5865	5865	5	193	1	1	47	19.65	921.55
5866	5866	1	193	4	1	3	20.85	72.00
5867	5867	2	193	4	1	3	19.65	68.35
5868	5868	6	193	2	1	44	19.35	847.25
5869	5869	2	65	4	1	1	44.00	44.00
5870	5870	3	283	3	1	44	94.40	4295.35
5871	5871	2	322	1	2	5	25.90	135.00
5872	5872	2	226	1	2	24	55.65	1400.55
5873	5873	2	129	3	2	1	69.65	69.65
5874	5874	2	161	3	1	18	75.40	1380.40
5875	5875	2	269	3	2	10	100.60	1060.20
5876	5876	5	122	1	1	65	71.00	4386.20
5877	5877	2	146	3	2	1	86.00	86.00
5878	5878	4	301	2	2	53	106.95	5785.50
5879	5879	3	193	4	1	3	21.20	52.05
5880	5880	6	117	4	1	33	61.05	2018.40
5881	5881	2	17	3	2	3	29.60	79.45
5882	5882	4	112	1	1	34	79.95	2727.30
5883	5883	6	193	4	1	14	19.70	263.65
5884	5884	2	193	4	1	13	20.30	275.40
5885	5885	4	32	1	2	46	59.90	2816.65
5886	5886	3	322	4	1	23	24.35	538.50
5887	5887	5	193	4	1	47	19.75	948.90
5888	5888	2	97	4	1	17	50.30	846.80
5889	5889	2	261	3	2	49	95.60	4783.50
5890	5890	2	20	3	1	59	50.25	2997.45
5891	5891	6	241	2	1	69	85.35	5897.40
5892	5892	4	11	3	2	11	41.60	470.60
5893	5893	2	97	4	1	10	51.65	524.50
5894	5894	6	322	1	1	12	24.00	269.65
5895	5895	2	277	2	2	45	100.85	4740.00
5896	5896	2	75	4	1	39	59.85	2341.50
5897	5897	5	322	2	1	71	25.45	1789.65
5898	5898	5	322	2	1	71	23.90	1626.40
5899	5899	3	322	2	1	33	24.15	800.30
5900	5900	2	258	4	1	67	75.70	5060.85
5901	5901	1	57	1	2	37	40.20	1448.80
5902	5902	1	260	3	2	49	84.50	4254.85
5903	5903	1	81	4	1	9	50.85	466.60
5904	5904	6	302	2	1	52	91.60	4627.80
5905	5905	3	277	3	1	70	98.90	6838.60
5906	5906	2	146	3	1	1	85.00	85.00
5907	5907	2	274	3	2	14	78.95	1101.85
5908	5908	2	65	4	1	1	44.30	44.30
5909	5909	1	193	4	2	1	20.20	20.20
5910	5910	4	274	4	1	52	80.20	4297.60
5911	5911	1	75	4	1	6	60.90	414.10
5912	5912	1	49	4	1	7	34.20	256.60
5913	5913	2	282	1	2	47	85.20	3969.35
5914	5914	4	173	2	1	26	87.15	2274.10
5915	5915	1	101	3	1	25	54.30	1296.80
5916	5916	6	193	4	1	69	19.10	1268.85
5917	5917	6	321	2	1	72	112.75	8192.60
5918	5918	2	193	4	1	4	19.95	59.25
5919	5919	5	193	4	1	59	19.50	1147.85
5920	5920	5	106	1	1	67	65.55	4361.55
5921	5921	2	130	3	1	26	78.80	2006.10
5922	5922	3	96	4	1	27	78.20	2078.95
5923	5923	5	301	1	1	72	105.25	7609.75
5924	5924	2	142	3	1	6	89.25	487.05
5925	5925	5	193	2	1	62	20.65	1218.45
5926	5926	4	216	3	1	20	68.70	1416.20
5927	5927	1	112	2	1	6	78.65	483.30
5928	5928	5	322	4	1	51	24.75	1234.60
5929	5929	5	193	2	1	61	19.75	1311.60
5930	5930	2	314	3	1	62	89.10	5618.30
5931	5931	6	294	1	1	72	84.70	6185.15
5932	5932	2	156	3	2	13	98.00	1237.85
5933	5933	2	140	3	2	5	94.45	498.10
5934	5934	2	285	3	2	3	105.00	294.45
5935	5935	2	283	3	2	26	93.85	2381.55
5936	5936	2	83	3	1	13	59.90	788.35
5937	5937	6	193	4	1	38	19.95	756.40
5938	5938	2	259	3	2	8	84.00	613.40
5939	5939	2	289	3	1	34	108.90	3625.20
5940	5940	1	41	4	1	18	33.60	550.35
5941	5941	4	157	4	1	56	85.85	4793.80
5942	5942	2	21	1	1	36	34.85	1267.20
5943	5943	2	12	3	2	9	48.75	442.20
5944	5944	2	139	3	2	1	84.85	84.85
5945	5945	1	101	4	2	12	56.65	654.85
5946	5946	2	159	2	1	57	95.30	5567.45
5947	5947	3	126	2	2	42	73.90	3160.55
5948	5948	6	322	4	2	33	24.50	740.30
5949	5949	5	181	1	1	70	84.60	5706.20
5950	5950	1	22	3	1	68	44.95	3085.35
5951	5951	2	1	3	1	1	24.70	24.70
5952	5952	1	265	2	1	37	100.30	3541.40
5953	5953	2	322	4	1	4	25.45	84.20
5954	5954	2	97	4	1	1	50.70	50.70
5955	5955	2	63	2	1	20	55.00	1165.55
5956	5956	5	119	1	1	72	68.40	4855.35
5957	5957	2	267	3	2	31	89.90	2806.90
5958	5958	1	130	3	2	18	78.55	1422.65
5959	5959	2	67	1	1	11	55.05	608.15
5960	5960	5	193	2	1	33	19.80	641.35
5961	5961	3	260	3	1	62	84.45	4959.15
5962	5962	1	13	4	1	1	35.90	35.90
5963	5963	1	177	1	1	16	80.75	1321.30
5964	5964	4	209	4	1	22	78.65	1663.75
5965	5965	1	109	1	1	49	61.75	3024.15
5966	5966	4	106	2	1	36	63.70	2188.50
5967	5967	2	287	3	2	42	99.45	4138.05
5968	5968	2	1	1	2	4	25.20	102.50
5969	5969	3	201	4	2	12	74.05	872.65
5970	5970	1	173	3	1	31	87.60	2724.25
5971	5971	2	291	3	1	5	89.15	413.25
5972	5972	5	193	2	1	66	20.00	1374.20
5973	5973	1	198	2	2	15	55.00	757.10
5974	5974	6	285	1	1	64	104.40	6692.65
5975	5975	2	193	2	1	10	20.05	218.50
5976	5976	2	151	3	2	7	89.75	608.80
5977	5977	1	21	3	1	29	34.30	1004.75
5978	5978	5	193	1	1	57	20.65	1125.60
5979	5979	1	306	4	1	46	84.25	3847.60
5980	5980	5	193	1	1	53	19.65	978.00
5981	5981	3	120	2	1	17	79.85	1387.35
5982	5982	6	193	4	1	38	20.20	746.05
5983	5983	3	193	4	1	15	19.80	304.60
5984	5984	2	20	3	1	22	50.35	1098.85
5985	5985	2	259	3	2	14	85.15	1139.20
5986	5986	3	224	1	1	57	74.60	4368.95
5987	5987	2	130	2	1	11	79.15	827.70
5988	5988	5	193	4	1	1	20.35	20.35
5989	5989	5	193	1	1	12	21.05	262.05
5990	5990	2	261	3	2	3	94.60	279.55
5991	5991	2	148	3	1	36	94.70	3512.50
5992	5992	2	164	3	2	16	94.25	1483.25
5993	5993	3	251	2	2	65	72.45	4653.85
5994	5994	1	145	3	1	2	74.95	151.75
5995	5995	2	301	3	2	42	105.20	4400.75
5996	5996	5	192	1	1	72	111.95	8033.10
5997	5997	5	193	1	1	62	19.85	1253.65
5998	5998	2	276	3	1	6	89.75	552.65
5999	5999	6	193	4	1	48	20.05	1036.00
6000	6000	6	305	3	1	35	108.95	4025.50
6001	6001	3	193	2	1	52	19.65	928.40
6002	6002	2	1	4	1	1	24.90	24.90
6003	6003	2	260	3	2	6	82.85	460.25
6004	6004	5	257	2	1	71	93.20	6506.15
6005	6005	3	185	1	1	67	84.80	5598.30
6006	6006	4	243	3	1	60	71.75	4374.55
6007	6007	2	5	1	1	23	30.35	678.75
6008	6008	3	16	1	1	39	54.85	2191.70
6009	6009	4	193	4	1	15	19.50	239.75
6010	6010	2	285	3	2	53	103.85	5485.50
6011	6011	5	322	4	1	24	24.20	609.05
6012	6012	1	193	3	1	37	19.35	683.75
6013	6013	2	146	3	2	5	83.60	404.20
6014	6014	4	265	3	1	50	100.65	5189.75
6015	6015	4	140	2	1	54	94.10	5060.90
6016	6016	2	161	3	1	3	74.55	233.65
6017	6017	3	289	3	2	68	108.45	7176.55
6018	6018	1	77	3	1	5	56.15	291.45
6019	6019	5	193	4	1	33	20.35	689.75
6020	6020	4	221	3	1	41	80.55	3263.90
6021	6021	3	48	4	1	34	61.25	1993.20
6022	6022	2	193	4	1	13	20.45	254.50
6023	6023	2	193	2	1	20	18.90	347.65
6024	6024	5	193	2	1	51	19.60	967.90
6025	6025	2	275	2	2	3	91.50	242.95
6026	6026	1	65	1	1	41	45.20	1841.90
6027	6027	1	193	2	1	13	19.45	232.10
6028	6028	5	322	1	1	35	25.45	809.25
6029	6029	1	165	1	2	12	80.85	866.45
6030	6030	2	182	4	1	4	94.90	360.55
6031	6031	2	12	1	2	43	49.05	2076.20
6032	6032	2	5	4	1	12	29.30	355.90
6033	6033	2	285	3	2	68	105.30	7299.65
6034	6034	2	276	3	2	25	88.95	2291.20
6035	6035	3	193	4	1	7	20.25	129.15
6036	6036	4	289	3	2	66	110.85	7491.75
6037	6037	3	192	3	1	53	110.50	5835.50
6038	6038	2	317	1	1	63	109.40	7031.45
6039	6039	6	321	1	2	70	114.20	7723.90
6040	6040	1	2	1	2	27	36.50	1032.00
6041	6041	1	129	4	2	1	70.75	70.75
6042	6042	1	193	4	1	5	19.95	109.60
6043	6043	3	193	4	1	37	19.60	727.80
6044	6044	2	11	4	2	3	40.15	130.75
6045	6045	2	258	3	1	12	76.60	893.00
6046	6046	3	193	2	1	38	19.60	763.10
6047	6047	2	138	2	1	9	85.30	781.40
6048	6048	2	227	3	1	13	65.85	902.25
6049	6049	2	261	3	2	29	94.45	2653.65
6050	6050	5	193	2	1	47	20.05	1016.70
6051	6051	1	304	1	1	61	99.40	5943.65
6052	6052	1	193	4	1	16	20.00	275.70
6053	6053	5	120	3	1	41	78.45	3126.45
6054	6054	6	322	3	1	43	25.10	1070.15
6055	6055	2	284	1	2	36	97.35	3457.90
6056	6056	2	66	3	1	6	55.00	340.40
6057	6057	4	254	2	1	58	71.10	4299.20
6058	6058	2	71	2	1	19	61.55	1093.20
6059	6059	2	65	1	1	11	45.90	521.90
6060	6060	4	53	1	1	39	40.30	1630.40
6061	6061	2	147	3	1	8	87.10	713.60
6062	6062	2	194	4	1	26	49.50	1265.65
6063	6063	2	145	2	1	53	73.80	4003.85
6064	6064	6	193	4	1	70	19.20	1401.40
6065	6065	2	4	4	2	1	45.30	45.30
6066	6066	5	322	4	1	59	25.00	1510.50
6067	6067	1	140	3	2	2	94.95	178.10
6068	6068	3	41	4	1	7	35.30	264.80
6069	6069	2	65	3	2	12	44.55	480.60
6070	6070	3	96	2	1	59	76.75	4541.90
6071	6071	6	209	1	1	61	81.00	4976.15
6072	6072	6	301	1	1	72	105.55	7542.25
6073	6073	1	193	4	1	13	18.80	251.25
6074	6074	3	322	4	1	64	24.90	1595.50
6075	6075	2	1	3	2	1	23.45	23.45
6076	6076	3	86	4	1	10	64.90	685.55
6077	6077	3	121	1	1	65	61.35	3874.10
6078	6078	5	321	4	1	62	113.95	6891.40
6079	6079	4	257	3	1	55	90.15	4916.95
6080	6080	1	210	3	1	25	54.10	1373.00
6081	6081	1	33	4	2	1	29.70	29.70
6082	6082	2	97	2	1	1	49.80	49.80
6083	6083	1	277	3	2	59	101.10	6039.90
6084	6084	6	322	1	1	64	24.40	1548.65
6085	6085	2	261	1	1	36	95.00	3440.25
6086	6086	2	194	4	2	3	50.65	151.30
6087	6087	6	235	4	1	61	69.90	4226.70
6088	6088	4	19	1	1	26	39.95	1023.75
6089	6089	2	66	3	2	1	55.40	55.40
6090	6090	2	276	3	2	1	90.60	90.60
6091	6091	6	188	2	1	68	103.25	7074.40
6092	6092	2	260	4	2	2	86.85	156.35
6093	6093	6	318	1	1	72	94.25	6849.75
6094	6094	6	14	3	1	71	47.05	3263.60
6095	6095	5	193	2	1	57	20.55	1252.85
6096	6096	2	193	4	1	4	19.65	67.55
6097	6097	2	129	3	1	1	70.20	70.20
6098	6098	5	255	2	1	72	81.00	5750.00
6099	6099	4	229	1	1	21	75.90	1549.75
6100	6100	5	322	1	1	71	24.70	1810.55
6101	6101	2	269	1	2	29	99.05	2952.85
6102	6102	5	305	2	1	69	110.25	7467.55
6103	6103	6	241	2	1	64	85.00	5484.40
6104	6104	1	193	2	1	16	19.75	294.90
6105	6105	3	322	3	1	4	23.90	97.50
6106	6106	4	313	2	2	52	111.25	5916.45
6107	6107	2	105	4	2	2	55.10	113.35
6108	6108	1	193	4	1	1	19.95	19.95
6109	6109	1	1	4	1	18	25.15	476.80
6110	6110	1	210	4	1	2	54.15	101.65
6111	6111	2	82	4	1	19	59.80	1130.85
6112	6112	1	259	1	1	40	83.85	3532.25
6113	6113	4	285	3	1	66	104.90	6891.45
6114	6114	1	258	4	1	21	75.30	1570.70
6115	6115	2	87	3	1	8	66.65	520.95
6116	6116	6	192	2	1	72	109.50	7854.90
6117	6117	4	224	1	1	48	73.85	3581.40
6118	6118	6	193	1	1	69	19.30	1447.90
6119	6119	6	321	3	1	72	118.20	8547.15
6120	6120	3	81	2	1	14	51.45	727.85
6121	6121	1	83	3	1	6	59.45	357.60
6122	6122	5	193	1	1	8	19.50	159.35
6123	6123	3	193	4	1	17	19.55	280.85
6124	6124	3	295	3	1	65	93.55	6069.25
6125	6125	4	109	4	1	57	59.30	3274.35
6126	6126	2	269	2	2	13	102.25	1359.00
6127	6127	2	140	2	2	19	95.90	1777.90
6128	6128	3	317	1	1	56	109.80	6109.65
6129	6129	2	130	3	1	14	78.10	1122.40
6130	6130	2	34	3	1	52	39.90	2020.90
6131	6131	6	125	2	1	58	64.90	3795.45
6132	6132	2	280	3	2	47	95.05	4504.55
6133	6133	2	16	2	1	67	53.40	3579.15
6134	6134	2	1	2	1	2	24.90	49.70
6135	6135	1	65	2	1	6	44.70	276.50
6136	6136	6	321	1	1	71	114.00	8175.90
6137	6137	5	193	1	1	46	20.25	890.35
6138	6138	1	101	2	2	5	53.85	259.80
6139	6139	1	306	1	1	67	83.85	5588.80
6140	6140	1	193	1	1	3	20.20	50.60
6141	6141	1	193	4	1	3	19.95	58.00
6142	6142	2	301	3	2	52	104.20	5568.35
6143	6143	2	194	3	2	42	50.25	2203.65
6144	6144	4	193	4	1	50	20.35	938.95
6145	6145	2	178	3	1	23	90.00	2024.10
6146	6146	5	63	2	1	67	54.20	3623.95
6147	6147	2	156	3	2	25	99.50	2369.05
6148	6148	3	180	4	1	39	99.10	3877.95
6149	6149	6	246	4	1	69	66.90	4577.90
6150	6150	3	1	4	1	1	25.85	25.85
6151	6151	1	132	3	1	32	91.05	2871.50
6152	6152	1	129	3	2	9	71.00	672.55
6153	6153	2	154	2	2	16	93.20	1573.70
6154	6154	6	193	1	1	60	20.95	1270.55
6155	6155	6	289	1	1	72	109.20	7711.45
6156	6156	1	193	4	2	5	19.35	126.05
6157	6157	2	163	2	1	26	85.80	2193.65
6158	6158	1	193	4	2	3	19.85	64.55
6159	6159	2	193	3	1	2	19.65	31.20
6160	6160	3	193	1	1	2	20.50	38.25
6161	6161	4	241	2	1	36	89.65	3348.10
6162	6162	1	161	4	1	7	74.35	533.60
6163	6163	6	20	2	1	60	49.45	2907.55
6164	6164	2	275	3	1	19	89.10	1620.80
6165	6165	5	239	2	1	45	75.15	3480.35
6166	6166	2	129	3	1	4	70.65	293.85
6167	6167	2	273	3	2	31	104.20	3243.45
6168	6168	1	170	3	1	47	90.05	4137.20
6169	6169	2	130	3	2	1	79.25	79.25
6170	6170	2	65	1	2	1	44.90	44.90
6171	6171	1	193	2	1	1	19.40	19.40
6172	6172	2	267	2	1	59	88.75	5348.65
6173	6173	2	129	3	2	10	70.10	659.65
6174	6174	1	291	2	1	35	91.00	3180.50
6175	6175	2	9	3	2	4	29.65	118.50
6176	6176	4	178	3	1	32	90.80	3023.85
6177	6177	2	274	3	2	43	77.85	3365.85
6178	6178	1	66	3	2	4	54.30	195.30
6179	6179	6	193	4	1	54	18.95	1031.10
6180	6180	2	261	1	2	11	95.15	997.65
6181	6181	6	293	1	1	66	102.40	6471.85
6182	6182	4	269	3	1	61	99.90	6241.35
6183	6183	5	257	2	1	72	88.70	6501.35
6184	6184	4	16	3	1	44	54.30	2317.10
6185	6185	2	202	1	1	41	55.70	2237.55
6186	6186	4	301	3	1	50	103.95	5231.30
6187	6187	4	305	2	2	47	110.85	5275.80
6188	6188	5	193	4	1	8	20.15	165.50
6189	6189	1	193	4	1	18	20.05	358.50
6190	6190	6	257	2	1	72	91.95	6614.90
6191	6191	1	130	3	2	1	80.50	80.50
6192	6192	1	202	3	1	42	55.65	2421.75
6193	6193	2	145	3	1	18	74.70	1294.60
6194	6194	4	285	2	1	13	104.15	1299.10
6195	6195	4	278	1	1	68	83.65	5733.40
6196	6196	2	258	1	2	4	72.20	305.55
6197	6197	6	317	2	1	69	110.05	7430.75
6198	6198	1	69	4	2	17	51.50	900.50
6199	6199	5	322	2	1	25	25.50	630.60
6200	6200	2	132	4	2	43	89.55	3856.75
6201	6201	5	193	2	1	59	19.50	1222.65
6202	6202	1	177	3	1	5	80.70	374.80
6203	6203	3	248	4	2	21	77.50	1625.00
6204	6204	4	320	2	1	69	105.10	7234.80
6205	6205	2	1	1	1	13	25.15	331.85
6206	6206	2	284	1	2	42	95.25	3959.35
6207	6207	2	279	2	1	52	95.65	5088.40
6208	6208	1	162	3	2	46	85.00	3969.40
6209	6209	6	255	1	1	61	80.80	4860.85
6210	6210	4	1	4	1	29	24.85	788.05
6211	6211	4	85	2	1	25	54.75	1266.35
6212	6212	2	135	3	2	5	85.75	470.95
6213	6213	3	12	3	1	15	50.75	688.20
6214	6214	5	193	4	1	19	20.15	387.70
6215	6215	5	193	4	1	44	20.05	845.25
6216	6216	2	277	3	2	6	98.25	560.60
6217	6217	5	254	2	1	58	71.60	4230.25
6218	6218	4	177	2	1	62	81.45	4983.05
6219	6219	4	32	1	1	70	58.40	4113.15
6220	6220	2	1	4	2	1	25.70	25.70
6221	6221	5	62	2	1	10	53.70	521.00
6222	6222	4	193	1	1	26	19.60	471.85
6223	6223	1	275	2	1	66	89.40	5976.90
6224	6224	2	129	3	2	7	69.00	506.90
6225	6225	3	278	1	1	51	84.20	4299.75
6226	6226	6	320	2	1	72	106.10	7548.60
6227	6227	5	322	4	1	65	25.75	1654.75
6228	6228	1	65	1	2	2	46.05	80.35
6229	6229	3	246	1	1	70	64.95	4551.50
6230	6230	6	225	2	1	72	85.45	6227.50
6231	6231	1	193	4	1	1	20.05	20.05
6232	6232	2	145	4	2	1	76.40	76.40
6233	6233	2	269	3	2	5	100.50	514.00
6234	6234	1	193	4	1	3	20.70	57.50
6235	6235	6	322	2	1	58	25.30	1474.35
6236	6236	1	34	4	2	22	40.05	880.20
6237	6237	2	277	1	1	33	100.60	3270.25
6238	6238	1	129	3	2	1	69.95	69.95
6239	6239	1	258	1	1	54	74.00	3919.15
6240	6240	6	277	3	1	72	99.40	7285.70
6241	6241	2	261	3	2	1	93.30	93.30
6242	6242	2	73	3	2	3	49.15	169.05
6243	6243	5	319	2	1	72	107.45	7658.30
6244	6244	6	253	2	1	72	83.60	5959.30
6245	6245	2	269	2	1	54	99.05	5295.70
6246	6246	4	217	3	1	59	80.10	4693.20
6247	6247	6	115	1	1	54	65.30	3512.90
6248	6248	6	268	3	1	60	89.55	5231.20
6249	6249	5	32	2	1	60	60.80	3603.45
6250	6250	1	258	3	1	3	74.50	217.45
6251	6251	5	293	1	1	69	99.15	6875.35
6252	6252	1	193	3	1	1	19.25	19.25
6253	6253	2	35	2	1	50	39.45	2021.35
6254	6254	2	4	2	1	56	44.85	2564.95
6255	6255	6	168	3	1	60	97.20	5611.75
6256	6256	4	305	4	1	69	110.55	7610.10
6257	6257	1	2	4	2	1	35.05	35.05
6258	6258	2	145	3	2	1	73.00	73.00
6259	6259	2	193	4	1	3	19.90	45.75
6260	6260	5	88	1	1	60	76.95	4543.95
6261	6261	5	13	4	1	13	35.40	450.40
6262	6262	5	193	1	1	62	20.45	1297.35
6263	6263	3	307	1	1	45	96.75	4442.75
6264	6264	3	16	3	1	25	54.20	1423.15
6265	6265	5	144	1	1	44	100.10	4378.35
6266	6266	2	65	4	1	2	45.25	74.20
6267	6267	2	282	2	2	33	83.85	2716.30
6268	6268	2	129	3	2	1	70.10	70.10
6269	6269	3	193	1	1	22	20.85	450.65
6270	6270	2	13	4	1	35	33.45	1175.85
6271	6271	5	193	4	1	29	20.20	558.80
6272	6272	4	298	3	1	27	85.90	2220.10
6273	6273	4	93	3	1	54	61.00	3283.05
6274	6274	2	129	3	2	2	70.65	142.35
6275	6275	4	260	3	1	57	86.90	4939.25
6276	6276	5	254	1	1	62	69.40	4237.50
6277	6277	3	193	2	1	15	20.35	335.95
6278	6278	1	193	4	2	2	20.35	33.20
6279	6279	6	273	1	1	70	104.30	7188.50
6280	6280	2	65	3	1	21	44.95	926.25
6281	6281	4	69	3	1	23	49.45	1119.35
6282	6282	3	193	4	1	6	20.60	116.60
6283	6283	5	193	2	1	4	19.55	68.80
6284	6284	2	172	2	2	3	99.00	287.40
6285	6285	2	261	3	1	23	93.50	2341.55
6286	6286	3	40	2	1	26	54.55	1362.85
6287	6287	1	193	4	1	8	20.05	163.60
6288	6288	2	259	3	2	26	83.95	2254.20
6289	6289	2	274	3	1	2	79.45	145.15
6290	6290	5	321	2	2	67	116.20	7752.30
6291	6291	6	261	1	2	71	93.70	6585.35
6292	6292	3	255	2	1	59	79.85	4786.10
6293	6293	3	269	3	1	39	100.00	3835.55
6294	6294	5	193	4	1	21	19.60	397.00
6295	6295	1	193	4	2	1	19.70	19.70
6296	6296	5	193	1	1	48	20.20	1027.25
6297	6297	4	58	2	1	31	50.40	1580.10
6298	6298	3	321	3	1	64	113.35	7222.75
6299	6299	2	274	1	1	46	80.00	3769.70
6300	6300	6	209	1	1	52	80.95	4233.95
6301	6301	6	322	4	1	67	24.90	1680.25
6302	6302	1	210	3	1	67	54.90	3725.50
6303	6303	1	258	3	2	5	75.55	413.65
6304	6304	5	289	3	1	71	109.25	7707.70
6305	6305	2	131	1	2	9	77.65	714.15
6306	6306	2	307	3	2	26	95.00	2497.20
6307	6307	4	321	1	1	71	116.30	8309.55
6308	6308	1	193	1	1	32	19.90	601.55
6309	6309	1	129	3	1	2	70.35	139.25
6310	6310	5	322	2	1	71	25.60	1888.25
6311	6311	4	42	3	1	60	44.45	2773.90
6312	6312	4	269	3	1	55	100.15	5409.75
6313	6313	4	184	2	2	54	105.40	5643.40
6314	6314	2	140	3	2	2	95.85	197.70
6315	6315	2	258	4	1	6	73.85	401.30
6316	6316	6	122	2	1	48	70.10	3238.40
6317	6317	5	322	4	1	63	25.25	1573.05
6318	6318	2	274	3	2	1	79.15	79.15
6319	6319	1	193	2	1	12	21.05	235.80
6320	6320	2	1	1	1	54	24.95	1364.75
6321	6321	4	79	3	1	30	64.50	1985.15
6322	6322	1	193	1	2	30	19.65	655.85
6323	6323	2	131	3	2	4	79.00	303.15
6324	6324	4	273	2	1	40	105.95	4335.20
6325	6325	2	133	3	1	9	75.85	647.50
6326	6326	1	167	3	2	17	91.85	1574.45
6327	6327	6	26	2	1	62	43.60	2748.70
6328	6328	4	151	1	1	28	91.25	2483.65
6329	6329	5	257	2	1	70	89.75	6367.20
6330	6330	6	160	1	1	46	104.40	4904.20
6331	6331	1	267	4	1	23	90.15	2044.95
6332	6332	3	45	3	1	47	40.30	1794.80
6333	6333	6	188	1	1	68	105.25	7173.15
6334	6334	4	273	3	2	60	106.00	6441.40
6335	6335	6	281	3	1	67	104.00	7039.05
6336	6336	2	72	3	1	14	69.65	921.40
6337	6337	2	258	3	1	57	74.30	4018.35
6338	6338	3	293	4	1	55	100.90	5448.60
6339	6339	2	193	4	1	1	20.25	20.25
6340	6340	2	69	4	2	1	49.90	49.90
6341	6341	2	272	2	1	23	96.90	2085.45
6342	6342	2	293	3	2	13	100.35	1358.85
6343	6343	2	285	3	1	47	104.10	5135.15
6344	6344	3	193	4	1	38	20.10	730.10
6345	6345	2	258	1	2	38	74.95	2869.85
6346	6346	2	210	2	1	2	56.55	118.25
6347	6347	2	69	2	2	1	49.25	49.25
6348	6348	2	129	1	1	15	68.60	1108.60
6349	6349	2	129	2	1	26	69.05	1815.65
6350	6350	5	193	2	1	35	19.70	730.40
6351	6351	2	193	4	1	3	20.05	75.45
6352	6352	1	281	3	2	50	103.70	5071.05
6353	6353	2	299	3	1	42	94.40	4014.60
6354	6354	2	101	2	1	10	54.95	568.85
6355	6355	3	182	1	1	61	93.70	5860.70
6356	6356	5	313	2	1	68	110.25	7279.35
6357	6357	4	172	3	1	10	98.90	1064.95
6358	6358	3	314	3	2	65	89.75	5769.60
6359	6359	6	112	1	1	72	80.45	5886.85
6360	6360	1	149	3	1	55	79.40	4238.45
6361	6361	2	193	4	2	1	20.30	20.30
6362	6362	1	78	1	1	7	62.80	418.30
6363	6363	2	258	4	1	2	74.90	136.05
6364	6364	2	161	3	1	9	74.85	708.20
6365	6365	6	322	2	1	27	25.85	788.55
6366	6366	2	269	3	2	7	101.95	700.85
6367	6367	6	94	4	1	64	68.30	4378.80
6368	6368	5	46	1	1	70	48.40	3442.80
6369	6369	2	261	3	2	2	94.00	181.70
6370	6370	6	184	3	1	67	105.05	7171.70
6371	6371	2	276	2	2	45	89.30	4016.85
6372	6372	5	322	2	1	24	25.15	553.00
6373	6373	5	193	2	1	4	19.50	96.85
6374	6374	2	140	1	1	44	92.95	4122.90
6375	6375	6	193	4	1	72	20.70	1482.30
6376	6376	2	145	2	2	1	74.30	74.30
6377	6377	5	193	1	1	66	19.35	1240.80
6378	6378	2	22	4	2	1	44.65	44.65
6379	6379	1	162	3	2	13	84.05	1095.30
6380	6380	2	274	1	2	10	80.70	788.80
6381	6381	2	285	3	1	65	104.35	6578.55
6382	6382	1	193	4	1	1	19.55	19.55
6383	6383	3	127	3	1	38	74.05	2802.30
6384	6384	5	45	4	1	23	40.10	857.75
6385	6385	3	193	4	1	10	20.10	184.40
6386	6386	2	277	3	2	4	101.70	364.55
6387	6387	6	241	2	1	72	83.55	6093.30
6388	6388	1	85	3	1	35	56.85	1861.10
6389	6389	1	193	4	2	1	20.40	20.40
6390	6390	5	193	2	1	58	19.55	1079.65
6391	6391	4	160	3	1	70	106.15	7475.10
6392	6392	3	221	2	1	38	78.95	2862.55
6393	6393	2	20	3	1	60	49.75	3069.45
6394	6394	2	308	2	1	26	92.40	2349.80
6395	6395	3	117	1	1	8	58.20	469.25
6396	6396	4	273	3	2	41	102.60	4213.35
6397	6397	2	276	2	1	36	91.95	3301.05
6398	6398	3	78	1	1	54	65.25	3529.95
6399	6399	6	285	1	2	71	106.00	7723.70
6400	6400	2	258	3	1	55	73.10	4144.90
6401	6401	5	242	1	1	72	59.75	4265.00
6402	6402	2	101	4	2	3	55.10	154.65
6403	6403	6	218	1	1	54	59.80	3246.45
6404	6404	6	321	1	1	72	116.60	8337.45
6405	6405	6	305	3	1	52	109.30	5731.40
6406	6406	4	293	1	1	60	101.40	6176.60
6407	6407	2	12	2	1	39	50.65	1905.40
6408	6408	3	67	4	1	15	56.15	931.90
6409	6409	6	273	1	2	69	106.50	7348.80
6410	6410	4	193	4	1	43	19.20	776.25
6411	6411	3	256	1	1	63	83.00	5243.05
6412	6412	1	129	3	1	2	70.10	141.65
6413	6413	6	192	1	1	72	108.30	7679.65
6414	6414	2	267	1	2	32	91.05	2954.50
6415	6415	5	322	2	1	40	25.25	1006.90
6416	6416	4	51	3	1	58	45.35	2540.10
6417	6417	5	39	3	1	67	43.90	3097.20
6418	6418	2	290	3	2	51	77.50	3807.35
6419	6419	4	209	4	1	31	79.30	2484.00
6420	6420	2	306	2	1	69	84.90	5785.65
6421	6421	4	262	3	1	32	79.25	2619.15
6422	6422	5	119	2	1	21	71.05	1524.85
6423	6423	3	105	3	1	52	53.75	2790.65
6424	6424	5	322	2	1	72	24.25	1784.50
6425	6425	6	28	3	2	72	54.20	3937.45
6426	6426	3	42	1	1	52	44.25	2276.10
6427	6427	3	69	1	1	41	50.05	2029.05
6428	6428	5	193	4	1	41	20.15	802.35
6429	6429	2	129	4	2	6	69.25	418.40
6430	6430	4	254	2	1	67	69.35	4653.25
6431	6431	1	193	4	1	16	19.35	275.90
6432	6432	5	193	4	1	17	19.15	343.45
6433	6433	1	121	4	1	35	61.00	2130.45
6434	6434	5	193	2	1	58	20.50	1191.40
6435	6435	2	73	3	2	1	50.50	50.50
6436	6436	5	31	4	1	52	50.20	2554.00
6437	6437	5	112	1	1	70	79.60	5589.45
6438	6438	6	322	1	1	19	24.90	467.70
6439	6439	2	258	3	2	1	74.40	74.40
6440	6440	2	176	3	1	35	106.90	3756.45
6441	6441	2	269	3	1	32	101.35	3334.90
6442	6442	2	101	2	1	17	55.35	920.50
6443	6443	3	81	2	1	67	50.55	3431.75
6444	6444	1	193	1	1	9	19.50	150.35
6445	6445	4	217	4	2	31	79.45	2587.70
6446	6446	1	292	3	1	4	90.65	367.95
6447	6447	4	310	1	1	58	89.85	5125.75
6448	6448	3	112	4	1	60	79.00	4801.10
6449	6449	4	273	3	2	58	104.65	6219.60
6450	6450	1	193	4	1	1	19.55	19.55
6451	6451	5	193	4	1	27	19.90	550.10
6452	6452	4	321	3	1	66	116.25	7862.25
6453	6453	2	292	1	1	15	87.75	1242.20
6454	6454	2	269	3	2	47	100.05	4871.05
6455	6455	2	290	2	1	41	81.30	3190.65
6456	6456	2	4	3	1	59	44.30	2666.75
6457	6457	5	129	2	1	50	70.35	3533.60
6458	6458	3	43	2	1	17	44.45	792.15
6459	6459	2	97	3	1	6	49.15	295.65
6460	6460	2	17	2	1	51	29.45	1459.35
6461	6461	1	152	3	2	44	100.55	4398.15
6462	6462	2	147	2	1	49	85.30	4297.95
6463	6463	1	148	3	2	2	95.65	167.30
6464	6464	4	231	4	1	59	69.10	4096.90
6465	6465	2	244	1	1	50	70.35	3454.60
6466	6466	5	193	4	1	59	20.60	1286.00
6467	6467	1	258	4	1	18	74.15	1387.00
6468	6468	1	258	3	1	10	75.05	786.30
6469	6469	3	65	3	1	14	44.60	641.25
6470	6470	5	193	1	1	35	21.45	705.45
6471	6471	4	65	4	1	8	43.45	345.50
6472	6472	3	193	1	1	18	20.05	345.90
6473	6473	3	308	1	1	60	94.15	5811.80
6474	6474	1	140	3	2	1	94.40	94.40
6475	6475	5	193	4	1	6	19.55	124.45
6476	6476	2	248	4	1	19	75.90	1375.60
6477	6477	3	246	1	1	53	64.15	3491.55
6478	6478	6	317	1	1	72	109.55	7920.70
6479	6479	6	289	2	1	60	110.80	6640.70
6480	6480	2	67	2	2	1	55.00	55.00
6481	6481	1	77	4	1	13	53.45	718.10
6482	6482	1	129	2	1	5	69.95	320.40
6483	6483	2	269	3	2	1	101.45	101.45
6484	6484	1	140	3	1	13	97.00	1334.45
6485	6485	4	257	1	1	37	90.60	3358.65
6486	6486	2	161	4	1	64	73.55	4764.00
6487	6487	1	208	1	2	5	67.95	350.30
6488	6488	6	279	1	1	61	94.35	5703.00
6489	6489	2	129	3	2	1	69.50	69.50
6490	6490	2	193	4	2	1	18.85	18.85
6491	6491	3	193	4	1	26	19.40	525.55
6492	6492	2	129	3	2	1	69.20	69.20
6493	6493	5	193	4	1	24	19.75	483.15
6494	6494	3	16	3	1	17	54.60	934.80
6495	6495	2	9	4	1	26	29.80	786.50
6496	6496	2	129	3	2	1	69.65	69.65
6497	6497	1	293	3	2	40	101.85	4086.30
6498	6498	2	285	3	1	52	103.05	5364.80
6499	6499	2	153	3	2	1	82.30	82.30
6500	6500	1	193	4	1	1	20.30	20.30
6501	6501	5	37	4	1	21	35.10	770.40
6502	6502	4	285	1	1	67	105.70	6816.95
6503	6503	1	101	1	1	44	56.25	2419.55
6504	6504	3	32	3	1	70	60.35	4138.70
6505	6505	1	131	3	2	3	79.25	267.60
6506	6506	6	121	1	1	56	59.80	3457.45
6507	6507	2	259	3	2	13	84.60	1115.20
6508	6508	2	307	1	2	58	93.40	5435.60
6509	6509	2	261	3	2	42	94.20	4186.30
6510	6510	1	1	3	2	1	25.05	25.05
6511	6511	5	303	4	1	46	99.65	4630.20
6512	6512	6	97	1	1	63	50.65	3221.25
6513	6513	2	93	3	1	11	60.90	688.50
6514	6514	2	206	1	1	15	59.65	867.10
6515	6515	6	64	3	1	72	64.70	4746.05
6516	6516	2	1	2	2	29	25.10	712.85
6517	6517	1	73	3	2	1	48.95	48.95
6518	6518	1	67	3	1	6	54.85	355.10
6519	6519	1	65	3	2	1	45.30	45.30
6520	6520	4	275	3	1	63	91.35	5764.70
6521	6521	2	138	3	2	2	85.85	167.30
6522	6522	5	322	4	1	18	25.10	428.45
6523	6523	1	37	1	1	43	34.00	1505.35
6524	6524	3	61	4	1	15	45.90	693.45
6525	6525	1	261	3	2	10	95.20	930.40
6526	6526	5	193	4	1	55	20.50	1177.95
6527	6527	4	265	1	2	49	100.60	5069.65
6528	6528	2	89	4	2	6	55.30	324.25
6529	6529	5	193	2	1	70	20.35	1458.10
6530	6530	2	258	4	2	2	74.85	156.40
6531	6531	3	37	1	1	63	36.10	2298.90
6532	6532	2	86	1	1	25	65.80	1679.65
6533	6533	3	193	1	1	18	20.35	369.60
6534	6534	2	281	3	1	28	105.80	2998.00
6535	6535	4	182	4	1	53	96.75	5206.55
6536	6536	4	156	1	2	35	102.35	3626.10
6537	6537	1	1	4	1	1	24.40	24.40
6538	6538	3	321	2	2	70	115.65	7968.85
6539	6539	2	141	3	2	2	79.85	152.45
6540	6540	2	88	3	1	26	73.05	1959.50
6541	6541	3	114	3	1	34	64.35	2053.05
6542	6542	5	193	4	1	19	20.50	398.55
6543	6543	2	258	4	2	15	76.00	1130.85
6544	6544	3	105	2	1	62	54.75	3425.35
6545	6545	2	285	1	2	42	104.75	4323.45
6546	6546	2	116	3	2	9	74.65	703.55
6547	6547	2	97	3	1	24	51.15	1275.70
6548	6548	6	57	3	1	68	41.95	2965.75
6549	6549	1	77	4	1	31	54.35	1647.00
6550	6550	2	66	3	2	1	56.25	56.25
6551	6551	2	273	3	2	21	106.10	2249.95
6552	6552	4	148	3	1	63	96.00	6109.75
6553	6553	2	130	1	2	2	79.75	159.40
6554	6554	6	32	1	1	61	61.45	3751.15
6555	6555	1	129	3	2	1	68.65	68.65
6556	6556	3	193	4	1	18	19.65	411.25
6557	6557	3	193	2	1	6	19.00	105.50
6558	6558	2	277	3	1	33	100.00	3320.60
6559	6559	1	193	1	2	16	20.25	327.45
6560	6560	2	144	3	1	56	98.70	5669.50
6561	6561	3	193	4	1	23	19.80	465.45
6562	6562	2	137	3	1	9	73.80	704.30
6563	6563	2	277	3	2	14	100.20	1369.80
6564	6564	2	258	1	2	15	74.90	1107.25
6565	6565	1	193	2	1	5	20.05	95.55
6566	6566	2	309	3	1	61	106.20	6375.20
6567	6567	6	321	2	1	70	116.55	8152.30
6568	6568	2	293	3	1	15	99.70	1566.75
6569	6569	5	193	4	1	8	19.70	130.25
6570	6570	5	193	4	1	8	19.50	162.15
6571	6571	2	33	4	1	4	29.15	110.05
6572	6572	3	113	4	1	34	55.00	1885.15
6573	6573	6	257	2	1	68	90.80	6302.85
6574	6574	3	30	1	1	45	51.00	2264.50
6575	6575	2	268	3	1	9	90.10	816.80
6576	6576	2	230	4	1	22	59.05	1253.50
6577	6577	1	193	4	1	2	20.30	41.20
6578	6578	5	224	1	1	70	72.95	5265.55
6579	6579	3	239	2	1	10	73.55	693.30
6580	6580	5	241	2	1	72	84.30	5997.10
6581	6581	3	92	2	1	49	78.00	3824.20
6582	6582	3	216	4	1	54	72.10	3886.05
6583	6583	6	317	2	1	71	106.75	7283.25
6584	6584	4	193	4	1	22	19.25	412.55
6585	6585	5	193	2	1	50	20.55	1070.25
6586	6586	3	193	4	1	43	20.00	817.95
6587	6587	6	322	2	1	45	24.65	1171.30
6588	6588	2	309	1	1	64	103.50	6548.65
6589	6589	5	322	4	1	23	23.85	625.65
6590	6590	5	322	2	1	68	25.80	1911.50
6591	6591	2	129	3	2	1	70.85	70.85
6592	6592	2	129	2	2	2	69.80	134.70
6594	6594	2	16	1	2	55	54.55	2978.30
6595	6595	2	193	3	1	14	20.05	299.30
6596	6596	6	112	3	1	71	82.55	5832.65
6597	6597	3	256	3	1	64	81.25	5567.55
6598	6598	2	72	2	2	7	70.75	450.80
6599	6599	6	127	2	1	57	74.30	4166.35
6600	6600	1	284	3	2	13	94.10	1215.60
6601	6601	1	33	2	2	3	29.70	91.70
6602	6602	5	289	2	1	72	109.70	7898.45
6603	6603	2	284	2	1	40	96.35	3915.40
6604	6604	2	200	2	1	14	66.60	979.50
6605	6605	2	65	3	1	2	44.50	90.05
6606	6606	3	289	2	2	66	110.90	7432.05
6607	6607	2	273	3	2	38	105.00	4026.40
6608	6608	2	1	3	2	1	25.30	25.30
6609	6609	4	85	2	2	22	55.15	1193.05
6610	6610	2	193	4	2	1	20.10	20.10
6611	6611	2	131	4	1	5	80.10	398.55
6612	6612	3	232	1	1	29	69.05	1958.45
6613	6613	2	129	4	2	1	69.90	69.90
6614	6614	1	193	4	1	3	20.40	63.15
6615	6615	5	193	2	1	71	19.70	1301.10
6616	6616	2	81	3	1	9	50.10	484.05
6617	6617	2	277	3	2	43	101.40	4528.00
6618	6618	4	253	2	1	48	83.45	3887.85
6619	6619	2	306	2	1	26	86.65	2208.75
6620	6620	1	193	1	1	9	20.15	238.15
6621	6621	2	130	3	2	1	80.80	80.80
6622	6622	5	193	2	1	46	19.40	958.15
6623	6623	1	195	1	2	2	62.05	118.30
6624	6624	2	258	3	2	1	76.45	76.45
6625	6625	6	48	1	1	64	60.05	3845.45
6626	6626	2	276	3	2	12	91.30	1094.50
6627	6627	2	140	3	2	6	95.75	573.75
6628	6628	3	193	4	1	59	20.35	1267.00
6629	6629	4	148	4	1	7	94.05	633.45
6630	6630	6	253	2	1	72	84.10	6129.65
6631	6631	2	130	3	1	16	78.75	1218.25
6632	6632	1	202	2	1	25	55.55	1405.30
6633	6633	1	246	3	2	34	62.65	2274.90
6634	6634	2	258	3	2	1	74.50	74.50
6635	6635	2	285	2	2	10	102.10	1068.85
6636	6636	3	193	4	1	24	20.10	533.90
6637	6637	3	244	3	1	10	70.30	676.15
6638	6638	4	113	2	1	69	53.65	3804.40
6639	6639	5	193	4	1	57	20.75	1118.80
6640	6640	4	160	1	1	50	103.40	5236.40
6641	6641	3	47	4	1	28	50.80	1386.80
6642	6642	2	97	3	2	16	50.15	762.25
6643	6643	2	120	4	1	25	79.00	1902.00
6644	6644	2	145	1	1	3	74.60	239.05
6645	6645	4	261	1	1	61	96.50	5673.70
6646	6646	1	193	4	1	2	20.10	39.80
6647	6647	3	193	4	1	51	19.40	997.75
6648	6648	5	108	2	1	71	77.55	5574.35
6649	6649	1	193	4	1	20	20.05	406.05
6650	6650	1	193	2	1	6	19.85	138.85
6651	6651	1	193	4	1	6	20.20	123.65
6652	6652	1	246	4	1	29	67.45	1801.10
6653	6653	6	193	2	1	36	18.55	689.00
6654	6654	2	9	4	1	28	29.75	790.70
6655	6655	2	260	3	2	7	86.50	582.50
6656	6656	5	322	4	1	63	24.20	1618.20
6657	6657	5	322	4	1	48	23.55	1173.35
6658	6658	3	193	1	1	49	20.45	900.90
6659	6659	2	274	3	2	27	81.45	2122.05
6660	6660	5	257	2	1	72	92.30	6719.90
6661	6661	2	129	3	2	1	69.15	69.15
6662	6662	5	24	2	1	72	53.65	3784.00
6663	6663	3	53	2	1	47	39.65	1798.65
6664	6664	2	67	3	1	1	54.65	54.65
6665	6665	4	285	1	1	36	104.80	3886.45
6666	6666	1	17	2	1	43	29.30	1224.05
6667	6667	1	225	3	1	27	83.85	2310.20
6668	6668	2	130	3	2	9	79.55	723.40
6669	6669	2	273	3	1	38	103.65	3988.50
6670	6670	2	293	3	1	35	99.05	3554.60
6671	6671	5	224	4	1	0	73.35	\N
6672	6672	6	152	4	1	59	100.05	6034.85
6673	6673	5	193	2	1	27	20.35	531.60
6674	6674	1	65	3	1	2	43.95	85.10
6675	6675	1	322	4	1	7	23.50	173.00
6676	6676	4	215	4	1	36	70.70	2511.95
6677	6677	2	308	1	1	41	94.30	3893.60
6678	6678	1	17	3	1	13	29.15	357.15
6679	6679	5	193	2	1	19	20.85	467.50
6680	6680	5	53	1	1	60	37.70	2288.70
6681	6681	6	159	4	2	48	95.50	4627.85
6682	6682	1	268	3	2	3	91.05	289.10
6683	6683	6	280	4	1	69	92.45	6460.55
6684	6684	3	14	3	1	43	44.15	1931.30
6685	6685	4	37	4	1	11	36.05	402.60
6686	6686	2	73	2	1	45	50.25	2221.55
6687	6687	6	289	2	1	72	109.75	7758.90
6688	6688	1	266	3	2	2	79.20	172.85
6689	6689	5	193	1	1	12	20.30	224.50
6690	6690	4	289	2	1	67	112.35	7388.45
6691	6691	5	272	4	1	37	94.30	3460.95
6692	6692	3	53	1	1	39	41.15	1700.90
6693	6693	2	239	1	1	41	74.65	3090.65
6694	6694	2	12	3	1	25	48.25	1293.80
6695	6695	6	247	2	1	8	76.15	645.80
6696	6696	5	254	4	1	71	71.10	5224.95
6697	6697	1	283	3	1	5	96.55	500.10
6698	6698	4	237	2	1	30	79.30	2427.10
6699	6699	4	150	2	1	40	89.60	3488.15
6700	6700	6	193	4	1	54	20.50	1035.70
6701	6701	6	285	1	1	72	106.30	7565.35
6702	6702	3	156	1	1	28	100.35	2799.00
6703	6703	2	134	3	1	18	85.60	1601.50
6704	6704	2	4	3	2	2	45.25	85.50
6705	6705	4	285	3	1	59	106.15	6256.20
6706	6706	2	69	3	1	22	51.10	1232.90
6707	6707	1	193	4	1	1	19.90	19.90
6708	6708	6	322	2	1	72	25.70	1937.40
6709	6709	2	258	3	2	14	74.30	1096.25
6710	6710	3	265	3	1	50	99.40	5059.75
6711	6711	3	111	1	1	48	69.70	3023.65
6712	6712	2	277	3	1	49	98.35	4889.20
6713	6713	1	139	3	1	28	85.45	2289.90
6714	6714	2	283	3	1	68	95.90	6503.20
6715	6715	1	265	3	1	13	100.75	1313.25
6716	6716	2	268	3	1	11	89.20	990.30
6717	6717	2	258	2	2	3	74.10	228.00
6718	6718	1	269	3	2	57	100.60	5746.15
6719	6719	1	258	4	2	3	75.00	209.10
6720	6720	5	322	2	1	72	25.75	1864.20
6721	6721	6	225	3	1	70	84.10	5979.70
6722	6722	5	217	1	1	49	79.30	3902.45
6723	6723	4	301	2	1	67	107.05	7142.50
6724	6724	5	193	1	1	46	20.05	902.00
6725	6725	6	119	2	2	64	70.20	4481.00
6726	6726	1	193	1	1	37	19.50	805.20
6727	6727	1	129	3	2	2	70.75	154.85
6728	6728	1	4	3	1	13	45.30	528.45
6729	6729	5	321	3	1	72	115.15	8349.70
6730	6730	6	80	1	1	68	72.95	4953.25
6731	6731	3	193	4	1	15	19.65	332.65
6732	6732	6	193	1	1	24	19.55	470.20
6733	6733	2	263	3	1	24	89.55	2259.35
6734	6734	1	97	4	1	27	50.35	1411.35
6735	6735	1	69	1	2	12	50.25	593.75
6736	6736	5	128	2	1	71	87.25	6328.70
6737	6737	6	193	4	1	67	20.80	1411.90
6738	6738	6	289	1	1	63	109.25	6841.40
6739	6739	1	193	4	1	1	20.35	20.35
6740	6740	2	66	3	1	4	55.90	238.50
6741	6741	2	177	2	2	40	79.20	3233.85
6742	6742	2	140	3	2	12	96.00	1062.10
6743	6743	5	124	3	1	52	79.20	4016.30
6744	6744	2	322	3	1	10	24.00	226.55
6745	6745	3	316	1	1	68	101.35	7110.75
6746	6746	2	265	3	2	54	100.10	5440.90
6747	6747	1	85	4	2	4	56.50	235.10
6748	6748	3	41	4	1	52	35.45	1958.95
6749	6749	2	138	3	2	1	85.00	85.00
6750	6750	3	256	1	1	70	79.40	5528.90
6751	6751	4	41	2	1	43	35.20	1463.70
6752	6752	5	193	4	1	52	19.65	1025.05
6753	6753	5	46	4	1	12	49.85	552.10
6754	6754	3	243	1	1	56	68.75	3815.40
6755	6755	6	246	1	1	0	61.90	\N
6756	6756	1	266	3	1	42	79.90	3313.40
6757	6757	2	132	1	1	22	89.75	1938.90
6758	6758	3	60	3	2	51	59.30	3014.65
6759	6759	2	193	2	1	27	19.40	460.25
6760	6760	4	299	1	1	51	93.65	4839.15
6761	6761	2	97	3	2	4	49.40	184.40
6762	6762	2	193	4	1	1	19.90	19.90
6763	6763	1	67	4	2	35	55.00	2010.55
6764	6764	4	223	1	1	71	72.90	5139.65
6765	6765	2	129	3	2	1	69.20	69.20
6766	6766	6	322	1	1	69	25.60	1673.40
6767	6767	3	193	4	1	14	19.75	309.35
6768	6768	1	101	3	1	57	55.70	3171.60
6769	6769	5	321	2	1	72	117.50	8670.10
6770	6770	5	193	2	1	48	19.85	916.00
6771	6771	2	131	4	1	4	78.90	299.75
6772	6772	2	193	3	1	31	20.65	702.05
6773	6773	4	78	4	2	38	62.30	2354.80
6774	6774	2	261	3	2	37	92.50	3473.40
6775	6775	1	193	4	1	1	19.65	19.65
6776	6776	6	221	1	1	57	79.75	4438.20
6777	6777	6	112	2	1	62	79.95	4819.75
6778	6778	2	5	3	1	3	29.90	92.25
6779	6779	6	193	4	1	72	19.75	1567.00
6780	6780	2	61	4	1	29	45.00	1242.45
6781	6781	1	65	1	1	13	44.80	559.20
6782	6782	1	129	3	2	3	69.65	220.10
6783	6783	1	81	3	1	11	51.10	531.15
6784	6784	5	63	4	1	21	53.15	1183.20
6785	6785	1	322	1	1	19	24.70	465.85
6786	6786	6	305	2	2	61	111.60	6876.05
6787	6787	1	97	2	2	11	48.55	501.00
6788	6788	2	289	3	1	35	109.95	3782.40
6789	6789	1	193	4	1	25	20.80	460.20
6790	6790	2	193	4	2	1	20.20	20.20
6791	6791	6	322	1	1	67	25.60	1790.35
6792	6792	2	11	3	2	19	39.65	733.35
6793	6793	3	322	3	2	56	24.90	1334.00
6794	6794	6	317	2	1	72	108.40	7767.25
6795	6795	5	193	4	1	43	19.55	876.15
6796	6796	2	306	3	1	55	85.10	4600.95
6797	6797	1	226	4	2	2	56.70	113.55
6798	6798	2	129	4	1	27	69.05	1793.25
6799	6799	2	129	4	1	13	70.15	886.70
6800	6800	6	317	4	1	70	111.15	7737.55
6801	6801	3	184	4	2	14	105.95	1348.90
6802	6802	4	263	1	1	19	89.35	1686.85
6803	6803	2	292	1	1	20	89.10	1879.25
6804	6804	4	302	2	1	43	91.25	4013.80
6805	6805	2	170	4	1	5	90.35	434.50
6806	6806	4	281	1	1	70	105.55	7195.35
6807	6807	5	193	4	1	40	19.10	780.10
6808	6808	6	193	2	1	6	20.40	107.60
6809	6809	6	172	3	1	39	100.45	3801.70
6810	6810	1	258	3	2	4	74.95	308.70
6811	6811	2	5	3	2	15	29.70	438.25
6812	6812	2	12	3	2	1	50.35	50.35
6813	6813	2	181	1	1	45	85.70	3778.10
6814	6814	5	46	3	2	64	47.85	3147.50
6815	6815	1	283	2	1	57	94.00	5438.95
6816	6816	5	254	1	1	72	69.85	5102.35
6817	6817	2	129	3	2	1	70.30	70.30
6818	6818	5	322	2	1	72	25.85	1872.20
6819	6819	5	118	4	1	3	71.10	213.35
6820	6820	2	293	3	2	55	98.80	5617.75
6821	6821	1	272	3	1	59	93.35	5386.50
6822	6822	2	265	1	2	18	99.85	1776.95
6823	6823	2	130	2	2	32	80.30	2483.05
6824	6824	2	97	1	1	4	50.55	235.65
6825	6825	2	274	2	2	66	80.45	5224.35
6826	6826	2	266	3	1	27	81.30	2272.80
6827	6827	2	193	2	1	4	20.70	83.75
6828	6828	2	120	2	1	60	79.05	4663.40
6829	6829	5	193	4	1	8	19.05	201.70
6830	6830	5	193	2	1	8	19.60	125.00
6831	6831	6	193	4	1	35	20.20	684.40
6832	6832	2	259	3	2	7	86.80	620.35
6833	6833	5	193	4	1	53	20.90	1146.05
6834	6834	2	281	2	1	18	103.60	1806.35
6835	6835	6	18	4	1	15	38.80	603.00
6836	6836	4	276	1	1	67	88.40	5798.30
6837	6837	2	146	3	2	6	84.20	519.15
6838	6838	2	131	3	1	6	79.70	497.60
6839	6839	2	265	4	2	13	99.00	1301.70
6840	6840	2	269	3	2	11	100.75	1129.75
6841	6841	2	193	4	1	1	19.30	19.30
6842	6842	2	101	4	1	5	55.75	266.95
6843	6843	4	193	4	1	13	19.95	257.00
6844	6844	1	314	1	2	9	91.75	865.80
6845	6845	1	151	4	1	29	89.65	2623.65
6846	6846	2	65	4	1	1	45.85	45.85
6847	6847	2	266	4	2	1	79.55	79.55
6848	6848	1	67	4	1	18	55.95	1082.80
6849	6849	1	76	2	1	2	69.00	147.80
6850	6850	2	278	1	1	30	83.55	2570.20
6851	6851	5	246	1	1	66	65.70	4378.90
6852	6852	6	272	1	1	38	94.90	3616.25
6853	6853	2	93	4	1	44	61.90	2924.05
6854	6854	1	289	3	2	54	111.10	6014.85
6855	6855	1	193	4	1	2	20.00	32.70
6856	6856	4	118	4	1	42	67.70	2882.25
6857	6857	5	322	2	1	58	25.15	1509.90
6858	6858	2	148	3	1	58	92.85	5305.05
6859	6859	2	267	3	2	25	89.10	2368.40
6860	6860	5	321	4	1	71	111.30	7985.90
6861	6861	2	285	1	2	37	101.90	3545.35
6862	6862	2	264	3	2	14	91.65	1301.00
6863	6863	2	267	3	2	4	88.85	372.45
6864	6864	4	230	1	1	48	60.60	2985.25
6865	6865	1	1	3	2	3	25.30	77.75
6866	6866	5	102	4	1	8	65.50	564.35
6867	6867	2	261	3	2	1	95.45	95.45
6868	6868	5	193	1	1	67	19.95	1311.75
6869	6869	2	132	3	2	13	91.10	1135.70
6870	6870	4	85	2	2	45	54.15	2319.80
6871	6871	2	258	1	1	49	74.60	3720.35
6872	6872	1	284	1	1	52	94.60	5025.80
6873	6873	4	169	2	1	63	81.15	5224.50
6874	6874	6	257	1	1	68	89.05	6185.80
6875	6875	2	69	4	1	31	49.20	1498.55
6876	6876	5	193	2	1	64	19.45	1208.60
6877	6877	4	176	3	1	62	104.30	6613.65
6878	6878	1	129	1	2	1	69.70	69.70
6879	6879	2	132	3	2	6	89.50	573.30
6880	6880	2	135	3	1	21	86.05	1818.90
6881	6881	5	322	1	1	72	25.20	1787.35
6882	6882	2	49	3	1	32	35.15	1051.05
6883	6883	4	312	2	1	71	99.65	7181.25
6884	6884	2	188	1	1	34	105.35	3688.60
6885	6885	2	2	3	2	3	35.15	99.75
6886	6886	2	258	2	2	12	73.75	871.40
6887	6887	1	269	3	2	8	101.35	780.50
6888	6888	5	322	1	1	35	24.30	821.60
6889	6889	2	131	3	1	3	80.70	239.45
6890	6890	2	143	4	1	3	89.85	244.45
6891	6891	4	74	3	1	53	61.10	3357.90
6892	6892	2	33	3	1	4	29.05	129.60
6893	6893	4	172	1	1	48	99.70	4977.20
6894	6894	1	113	2	2	6	55.90	365.35
6895	6895	2	285	3	2	3	105.90	334.65
6896	6896	5	14	2	1	54	46.00	2424.05
6897	6897	1	65	4	2	1	43.95	43.95
6898	6898	2	96	1	1	62	80.40	4981.15
6899	6899	4	156	4	1	22	100.05	2090.25
6900	6900	2	65	1	2	1	45.10	45.10
6901	6901	4	140	1	1	51	94.00	4905.75
6902	6902	4	220	2	1	30	68.95	2038.70
6903	6903	4	254	2	1	56	68.45	4014.00
6904	6904	4	216	3	1	35	69.00	2441.70
6905	6905	2	23	3	1	64	43.85	2751.00
6906	6906	2	4	3	1	30	44.50	1307.80
6907	6907	6	193	4	1	25	18.70	383.65
6908	6908	1	129	1	2	41	70.25	2868.05
6909	6909	1	67	3	2	9	55.35	449.75
6910	6910	2	113	4	1	1	53.55	53.55
6911	6911	6	321	3	1	70	114.60	7882.50
6912	6912	6	193	1	1	57	20.10	1087.70
6913	6913	2	260	3	1	9	85.50	791.70
6914	6914	4	289	1	1	69	108.75	7493.05
6915	6915	2	285	3	2	43	103.00	4414.30
6916	6916	6	269	3	1	72	97.85	6841.30
6917	6917	5	193	1	1	44	19.55	819.95
6918	6918	6	306	1	1	72	84.05	6052.25
6919	6919	4	176	3	2	33	103.75	3361.05
6920	6920	1	267	2	1	54	89.40	4869.50
6921	6921	5	193	2	1	27	19.70	509.30
6922	6922	2	274	1	1	54	79.85	4308.25
6923	6923	1	145	2	1	3	74.45	221.10
6924	6924	3	251	1	1	53	74.10	3833.95
6925	6925	2	129	3	2	1	69.35	69.35
6926	6926	3	193	4	1	15	18.80	294.95
6927	6927	2	145	3	2	56	73.85	4092.85
6928	6928	1	246	2	1	5	64.40	316.90
6929	6929	4	89	2	1	48	55.80	2651.20
6930	6930	1	193	2	1	25	20.05	471.70
6931	6931	2	258	2	2	3	75.15	216.75
6932	6932	3	180	1	1	58	99.15	5720.95
6933	6933	2	66	1	1	10	56.75	503.25
6934	6934	2	129	3	2	1	69.60	69.60
6935	6935	6	281	2	1	71	104.15	7365.30
6936	6936	6	289	2	1	65	110.80	7245.90
6937	6937	2	274	3	2	5	80.15	385.00
6938	6938	2	13	4	1	28	35.75	961.40
6939	6939	6	207	1	1	67	69.90	4615.90
6940	6940	4	166	3	1	35	89.20	3251.30
6941	6941	5	62	2	1	72	55.65	3880.05
6942	6942	4	54	1	1	61	50.70	3088.75
6943	6943	6	193	2	1	68	20.00	1396.00
6944	6944	1	33	1	2	1	30.50	30.50
6945	6945	2	193	4	1	3	19.10	53.05
6946	6946	5	277	1	2	70	98.30	6859.50
6947	6947	1	26	2	1	48	45.55	2108.35
6948	6948	4	277	2	1	68	101.05	6770.50
6949	6949	4	176	3	1	47	103.70	4730.60
6950	6950	4	13	4	1	32	36.25	1151.05
6951	6951	2	97	4	1	5	49.40	232.55
6952	6952	6	193	2	1	49	19.90	1022.60
6953	6953	2	285	1	2	48	107.40	5121.30
6954	6954	2	259	3	2	13	82.00	1127.20
6955	6955	2	193	4	1	15	19.80	309.40
6956	6956	2	65	3	1	12	45.05	523.10
6957	6957	6	246	1	1	67	64.55	4250.10
6958	6958	1	135	3	1	9	86.25	770.50
6959	6959	6	193	1	1	13	19.75	246.70
6960	6960	4	132	4	1	38	89.10	3342.00
6961	6961	2	284	3	1	42	95.55	3930.60
6962	6962	2	258	2	2	24	75.40	1747.85
6963	6963	2	172	3	2	27	101.25	2754.45
6964	6964	2	285	2	1	9	102.60	897.75
6965	6965	4	24	2	1	49	56.30	2780.60
6966	6966	2	318	2	1	61	94.20	5895.45
6967	6967	4	51	1	1	50	43.05	2208.05
6968	6968	2	276	3	2	25	89.50	2196.15
6969	6969	2	258	1	2	22	74.40	1692.60
6970	6970	1	193	4	2	1	20.50	20.50
6971	6971	2	258	3	2	4	74.35	265.35
6972	6972	1	265	1	2	18	99.75	1836.25
6973	6973	4	289	3	2	56	111.95	6418.90
6974	6974	4	159	3	1	53	94.00	4871.45
6975	6975	4	269	3	1	51	98.85	4947.55
6976	6976	5	250	3	1	24	64.35	1558.65
6977	6977	6	123	2	1	62	72.00	4284.20
6978	6978	2	81	4	1	24	49.70	1218.25
6979	6979	5	256	3	1	70	80.70	5617.95
6980	6980	1	1	4	1	1	24.20	24.20
6981	6981	2	19	4	2	16	39.00	679.85
6982	6982	2	87	3	1	8	65.45	554.45
6983	6983	6	126	3	1	72	74.35	5237.40
6984	6984	1	157	1	1	23	83.20	2032.30
6985	6985	1	1	2	1	31	25.00	789.20
6986	6986	4	45	3	1	37	40.20	1525.35
6987	6987	2	280	2	2	30	94.10	2804.45
6988	6988	4	317	3	1	35	108.35	3726.15
6989	6989	2	216	2	1	23	69.50	1652.10
6990	6990	3	229	1	1	20	76.00	1588.75
6991	6991	2	164	3	1	36	93.60	3366.05
6992	6992	1	261	1	2	8	95.65	778.10
6993	6993	3	277	1	1	71	100.55	7113.75
6994	6994	2	276	3	2	50	88.05	4367.35
6995	6995	4	322	1	1	43	24.45	993.15
6996	6996	5	257	4	1	57	89.55	5012.35
6997	6997	4	86	1	2	41	66.50	2728.60
6998	6998	2	145	3	1	27	76.10	2093.40
6999	6999	2	130	3	1	13	80.50	1011.80
7000	7000	2	49	4	2	3	35.45	106.85
7001	7001	3	193	3	1	67	20.55	1343.40
7002	7002	2	81	4	2	3	49.90	130.10
7003	7003	6	281	1	1	64	105.40	6794.75
7004	7004	1	13	3	1	26	35.75	1022.50
7005	7005	2	283	2	1	38	95.10	3691.20
7006	7006	3	193	2	1	23	19.30	486.20
7007	7007	2	285	2	2	40	104.50	4036.85
7008	7008	6	64	1	1	72	63.10	4685.55
7009	7009	2	258	2	2	3	75.05	256.25
7010	7010	2	266	3	2	23	81.00	1917.10
7011	7011	2	258	3	2	1	74.45	74.45
7012	7012	2	117	4	2	4	60.40	272.15
7013	7013	6	249	3	1	62	84.95	5150.55
7014	7014	2	284	1	1	40	93.40	3756.40
7015	7015	2	276	3	1	41	89.20	3645.75
7016	7016	2	139	2	1	34	85.20	2874.45
7017	7017	1	81	3	1	1	49.95	49.95
7018	7018	5	193	1	1	51	20.65	1020.75
7019	7019	2	129	4	2	1	70.65	70.65
7020	7020	5	193	4	1	39	20.15	826.00
7021	7021	2	193	3	1	12	19.20	239.00
7022	7022	4	71	3	2	12	59.80	727.80
7023	7023	4	285	3	1	72	104.95	7544.30
7024	7024	2	285	3	1	63	103.50	6479.40
7025	7025	2	298	2	1	44	84.80	3626.35
7026	7026	2	271	1	1	18	95.05	1679.40
7027	7027	2	65	1	2	9	44.20	403.35
7028	7028	1	88	4	1	13	73.35	931.55
7029	7029	5	87	1	1	68	64.10	4326.25
7030	7030	2	4	3	1	6	44.40	263.05
7031	7031	2	193	4	1	2	20.05	39.25
7032	7032	3	242	2	1	55	60.00	3316.10
7033	7033	2	258	3	2	1	75.75	75.75
7034	7034	2	129	2	1	38	69.50	2625.25
7035	7035	2	316	2	2	67	102.95	6886.25
7036	7036	2	131	1	1	19	78.70	1495.10
7037	7037	3	32	3	1	12	60.65	743.30
7038	7038	6	193	1	1	72	21.15	1419.40
7039	7039	4	241	4	1	24	84.80	1990.50
7040	7040	4	285	2	1	72	103.20	7362.90
7041	7041	2	33	3	1	11	29.60	346.45
7042	7042	2	258	4	2	4	74.40	306.60
7043	7043	6	176	1	1	66	105.65	6844.50
\.


--
-- Name: dim_churn_churn_key_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('legacy.dim_churn_churn_key_seq', 2, true);


--
-- Name: dim_contract_contract_key_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('legacy.dim_contract_contract_key_seq', 6, true);


--
-- Name: dim_customer_customer_key_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('legacy.dim_customer_customer_key_seq', 7043, true);


--
-- Name: dim_payment_payment_key_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('legacy.dim_payment_payment_key_seq', 4, true);


--
-- Name: dim_service_service_key_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('legacy.dim_service_service_key_seq', 322, true);


--
-- Name: fact_customer_churn_fact_key_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('legacy.fact_customer_churn_fact_key_seq', 7043, true);


--
-- Name: dim_churn dim_churn_churn_label_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY legacy.dim_churn
    ADD CONSTRAINT dim_churn_churn_label_key UNIQUE (churn_label);


--
-- Name: dim_churn dim_churn_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY legacy.dim_churn
    ADD CONSTRAINT dim_churn_pkey PRIMARY KEY (churn_key);


--
-- Name: dim_contract dim_contract_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY legacy.dim_contract
    ADD CONSTRAINT dim_contract_pkey PRIMARY KEY (contract_key);


--
-- Name: dim_customer dim_customer_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY legacy.dim_customer
    ADD CONSTRAINT dim_customer_customer_id_key UNIQUE (customer_id);


--
-- Name: dim_customer dim_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY legacy.dim_customer
    ADD CONSTRAINT dim_customer_pkey PRIMARY KEY (customer_key);


--
-- Name: dim_payment dim_payment_payment_method_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY legacy.dim_payment
    ADD CONSTRAINT dim_payment_payment_method_key UNIQUE (payment_method);


--
-- Name: dim_payment dim_payment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY legacy.dim_payment
    ADD CONSTRAINT dim_payment_pkey PRIMARY KEY (payment_key);


--
-- Name: dim_service dim_service_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY legacy.dim_service
    ADD CONSTRAINT dim_service_pkey PRIMARY KEY (service_key);


--
-- Name: fact_customer_churn fact_customer_churn_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY legacy.fact_customer_churn
    ADD CONSTRAINT fact_customer_churn_pkey PRIMARY KEY (fact_key);


--
-- Name: dim_contract uq_contract; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY legacy.dim_contract
    ADD CONSTRAINT uq_contract UNIQUE (contract_type, paperless_billing);


--
-- Name: dim_service uq_service; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY legacy.dim_service
    ADD CONSTRAINT uq_service UNIQUE (phone_service, multiple_lines, internet_service, online_security, online_backup, device_protection, tech_support, streaming_tv, streaming_movies);


--
-- Name: fact_customer_churn fk_churn_key; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY legacy.fact_customer_churn
    ADD CONSTRAINT fk_churn_key FOREIGN KEY (churn_key) REFERENCES legacy.dim_churn(churn_key);


--
-- Name: fact_customer_churn fk_contract_key; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY legacy.fact_customer_churn
    ADD CONSTRAINT fk_contract_key FOREIGN KEY (contract_key) REFERENCES legacy.dim_contract(contract_key);


--
-- Name: fact_customer_churn fk_customer_key; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY legacy.fact_customer_churn
    ADD CONSTRAINT fk_customer_key FOREIGN KEY (customer_key) REFERENCES legacy.dim_customer(customer_key);


--
-- Name: fact_customer_churn fk_payment_key; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY legacy.fact_customer_churn
    ADD CONSTRAINT fk_payment_key FOREIGN KEY (payment_key) REFERENCES legacy.dim_payment(payment_key);


--
-- Name: fact_customer_churn fk_service_key; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY legacy.fact_customer_churn
    ADD CONSTRAINT fk_service_key FOREIGN KEY (service_key) REFERENCES legacy.dim_service(service_key);


--
-- PostgreSQL database dump complete
--

\unrestrict FvZs1MufrmTwq7L7GmWXNgOCaO1EbuDmddi7L8F4SKZ2sLYhY90B3wZh0xbDVbN

